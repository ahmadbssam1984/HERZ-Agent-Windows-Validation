# Invoked by windows-standard-user.ps1 in an ephemeral CI account only.
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$PackageRoot,
    [Parameter(Mandatory = $true)][string]$OutputDirectory
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$watch = [Diagnostics.Stopwatch]::StartNew()
$records = [Collections.Generic.List[object]]::new()
$failed = 0
$incomplete = 0
$PackageRoot = [IO.Path]::GetFullPath($PackageRoot).TrimEnd('\')
$OutputDirectory = [IO.Path]::GetFullPath($OutputDirectory).TrimEnd('\')
[IO.Directory]::CreateDirectory($OutputDirectory) | Out-Null

function Write-Json {
    param([string]$Path, [object]$Value)
    [IO.File]::WriteAllText($Path, ($Value | ConvertTo-Json -Depth 100), [Text.UTF8Encoding]::new($false))
}
function Quote-NativeArgument {
    param([AllowEmptyString()][string]$Value)
    if ($Value.Contains([string][char]0)) { throw 'NUL in argument.' }
    $builder = [Text.StringBuilder]::new()
    [void]$builder.Append('"')
    $slashes = 0
    foreach ($character in $Value.ToCharArray()) {
        if ($character -eq '\') { $slashes++; continue }
        if ($character -eq '"') {
            [void]$builder.Append(('\' * ($slashes * 2 + 1)))
            [void]$builder.Append('"')
        } else {
            [void]$builder.Append(('\' * $slashes))
            [void]$builder.Append($character)
        }
        $slashes = 0
    }
    [void]$builder.Append(('\' * ($slashes * 2)))
    [void]$builder.Append('"')
    return $builder.ToString()
}

function Run-Check {
    param([string]$Name, [string]$Executable, [string[]]$Arguments, [string]$ReportPath, [int]$TimeoutSeconds = 300)
    $timer = [Diagnostics.Stopwatch]::StartNew()
    $process = $null
    $code = $null
    $status = 'failed'
    $reason = $null
    try {
        if (!(Test-Path -LiteralPath $Executable -PathType Leaf)) { throw 'Required Windows test executable is missing.' }
        $start = [Diagnostics.ProcessStartInfo]::new()
        $start.FileName = $Executable
        $start.Arguments = (($Arguments | ForEach-Object { Quote-NativeArgument $_ }) -join ' ')
        $start.WorkingDirectory = $PackageRoot
        $start.UseShellExecute = $false
        $start.CreateNoWindow = $true
        $start.RedirectStandardOutput = $true
        $start.RedirectStandardError = $true
        $start.StandardOutputEncoding = [Text.UTF8Encoding]::new($false)
        $start.StandardErrorEncoding = [Text.UTF8Encoding]::new($false)
        $process = [Diagnostics.Process]::new()
        $process.StartInfo = $start
        if (!$process.Start()) { throw 'Process start returned false.' }
        $stdout = $process.StandardOutput.ReadToEndAsync()
        $stderr = $process.StandardError.ReadToEndAsync()
        if (!$process.WaitForExit($TimeoutSeconds * 1000)) {
            & (Join-Path $env:SystemRoot 'System32\taskkill.exe') /PID $process.Id /T /F 2>$null | Out-Null
            throw 'The managed test process exceeded its timeout.'
        }
        $code = $process.ExitCode
        if (!$stdout.Wait(5000) -or !$stderr.Wait(5000)) { throw 'Test output streams were not closed after process exit.' }
        [IO.File]::WriteAllText((Join-Path $OutputDirectory ($Name + '.stdout.log')), $stdout.Result, [Text.UTF8Encoding]::new($false))
        [IO.File]::WriteAllText((Join-Path $OutputDirectory ($Name + '.stderr.log')), $stderr.Result, [Text.UTF8Encoding]::new($false))
        if (!(Test-Path -LiteralPath $ReportPath -PathType Leaf)) { throw 'The process did not produce its required JSON report.' }
        $report = Get-Content -LiteralPath $ReportPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $propertyNames = @($report.PSObject.Properties.Name)
        $status = switch ($code) { 0 { 'passed' }; 2 { 'incomplete' }; 125 { 'not_executed' }; default { 'failed' } }
        if (($propertyNames -contains 'failed') -and [int]$report.failed -gt 0) { $status = 'failed' }
        if (($propertyNames -contains 'status') -and [string]$report.status -in @('failed', 'not_executed', 'incomplete', 'inconclusive')) { $status = [string]$report.status }
        if ($propertyNames -contains 'results') {
            foreach ($item in @($report.results)) {
                $names = @($item.PSObject.Properties.Name)
                if (($names -contains 'passed' -and $item.passed -eq $false) -or ($names -contains 'status' -and $item.status -eq 'failed')) { $status = 'failed' }
            }
        }
        $destination = Join-Path $OutputDirectory ($Name + '.json')
        if (![IO.Path]::GetFullPath($ReportPath).Equals($destination, [StringComparison]::OrdinalIgnoreCase)) {
            Copy-Item -LiteralPath $ReportPath -Destination $destination
        }
    } catch {
        $reason = $_.Exception.GetType().Name + ': ' + $_.Exception.Message
        $status = 'failed'
    } finally {
        if ($process) {
            try {
                if (!$process.HasExited) { & (Join-Path $env:SystemRoot 'System32\taskkill.exe') /PID $process.Id /T /F 2>$null | Out-Null }
            } catch { }
            $process.Dispose()
        }
    }
    if ($status -eq 'failed') { $script:failed++ }
    if ($status -in @('incomplete', 'not_executed', 'inconclusive')) { $script:incomplete++ }
    $script:records.Add([ordered]@{ name = $Name; status = $status; exitCode = $code; milliseconds = $timer.ElapsedMilliseconds; reason = $reason })
}

$machine = $null
try {
    if ($env:OS -ne 'Windows_NT' -or ![Environment]::Is64BitProcess) { throw 'Actual native Windows x64 is required.' }
    $principal = [Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
    if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Tests must run with an ordinary, non-administrator Windows identity.' }
    $drive = [IO.Path]::GetPathRoot($PackageRoot).TrimEnd('\')
    $volume = Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='" + $drive + "'")
    if ($volume.FileSystem -ne 'NTFS') { throw 'NTFS is required for the Windows access-control checks.' }
    $os = Get-CimInstance Win32_OperatingSystem
    $cpu = @(Get-CimInstance Win32_Processor | Select-Object -ExpandProperty Name)
    $machine = [ordered]@{
        os = $os.Caption; version = $os.Version; build = $os.BuildNumber
        architecture = $env:PROCESSOR_ARCHITECTURE; logicalProcessors = [Environment]::ProcessorCount
        processors = $cpu; visiblePhysicalMemoryKiB = [long]$os.TotalVisibleMemorySize
        availablePhysicalMemoryKiB = [long]$os.FreePhysicalMemory
        administrator = $false; fileSystem = $volume.FileSystem
        packagePathHasArabic = [bool]($PackageRoot -match '[\u0600-\u06FF]')
        packagePathHasSpaceAndAmpersand = $PackageRoot.Contains(' ') -and $PackageRoot.Contains('&')
        exactHomeEnvironment = $false
    }
    $env:PATH = (Join-Path $PackageRoot 'release\tools\node') + ';' + $env:PATH
    $env:DOTNET_CLI_TELEMETRY_OPTOUT = '1'
    $env:DOTNET_CLI_WORKLOAD_UPDATE_NOTIFY_DISABLE = 'true'
    $env:DOTNET_NOLOGO = '1'
    $temp = Join-Path $PackageRoot 'test-temp'
    [IO.Directory]::CreateDirectory($temp) | Out-Null
    $env:TEMP = $temp
    $env:TMP = $temp
    $source = Join-Path $PackageRoot 'source'
    Run-Check -Name 'core' -Executable (Join-Path $PackageRoot 'checks\core\Herz.Tests.exe') -Arguments @($source) -ReportPath (Join-Path $source 'evidence\core-tests.json')
    foreach ($entry in @(
        @{ name = 'native-layout'; exe = 'NativeChecks.exe' },
        @{ name = 'preparation'; exe = 'PreparationChecks.exe' },
        @{ name = 'admission'; exe = 'AdmissionChecks.exe' },
        @{ name = 'startup'; exe = 'StartupChecks.exe' }
    )) {
        $report = Join-Path $OutputDirectory ($entry.name + '.json')
        Run-Check -Name $entry.name -Executable (Join-Path $PackageRoot ('checks\' + $entry.name + '\' + $entry.exe)) -Arguments @($report) -ReportPath $report
    }
    $ui = Join-Path $OutputDirectory 'ui-captures'
    Run-Check -Name 'ui' -Executable (Join-Path $PackageRoot 'checks\ui\UiChecks.exe') -Arguments @('--output', $ui) -ReportPath (Join-Path $ui 'ui-results.json')
    $native = Join-Path $OutputDirectory 'windows.json'
    Run-Check -Name 'windows' -Executable (Join-Path $PackageRoot 'checks\windows\Herz.WindowsAcceptance.exe') -Arguments @('--release', (Join-Path $PackageRoot 'release'), '--report', $native, '--expect-non-admin') -ReportPath $native -TimeoutSeconds 600
} catch {
    $failed++
    $records.Add([ordered]@{ name = 'test-environment'; status = 'failed'; reason = $_.Exception.GetType().Name + ': ' + $_.Exception.Message })
}
$status = if ($failed -gt 0) { 'failed' } elseif ($incomplete -gt 0) { 'incomplete' } else { 'passed' }
$summary = [ordered]@{
    suite = 'C# HERZ Command Center Windows candidate checks'
    status = $status; failedSuites = $failed; incompleteSuites = $incomplete
    executedUtc = [DateTimeOffset]::UtcNow.ToString('O'); elapsedMilliseconds = $watch.ElapsedMilliseconds
    machine = $machine; completeProductAcceptance = $false; exactHomeEnvironmentTested = $false
    modelInferenceTested = $false
    scope = 'Windows Server native checks and actual WinForms control tests; test reports define their coverage. No matching Windows 11 Home or full product acceptance is claimed.'
    results = $records
}
Write-Json -Path (Join-Path $OutputDirectory 'windows-standard-user.json') -Value $summary
if ($failed -gt 0) { exit 1 }
if ($incomplete -gt 0) { exit 2 }
exit 0
