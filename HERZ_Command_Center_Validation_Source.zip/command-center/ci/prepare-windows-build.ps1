# CI preparation only. Never invoke this downloader from the local application.
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if ($env:OS -ne 'Windows_NT' -or !$env:GITHUB_ACTIONS -or $env:GITHUB_ACTIONS -ne 'true') {
    throw 'This preparation script is restricted to the reviewed ephemeral GitHub Windows CI VM.'
}
if ($env:GITHUB_REPOSITORY -ne 'ahmadbssam1984/HERZ-Agent-Windows-Validation') { throw 'Unreviewed repository.' }
$event = Get-Content -LiteralPath $env:GITHUB_EVENT_PATH -Raw | ConvertFrom-Json
if ($event.repository.private -ne $false) { throw 'Only a public repository on the standard runner is permitted.' }
if (![Environment]::Is64BitProcess -or $env:RUNNER_ARCH -ne 'X64') { throw 'Native Windows x64 CI is required.' }
$root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$manifestPath = Join-Path $root 'public-source-manifest.json'
if (!(Test-Path -LiteralPath $manifestPath -PathType Leaf)) { throw 'Reviewed public-source manifest is missing.' }
$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
$properties = @($manifest.PSObject.Properties)
if ($properties.Count -lt 10 -or $properties.Count -gt 5000) { throw 'Invalid public-source manifest.' }
$listed = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($entry in $properties) {
    $relative = [string]$entry.Name
    if ([IO.Path]::IsPathRooted($relative) -or $relative.Split('/') -contains '..' -or $relative.Contains('\') -or $relative.Contains(':')) {
        throw 'Invalid manifest path.'
    }
    $path = [IO.Path]::GetFullPath((Join-Path $root $relative))
    if (!$path.StartsWith($root + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Manifest path escaped source.' }
    $item = Get-Item -LiteralPath $path -Force
    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Manifest entry must be an ordinary file.' }
    if ([string]$entry.Value -notmatch '^[0-9a-f]{64}$' -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.Value) {
        throw ('Reviewed source hash mismatch: ' + $relative)
    }
    if (!$listed.Add($relative)) { throw 'Duplicate manifest path.' }
}
foreach ($entry in (Get-ChildItem -LiteralPath $root -Force -Recurse)) {
    if ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse points are not allowed in the public source.' }
    if ($entry.PSIsContainer) { continue }
    $relative = $entry.FullName.Substring($root.Length + 1).Replace('\', '/')
    if ($relative -ne 'public-source-manifest.json' -and !$listed.Contains($relative)) { throw ('Unreviewed source file: ' + $relative) }
}
$activeWorkflow = Join-Path $env:GITHUB_WORKSPACE '.github\workflows\windows-command-center.yml'
if ((Get-FileHash -LiteralPath $activeWorkflow -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'windows-command-center.yml') -Algorithm SHA256).Hash) {
    throw 'Active workflow differs from the reviewed command-center workflow.'
}

$build = Join-Path $root '.ci-build'
if (Test-Path -LiteralPath $build) { throw 'Build directory already exists; no existing files were overwritten.' }
$downloadRoot = Join-Path $build 'downloads'
$package = Join-Path $build 'package'
$release = Join-Path $package 'release'
$output = Join-Path $root 'ci-results'
foreach ($directory in @($downloadRoot, $package, $release, $output)) { [IO.Directory]::CreateDirectory($directory) | Out-Null }
$plan = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'dependencies-windows.json') -Raw -Encoding UTF8 | ConvertFrom-Json
Write-Output 'Explicit setup download plan: sources, byte sizes, digests, versions and licenses follow.'
$plan | ConvertTo-Json -Depth 6 | Write-Output

function Download-Verified {
    param([object]$Entry, [string]$Name)
    $uri = [Uri]$Entry.url
    if ($uri.Scheme -ne 'https' -or $uri.UserInfo -or $uri.Host -notin @('builds.dotnet.microsoft.com', 'nodejs.org', 'github.com')) { throw 'Unreviewed dependency host.' }
    $path = Join-Path $downloadRoot ($Name + '.zip')
    Invoke-WebRequest -Uri $uri.AbsoluteUri -OutFile $path -MaximumRedirection 5 -TimeoutSec 300
    if ((Get-Item -LiteralPath $path).Length -ne [long]$Entry.bytes) { throw ('Dependency byte count mismatch: ' + $Name) }
    if ((Get-FileHash -LiteralPath $path -Algorithm $Entry.hashAlgorithm).Hash.ToLowerInvariant() -ne $Entry.hash) { throw ('Dependency hash mismatch: ' + $Name) }
    $destination = Join-Path $build $Name
    Expand-Archive -LiteralPath $path -DestinationPath $destination
    return $destination
}

$sdk = Download-Verified -Entry $plan.sdk -Name 'sdk'
$node = Download-Verified -Entry $plan.node -Name 'node'
$llama = Download-Verified -Entry $plan.llama -Name 'llama'
$dotnet = Join-Path $sdk 'dotnet.exe'
$env:DOTNET_ROOT = $sdk
$env:DOTNET_MULTILEVEL_LOOKUP = '0'
$env:DOTNET_CLI_HOME = Join-Path $build 'dotnet-home'
$env:NUGET_PACKAGES = Join-Path $build 'nuget-packages'
$env:DOTNET_CLI_TELEMETRY_OPTOUT = '1'
$env:DOTNET_SKIP_FIRST_TIME_EXPERIENCE = '1'
$env:DOTNET_CLI_WORKLOAD_UPDATE_NOTIFY_DISABLE = 'true'
$env:DOTNET_GENERATE_ASPNET_CERTIFICATE = 'false'
$env:DOTNET_NOLOGO = '1'
$version = (& $dotnet --version | Out-String).Trim()
if ($LASTEXITCODE -ne 0 -or $version -ne '10.0.404') { throw 'The pinned SDK did not start correctly.' }
$nugetConfig = Join-Path $build 'NuGet.Config'
[IO.File]::WriteAllText($nugetConfig, '<?xml version="1.0" encoding="utf-8"?><configuration><packageSources><clear/><add key="nuget.org" value="https://api.nuget.org/v3/index.json"/></packageSources></configuration>', [Text.UTF8Encoding]::new($false))

$projects = @(
    @{ name = 'application'; project = 'src/Herz.Windows/Herz.Windows.csproj'; executable = 'HERZ.exe' },
    @{ name = 'core'; project = 'src/Herz.Tests/Herz.Tests.csproj'; executable = 'Herz.Tests.exe' },
    @{ name = 'native-layout'; project = 'tests/native/NativeChecks.csproj'; executable = 'NativeChecks.exe' },
    @{ name = 'preparation'; project = 'tests/preparation/PreparationChecks.csproj'; executable = 'PreparationChecks.exe' },
    @{ name = 'admission'; project = 'tests/admission/AdmissionChecks.csproj'; executable = 'AdmissionChecks.exe' },
    @{ name = 'startup'; project = 'tests/startup/StartupChecks.csproj'; executable = 'StartupChecks.exe' },
    @{ name = 'ui'; project = 'tests/ui/UiChecks.csproj'; executable = 'UiChecks.exe' },
    @{ name = 'windows'; project = 'tests/windows/WindowsAcceptance.csproj'; executable = 'Herz.WindowsAcceptance.exe' }
)
foreach ($project in $projects) {
    $projectPath = Join-Path $root $project.project
    if (!(Test-Path -LiteralPath $projectPath -PathType Leaf)) { throw ('Required test project is missing: ' + $project.project) }
    $lockFile = Join-Path (Split-Path -Parent $projectPath) 'packages.lock.json'
    if (!(Test-Path -LiteralPath $lockFile -PathType Leaf)) { throw ('Reviewed dependency lock is missing: ' + $project.project) }
    & $dotnet restore $projectPath --locked-mode --configfile $nugetConfig -r win-x64 '-p:RuntimeFrameworkVersion=10.0.15' '-p:SelfContained=true' '-p:NuGetAudit=false' '-p:UseSharedCompilation=false' '-m:1'
    if ($LASTEXITCODE -ne 0) { throw ('Locked restore failed: ' + $project.name) }
    $destination = if ($project.name -eq 'application') { $release } else { Join-Path $package ('checks\' + $project.name) }
    & $dotnet publish $projectPath -c Release -r win-x64 --self-contained true --no-restore '-p:RuntimeFrameworkVersion=10.0.15' '-p:PublishTrimmed=false' '-p:PublishSingleFile=false' '-p:NuGetAudit=false' '-p:UseSharedCompilation=false' '-m:1' -o $destination
    if ($LASTEXITCODE -ne 0 -or !(Test-Path -LiteralPath (Join-Path $destination $project.executable) -PathType Leaf)) { throw ('Windows publish failed: ' + $project.name) }
}

$nodeRoot = Join-Path $node 'node-v24.22.3-win-x64'
$nodeDestination = Join-Path $release 'tools\node'
$llamaDestination = Join-Path $release 'tools\llama'
[IO.Directory]::CreateDirectory($nodeDestination) | Out-Null
[IO.Directory]::CreateDirectory($llamaDestination) | Out-Null
foreach ($name in @('node.exe', 'LICENSE')) { Copy-Item -LiteralPath (Join-Path $nodeRoot $name) -Destination (Join-Path $nodeDestination $name) }
$llamaExecutables = @(Get-ChildItem -LiteralPath $llama -Filter 'llama-completion.exe' -File -Recurse)
if ($llamaExecutables.Count -ne 1) { throw 'Unexpected llama.cpp archive layout.' }
$llamaRoot = $llamaExecutables[0].Directory.FullName
$llamaFiles = @('llama-completion.exe', 'llama-completion-impl.dll', 'llama-common.dll', 'llama.dll', 'ggml.dll', 'ggml-base.dll', 'libomp.dll', 'LICENSE-LLVM-OpenMP')
$llamaFiles += @(Get-ChildItem -LiteralPath $llamaRoot -Filter 'ggml-cpu-*.dll' -File | Select-Object -ExpandProperty Name)
foreach ($name in $llamaFiles) { Copy-Item -LiteralPath (Join-Path $llamaRoot $name) -Destination (Join-Path $llamaDestination $name) }
foreach ($name in @('examples', 'licenses')) { Copy-Item -LiteralPath (Join-Path $root $name) -Destination (Join-Path $release $name) -Recurse }
foreach ($name in @('LICENSE', 'model-selection.json', 'policy-canary.json')) { Copy-Item -LiteralPath (Join-Path $root $name) -Destination (Join-Path $release $name) }
$runtimeManifest = [ordered]@{}
foreach ($file in (Get-ChildItem -LiteralPath $release -File -Recurse | Sort-Object FullName)) {
    $runtimeManifest[$file.FullName.Substring($release.Length + 1).Replace('\', '/')] = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
}
if ($runtimeManifest.Count -lt 20 -or !$runtimeManifest.Contains('HERZ.exe') -or !$runtimeManifest.Contains('HERZ.dll')) { throw 'Incomplete runtime staging.' }
[IO.File]::WriteAllText((Join-Path $release 'release-manifest.json'), ($runtimeManifest | ConvertTo-Json -Depth 5), [Text.UTF8Encoding]::new($false))
$fixtureDestination = Join-Path $package 'source\src\Herz.Tests'
[IO.Directory]::CreateDirectory($fixtureDestination) | Out-Null
Copy-Item -LiteralPath (Join-Path $root 'src\Herz.Tests\fixture_reporter.mjs') -Destination $fixtureDestination
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'windows-test-worker.ps1') -Destination (Join-Path $package 'windows-test-worker.ps1')
$record = [ordered]@{ status = 'built'; sdk = $version; runtime = '10.0.15'; publicSourceManifestSha256 = (Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant(); releaseFiles = $runtimeManifest.Count; modelDownloaded = $false; testsExecuted = $false; completeProductAcceptance = $false }
[IO.File]::WriteAllText((Join-Path $output 'build.json'), ($record | ConvertTo-Json -Depth 5), [Text.UTF8Encoding]::new($false))
Write-Output 'Pinned executables built. Windows tests have not yet run.'
