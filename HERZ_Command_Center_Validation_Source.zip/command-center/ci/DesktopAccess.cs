using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;

// CI-only temporary GUI access for the one generated ordinary test account.
// This helper is never linked into HERZ or used on the user's home computer.
public sealed class HerzCiDesktopAccess : IDisposable
{
    private const uint DaclSecurityInformation = 4;
    private readonly IntPtr station;
    private readonly IntPtr desktop;
    private readonly byte[] oldStation;
    private readonly byte[] oldDesktop;
    private bool disposed;

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr GetProcessWindowStation();
    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr GetThreadDesktop(uint threadId);
    [DllImport("kernel32.dll")]
    private static extern uint GetCurrentThreadId();
    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetUserObjectSecurity(IntPtr handle, ref uint information, byte[] securityDescriptor, uint length, out uint needed);
    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetUserObjectSecurity(IntPtr handle, ref uint information, byte[] securityDescriptor);

    public static HerzCiDesktopAccess Grant(string sid)
    {
        if (Environment.OSVersion.Platform != PlatformID.Win32NT ||
            Environment.GetEnvironmentVariable("GITHUB_ACTIONS") != "true" ||
            Environment.GetEnvironmentVariable("GITHUB_REPOSITORY") != "ahmadbssam1984/HERZ-Agent-Windows-Validation")
            throw new InvalidOperationException("Desktop ACL setup is restricted to the reviewed ephemeral Windows CI VM.");
        return new HerzCiDesktopAccess(new SecurityIdentifier(sid));
    }

    private HerzCiDesktopAccess(SecurityIdentifier sid)
    {
        // Both handles are borrowed from this process/thread, not closed here.
        station = GetProcessWindowStation();
        desktop = GetThreadDesktop(GetCurrentThreadId());
        if (station == IntPtr.Zero || desktop == IntPtr.Zero)
            throw new Win32Exception(Marshal.GetLastWin32Error(), "CI window station or desktop is unavailable.");
        oldStation = Read(station);
        oldDesktop = Read(desktop);
        try
        {
            // Window-station GUI rights + READ_CONTROL, never WRITE_DAC/OWNER.
            Write(station, AddAllow(oldStation, sid, 0x0002033f));
            // READOBJECTS, CREATEWINDOW, CREATEMENU, ENUMERATE, WRITEOBJECTS.
            // No hooks, journal recording/playback, or desktop switching.
            Write(desktop, AddAllow(oldDesktop, sid, 0x000200c7));
        }
        catch
        {
            Write(station, oldStation);
            throw;
        }
    }

    private static byte[] Read(IntPtr handle)
    {
        uint information = DaclSecurityInformation, needed;
        GetUserObjectSecurity(handle, ref information, null, 0, out needed);
        if (needed == 0 || needed > 1024 * 1024)
            throw new Win32Exception(Marshal.GetLastWin32Error(), "Cannot read CI desktop security descriptor.");
        byte[] buffer = new byte[needed];
        if (!GetUserObjectSecurity(handle, ref information, buffer, (uint)buffer.Length, out needed))
            throw new Win32Exception(Marshal.GetLastWin32Error());
        return buffer;
    }

    private static byte[] AddAllow(byte[] original, SecurityIdentifier sid, int mask)
    {
        RawSecurityDescriptor descriptor = new RawSecurityDescriptor(original, 0);
        RawAcl acl = descriptor.DiscretionaryAcl;
        if (acl == null)
            throw new InvalidOperationException("CI desktop has no explicit DACL; refusing an unreviewed security change.");
        int index = 0;
        while (index < acl.Count)
        {
            QualifiedAce ace = acl[index] as QualifiedAce;
            if (ace == null || ace.IsInherited || ace.AceQualifier != AceQualifier.AccessDenied) break;
            index++;
        }
        acl.InsertAce(index, new CommonAce(AceFlags.None, AceQualifier.AccessAllowed, mask, sid, false, null));
        byte[] result = new byte[descriptor.BinaryLength];
        descriptor.GetBinaryForm(result, 0);
        return result;
    }

    private static void Write(IntPtr handle, byte[] descriptor)
    {
        uint information = DaclSecurityInformation;
        if (!SetUserObjectSecurity(handle, ref information, descriptor))
            throw new Win32Exception(Marshal.GetLastWin32Error(), "Cannot apply or restore CI desktop DACL.");
    }

    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        try { Write(desktop, oldDesktop); }
        finally { Write(station, oldStation); }
    }
}
