# Account creation is restricted to an ephemeral hosted CI VM, never the home PC.
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$PackageRoot,
    [Parameter(Mandatory = $true)][string]$OutputDirectory,
    [ValidateRange(3, 25)][int]$TimeoutMinutes = 20
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if ($env:OS -ne 'Windows_NT' -or $env:GITHUB_ACTIONS -ne 'true' -or $env:GITHUB_REPOSITORY -ne 'ahmadbssam1984/HERZ-Agent-Windows-Validation') {
    throw 'This account-creation harness is restricted to the reviewed ephemeral GitHub Windows CI VM.'
}
$event = Get-Content -LiteralPath $env:GITHUB_EVENT_PATH -Raw | ConvertFrom-Json
if ($event.repository.private -ne $false) { throw 'Private repository execution is not permitted.' }
$principal = [Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
if (!$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'The ephemeral CI setup identity needs permission to create its temporary ordinary test user.'
}
$PackageRoot = (Resolve-Path -LiteralPath $PackageRoot).Path.TrimEnd('\')
$OutputDirectory = [IO.Path]::GetFullPath($OutputDirectory).TrimEnd('\')
if ($PackageRoot.Contains('"') -or $OutputDirectory.Contains('"')) { throw 'Invalid path.' }
if (!(Test-Path -LiteralPath (Join-Path $PackageRoot 'windows-test-worker.ps1') -PathType Leaf)) { throw 'The reviewed Windows test worker is missing.' }
if ((Get-Item -LiteralPath $PackageRoot -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'A package root reparse point is not permitted.' }
[IO.Directory]::CreateDirectory($OutputDirectory) | Out-Null

$suffix = [Guid]::NewGuid().ToString('N').Substring(0, 10)
$userName = 'herzci' + $suffix
$systemDrive = [IO.Path]::GetPathRoot($env:SystemRoot).TrimEnd('\')
$volume = Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='" + $systemDrive + "'")
if ($systemDrive -ne 'C:' -or $volume.FileSystem -ne 'NTFS') { throw 'These checks require the C: NTFS volume; no substitute file system is accepted.' }
$caseRoot = Join-Path ($systemDrive + '\Users\Public') ('HERZ-Command-Center-CI-' + $suffix)
$arabic = -join @([char]0x062D, [char]0x0632, [char]0x0645, [char]0x0629)
$casePackage = Join-Path $caseRoot ($arabic + ' package & spaces')
$caseOutput = Join-Path $caseRoot 'reports'
$stdoutPath = Join-Path $caseRoot 'worker.stdout.log'
$stderrPath = Join-Path $caseRoot 'worker.stderr.log'
$userCreated = $false
$process = $null
$credential = $null
$securePassword = $null
$desktopAccess = $null
$exitCode = 1

function Copy-OrdinaryTree {
    param([string]$Source, [string]$Destination)
    $item = Get-Item -LiteralPath $Source -Force
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse points are not permitted in the disposable test package.' }
    if ($item.PSIsContainer) {
        [IO.Directory]::CreateDirectory($Destination) | Out-Null
        foreach ($child in (Get-ChildItem -LiteralPath $Source -Force)) {
            Copy-OrdinaryTree -Source $child.FullName -Destination (Join-Path $Destination $child.Name)
        }
    } else {
        [IO.File]::Copy($item.FullName, $Destination, $false)
    }
}
function Save-SanitizedJson {
    param([string]$Source, [string]$Destination)
    $text = Get-Content -LiteralPath $Source -Raw -Encoding UTF8
    $null = $text | ConvertFrom-Json
    foreach ($replacement in @(
        @{ path = $casePackage; label = '%CI_PACKAGE%' },
        @{ path = $caseRoot; label = '%CI_CASE%' },
        @{ path = ($systemDrive + '\Users\' + $userName); label = '%CI_USERPROFILE%' }
    )) {
        $encoded = ConvertTo-Json -InputObject $replacement.path -Compress
        $needle = $encoded.Substring(1, $encoded.Length - 2)
        $text = $text.Replace($needle, $replacement.label)
    }
    [IO.File]::WriteAllText($Destination, $text, [Text.UTF8Encoding]::new($false))
}

try {
    $randomBytes = New-Object byte[] 40
    $generator = [Security.Cryptography.RandomNumberGenerator]::Create()
    $generator.GetBytes($randomBytes)
    $generator.Dispose()
    $plainPassword = 'Aa1!' + [Convert]::ToBase64String($randomBytes)
    $securePassword = ConvertTo-SecureString -String $plainPassword -AsPlainText -Force
    $plainPassword = $null
    [Array]::Clear($randomBytes, 0, $randomBytes.Length)
    New-LocalUser -Name $userName -Password $securePassword -AccountNeverExpires -PasswordNeverExpires -UserMayNotChangePassword -Description 'Temporary HERZ C# ordinary-user acceptance account' | Out-Null
    $userCreated = $true
    $localUser = Get-LocalUser -Name $userName
    $users = Get-LocalGroup -SID 'S-1-5-32-545'
    if (!(Get-LocalGroupMember -Group $users | Where-Object { $_.SID -eq $localUser.SID })) { Add-LocalGroupMember -Group $users -Member $localUser }
    $administrators = Get-LocalGroup -SID 'S-1-5-32-544'
    if (Get-LocalGroupMember -Group $administrators | Where-Object { $_.SID -eq $localUser.SID }) { throw 'The test account unexpectedly belongs to Administrators.' }
    [IO.Directory]::CreateDirectory($caseRoot) | Out-Null
    $acl = [Security.AccessControl.DirectorySecurity]::new()
    $acl.SetAccessRuleProtection($true, $false)
    foreach ($sidText in @($localUser.SID.Value, 'S-1-5-32-544', 'S-1-5-18')) {
        $sid = [Security.Principal.SecurityIdentifier]::new($sidText)
        $acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($sid, 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow'))
    }
    Set-Acl -LiteralPath $caseRoot -AclObject $acl
    Add-Type -Path (Join-Path $PSScriptRoot 'DesktopAccess.cs')
    $desktopAccess = [HerzCiDesktopAccess]::Grant($localUser.SID.Value)
    Copy-OrdinaryTree -Source $PackageRoot -Destination $casePackage
    [IO.Directory]::CreateDirectory($caseOutput) | Out-Null
    $credential = [PSCredential]::new(('.\' + $userName), $securePassword)
    $powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $worker = Join-Path $casePackage 'windows-test-worker.ps1'
    # Generated paths contain no quotes and do not end in a backslash. Passing
    # them as quoted native arguments preserves Arabic, ampersands and spaces.
    $arguments = '-NoLogo -NoProfile -NonInteractive -File "' + $worker + '" -PackageRoot "' + $casePackage + '" -OutputDirectory "' + $caseOutput + '"'
    $process = Start-Process -FilePath $powershell -ArgumentList $arguments -Credential $credential -LoadUserProfile -UseNewEnvironment -WorkingDirectory $casePackage -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath -PassThru
    if (!$process.WaitForExit($TimeoutMinutes * 60000)) {
        & (Join-Path $env:SystemRoot 'System32\taskkill.exe') /PID $process.Id /T /F 2>$null | Out-Null
        throw 'Ordinary-user Windows checks exceeded their timeout.'
    }
    $process.WaitForExit()
    $process.Refresh()
    $exitCode = $process.ExitCode
    if ($null -eq $exitCode) { throw 'The Windows worker exited without an observable exit code.' }
    $summaryPath = Join-Path $caseOutput 'windows-standard-user.json'
    if (!(Test-Path -LiteralPath $summaryPath -PathType Leaf)) { throw 'Windows worker exited without a result report.' }
    $summary = Get-Content -LiteralPath $summaryPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($null -eq $summary.machine -or $summary.machine.administrator -ne $false) { throw 'The result did not prove an ordinary Windows test identity.' }
    if ($summary.machine.packagePathHasArabic -ne $true -or $summary.machine.packagePathHasSpaceAndAmpersand -ne $true -or $summary.machine.fileSystem -ne 'NTFS') {
        throw 'The required NTFS and Arabic/space/ampersand path fixture was not exercised.'
    }
    if ($summary.completeProductAcceptance -ne $false -or $summary.exactHomeEnvironmentTested -ne $false) { throw 'Candidate checks must not claim full or identical-home acceptance.' }
    if ($summary.status -eq 'failed' -and $exitCode -eq 0) { $exitCode = 1 }
    if ($summary.status -eq 'incomplete' -and $exitCode -eq 0) { $exitCode = 2 }
    Write-Output ('Actual Windows ordinary-user checks: ' + $summary.status + '. Windows Server evidence only; no complete product acceptance is claimed.')
} catch {
    $exitCode = 1
    $failure = [ordered]@{ status = 'failed'; suite = 'Windows ordinary-user CI harness'; reason = $_.Exception.GetType().Name + ': ' + $_.Exception.Message; completeProductAcceptance = $false; exactHomeEnvironmentTested = $false }
    [IO.File]::WriteAllText((Join-Path $OutputDirectory 'windows-harness-error.json'), ($failure | ConvertTo-Json -Depth 6), [Text.UTF8Encoding]::new($false))
} finally {
    if (Test-Path -LiteralPath $caseOutput) {
        foreach ($file in (Get-ChildItem -LiteralPath $caseOutput -Filter '*.json' -File)) {
            try { Save-SanitizedJson -Source $file.FullName -Destination (Join-Path $OutputDirectory $file.Name) } catch { $exitCode = 1 }
        }
        $images = @()
        $retained = 0
        $captureDirectory = Join-Path $caseOutput 'ui-captures'
        if (Test-Path -LiteralPath $captureDirectory) {
            foreach ($file in (Get-ChildItem -LiteralPath $captureDirectory -Filter '*.png' -File | Sort-Object Name)) {
                $hash = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
                $inLog = $false
                if ($retained -lt 4 -and $file.Length -le 1MB -and $file.Length -ge 8 -and $file.Name -match '^[A-Za-z0-9_.-]+\.png$') {
                    $bytes = [IO.File]::ReadAllBytes($file.FullName)
                    if ([BitConverter]::ToString($bytes, 0, 8) -eq '89-50-4E-47-0D-0A-1A-0A') {
                        $encoded = [Convert]::ToBase64String($bytes)
                        Write-Output ('HERZ_UI_PNG_BEGIN ' + $file.Name + ' ' + $hash + ' ' + $file.Length)
                        for ($offset = 0; $offset -lt $encoded.Length; $offset += 120) {
                            Write-Output ('HERZ_UI_PNG_DATA ' + $encoded.Substring($offset, [Math]::Min(120, $encoded.Length - $offset)))
                        }
                        Write-Output ('HERZ_UI_PNG_END ' + $file.Name)
                        $retained++
                        $inLog = $true
                    }
                }
                $images += [ordered]@{ name = $file.Name; bytes = $file.Length; sha256 = $hash; retainedInWorkflowLog = $inLog }
            }
        }
        $imageRecord = [ordered]@{ generated = $images.Count; uploadedAsArtifact = $false; imagesInWorkflowLogs = $retained; retainedAfterVm = $(if ($retained -gt 0) { 'in_workflow_logs' } else { 'not_retained' }); actualDesktopScreenshot = $false; captureMethod = 'WinForms.DrawToBitmap'; images = $images }
        [IO.File]::WriteAllText((Join-Path $OutputDirectory 'ui-capture-index.json'), ($imageRecord | ConvertTo-Json -Depth 6), [Text.UTF8Encoding]::new($false))
    }
    if ($process) {
        try { if (!$process.HasExited) { & (Join-Path $env:SystemRoot 'System32\taskkill.exe') /PID $process.Id /T /F 2>$null | Out-Null } } catch { }
    }
    # Only executables inside this unique disposable package are eligible.
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
        $_.ExecutablePath -and $_.ExecutablePath.StartsWith($casePackage + '\', [StringComparison]::OrdinalIgnoreCase)
    } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    if ($desktopAccess) {
        try { $desktopAccess.Dispose() } catch {
            $exitCode = 1
            $cleanup = [ordered]@{ status = 'failed'; suite = 'CI desktop DACL restoration'; reason = $_.Exception.GetType().Name; completeProductAcceptance = $false }
            [IO.File]::WriteAllText((Join-Path $OutputDirectory 'desktop-cleanup-error.json'), ($cleanup | ConvertTo-Json), [Text.UTF8Encoding]::new($false))
        }
    }
    if ($userCreated) { Remove-LocalUser -Name $userName -ErrorAction SilentlyContinue }
    if (Test-Path -LiteralPath $caseRoot) { Remove-Item -LiteralPath $caseRoot -Recurse -Force -ErrorAction SilentlyContinue }
    $credential = $null
    $securePassword = $null
}
exit $exitCode
