// MIT License; see LICENSE. Algorithm/protocol reference for the built-in worker.
// Production dispatch is compiled in Herz.Windows.WorkerHost.Stats. This source
// is not dynamically compiled or executed when a manifest is registered.
using System.Text.Json;
using System.Text.Json.Nodes;
using Herz.Core;

namespace Herz.ConnectorExamples;
public static class BuiltinStats
{
    public static AgentExecution Execute(JsonObject input, string workspace, CancellationToken token)
    {
        decimal[] numbers = input["numbers"]?.AsArray().Select(value => value!.GetValue<decimal>()).ToArray() ?? throw new PolicyException("Numbers are required.");
        if (numbers.Length is < 1 or > 200 || numbers.Any(value => Math.Abs(value) > 1000000000m))
            throw new PolicyException("Expected 1–200 values within ±1,000,000,000.");
        token.ThrowIfCancellationRequested();
        decimal sum = numbers.Sum();
        var result = new JsonObject
        {
            ["count"] = numbers.Length,
            ["sum"] = sum,
            ["mean"] = sum / numbers.Length,
            ["min"] = numbers.Min(),
            ["max"] = numbers.Max(),
            ["numbers"] = new JsonArray(numbers.Select(value => (JsonNode? )JsonValue.Create(value)).ToArray())
        };
        string target = Path.Combine(workspace, "stats.json");
        using (var file = new FileStream(target, FileMode.CreateNew, FileAccess.Write, FileShare.None))
        {
            JsonSerializer.Serialize(file, result);
            file.Flush(true);
        }

        return new AgentExecution(0, result, ["stats.json"]);
    }
}
