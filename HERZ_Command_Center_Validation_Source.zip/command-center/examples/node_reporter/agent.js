/* HERZ Node report agent, MIT. Offline stdin/stdout contract. */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const chunks=[]; let size=0;
process.stdin.on('data', b=>{size+=b.length; if(size>1024*1024){process.stderr.write('Input too large');process.exit(2);}chunks.push(b);});
process.stdin.on('end',()=>{
 try {
  const context=JSON.parse(Buffer.concat(chunks).toString('utf8'));
  const files=context.inputs||[];
  const item=files.find(x=>path.basename(x.fullPath||'')==='stats.json');
  const stats=item ? JSON.parse(fs.readFileSync(item.fullPath,'utf8')) : context.input.stats;
  if(!stats||![stats.sum,stats.mean,stats.count].every(Number.isFinite))throw Error('Verified numeric analysis is required');
  const title=String(context.input.title||'تقرير التحليل المحلي');
  const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const html='<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'"><title>'+esc(title)+'</title><style>body{font:18px Segoe UI,Tahoma,sans-serif;max-width:800px;margin:40px auto;color:#123344;padding:24px}h1{color:#176b56}table{border-collapse:collapse;width:100%}th,td{border:1px solid #cbd5e1;padding:14px;text-align:right}</style><h1>'+esc(title)+'</h1><p>نتيجة تعاون وكيل التحليل ووكيل التقرير على الجهاز.</p><table><tr><th>المؤشر</th><th>القيمة</th></tr>'+[['عدد القيم',stats.count],['المجموع',stats.sum],['المتوسط',stats.mean],['الأصغر',stats.min],['الأكبر',stats.max]].map(([k,v])=>'<tr><td>'+esc(k)+'</td><td>'+esc(v)+'</td></tr>').join('')+'</table><p>تم التحقق من القيم آليًا قبل إنتاج الملف.</p></html>';
  fs.writeFileSync(path.join(context.workspace,'report.html'),html,{encoding:'utf8',flag:'wx'});
  process.stdout.write(JSON.stringify({result:{title,count:stats.count,sum:stats.sum,mean:stats.mean},artifacts:['report.html']}));
 } catch(e){process.stderr.write(String(e.message));process.exitCode=2;}
});
