using System.IO.Pipes;
using System.Text;
using System.Text.Json;
using Herz.Windows;

var results = new List<object>();
int failed = 0;
void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
async Task Test(string name, Func<Task> action)
{
    try { await action(); results.Add(new { name, status = "passed" }); Console.WriteLine("PASS " + name); }
    catch (Exception e) { failed++; results.Add(new { name, status = "failed", error = e.GetType().Name + ": " + e.Message }); Console.WriteLine("FAIL " + name + ": " + e.Message); }
}
void Reject(Action action)
{
    try { action(); } catch (InvalidDataException) { return; }
    throw new InvalidOperationException("An invalid authorization was accepted.");
}
string nonce = StartupProtocol.CreateNonce();
const int pid = 12345;
string Frame(bool allow, string? key = null, int process = pid, string type = "startup-commit") => StartupProtocol.Encode(new StartupProtocol.Commit(type, process, key ?? nonce, allow));

await Test("valid_commit_requires_successful_manager_proof", () =>
{
    Require(StartupProtocol.ValidateCommit(Frame(true), pid, nonce, true), "Valid authorization was rejected.");
    Require(!StartupProtocol.ValidateCommit(Frame(true), pid, nonce, false), "Failed proof became allowed.");
    Require(!StartupProtocol.ValidateCommit(Frame(false), pid, nonce, true), "Launcher denial became allowed.");
    return Task.CompletedTask;
});
await Test("replayed_or_wrong_process_commit_rejected", () =>
{
    Reject(() => StartupProtocol.ValidateCommit(Frame(true, StartupProtocol.CreateNonce()), pid, nonce, true));
    Reject(() => StartupProtocol.ValidateCommit(Frame(true, process: pid + 1), pid, nonce, true));
    Reject(() => StartupProtocol.ValidateCommit(Frame(true, type: "worker-result"), pid, nonce, true));
    Reject(() => StartupProtocol.ValidateCommit(Frame(true, key: ""), pid, nonce, true));
    return Task.CompletedTask;
});
await Test("startup_probe_and_readiness_bound_to_same_session", () =>
{
    var p = StartupProtocol.ValidateProbe(StartupProtocol.Encode(new StartupProtocol.Probe("manager-probed", pid, nonce, true)), pid);
    StartupProtocol.ValidateReady(StartupProtocol.Encode(new StartupProtocol.Ready("manager-ready", pid, nonce, false)), p, false);
    Reject(() => StartupProtocol.ValidateReady(StartupProtocol.Encode(new StartupProtocol.Ready("manager-ready", pid, nonce, true)), p, false));
    Reject(() => StartupProtocol.ValidateProbe(StartupProtocol.Encode(new StartupProtocol.Probe("manager-probed", pid + 1, nonce, true)), pid));
    return Task.CompletedTask;
});
await Test("real_anonymous_pipe_cannot_authorize_before_parent_writes", async () =>
{
    using var pipe = new AnonymousPipeServerStream(PipeDirection.Out, HandleInheritability.None);
    using var client = new AnonymousPipeClientStream(PipeDirection.In, pipe.ClientSafePipeHandle);
    using var input = new StreamReader(client, new UTF8Encoding(false, true));
    using var writer = new StreamWriter(pipe, new UTF8Encoding(false)) { AutoFlush = true };
    var waiting = StartupProtocol.ReadLineAsync(input, TimeSpan.FromSeconds(3));
    await Task.Delay(20);
    Require(!waiting.IsCompleted, "Startup advanced without parent authorization.");
    await writer.WriteLineAsync(Frame(true));
    Require(StartupProtocol.ValidateCommit(await waiting, pid, nonce, true), "Pipe authorization failed.");
});
await Test("closed_parent_pipe_is_not_authorization", async () =>
{
    try { await StartupProtocol.ReadLineAsync(new StringReader(""), TimeSpan.FromSeconds(1)); }
    catch (EndOfStreamException) { return; }
    throw new InvalidOperationException("EOF granted startup.");
});
await Test("oversized_frame_is_rejected_before_json_parse", async () =>
{
    try { await StartupProtocol.ReadLineAsync(new StringReader(new string('x', StartupProtocol.MaximumMessageCharacters + 1) + "\n"), TimeSpan.FromSeconds(1)); }
    catch (InvalidDataException) { return; }
    throw new InvalidOperationException("Oversized frame accepted.");
});
await Test("silent_parent_times_out_without_authorizing", async () =>
{
    using var pipe = new AnonymousPipeServerStream(PipeDirection.Out, HandleInheritability.None);
    using var client = new AnonymousPipeClientStream(PipeDirection.In, pipe.ClientSafePipeHandle);
    using var input = new StreamReader(client, new UTF8Encoding(false, true));
    try { await StartupProtocol.ReadLineAsync(input, TimeSpan.FromMilliseconds(80)); }
    catch (OperationCanceledException) { return; }
    throw new InvalidOperationException("Silent parent did not time out.");
});
await Test("cancellation_closes_admission", async () =>
{
    using var canceled = new CancellationTokenSource(); canceled.Cancel();
    try { await StartupProtocol.ReadLineAsync(new StringReader(Frame(true) + "\n"), TimeSpan.FromSeconds(1), canceled.Token); }
    catch (OperationCanceledException) { return; }
    throw new InvalidOperationException("A canceled launch was accepted.");
});
var report = new
{
    suite = "Actual production startup authorization protocol",
    executedUtc = DateTimeOffset.UtcNow,
    os = System.Runtime.InteropServices.RuntimeInformation.OSDescription,
    passed = results.Count - failed, failed, results,
    nativeAppContainerTested = false,
    note = "Managed protocol and real inherited-pipe primitives only; no Windows isolation or GUI proof."
};
string output = args.Length > 0 ? Path.GetFullPath(args[0]) : Path.Combine(AppContext.BaseDirectory, "startup-checks.json");
Directory.CreateDirectory(Path.GetDirectoryName(output)!);
File.WriteAllText(output, JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"TOTAL {results.Count - failed} passed, {failed} failed");
return failed == 0 ? 0 : 1;
