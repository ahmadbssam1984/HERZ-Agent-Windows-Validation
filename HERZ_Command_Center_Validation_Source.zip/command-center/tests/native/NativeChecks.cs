using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.Json;
using Herz.Windows;

// This neutral-runtime suite tests layouts, input encoding, and managed stream
// ownership. It never treats compilation or fixture tokens as native containment.
var results = new List<object>();
int passed = 0, failed = 0, skipped = 0;
void Test(string name, Action action)
{
    try
    {
        action();
        results.Add(new { name, status = "passed" });
        passed++;
        Console.WriteLine("PASS " + name);
    }
    catch (Exception ex)
    {
        results.Add(new { name, status = "failed", error = ex.GetType().Name + ": " + ex.Message });
        failed++;
        Console.WriteLine("FAIL " + name + ": " + ex.Message);
    }
}

void Require(bool value, string message)
{
    if (!value)
        throw new Exception(message);
}

var native = typeof(NativeSandbox);
foreach (var pair in new Dictionary<string, int>
{
    {
        "SecurityAttributes",
        24
    },
    {
        "SidAndAttributes",
        16
    },
    {
        "SecurityCapabilities",
        24
    },
    {
        "StartupInfo",
        104
    },
    {
        "StartupInfoEx",
        112
    },
    {
        "ProcessInformation",
        24
    },
    {
        "JobBasicLimitInformation",
        64
    },
    {
        "IoCounters",
        48
    },
    {
        "JobExtendedLimitInformation",
        144
    },
    {
        "JobCpuRateControlInformation",
        8
    },
    {
        "JobBasicAccountingInformation",
        48
    }
}

)
{
    var current = pair;
    Test("x64 ABI " + current.Key, () =>
    {
        Require(Environment.Is64BitProcess, "This ABI suite requires an x64 process.");
        Require(Marshal.SizeOf(native.GetNestedType(current.Key, BindingFlags.NonPublic)!) == current.Value, "Win32 x64 structure size mismatch.");
    });
}

Test("empty argv", () => Require(NativeSandbox.QuoteArgument("") == "\"\"", "Empty argument not preserved."));
Test("spaces argv", () => Require(NativeSandbox.QuoteArgument("a b") == "\"a b\"", "Whitespace escaped incorrectly."));
Test("Unicode argv", () => Require(NativeSandbox.QuoteArgument("العربية") == "\"العربية\"", "Unicode text changed."));
Test("embedded quote argv", () => Require(NativeSandbox.QuoteArgument("a\"b") == "\"a\\\"b\"", "Literal quote escaped incorrectly."));
Test("trailing slash argv", () => Require(NativeSandbox.QuoteArgument("C:\\x\\") == "\"C:\\x\\\\\"", "Trailing backslash escaped incorrectly."));
Test("NUL rejected", () =>
{
    try
    {
        NativeSandbox.QuoteArgument("x\0y");
    }
    catch (ArgumentException)
    {
        return;
    }

    throw new Exception("NUL was accepted.");
});
if (!OperatingSystem.IsWindows())
    Test("non-Windows token query refused before P/Invoke", () =>
    {
        try
        {
            NativeSandbox.GetCurrentTokenInfo();
        }
        catch (PlatformNotSupportedException)
        {
            return;
        }

        throw new Exception("Wrong platform was not explicitly refused.");
    });
else
{
    skipped++;
    results.Add(new { name = "non-Windows token query refused before P/Invoke", status = "skipped", reason = "This negative platform test specifically requires non-Windows." });
}

Test("closing StandardInput closes the production input stream", () =>
{
    string directory = Path.Combine(Path.GetTempPath(), "herz-native-fixture-" + Guid.NewGuid().ToString("N"));
    Directory.CreateDirectory(directory);
    try
    {
        string a = Path.Combine(directory, "in"), b = Path.Combine(directory, "out"), c = Path.Combine(directory, "err");
        File.WriteAllText(a, "");
        File.WriteAllText(b, "");
        File.WriteAllText(c, "");
        using var ih = File.OpenHandle(a, FileMode.Open, FileAccess.Write);
        using var oh = File.OpenHandle(b, FileMode.Open, FileAccess.Read);
        using var eh = File.OpenHandle(c, FileMode.Open, FileAccess.Read);
        IntPtr input = ih.DangerousGetHandle(), output = oh.DangerousGetHandle(), error = eh.DangerousGetHandle();
        ih.SetHandleAsInvalid();
        oh.SetHandleAsInvalid();
        eh.SetHandleAsInvalid();
        // Ordinary temporary-file handles exercise actual constructor/stream ownership.
        // Zero process/job handles and a fixture record do NOT represent a real sandbox.
        using var process = new SandboxProcess(0, IntPtr.Zero, IntPtr.Zero, input, output, error, new TokenVerificationInfo(false, false, null, false, 0, "fixture"));
        process.StandardInput.Write("test");
        process.StandardInput.Close();
        Require(!process.InputStream.CanWrite, "StandardInput.Close left the underlying input open; pipe EOF would not be delivered.");
    }
    finally
    {
        Directory.Delete(directory, true);
    }
});
var evidence = new
{
    suite = "Native layout, argument and managed stream ownership checks",
    executedUtc = DateTimeOffset.UtcNow.ToString("O"),
    os = RuntimeInformation.OSDescription,
    architecture = RuntimeInformation.ProcessArchitecture.ToString(),
    runtime = Environment.Version.ToString(),
    passed,
    failed,
    skipped,
    nativeWindowsExecution = false,
    appContainerCreated = false,
    networkIsolationTested = false,
    filesystemAclApplied = false,
    limitations = "ABI/quoting checks are not Windows execution. Stream ownership uses ordinary temporary-file handles. No profile, ACL, Job or Windows token success is fabricated.",
    results
};
string outputPath = args.Length == 1 ? Path.GetFullPath(args[0]) : Path.Combine(AppContext.BaseDirectory, "results.json");
Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
File.WriteAllText(outputPath, JsonSerializer.Serialize(evidence, new JsonSerializerOptions { WriteIndented = true }) + "\n");
Console.WriteLine($"TOTAL {passed} passed, {failed} failed, {skipped} skipped; native Windows execution NOT performed");
return failed == 0 ? 0 : 1;
