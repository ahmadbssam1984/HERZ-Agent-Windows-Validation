using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text.Json;
using Herz.Windows;

// These are decision/regression inputs, NOT measured Windows security results.
// No socket is opened and no Windows native function is invoked by this runner.
var results = new List<TestResult>();
var elapsed = Stopwatch.StartNew();
void Check(string name, Action assertion)
{
    var timer = Stopwatch.StartNew();
    try
    {
        assertion();
        results.Add(new(name, true, timer.Elapsed.TotalMilliseconds, null));
    }
    catch (Exception e)
    { results.Add(new(name, false, timer.Elapsed.TotalMilliseconds, e.Message)); }
}
void Require(bool condition, string message)
{
    if (!condition) throw new InvalidOperationException(message);
}
List<SandboxProbeResult> CompleteDenialFixture()
{
    var list = new List<SandboxProbeResult> { new("token", "verified", null, "Synthetic regression fixture, not OS evidence") };
    foreach (string kind in NetworkAdmission.RequiredChecks)
        list.Add(new(kind, "denied", kind.StartsWith("dns-api-", StringComparison.Ordinal) ||
            kind.Contains("file-", StringComparison.Ordinal) || kind.Contains("write-", StringComparison.Ordinal)
                ? 5 : 10013, "Synthetic regression fixture, not OS evidence"));
    return list;
}

const string appSid = "S-1-15-2-123-456-789-123-456-789-123";
var tokenFixture = new TokenVerificationInfo(true, false, appSid, false, 0, "S-1-16-4096");
Check("Expected zero-capability low-integrity AppContainer token fixture is accepted", () =>
    Require(NetworkAdmission.TokenValid(tokenFixture, appSid), "Valid low-integrity token fixture rejected"));
foreach (var invalid in new[]
{
    ("not AppContainer", tokenFixture with { IsAppContainer = false }),
    ("network capabilities", tokenFixture with { HasNetworkCapabilities = true }),
    ("unexpected capability count", tokenFixture with { CapabilityCount = 1 }),
    ("elevated", tokenFixture with { Elevated = true }),
    ("wrong AppContainer SID", tokenFixture with { AppContainerSid = appSid + "-1" }),
    ("missing AppContainer SID", tokenFixture with { AppContainerSid = null }),
    ("medium integrity", tokenFixture with { IntegritySid = "S-1-16-8192" }),
    ("high integrity", tokenFixture with { IntegritySid = "S-1-16-12288" }),
    ("untrusted integrity", tokenFixture with { IntegritySid = "S-1-16-0" })
})
    Check("Invalid token cannot pass admission: " + invalid.Item1, () =>
        Require(!NetworkAdmission.TokenValid(invalid.Item2, appSid), "Invalid token accepted: " + invalid.Item1));
Check("Missing expected identity cannot match an empty token SID", () =>
{
    Require(!NetworkAdmission.TokenValid(tokenFixture with { AppContainerSid = "" }, ""), "Empty expected SID accepted");
    Require(!NetworkAdmission.TokenValid(tokenFixture with { AppContainerSid = null }, null), "Null expected SID accepted");
});

Check("Complete explicit-denial decision fixture is accepted, without claiming a Windows test", () =>
    Require(NetworkAdmission.Evaluate(true, CompleteDenialFixture()).Passed, "Valid complete decision fixture rejected"));
Check("Empty input cannot pass by vacuous All", () =>
    Require(!NetworkAdmission.Evaluate(true, []).Passed, "Empty proof accepted"));
Check("Token boolean cannot substitute for missing token check", () =>
    Require(!NetworkAdmission.Evaluate(true, CompleteDenialFixture().Where(c => c.Kind != "token").ToArray()).Passed, "Missing token accepted"));
Check("Failed token rejects an otherwise complete fixture", () =>
    Require(!NetworkAdmission.Evaluate(false, CompleteDenialFixture()).Passed, "Failed token accepted"));

foreach (string kind in NetworkAdmission.RequiredChecks)
{
    Check("Missing required check is rejected: " + kind, () =>
        Require(!NetworkAdmission.Evaluate(true, CompleteDenialFixture().Where(c => c.Kind != kind).ToArray()).Passed, "Missing " + kind + " accepted"));
    Check("Duplicate required check is rejected: " + kind, () =>
    {
        var checks = CompleteDenialFixture();
        checks.Add(checks.Single(c => c.Kind == kind));
        Require(!NetworkAdmission.Evaluate(true, checks).Passed, "Duplicate " + kind + " accepted");
    });
    Check("Non-denial cannot pass required check: " + kind, () =>
    {
        foreach (string outcome in new[] { "inconclusive", "unverified-offline-route", "diagnostic-only", "blocked-comparative", "failed", "allowed" })
        {
            var checks = CompleteDenialFixture().Select(c => c.Kind == kind ? c with { Outcome = outcome } : c).ToArray();
            Require(!NetworkAdmission.Evaluate(true, checks).Passed, outcome + " accepted for " + kind);
        }
    });
}

foreach (int error in new[] { 10051, 10061, 10060, 10050, 10065, 11001, 11004, 995, 0 })
    Check("Socket error never upgraded to permission denial: " + error, () =>
    {
        foreach (string reported in new[] { "inconclusive", "denied", "blocked-comparative" })
        {
            var actual = NetworkAdmission.SocketResult("tcp-ipv4", new("tcp", reported, error, "Synthetic prior label"));
            Require(actual.Outcome == "inconclusive", "Non-security error upgraded: " + error);
        }
    });
Check("Actual socket permission error remains denied", () =>
    Require(NetworkAdmission.SocketResult("tcp-ipv4", new("tcp", "denied", 10013, "Fixture")).Outcome == "denied", "WSAEACCES lost"));
Check("Successful TCP cannot pass even with contradictory error label", () =>
    Require(NetworkAdmission.SocketResult("tcp-ipv4", new("tcp", "allowed", 10013, "Fixture")).Outcome == "failed", "Connected TCP admitted"));
Check("Successful UDP enqueue proves neither delivery nor blocking", () =>
{
    foreach (string kind in new[] { "dns-udp-ipv4", "dns-udp-ipv6" })
    {
        var actual = NetworkAdmission.SocketResult(kind, new(kind, "unexpected-send", null, "Fixture"));
        Require(actual.Outcome == "inconclusive", "UDP enqueue was misreported as proof");
        Require(!NetworkAdmission.Evaluate(true, CompleteDenialFixture().Select(c => c.Kind == kind ? actual : c).ToArray()).Passed,
            "UDP enqueue admitted the process");
    }
});
Check("Outcome label denied cannot conceal a non-denial native code", () =>
{
    var checks = CompleteDenialFixture().Select(c => c.Kind == "tcp-ipv4" ? c with { NativeError = 10061 } : c).ToArray();
    Require(!NetworkAdmission.Evaluate(true, checks).Passed, "Forged denied label accepted");
});
Check("UnauthorizedAccessException HRESULT is an accepted file denial", () =>
{
    var checks = CompleteDenialFixture().Select(c => c.Kind is "file-read" or "file-write" ? c with { NativeError = unchecked((int)0x80070005) } : c).ToArray();
    Require(NetworkAdmission.Evaluate(true, checks).Passed, "File access denied HRESULT rejected");
});

foreach (int error in new[] { 9003, 9005, 9501, 9506, 1460, 995, 87, 10051, 10061 })
    Check("DNS negative result is not policy denial: " + error, () =>
        Require(NetworkAdmission.DnsResult("dns-api-a", error).Outcome == "inconclusive", "DNS error admitted: " + error));
Check("DNS access-denied native status is retained", () =>
{
    foreach (int status in new[] { 5, 10013 })
        Require(NetworkAdmission.DnsResult("dns-api-a", status).Outcome == "denied", "Explicit DNS permission denial lost");
});
Check("Completed wire-only DNS query prevents admission", () =>
    Require(NetworkAdmission.DnsResult("dns-api-a", 0).Outcome == "failed", "DNS success treated as denial"));
Check("Unavailable native DNS API prevents admission", () =>
    Require(NetworkAdmission.DnsResult("dns-api-a", null, "API unavailable").Outcome == "inconclusive", "Missing native DNS API admitted"));
Check("Unknown check cannot be silently ignored", () =>
{
    var checks = CompleteDenialFixture();
    checks.Add(new("unknown-network-probe", "inconclusive", null, "Fixture"));
    Require(!NetworkAdmission.Evaluate(true, checks).Passed, "Unexpected check silently ignored");
});

var now = new DateTimeOffset(2026, 11, 26, 12, 0, 0, TimeSpan.Zero);
const string session = "6a3be4e0d11c4217abf24d027e9fcaa8";
const string otherSession = "70f02d1e14ca49b2b4eb4ecf9a04c742";
Check("Same-session fresh baseline remains diagnostic-current", () =>
    Require(NetworkAdmission.CurrentBaseline(session, session, now.AddSeconds(-30).ToString("O"), now), "Current baseline rejected"));
Check("Recent previous launch cannot be reused as current baseline", () =>
    Require(!NetworkAdmission.CurrentBaseline(otherSession, session, now.AddSeconds(-1).ToString("O"), now), "Recent other session accepted"));
Check("Legacy baseline without session is rejected", () =>
    Require(!NetworkAdmission.CurrentBaseline("", session, now.ToString("O"), now), "Legacy cached baseline accepted"));
Check("Empty GUID cannot identify a preparation session", () =>
    Require(!NetworkAdmission.CurrentBaseline(new string('0', 32), new string('0', 32), now.ToString("O"), now), "Empty identity accepted"));
Check("Expired, future and malformed baseline timestamps are rejected", () =>
{
    foreach (string value in new[] { now.AddMinutes(-4).ToString("O"), now.AddSeconds(1).ToString("O"), "not-a-time" })
        Require(!NetworkAdmission.CurrentBaseline(session, session, value, now), "Invalid baseline time accepted");
});
Check("Fresh local witness has a valid identity and endpoint range", () =>
    Require(NetworkAdmission.WitnessValid(45001, 45002, session, now.AddMinutes(-1).ToString("O"), now), "Valid local witness rejected"));
Check("Expired local witness cannot refresh itself by being read again", () =>
    Require(!NetworkAdmission.WitnessValid(45001, 45002, session, now.AddMinutes(-6).ToString("O"), now), "Expired witness accepted"));
Check("Invalid local witness endpoints and identity are rejected", () =>
{
    Require(!NetworkAdmission.WitnessValid(0, 45002, session, now.ToString("O"), now), "Port zero accepted");
    Require(!NetworkAdmission.WitnessValid(45001, 65536, session, now.ToString("O"), now), "Out-of-range port accepted");
    Require(!NetworkAdmission.WitnessValid(45001, 45002, "", now.ToString("O"), now), "Missing session accepted");
});

elapsed.Stop();
var report = new
{
    executedUtc = DateTimeOffset.UtcNow.ToString("O"),
    operatingSystem = RuntimeInformation.OSDescription,
    architecture = RuntimeInformation.ProcessArchitecture.ToString(),
    runtime = Environment.Version.ToString(),
    scope = "Production NetworkAdmission decision regression tests. Synthetic inputs test classification only; no Windows isolation, DNS native call, network denial or UI execution is claimed.",
    windowsIsolationExecuted = false,
    nativeDnsExecuted = false,
    total = results.Count,
    passed = results.Count(r => r.Passed),
    failed = results.Count(r => !r.Passed),
    elapsedMilliseconds = elapsed.Elapsed.TotalMilliseconds,
    results
};
var options = new JsonSerializerOptions { WriteIndented = true, PropertyNamingPolicy = JsonNamingPolicy.CamelCase };
string destination = args.Length > 0 ? args[0] : "admission-results.json";
File.WriteAllText(destination, JsonSerializer.Serialize(report, options));
Console.WriteLine($"Admission regression checks: {report.passed}/{report.total} passed. Windows isolation not executed.");
foreach (var failure in results.Where(r => !r.Passed)) Console.WriteLine(failure.Name + ": " + failure.Error);
return report.failed == 0 ? 0 : 1;

sealed record TestResult(string Name, bool Passed, double ElapsedMilliseconds, string? Error);
