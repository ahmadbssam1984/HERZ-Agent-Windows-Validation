using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Herz.Windows;

var results = new List<object>();
object? liveDownload = null;
string root = Path.Combine(Path.GetTempPath(), "HERZ-download-check-" + Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(root);
byte[] bytes = Encoding.UTF8.GetBytes("HERZ فحص ملف محلي\n");
string sha = Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
IProgress<string> progress = new Progress<string>(_ =>
{
});
async Task Check(string name, Func<Task> action)
{
    try
    {
        await action();
        results.Add(new { name, passed = true });
    }
    catch (Exception e)
    {
        results.Add(new { name, passed = false, error = e.ToString() });
    }
}

async Task Rejected(Func<Task> action)
{
    bool rejected = false;
    try
    {
        await action();
    }
    catch (Exception e)when (e is IOException or InvalidDataException or OperationCanceledException)
    {
        rejected = true;
    }

    if (!rejected)
        throw new Exception("Unexpected acceptance.");
}

void Require(bool value)
{
    if (!value)
        throw new Exception("Assertion failed.");
}

await Check("verified stream preserved exactly", async () =>
{
    string path = Path.Combine(root, "good");
    await ArtifactDownload.CopyVerifiedAsync(new MemoryStream(bytes), path, bytes.Length, sha, progress, default);
    Require(File.ReadAllBytes(path).SequenceEqual(bytes));
});
await Check("corrupt checksum refused without committed file", async () =>
{
    string path = Path.Combine(root, "bad");
    await Rejected(() => ArtifactDownload.CopyVerifiedAsync(new MemoryStream(bytes), path, bytes.Length, new string ('0', 64), progress, default));
    Require(!File.Exists(path));
});
await Check("short and excessive responses refused", async () =>
{
    foreach (long size in new long[]
    {
        bytes.Length - 1,
        bytes.Length + 1
    }

    )
        await Rejected(() => ArtifactDownload.CopyVerifiedAsync(new MemoryStream(bytes), Path.Combine(root, "size" + size), size, sha, progress, default));
});
await Check("existing model preserved", async () =>
{
    string path = Path.Combine(root, "existing");
    File.WriteAllText(path, "original");
    await Rejected(() => ArtifactDownload.CopyVerifiedAsync(new MemoryStream(bytes), path, bytes.Length, sha, progress, default));
    Require(File.ReadAllText(path) == "original");
});
await Check("cancelled transfer uncommitted and own temporary cleaned", async () =>
{
    string path = Path.Combine(root, "cancelled");
    using var cancel = new CancellationTokenSource();
    cancel.Cancel();
    await Rejected(() => ArtifactDownload.CopyVerifiedAsync(new MemoryStream(bytes), path, bytes.Length, sha, progress, cancel.Token));
    Require(!File.Exists(path) && !Directory.EnumerateFiles(root, "*.download").Any());
});
await Check("source allowlist rejects remote substitutes and credentials", () =>
{
    foreach (string u in new[]
    {
        "http://huggingface.co/file",
        "https://evil.example/file",
        "https://huggingface.co.evil.example/file",
        "https://user:secret@huggingface.co/file",
        "https://127.0.0.1/file",
        "https://huggingface.co:444/file"
    }

    )
        Require(!ArtifactDownload.AllowedSource(new Uri(u)));
    Require(ArtifactDownload.AllowedSource(new Uri("https://huggingface.co/Qwen/model/resolve/commit/file")));
    Require(ArtifactDownload.AllowedSource(new Uri("https://cas-bridge.xethub.hf.co/object")));
    Require(!ArtifactDownload.AllowedSource(new Uri("relative/path", UriKind.Relative)));
    return Task.CompletedTask;
});
if (args.Length == 4)
{
    await Check("live preparation HTTPS source size and digest", async () =>
    {
        string path = Path.Combine(root, "LICENSE.downloaded.txt");
        await ArtifactDownload.DownloadAsync(new Uri(args[1]), path, long.Parse(args[2]), args[3], progress, default);
        Require(File.Exists(path));
        liveDownload = new
        {
            source = args[1],
            bytes = new FileInfo(path).Length,
            sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant()
        };
    });
}

var report = new
{
    executedUtc = DateTimeOffset.UtcNow.ToString("O"),
    runtime = Environment.Version.ToString(),
    os = System.Runtime.InteropServices.RuntimeInformation.OSDescription,
    scope = "Production preparation downloader integrity checks on the recorded OS; no Windows UI or AppContainer execution.",
    connectionPolicy = "Preparation honors the configured system proxy, without default credentials or cookies; TLS, redirect allowlist, size and SHA-256 verification remain enabled. Runtime agents do not invoke this downloader.",
    liveDownload,
    results
};
string destination = args.Length > 0 ? args[0] : "preparation-results.json";
File.WriteAllText(destination, JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine(File.ReadAllText(destination));
return results.Any(x => JsonSerializer.Serialize(x).Contains("\"passed\":false", StringComparison.Ordinal)) ? 1 : 0;
