#!/usr/bin/env python3
"""Execute the production Node flags and script; no Windows isolation claim."""
import hashlib, json, os, shutil, subprocess, tempfile, time
from pathlib import Path

root=Path(__file__).resolve().parents[1]
script=(root/'examples/node_reporter/agent.js').resolve()
temporary=Path(tempfile.mkdtemp(prefix='herz-node-flags-'))
workspace=temporary/'workspace with spaces العربية';workspace.mkdir()
source=workspace/'stats.json'
stats={'count':4,'sum':60,'mean':15,'min':10,'max':20,'numbers':[12,18,20,10]}
source.write_text(json.dumps(stats))
env=dict(os.environ);env.pop('NODE_OPTIONS',None);env.pop('NODE_PATH',None)
def run(work:Path, input_file:Path):
 args=['node','--no-addons','--disable-proto=throw','--max-old-space-size=128','--permission','--allow-fs-read='+str(work),'--allow-fs-read='+str(script),'--allow-fs-write='+str(work),str(script)]
 context={'taskId':'production-flags-test','input':{'title':'تقرير التحقق المحلي'},'workspace':str(work),'inputs':[{'fullPath':str(input_file)}],'knowledge':[]}
 return subprocess.run(args,input=json.dumps(context),capture_output=True,text=True,cwd=work,timeout=20,env=env)
started=time.monotonic();good=run(workspace,source)
assert good.returncode==0,good.stderr
response=json.loads(good.stdout);output=workspace/'report.html'
assert response['result']['sum']==60 and response['result']['mean']==15 and output.exists()
assert '<td>60</td>' in output.read_text() and '<td>15</td>' in output.read_text()
blocked_work=temporary/'blocked';blocked_work.mkdir();private=temporary/'private';private.mkdir();private_input=private/'stats.json';private_input.write_text(json.dumps(stats))
blocked=run(blocked_work,private_input)
assert blocked.returncode!=0 and not (blocked_work/'report.html').exists(),blocked.stdout
assert 'Access' in blocked.stderr or 'permission' in blocked.stderr.lower(),blocked.stderr
sample=root/'examples/verified-output';sample.mkdir(exist_ok=True)
shutil.copy2(output,sample/'report.html');shutil.copy2(source,sample/'stats.json')
report={'scope':'Production Node script and exact flags executed on Linux, not Windows AppContainer','nodeVersion':subprocess.check_output(['node','--version'],text=True).strip(),'passed':2,'failed':0,'seconds':time.monotonic()-started,'checks':['stdin EOF and actual HTML with production permission flags','Node permission rejects an input outside the allowed directory'],'outputSha256':hashlib.sha256(output.read_bytes()).hexdigest(),'blockedExitCode':blocked.returncode,'blockedMessage':blocked.stderr.strip(),'windowsExecution':False,'kernelIsolationVerified':False,'sample':'examples/verified-output/report.html'}
(root/'evidence/production-node-flags.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
