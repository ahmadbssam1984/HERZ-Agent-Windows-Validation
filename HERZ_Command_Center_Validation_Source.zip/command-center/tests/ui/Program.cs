using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Windows.Forms;
using Herz.Core;
using Herz.Windows;

internal static class UiChecks
{
    private sealed record Check(string Name, bool Passed, double Milliseconds, string Detail);
    private static readonly List<Check> Checks = [];
    private static readonly List<object> Images = [];
    private static string output = "";

    [STAThread]
    private static int Main(string[] args)
    {
        output = Path.GetFullPath(args.Length == 2 && args[0] == "--output" ? args[1] : "ui-check-output");
        Directory.CreateDirectory(output);
        int dpi = 0;
        string? fatal = null;
        if (!OperatingSystem.IsWindows())
        {
            WriteReport(0, "not_executed", "A real Windows host is required.");
            return 125;
        }
        try
        {
            Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            var work = Path.Combine(output, "ui-data-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(work);
            using var core = new CommandCenter(work, new UnavailableAgentRunner("UI acceptance fixture: managed execution is unavailable; no network isolation is claimed."));
            using var form = new MainForm(core, new UiHostStatus
            {
                WorkspaceRoot = work,
                InboxDirectory = Path.Combine(work, "inbox"),
                ManagerIsolated = true,
                IsolationVerified = false,
                IsolationSummary = "فشل إثبات العزل: " + string.Join("؛ ", Enumerable.Repeat("loopback-ipv6=inconclusive/10051", 14)),
                ModelStatus = "غير متاح: لا يوجد نموذج محلي معتمد في اختبار الواجهة.",
                WindowsAcceptanceVerified = false
            });
            Directory.CreateDirectory(Path.Combine(work, "inbox"));
            form.Show();
            Pump();
            dpi = form.DeviceDpi;
            CheckIt("Native form handle created", () => Require(form.IsHandleCreated && form.Visible, "The real WinForms window was not created."));
            CheckIt("Failed admission stays amber", () =>
            {
                var status = Descendants(form).OfType<Label>().Single(x => x.Name == "runtimeStatus");
                Require(status.Text.Contains("محظور") && status.Tag?.ToString() == "warning", "An unverified AppContainer must not get a green success banner.");
                Require(status.AccessibleDescription?.Contains("inconclusive/10051") == true, "Full failure evidence is unavailable to accessibility tools.");
            });
            CheckIt("Empty database is real", () => Require(core.Agents().Count == 0 && core.Tasks().Count == 0 && !core.Dashboard().Isolation.Supported, "UI fixture unexpectedly has ready agents/tasks."));
            Capture(form, "dashboard-1280x800-dark", new Size(1280, 800));
            Capture(form, "dashboard-900x620-dark", new Size(900, 620));
            CheckIt("Navigation labels fit", () =>
            {
                foreach (var nav in Descendants(form).OfType<Button>().Where(x => x.GetType().Name == "NavigationButton"))
                    Require(TextRenderer.MeasureText(nav.Text, nav.Font).Width + nav.Padding.Horizontal <= nav.ClientSize.Width,
                        "Navigation text is clipped: " + nav.Text);
            });
            CheckIt("Header and status rows fit their text", () =>
            {
                foreach (var label in Descendants(form).OfType<Label>().Where(x => x.Name == "runtimeStatus" || x.Text == "HERZ  |  مركز إدارة الوكلاء المحليين"))
                {
                    Require(label.Parent is not null && label.Bottom <= label.Parent.ClientSize.Height,
                        "A header/status label extends below its row.");
                    Require(label.Height >= label.GetPreferredSize(new Size(label.Width, 0)).Height,
                        "A header/status label does not have its preferred text height.");
                }
            });
            CheckIt("Unavailable resume is disabled", () => Require(!Button(form, "استئناف استقبال المهام").Enabled, "Resume was offered while isolation is unavailable."));
            var dark = form.BackColor;
            CheckIt("Theme button changes actual controls", () =>
            {
                Button(form, "تبديل المظهر").PerformClick();
                Pump();
                Require(form.BackColor != dark, "The theme button did not alter the form colors.");
                Require(File.Exists(Path.Combine(work, "ui-theme.json")), "Theme preference was not saved locally.");
            });
            Capture(form, "dashboard-1280x800-light", new Size(1280, 800));

            var pages = new[] { "مساحة الأوامر", "الوكلاء والموصلات", "المهام والنتائج", "اتصالات الوكلاء", "المعرفة والتعليمات", "النماذج والموارد", "الحظر وسجل التنفيذ", "النسخ والاستعادة" };
            foreach (string page in pages)
                CheckIt("Navigate: " + page, () =>
                {
                    Button(form, page).PerformClick();
                    Pump();
                    Require(!Descendants(form).OfType<Label>().Any(x => x.Text.StartsWith("تعذر فتح القسم:", StringComparison.Ordinal)), "Navigation produced an error label.");
                });
            CheckIt("Backup button writes a verified backup", () =>
            {
                Button(form, "إنشاء نسخة احتياطية").PerformClick();
                PumpUntil(() => core.Backups().Count == 1, TimeSpan.FromSeconds(15));
                var backup = core.Backups().Single();
                Require(File.Exists(backup.Path) && new FileInfo(backup.Path).Length > 0 && backup.Sha256.Length == 64, "Backup file or hash is missing.");
            });
            CheckIt("Command editor accepts long Arabic and English", () =>
            {
                Button(form, "مساحة الأوامر").PerformClick();
                Pump();
                var editor = Descendants(form).OfType<TextBox>().Single(x => x.AccessibleName == "الطلب العربي للمدير");
                string request = string.Concat(Enumerable.Repeat("تعليمات عربية طويلة مع English names وملفات محلية. ", 100));
                editor.Text = request;
                Require(editor.Text == request && editor.RightToLeft == RightToLeft.Yes, "Command text was truncated or RTL was lost.");
                Require(!Button(form, "استشارة النموذج المحلي").Enabled, "An unavailable model was exposed as ready.");
            });
            Capture(form, "commands-long-arabic-light", new Size(900, 620));
            CheckIt("Emergency stop changes stored admission state", () =>
            {
                Button(form, "إيقاف طارئ").PerformClick();
                Pump();
                Require(core.Dashboard().Paused, "Emergency stop did not persist the paused state.");
                Require(core.Tasks().Count == 0, "The UI created an unrequested task.");
            });
            form.Close();
            Pump();
        }
        catch (Exception e)
        {
            fatal = e.GetType().Name + ": " + e.Message;
            Checks.Add(new("Windows UI initialization/run", false, 0, fatal));
        }
        bool passed = Checks.Count > 0 && Checks.All(x => x.Passed);
        WriteReport(dpi, passed ? "passed" : "failed", fatal);
        return passed ? 0 : 1;
    }

    private static void Capture(Form form, string name, Size requested)
    {
        CheckIt("Render " + name, () =>
        {
            form.Size = requested;
            form.PerformLayout();
            Pump();
            using var image = new Bitmap(form.Width, form.Height);
            form.DrawToBitmap(image, new Rectangle(Point.Empty, form.Size));
            string path = Path.Combine(output, name + ".png");
            image.Save(path, ImageFormat.Png);
            Require(new FileInfo(path).Length > 5000, "Rendered PNG has unexpectedly little content.");
            Images.Add(new { file = name + ".png", requestedWidth = requested.Width, requestedHeight = requested.Height, actualWidth = form.Width, actualHeight = form.Height, dpi = form.DeviceDpi, method = "real WinForms DrawToBitmap" });
        });
    }

    private static Button Button(Control root, string text) => Descendants(root).OfType<Button>().Single(x => x.Text == text);
    private static IEnumerable<Control> Descendants(Control root)
    {
        foreach (Control child in root.Controls)
        {
            yield return child;
            foreach (var nested in Descendants(child)) yield return nested;
        }
    }
    private static void Require(bool value, string detail) { if (!value) throw new InvalidOperationException(detail); }
    private static void Pump() { Application.DoEvents(); Thread.Sleep(30); Application.DoEvents(); }
    private static void PumpUntil(Func<bool> ready, TimeSpan timeout)
    {
        var clock = Stopwatch.StartNew();
        while (!ready() && clock.Elapsed < timeout) Pump();
        Require(ready(), "UI operation did not complete within " + timeout.TotalSeconds + " seconds.");
    }
    private static void CheckIt(string name, Action run)
    {
        var watch = Stopwatch.StartNew();
        try { run(); Checks.Add(new(name, true, watch.Elapsed.TotalMilliseconds, "")); }
        catch (Exception e) { Checks.Add(new(name, false, watch.Elapsed.TotalMilliseconds, e.GetType().Name + ": " + e.Message)); }
    }
    private static void WriteReport(int dpi, string status, string? error)
    {
        using var process = Process.GetCurrentProcess();
        var result = new
        {
            status,
            passed = Checks.Count(x => x.Passed),
            failed = Checks.Count(x => !x.Passed),
            error,
            runtime = RuntimeInformation.FrameworkDescription,
            os = RuntimeInformation.OSDescription,
            userInteractive = Environment.UserInteractive,
            dpi,
            workingSetBytes = process.WorkingSet64,
            checks = Checks,
            images = Images,
            isolationTested = false,
            actualDesktopScreenshot = false,
            scope = "Actual WinForms controls, real local database, unavailable runner. PNGs are rendered by the real Windows form, not desktop screenshots. This test does not execute agents or establish AppContainer/network isolation."
        };
        string json = JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(Path.Combine(output, "ui-results.json"), json);
        Console.WriteLine(json);
    }
}
