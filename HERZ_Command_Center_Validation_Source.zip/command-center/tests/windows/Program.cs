using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Text.Json;
using Herz.Windows;

// Windows-only acceptance instrumentation. No synthetic successful token, denied
// packet or completed task is substituted when native calls cannot be executed.
internal static class AcceptanceProgram
{
    private static readonly List<object> Results = [];
    private static int failures, incomplete;
    private sealed record ChildEvidence(int Pid, RuntimeProof Proof, RuntimeProof? Descendant, uint? DescendantPid, string? DescendantError);
    private sealed record IdleEvidence(int Pid, uint DescendantPid);

    private static async Task<int> Main(string[] args)
    {
        if (!OperatingSystem.IsWindows() || RuntimeInformation.ProcessArchitecture != Architecture.X64)
        {
            Console.Error.WriteLine("NOT RUN: this executable requires actual Windows x64; no native acceptance is implied.");
            return 125;
        }
        if (args.Length > 0 && args[0] is "--native-probe" or "--native-leaf")
            return await ProbeChild(args);
        if (args.Length == 2 && args[0] == "--native-idle")
            return await IdleChild(args[1]);
        if (args.Length == 2 && args[0] == "--native-idle-leaf")
        {
            using var p = NativeSandbox.OpenExistingProfile(args[1]);
            NativeSandbox.VerifyCurrentAppContainer(p.Sid);
            Console.WriteLine("ready"); await Task.Delay(TimeSpan.FromSeconds(90)); return 0;
        }
        if (args.Length == 1 && args[0] == "--unrelated-witness")
        {
            Console.WriteLine("ready"); await Task.Delay(TimeSpan.FromSeconds(90)); return 0;
        }

        string? reportPath = Argument(args, "--report"), releasePath = Argument(args, "--release");
        if (reportPath is null || releasePath is null || !args.Contains("--expect-non-admin"))
        {
            Console.Error.WriteLine("Usage: Herz.WindowsAcceptance.exe --release <dir> --report <json> --expect-non-admin");
            return 125;
        }
        var watch = Stopwatch.StartNew();
        bool nativeStarted = false;
        string? root = null;
        string actualLoadedAssemblySha256 = Hash(typeof(NativeSandbox).Assembly.Location);
        var identity = NativeSandbox.GetCurrentTokenInfo();
        try
        {
            using var who = WindowsIdentity.GetCurrent();
            bool standard = !identity.IsAppContainer && !identity.Elevated && !new WindowsPrincipal(who).IsInRole(WindowsBuiltInRole.Administrator);
            Record("ordinary_windows_user", standard, new { identity.Elevated, identity.IsAppContainer });
            if (!standard) throw new UnauthorizedAccessException("Run this suite as a real ordinary Windows user.");
            releasePath = Path.GetFullPath(releasePath);
            NativeSandbox.EnsureNoReparsePoints(releasePath);
            if (!File.Exists(Path.Combine(releasePath, "HERZ.exe")) || !File.Exists(Path.Combine(releasePath, "HERZ.dll")))
                throw new FileNotFoundException("The published HERZ Windows release is missing.");
            string releaseAssemblySha256 = Hash(Path.Combine(releasePath, "HERZ.dll"));
            Record("tested_assembly_matches_published_release", actualLoadedAssemblySha256 == releaseAssemblySha256,
                new { actualLoadedAssemblySha256, releaseAssemblySha256 });
            if (actualLoadedAssemblySha256 != releaseAssemblySha256)
                throw new InvalidDataException("The loaded HERZ assembly does not match the supplied release; do not bind these results to it.");
            string fixtureId = Guid.NewGuid().ToString("N");
            string owned = NativeSandbox.OwnedRoot;
            root = Path.Combine(owned, "acceptance-" + fixtureId);
            Directory.CreateDirectory(root);
            NativeSandbox.EnsureNoReparsePoints(root);
            string format = new DriveInfo(Path.GetPathRoot(root)!).DriveFormat;
            Record("ntfs_fixture_volume", format == "NTFS", new { format });
            if (format != "NTFS") throw new PlatformNotSupportedException("Actual NTFS ACLs are required.");
            string harness = Path.Combine(root, "harness");
            CopyChecked(AppContext.BaseDirectory, harness);
            string executable = Path.Combine(harness, Path.GetFileName(Environment.ProcessPath!));
            string privateFolder = Path.Combine(root, "private");
            Directory.CreateDirectory(privateFolder);
            string canary = Path.Combine(privateFolder, "private-canary.txt");
            string policy = Path.Combine(harness, "acceptance-policy-canary.json");
            File.WriteAllText(canary, "Synthetic HERZ access-control test; no user data.");
            File.WriteAllText(policy, "{\"network\":\"deny\",\"fixtureOnly\":true}");
            string originalPolicyHash = Hash(policy);
            var baseline = await RuntimeChecks.BaselineAsync(fixtureId);
            Record("outside_container_ipv4_positive_control", baseline.Ipv4Connected, baseline, inconclusive: !baseline.Ipv4Connected);
            Record("outside_container_ipv6_positive_control", baseline.Ipv6Connected, new { baseline.Ipv6Connected }, inconclusive: !baseline.Ipv6Connected);
            Record("outside_container_dns_positive_control", baseline.DnsResolved, new { baseline.DnsResolved }, inconclusive: !baseline.DnsResolved);
            using var witness = await NetworkWitness.StartAsync(baseline, CancellationToken.None);
            var control = witness.Control(baseline);
            foreach (string role in new[] { "manager", "agent" })
            {
                string slot = Path.Combine(root, role); Directory.CreateDirectory(slot);
                using var profile = NativeSandbox.CreateProfile("HERZ.Test." + role + "." + fixtureId);
                NativeSandbox.GrantDirectory(owned, harness, profile, false);
                NativeSandbox.GrantDirectory(owned, slot, profile, true);
                using var process = NativeSandbox.Launch(profile, executable,
                    ["--native-probe", profile.Name, canary, policy, Convert.ToBase64String(Encoding.UTF8.GetBytes(Wire.Encode(control)))], slot,
                    limits: new(768L * 1024 * 1024, 50, 5));
                nativeStarted = true;
                var error = ReadBounded(process.StandardError, 16384);
                var text = await ReadBounded(process.StandardOutput, 128 * 1024).WaitAsync(TimeSpan.FromSeconds(65));
                bool exited = process.WaitForExit(TimeSpan.FromSeconds(3));
                if (!exited) process.Terminate(125);
                string errorText = await error.WaitAsync(TimeSpan.FromSeconds(3));
                if (string.IsNullOrWhiteSpace(text)) throw new IOException("Isolated probe produced no result: " + errorText);
                var evidence = Wire.Decode<ChildEvidence>(text);
                Record(role + "_actual_token", evidence.Pid == process.Pid && evidence.Proof.Token.IsAppContainer &&
                    evidence.Proof.Token.AppContainerSid == profile.Sid && evidence.Proof.Token.CapabilityCount == 0 &&
                    !evidence.Proof.Token.Elevated && evidence.Proof.Token.IntegritySid == "S-1-16-4096", evidence.Proof.Token);
                Record(role + "_runtime_admission", exited && process.ExitCode == 0 && evidence.Proof.Passed &&
                    evidence.Descendant?.Passed == true, evidence);
                Record(role + "_descendant_executed", evidence.Descendant is not null && evidence.DescendantPid is > 0,
                    new { evidence.DescendantPid, evidence.DescendantError }, inconclusive: evidence.Descendant is null);
                Record(role + "_policy_bytes_preserved", Hash(policy) == originalPolicyHash, new { originalPolicyHash });
                if (role == "agent") await CheckJobTermination(profile, executable, slot);
            }
            await witness.AssertAliveAsync(CancellationToken.None);
            Record("positive_witness_still_alive_after_probes", true, new { ipv4 = "verified local listener", ipv6 = "verified local listener" });
        }
        catch (Exception error)
        {
            Record("native_suite_completion", false, new { error = error.GetType().Name, message = Redact(error.Message) });
        }

        // These are different acceptance requirements. A successful network probe
        // suite must not turn them into fictitious full-product success.
        foreach (var missing in new[] {
            "local_llm_task_with_internet_disconnected", "two_production_agents_verified_output",
            "full_manager_startup_and_recovery", "all_eleven_product_acceptance_criteria",
            "windows_11_home_build_26300_10075", "complete_kernel_dns_proxy_denial_audit" })
            NotRun(missing, "This native harness does not execute or certify this requirement.");
        var report = new
        {
            suite = "Actual Windows native containment diagnostics; NOT full product approval",
            timeUtc = DateTimeOffset.UtcNow, os = RuntimeInformation.OSDescription,
            architecture = RuntimeInformation.ProcessArchitecture.ToString(), logicalProcessors = Environment.ProcessorCount,
            nativeWindowsProcessesExecuted = nativeStarted, windows11HomeEquivalent = false,
            seconds = watch.Elapsed.TotalSeconds, peakHarnessWorkingSetBytes = Process.GetCurrentProcess().PeakWorkingSet64,
            failed = failures, notRunOrInconclusive = incomplete, completeProductAcceptance = false,
            sourceReleaseSha256 = File.Exists(Path.Combine(releasePath, "HERZ.dll")) ? Hash(Path.Combine(releasePath, "HERZ.dll")) : null,
            actualLoadedAssemblySha256,
            fixtureFilesPreserved = root is not null, results = Results
        };
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(reportPath))!);
        File.WriteAllText(reportPath, JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true }));
        Console.WriteLine(JsonSerializer.Serialize(report));
        return failures > 0 ? 1 : incomplete > 0 ? 2 : 0;
    }

    private static async Task<int> ProbeChild(string[] args)
    {
        if (args.Length != 5) return 125;
        using var profile = NativeSandbox.OpenExistingProfile(args[1]);
        NativeSandbox.VerifyCurrentAppContainer(profile.Sid);
        var control = Wire.Decode<NetworkControl>(Encoding.UTF8.GetString(Convert.FromBase64String(args[4])));
        var proof = await RuntimeChecks.ProbeAsync(profile.Sid, args[2], args[3], control);
        RuntimeProof? descendant = null; uint? descendantPid = null; string? descendantError = null;
        if (args[0] == "--native-probe")
        {
            try
            {
                // Run diagnostics even if the parent's proof is inconclusive.
                // This never permits user tasks or changes admission policy.
                using var child = NativeSandbox.Launch(profile, Environment.ProcessPath!,
                    ["--native-leaf", args[1], args[2], args[3], args[4]], Environment.CurrentDirectory,
                    limits: new(512L * 1024 * 1024, 50, 2));
                child.StandardInput.Close();
                var stderr = ReadBounded(child.StandardError, 8192);
                string raw = await ReadBounded(child.StandardOutput, 65536).WaitAsync(TimeSpan.FromSeconds(30));
                if (!child.WaitForExit(TimeSpan.FromSeconds(2))) throw new TimeoutException("Descendant probe did not exit.");
                var result = Wire.Decode<ChildEvidence>(raw);
                if (result.Pid != child.Pid) throw new InvalidDataException("Descendant PID did not match.");
                _ = await stderr.WaitAsync(TimeSpan.FromSeconds(2));
                // Preserve the actually observed proof even on denial/inconclusive,
                // but never turn a transport/exit/identity failure into a pass.
                if (result.Proof.Passed && child.ExitCode != 0)
                    throw new InvalidDataException("Descendant reported success but exited with an error.");
                descendant = result.Proof; descendantPid = child.Pid;
            }
            catch (Exception e) { descendant = null; descendantPid = null; descendantError = e.GetType().Name + ": " + Redact(e.Message); }
        }
        Console.WriteLine(Wire.Encode(new ChildEvidence(Environment.ProcessId, proof, descendant, descendantPid, descendantError)));
        return proof.Passed && (args[0] == "--native-leaf" || descendant?.Passed == true) ? 0 : 125;
    }

    private static async Task<int> IdleChild(string profileName)
    {
        using var profile = NativeSandbox.OpenExistingProfile(profileName);
        NativeSandbox.VerifyCurrentAppContainer(profile.Sid);
        using var descendant = NativeSandbox.Launch(profile, Environment.ProcessPath!,
            ["--native-idle-leaf", profileName], Environment.CurrentDirectory, limits: new(256L * 1024 * 1024, 25, 2));
        string? ready = await descendant.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(10));
        if (ready != "ready") return 125;
        Console.WriteLine(Wire.Encode(new IdleEvidence(Environment.ProcessId, descendant.Pid)));
        await Task.Delay(TimeSpan.FromSeconds(90)); return 0;
    }

    private static async Task CheckJobTermination(SandboxProfile profile, string executable, string slot)
    {
        var info = new ProcessStartInfo(Environment.ProcessPath!) { UseShellExecute = false, RedirectStandardOutput = true };
        info.ArgumentList.Add("--unrelated-witness");
        using var unrelated = Process.Start(info) ?? throw new IOException("Could not start unrelated witness.");
        try
        {
            if (await unrelated.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(10)) != "ready")
                throw new IOException("Unrelated witness was not ready.");
            using var managed = NativeSandbox.Launch(profile, executable, ["--native-idle", profile.Name], slot,
                limits: new(512L * 1024 * 1024, 25, 4));
            string? ready = await managed.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(15));
            var ids = Wire.Decode<IdleEvidence>(ready ?? "");
            if (ids.Pid != managed.Pid) throw new InvalidDataException("Idle worker identity mismatch.");
            using var descendant = Process.GetProcessById(checked((int)ids.DescendantPid));
            var before = managed.GetUsage();
            managed.Terminate(125);
            bool parentEnded = managed.WaitForExit(TimeSpan.FromSeconds(5));
            bool childEnded = descendant.WaitForExit(5000);
            Record("managed_job_cancellation_and_descendant", parentEnded && childEnded, new { parentEnded, childEnded, before.ActiveProcesses, before.PeakCommittedBytes });
            Record("unrelated_process_survives_managed_stop", !unrelated.HasExited, new { alive = !unrelated.HasExited });
        }
        finally { if (!unrelated.HasExited) unrelated.Kill(); }
    }

    private static string? Argument(string[] args, string flag) { int i = Array.IndexOf(args, flag); return i >= 0 && i + 1 < args.Length ? args[i + 1] : null; }
    private static string Hash(string path) { using var stream = File.OpenRead(path); return Convert.ToHexString(SHA256.HashData(stream)).ToLowerInvariant(); }
    private static string Redact(string text)
    {
        string profile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        return string.IsNullOrWhiteSpace(profile) ? text : text.Replace(profile, "%USERPROFILE%", StringComparison.OrdinalIgnoreCase);
    }
    private static void Record(string name, bool passed, object evidence, bool inconclusive = false)
    {
        string status = passed ? "passed" : inconclusive ? "inconclusive" : "failed";
        if (!passed) { if (inconclusive) incomplete++; else failures++; }
        Results.Add(new { name, status, evidence });
        Console.Error.WriteLine(status.ToUpperInvariant() + " " + name);
    }
    private static void NotRun(string name, string reason) { incomplete++; Results.Add(new { name, status = "not_run", reason }); }
    private static async Task<string> ReadBounded(StreamReader reader, int limit)
    {
        var text = new StringBuilder(); var buffer = new char[2048];
        while (await reader.ReadAsync(buffer) is var count && count > 0)
        {
            if (text.Length + count > limit) throw new InvalidDataException("Probe output exceeded its bound.");
            text.Append(buffer, 0, count);
        }
        return text.ToString();
    }
    private static void CopyChecked(string source, string destination)
    {
        string sourceRoot = Path.GetFullPath(source).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        if (Path.GetFullPath(destination).StartsWith(sourceRoot, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Test deployment may not recursively copy into its own source.");
        NativeSandbox.EnsureNoReparsePoints(source);
        Directory.CreateDirectory(destination);
        foreach (string file in Directory.EnumerateFiles(source, "*", SearchOption.AllDirectories))
        {
            NativeSandbox.EnsureNoReparsePoints(file);
            string relative = Path.GetRelativePath(source, file), target = Path.Combine(destination, relative);
            Directory.CreateDirectory(Path.GetDirectoryName(target)!); File.Copy(file, target, false);
            if (Hash(file) != Hash(target)) throw new IOException("Test executable copy integrity failure.");
        }
    }
}
