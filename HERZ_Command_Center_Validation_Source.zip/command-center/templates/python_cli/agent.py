#!/usr/bin/env python3
"""Original HERZ MIT CLI template; no third-party packages or network code.
Windows integration remains disabled until its runner and OS isolation are approved.
"""
import hashlib
import json
import pathlib
import sys

MAX_INPUT_BYTES = 1024 * 1024


def main():
    if sys.argv[1:] == ["--health"]:
        print(json.dumps({"ready": True, "protocol": "cli_json", "version": "2.0.0"}))
        return
    if sys.argv[1:]:
        raise ValueError("No custom execution arguments are supported")
    raw = sys.stdin.buffer.read(MAX_INPUT_BYTES + 1)
    if len(raw) > MAX_INPUT_BYTES:
        raise ValueError("Input exceeds 1 MiB")
    context = json.loads(raw.decode("utf-8"))
    text = context.get("input", {}).get("text")
    if not isinstance(text, str) or len(text) > 20000:
        raise ValueError("text must be a string of at most 20000 Unicode code points")
    workspace = pathlib.Path(context["workspace"]).resolve(strict=True)
    if workspace != pathlib.Path.cwd().resolve(strict=True):
        raise ValueError("The process working directory must be its assigned workspace")
    result = {"characters": len(text), "words": len(text.split()),
              "sha256": hashlib.sha256(text.encode("utf-8")).hexdigest()}
    output = workspace / "text_summary.json"
    with output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, allow_nan=False)
    print(json.dumps({"result": result, "artifacts": ["text_summary.json"]},
                     ensure_ascii=False, allow_nan=False))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, OSError, TypeError) as error:
        print(type(error).__name__ + ": " + str(error)[:300], file=sys.stderr)
        raise SystemExit(2)
