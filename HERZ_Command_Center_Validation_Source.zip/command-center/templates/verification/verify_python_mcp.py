#!/usr/bin/env python3
"""Real local protocol checks. Does not assert Windows isolation or activation."""
import hashlib
import json
import pathlib
import subprocess
import sys
import tempfile
import time

ROOT = pathlib.Path(__file__).resolve().parents[2]
OBSERVATIONS = []
START = time.monotonic()


def check(name, operation):
    start = time.monotonic()
    try:
        operation()
        row = {"name": name, "status": "passed"}
        print("PASS", name)
    except Exception as error:
        row = {"name": name, "status": "failed", "error": str(error)}
        print("FAIL", name, str(error))
    row["seconds"] = round(time.monotonic() - start, 6)
    OBSERVATIONS.append(row)


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def execute(script, workspace, text, extra=None):
    frame = {"taskId": "a" * 32, "input": {"text": text}, "workspace": str(workspace),
             "inputs": [], "knowledge": []}
    if extra:
        frame.update(extra)
    return subprocess.run([sys.executable, "-B", str(script)], cwd=workspace,
                          input=json.dumps(frame, ensure_ascii=False).encode("utf-8"),
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=12)


def health():
    for relative in ("templates/python_cli/agent.py", "templates/mcp_text/bridge.py"):
        run = subprocess.run([sys.executable, "-B", str(ROOT / relative), "--health"], capture_output=True, timeout=5)
        require(run.returncode == 0 and json.loads(run.stdout)["ready"] is True, "Health failed")


def cli_and_bridge():
    text = "مرحبا أحمد\nHello HERZ"
    expected = {"characters": len(text), "words": len(text.split()),
                "sha256": hashlib.sha256(text.encode("utf-8")).hexdigest()}
    for relative, output in (("templates/python_cli/agent.py", "text_summary.json"),
                             ("templates/mcp_text/bridge.py", "mcp_result.json")):
        with tempfile.TemporaryDirectory(prefix="herz-connector-") as temporary:
            workspace = pathlib.Path(temporary)
            run = execute(ROOT / relative, workspace, text)
            require(run.returncode == 0, run.stderr.decode("utf-8", "replace"))
            frame = json.loads(run.stdout)
            require(frame["result"] == expected and frame["artifacts"] == [output], "CLI response mismatch")
            require(json.loads((workspace / output).read_text()) == expected, "Output file mismatch")
            before = (workspace / output).read_bytes()
            duplicate = execute(ROOT / relative, workspace, "replacement")
            require(duplicate.returncode != 0 and (workspace / output).read_bytes() == before, "Existing output overwritten")


def workspace_and_size():
    with tempfile.TemporaryDirectory(prefix="herz-connector-invalid-") as temporary:
        workspace = pathlib.Path(temporary)
        for relative in ("templates/python_cli/agent.py", "templates/mcp_text/bridge.py"):
            mismatch = execute(ROOT / relative, workspace, "text", {"workspace": str(workspace.parent)})
            require(mismatch.returncode != 0, "Mismatched workspace accepted")
            huge = execute(ROOT / relative, workspace, "x" * 20001)
            require(huge.returncode != 0, "Oversized text accepted")


def protocol():
    # Distinct messages exercise lifecycle rejection, initialization, list/call,
    # notifications without responses, unsupported method and argument errors.
    lines = [
        {"jsonrpc": "2.0", "id": 0, "method": "tools/list", "params": {}},
        {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2025-11-25", "capabilities": {}, "clientInfo": {"name": "test", "version": "1.0"}}},
        {"jsonrpc": "2.0", "method": "notifications/initialized"},
        {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}},
        {"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {"name": "text_summary", "arguments": {"text": "نص عربي"}}},
        {"jsonrpc": "2.0", "id": 4, "method": "tools/call", "params": {"name": "shell", "arguments": {"command": "no execution"}}},
        {"jsonrpc": "2.0", "id": 5, "method": "tools/call", "params": {"name": "text_summary", "arguments": {"text": 10}}},
        {"jsonrpc": "2.0", "id": 6, "method": "unknown", "params": {}}]
    payload = b"\n".join(json.dumps(line, ensure_ascii=False).encode("utf-8") for line in lines) + b"\n"
    # This probes server parsing with ordered frames; the bridge test above is
    # the real client that waits for initialize before sending later requests.
    run = subprocess.run([sys.executable, "-B", str(ROOT / "templates/mcp_text/server.py")],
                         input=payload, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=8)
    require(run.returncode == 0, "MCP server failed")
    replies = [json.loads(line) for line in run.stdout.splitlines()]
    require([r["id"] for r in replies] == list(range(7)), "Unexpected notification response or ordering")
    require(replies[0]["error"]["code"] == -32000, "Preinitialize request accepted")
    require(replies[1]["result"]["protocolVersion"] == "2025-11-25", "Version negotiation mismatch")
    require(replies[2]["result"]["tools"][0]["name"] == "text_summary", "Tool list incorrect")
    result = replies[3]["result"]
    require(result["isError"] is False and result["structuredContent"]["words"] == 2, "Tool result incorrect")
    require(json.loads(result["content"][0]["text"]) == result["structuredContent"], "Structured/text result mismatch")
    require(replies[4]["error"]["code"] == -32602 and replies[5]["error"]["code"] == -32602, "Unknown tool/invalid arguments accepted")
    require(replies[6]["error"]["code"] == -32601, "Unknown method accepted")


check("python_and_bridge_health", health)
check("real_cli_and_mcp_bridge_arabic_files_and_no_overwrite", cli_and_bridge)
check("template_workspace_and_size_rejections", workspace_and_size)
check("mcp_lifecycle_tools_and_protocol_errors", protocol)
failed = sum(row["status"] != "passed" for row in OBSERVATIONS)
report = {"suite": "Python CLI and MCP stdio local source examples", "executed": len(OBSERVATIONS),
          "passed": len(OBSERVATIONS) - failed, "failed": failed,
          "seconds": round(time.monotonic() - START, 6), "python": sys.version.split()[0],
          "windowsExecution": False, "nativeIsolationTested": False, "windowsIntegrationEnabled": False,
          "actualSubprocesses": True, "observations": OBSERVATIONS}
(ROOT / "evidence").mkdir(exist_ok=True)
(ROOT / "evidence/python-mcp-connectors-tests.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
raise SystemExit(1 if failed else 0)
