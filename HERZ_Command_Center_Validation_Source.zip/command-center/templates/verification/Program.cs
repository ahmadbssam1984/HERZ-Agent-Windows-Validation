using System.Diagnostics;
using System.Text.Json;
using System.Text.Json.Nodes;
using Herz.Core;
using Herz.ConnectorExamples;

var json = new JsonSerializerOptions
{
    PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
    PropertyNameCaseInsensitive = true
};
if (args.Contains("--stats-worker"))
{
    var context = JsonSerializer.Deserialize<TaskContext>(await Console.In.ReadToEndAsync(), json) ?? throw new InvalidDataException();
    var output = BuiltinStats.Execute(context.Input, context.Workspace, CancellationToken.None);
    Console.WriteLine(JsonSerializer.Serialize(new { output.Result, output.Artifacts }, json));
    return;
}

string root = Path.GetFullPath(args.Single());
string temporary = Path.Combine(Path.GetTempPath(), "herz-connectors-" + Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(temporary);
var observations = new List<object>();
int failed = 0;
var watch = Stopwatch.StartNew();
void Assert(bool condition, string message)
{
    if (!condition)
        throw new Exception(message);
}

async Task Check(string name, Func<Task> test)
{
    try
    {
        await test();
        observations.Add(new { name, status = "passed" });
        Console.WriteLine("PASS " + name);
    }
    catch (Exception error)
    {
        failed++;
        observations.Add(new { name, status = "failed", error = error.Message });
        Console.WriteLine("FAIL " + name + ": " + error.Message);
    }
}

string[] manifests = ["examples/stats_dotnet/agent.json", "examples/node_reporter/agent.json", "templates/python_cli/agent.json", "templates/mcp_text/agent.json", "templates/mcp_text/server-agent.json"];
using var disabled = new CommandCenter(Path.Combine(temporary, "registration"), new UnavailableAgentRunner("Windows isolation not tested in this verifier"));
foreach (string relative in manifests)
{
    await Check("inspect_register_" + relative, () =>
    {
        string path = Path.Combine(root, relative);
        var inspection = disabled.InspectAgent(path);
        Assert(inspection.Allowed && inspection.Definition is not null, inspection.Reason);
        var registered = disabled.RegisterAgent(path, inspection.ApprovalDigest);
        Assert(!registered.Enabled && !registered.Readiness.Ready, "An unverified runner was enabled");
        Assert(registered.Definition.FileHashes.ContainsKey("LICENSE"), "License omitted from reviewed source snapshot");
        return Task.CompletedTask;
    });
}

using var running = new CommandCenter(Path.Combine(temporary, "cooperation"), new ExampleTestRunner(root));
foreach (string relative in manifests.Take(2))
{
    var inspected = running.InspectAgent(Path.Combine(root, relative));
    Assert(inspected.Allowed, inspected.Reason);
    running.RegisterAgent(Path.Combine(root, relative), inspected.ApprovalDigest);
}

await Check("production_manifests_real_dotnet_reference_and_existing_node_script", async () =>
{
    var plan = running.PreviewPlan("حلل الأرقام ١٢، ١٨، ٢٠، ١٠ ثم أنشئ تقريرًا");
    var tasks = running.SubmitPlan(plan.Id);
    await running.RunNextAsync();
    await running.RunNextAsync();
    var stats = running.TaskDetails(tasks[0].Id);
    var report = running.TaskDetails(tasks[1].Id);
    Assert(stats.Status == "succeeded", stats.Error ?? "Stats failed");
    Assert(report.Status == "succeeded", report.Error ?? "Report failed");
    Assert(stats.Result!["sum"]!.GetValue<decimal>() == 60 && stats.Result["mean"]!.GetValue<decimal>() == 15, "Wrong result");
    string html = File.ReadAllText(report.Artifacts.Single().FullPath);
    Assert(html.Contains("<td>60</td>") && html.Contains("<td>15</td>"), "HTML values missing");
    Assert(html.Contains("Content-Security-Policy"), "Local report CSP missing");
});
await Check("production_numeric_manifest_rejects_201_values_and_out_of_range", () =>
{
    foreach (var values in new[]
    {
        new JsonArray(Enumerable.Range(0, 201).Select(x => (JsonNode? )JsonValue.Create(x)).ToArray()),
        new JsonArray(1000000001)
    }

    )
    {
        bool rejected = false;
        try
        {
            running.Submit(new TaskSubmission("stats_dotnet", new JsonObject { ["numbers"] = values }));
        }
        catch (PolicyException)
        {
            rejected = true;
        }

        Assert(rejected, "Numeric manifest limit was not enforced");
    }

    return Task.CompletedTask;
});
await Check("production_decimal_manifest_and_reference", async () =>
{
    var input = new JsonObject
    {
        ["numbers"] = new JsonArray(JsonValue.Create(0.1m), JsonValue.Create(0.2m))
    };
    var submitted = running.Submit(new TaskSubmission("stats_dotnet", input));
    await running.RunNextAsync();
    var done = running.TaskDetails(submitted.Id);
    Assert(done.Status == "succeeded", done.Error ?? "Decimal failed");
    Assert(done.Result!["sum"]!.GetValue<decimal>() == 0.3m, "Decimal sum mismatch");
});
var evidence = new
{
    suite = "Connector production manifests and local reference processes",
    executed = observations.Count,
    passed = observations.Count - failed,
    failed,
    seconds = watch.Elapsed.TotalSeconds,
    windowsExecution = false,
    nativeIsolationTested = false,
    actualDotnetReferenceCompiledAndExecuted = true,
    actualExistingNodeScriptExecuted = true,
    externalTemplatesEnabled = false,
    observations
};
Directory.CreateDirectory(Path.Combine(root, "evidence"));
await File.WriteAllTextAsync(Path.Combine(root, "evidence/connector-manifests-tests.json"), JsonSerializer.Serialize(evidence, new JsonSerializerOptions(json) { WriteIndented = true }));
Environment.ExitCode = failed == 0 ? 0 : 1;
sealed class ExampleTestRunner(string root) : IAgentRunner
{
    private readonly List<Process> owned = [];
    public IsolationStatus Probe() => new(true, "Linux development test adapter", "No claim of Windows or OS isolation", false);
    public AgentReadiness Check(AgentDefinition definition) => new(definition.Id is "stats_dotnet" or "report_node", "Only these local test processes are wired");
    public async Task<AgentExecution> ExecuteAsync(AgentDefinition definition, TaskContext context, CancellationToken cancellationToken)
    {
        var start = new ProcessStartInfo
        {
            UseShellExecute = false,
            RedirectStandardInput = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            WorkingDirectory = context.Workspace
        };
        if (definition.Id == "stats_dotnet")
        {
            start.FileName = Environment.ProcessPath!;
            if (Path.GetFileNameWithoutExtension(start.FileName) == "dotnet")
                start.ArgumentList.Add(typeof(ExampleTestRunner).Assembly.Location);
            start.ArgumentList.Add("--stats-worker");
        }
        else
        {
            start.FileName = "node";
            start.ArgumentList.Add(Path.Combine(root, "examples/node_reporter/agent.js"));
        }

        using var process = Process.Start(start) ?? throw new IOException("Test child failed to start");
        owned.Add(process);
        try
        {
            using var registration = cancellationToken.Register(() =>
            {
                try
                {
                    if (!process.HasExited)
                        process.Kill(true);
                }
                catch (InvalidOperationException)
                {
                }
            });
            var output = process.StandardOutput.ReadToEndAsync(cancellationToken);
            var error = process.StandardError.ReadToEndAsync(cancellationToken);
            await process.StandardInput.WriteAsync(JsonSerializer.Serialize(context, new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase }));
            process.StandardInput.Close();
            await process.WaitForExitAsync(cancellationToken);
            string text = await output;
            string diagnostic = await error;
            if (process.ExitCode != 0)
                return new(process.ExitCode, new JsonObject(), [], diagnostic);
            var frame = JsonNode.Parse(text)!.AsObject();
            return new(0, frame["result"]!.AsObject(), frame["artifacts"]!.AsArray().Select(x => x!.GetValue<string>()).ToArray());
        }
        finally
        {
            owned.Remove(process);
        }
    }

    public void StopAll()
    {
        foreach (var process in owned.ToArray())
        {
            try
            {
                if (!process.HasExited)
                    process.Kill(true);
            }
            catch (InvalidOperationException)
            {
            }
        }
    }
}
