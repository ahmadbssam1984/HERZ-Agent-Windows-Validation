#!/usr/bin/env python3
"""Original HERZ MIT bridge: one bounded CLI task -> local MCP stdio -> JSON file.
Does not enable itself in the Windows manager. The managed runner must provide
OS isolation and terminate the whole process tree when this bridge is canceled.
"""
import hashlib
import json
import pathlib
import queue
import subprocess
import sys
import threading

LIMIT = 1024 * 1024
PROTOCOL = "2025-11-25"


def main():
    if sys.argv[1:] == ["--health"]:
        print(json.dumps({"ready": True, "protocol": "cli_json_to_mcp_stdio", "version": "2.0.0"}))
        return
    if sys.argv[1:]:
        raise ValueError("No custom arguments")
    raw = sys.stdin.buffer.read(LIMIT + 1)
    if len(raw) > LIMIT:
        raise ValueError("Input exceeds 1 MiB")
    context = json.loads(raw.decode("utf-8"))
    text = context.get("input", {}).get("text")
    if not isinstance(text, str) or len(text) > 20000:
        raise ValueError("Invalid text input")
    workspace = pathlib.Path(context["workspace"]).resolve(strict=True)
    if workspace != pathlib.Path.cwd().resolve(strict=True):
        raise ValueError("Workspace differs from working directory")
    server = pathlib.Path(__file__).with_name("server.py").resolve(strict=True)
    process = subprocess.Popen([sys.executable, "-I", str(server)], stdin=subprocess.PIPE,
                               stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                               cwd=workspace)
    responses = queue.Queue(maxsize=8)

    def read_output():
        try:
            for _ in range(8):
                line = process.stdout.readline(LIMIT + 1)
                if not line:
                    responses.put_nowait(RuntimeError("MCP server closed output"))
                    return
                if len(line) > LIMIT:
                    responses.put_nowait(ValueError("MCP response exceeds 1 MiB"))
                    return
                responses.put_nowait(json.loads(line.decode("utf-8")))
        except (ValueError, UnicodeError, OSError, queue.Full) as problem:
            try:
                responses.put_nowait(problem)
            except queue.Full:
                pass

    thread = threading.Thread(target=read_output, daemon=True)
    thread.start()

    def send(message):
        process.stdin.write(json.dumps(message, ensure_ascii=False, allow_nan=False).encode("utf-8") + b"\n")
        process.stdin.flush()

    def call(ident, method, params):
        send({"jsonrpc": "2.0", "id": ident, "method": method, "params": params})
        response = responses.get(timeout=5)
        if isinstance(response, Exception):
            raise response
        if not isinstance(response, dict) or response.get("jsonrpc") != "2.0" or response.get("id") != ident or "error" in response:
            raise ValueError("MCP request failed or response id did not match")
        return response["result"]

    try:
        ready = call(1, "initialize", {"protocolVersion": PROTOCOL, "capabilities": {},
                                      "clientInfo": {"name": "herz-local-bridge", "version": "2.0.0"}})
        if ready.get("protocolVersion") != PROTOCOL:
            raise ValueError("MCP version mismatch")
        send({"jsonrpc": "2.0", "method": "notifications/initialized"})
        listed = call(2, "tools/list", {})
        if [tool.get("name") for tool in listed.get("tools", [])] != ["text_summary"]:
            raise ValueError("Unexpected MCP tool list")
        output = call(3, "tools/call", {"name": "text_summary", "arguments": {"text": text}})
        data = output.get("structuredContent")
        expected = {"characters": len(text), "words": len(text.split()),
                    "sha256": hashlib.sha256(text.encode("utf-8")).hexdigest()}
        if output.get("isError") or data != expected:
            raise ValueError("MCP result failed independent validation")
        with (workspace / "mcp_result.json").open("x", encoding="utf-8") as stream:
            json.dump(data, stream, ensure_ascii=False, allow_nan=False)
        print(json.dumps({"result": data, "artifacts": ["mcp_result.json"]}, ensure_ascii=False))
    finally:
        if process.stdin:
            process.stdin.close()
        try:
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            process.terminate()
            try:
                process.wait(timeout=1)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=1)
        if process.stdout:
            process.stdout.close()
        thread.join(timeout=1)


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, TypeError, OSError, RuntimeError, queue.Empty, subprocess.SubprocessError) as error:
        print(type(error).__name__ + ": " + str(error)[:300], file=sys.stderr)
        raise SystemExit(2)
