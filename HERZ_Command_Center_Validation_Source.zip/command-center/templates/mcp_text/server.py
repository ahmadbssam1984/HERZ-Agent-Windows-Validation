#!/usr/bin/env python3
"""Original HERZ MIT minimal MCP stdio server, protocol 2025-11-25.
Only text_summary is exposed. No HTTP, network, sampling or tool delegation.
This is a protocol example, not an enabled Windows integration.
"""
import hashlib
import json
import sys

PROTOCOL = "2025-11-25"
LIMIT = 1024 * 1024
INPUT_SCHEMA = {"type": "object", "properties": {"text": {"type": "string", "maxLength": 20000}},
                "required": ["text"], "additionalProperties": False}
OUTPUT_SCHEMA = {"type": "object", "properties": {"characters": {"type": "integer", "minimum": 0},
                  "words": {"type": "integer", "minimum": 0}, "sha256": {"type": "string", "maxLength": 64}},
                 "required": ["characters", "words", "sha256"], "additionalProperties": False}


def emit(message):
    sys.stdout.buffer.write(json.dumps(message, ensure_ascii=False, allow_nan=False,
                                       separators=(",", ":")).encode("utf-8") + b"\n")
    sys.stdout.buffer.flush()


def error(ident, code, message):
    emit({"jsonrpc": "2.0", "id": ident, "error": {"code": code, "message": message}})


def main():
    initialized = False
    negotiated = False
    while True:
        raw = sys.stdin.buffer.readline(LIMIT + 1)
        if not raw:
            return
        if len(raw) > LIMIT:
            error(None, -32600, "Message exceeds 1 MiB")
            raise SystemExit(2)
        try:
            message = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeError):
            error(None, -32700, "Invalid JSON")
            continue
        if not isinstance(message, dict) or message.get("jsonrpc") != "2.0" or not isinstance(message.get("method"), str):
            error(None, -32600, "Invalid request")
            continue
        method = message["method"]
        if "id" not in message:
            if method == "notifications/initialized" and negotiated:
                initialized = True
            continue
        ident = message["id"]
        if isinstance(ident, bool) or not isinstance(ident, (int, str)):
            error(None, -32600, "Invalid request id")
            continue
        params = message.get("params", {})
        if not isinstance(params, dict):
            error(ident, -32602, "Parameters must be an object")
            continue
        if method == "initialize":
            if negotiated:
                error(ident, -32600, "Already initialized")
                continue
            if not isinstance(params.get("protocolVersion"), str) or not isinstance(params.get("clientInfo"), dict):
                error(ident, -32602, "Missing initialize parameters")
                continue
            negotiated = True
            result = {"protocolVersion": PROTOCOL, "capabilities": {"tools": {"listChanged": False}},
                      "serverInfo": {"name": "herz-local-text", "version": "2.0.0"}}
        elif method == "ping":
            result = {}
        elif not initialized:
            error(ident, -32000, "Complete initialize and notifications/initialized first")
            continue
        elif method == "tools/list":
            result = {"tools": [{"name": "text_summary", "description": "Count local text code points and whitespace-separated words; compute SHA-256.",
                                 "inputSchema": INPUT_SCHEMA, "outputSchema": OUTPUT_SCHEMA}]}
        elif method == "tools/call":
            arguments = params.get("arguments", {})
            if params.get("name") != "text_summary" or not isinstance(arguments, dict) or set(arguments) != {"text"}:
                error(ident, -32602, "Expected text_summary with only text")
                continue
            text = arguments["text"]
            if not isinstance(text, str) or len(text) > 20000:
                error(ident, -32602, "text must contain at most 20000 code points")
                continue
            data = {"characters": len(text), "words": len(text.split()),
                    "sha256": hashlib.sha256(text.encode("utf-8")).hexdigest()}
            result = {"content": [{"type": "text", "text": json.dumps(data, ensure_ascii=False)}],
                      "structuredContent": data, "isError": False}
        else:
            error(ident, -32601, "Method not found")
            continue
        emit({"jsonrpc": "2.0", "id": ident, "result": result})


if __name__ == "__main__":
    main()
