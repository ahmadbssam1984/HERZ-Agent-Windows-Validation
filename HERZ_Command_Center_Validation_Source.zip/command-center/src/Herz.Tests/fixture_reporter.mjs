// Original HERZ MIT test fixture. No runtime dependency or network access.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
if(process.argv.includes('--health')){console.log(JSON.stringify({ready:true}));process.exit(0);}
let text='';for await(const chunk of process.stdin)text+=chunk;
const request=JSON.parse(text);
const artifact=request.inputs.find(a=>a.relativePath==='stats.json');
if(!artifact)throw new Error('Verified stats dependency is missing');
const bytes=fs.readFileSync(artifact.fullPath);
if(crypto.createHash('sha256').update(bytes).digest('hex')!==artifact.sha256)throw new Error('Dependency hash mismatch');
const stats=JSON.parse(bytes);
const escape=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const title=request.input.title||'HERZ report';
const html='<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>'+escape(title)+'</title><h1>'+escape(title)+'</h1><p>المجموع: '+stats.sum+'</p><p>المتوسط: '+stats.mean+'</p><p data-source-sha256="'+artifact.sha256+'">'+artifact.sha256+'</p></html>';
fs.writeFileSync(path.join(request.workspace,'report.html'),html,{flag:'wx'});
console.log(JSON.stringify({result:{title,sum:stats.sum,mean:stats.mean,sourceSha256:artifact.sha256},artifacts:['report.html']}));
