using System.Diagnostics;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using Herz.Core;
using Microsoft.Data.Sqlite;

var json = new JsonSerializerOptions
{
    PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
    PropertyNameCaseInsensitive = true
};
if (args.Contains("--sleep-witness"))
{
    await Task.Delay(TimeSpan.FromSeconds(30));
    return;
}
if (args.Contains("--stats-worker"))
{
    var request = JsonNode.Parse(await Console.In.ReadToEndAsync())!.AsObject();
    var input = request["input"]!.AsObject();
    if (input["wait"]?.GetValue<bool>() == true)
        await Task.Delay(TimeSpan.FromSeconds(30));
    var values = input["numbers"]!.AsArray().Select(x => x!.GetValue<decimal>()).ToArray();
    var workerResult = new JsonObject
    {
        ["count"] = values.Length,
        ["sum"] = values.Sum(),
        ["mean"] = values.Average(),
        ["min"] = values.Min(),
        ["max"] = values.Max(),
        ["numbers"] = input["numbers"]!.DeepClone()
    };
    await File.WriteAllTextAsync(Path.Combine(request["workspace"]!.GetValue<string>(), "stats.json"), workerResult.ToJsonString());
    Console.WriteLine(new JsonObject { ["result"] = workerResult, ["artifacts"] = new JsonArray("stats.json") }.ToJsonString());
    return;
}

var projectRoot = Path.GetFullPath(args.FirstOrDefault(a => !a.StartsWith('-')) ?? Path.Combine(AppContext.BaseDirectory, "../../../../../"));
var testingRoot = Path.Combine(Path.GetTempPath(), "herz-core-tests-" + Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(testingRoot);
var filter = args.FirstOrDefault(a => a.StartsWith("--filter="))?[9..];
var evidence = new List<object>();
var failures = 0;
var timer = Stopwatch.StartNew();
void Require(bool condition, string message)
{
    if (!condition)
        throw new Exception(message);
}

void Throws(Action action, string message)
{
    try
    {
        action();
    }
    catch (PolicyException)
    {
        return;
    }

    throw new Exception("Expected rejection: " + message);
}

async Task Test(string name, Func<Task> run)
{
    if (filter != null && !name.Contains(filter, StringComparison.Ordinal))
        return;
    var t = Stopwatch.StartNew();
    try
    {
        await run();
        evidence.Add(new { name, status = "passed", milliseconds = t.Elapsed.TotalMilliseconds });
        Console.WriteLine("PASS " + name);
    }
    catch (Exception e)
    {
        failures++;
        evidence.Add(new { name, status = "failed", error = e.ToString(), milliseconds = t.Elapsed.TotalMilliseconds });
        Console.WriteLine("FAIL " + name + ": " + e.Message);
    }
}

const string license = "MIT License\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files. THE SOFTWARE IS PROVIDED AS IS, WITHOUT WARRANTY OF ANY KIND.";
string Manifest(string folder, string id, string runtime, string capability, int wall = 10)
{
    Directory.CreateDirectory(folder);
    File.WriteAllText(Path.Combine(folder, "entry.txt"), "Reviewed original HERZ test fixture");
    var manifest = new AgentDefinition
    {
        Id = id,
        Name = id,
        Runtime = runtime,
        Entry = "entry.txt",
        Capabilities = [capability],
        LicenseSpdx = "MIT",
        LicenseSource = "HERZ original test fixture",
        LicenseText = license,
        Idempotent = true,
        WallSeconds = wall,
        InputSchema = new JsonObject
        {
            ["type"] = "object"
        },
        OutputSchema = new JsonObject
        {
            ["type"] = "object"
        }
    };
    var path = Path.Combine(folder, "agent.json");
    File.WriteAllText(path, JsonSerializer.Serialize(manifest, json));
    return path;
}

var statsManifest = Manifest(Path.Combine(testingRoot, "sources/stats"), "stats_dotnet", "dotnet", "numeric_analysis");
var reportManifest = Manifest(Path.Combine(testingRoot, "sources/report"), "report_node", "node", "html_reporting");
var runner = new RealTestRunner(projectRoot);
var data = Path.Combine(testingRoot, "main");
using var core = new CommandCenter(data, runner);
void Register(CommandCenter c, string path)
{
    var i = c.InspectAgent(path);
    Require(i.Allowed && i.Definition != null, i.Reason);
    c.RegisterAgent(path, i.ApprovalDigest);
}

await Test("register_two_reviewed_agents", () =>
{
    Register(core, statsManifest);
    Register(core, reportManifest);
    Require(core.Agents().Count == 2, "agent count");
    return Task.CompletedTask;
});
await Test("paid_cloud_unknown_license_rejected", () =>
{
    foreach (var edit in new Action<JsonObject>[]
    {
        o => o["cost"] = "paid",
        o => o["cloud"] = true,
        o => o["licenseSpdx"] = "Unknown",
        o => o["network"] = "allow"
    }

    )
    {
        var folder = Path.Combine(testingRoot, "bad-" + Guid.NewGuid().ToString("N"));
        var path = Manifest(folder, "bad_agent", "node", "misc");
        var node = JsonNode.Parse(File.ReadAllText(path))!.AsObject();
        edit(node);
        File.WriteAllText(path, node.ToJsonString());
        Require(!core.InspectAgent(path).Allowed, "unsafe registration accepted");
    }

    Require(core.Audit("blocked").Count >= 4, "denials were not persisted");
    return Task.CompletedTask;
});
IReadOnlyList<TaskRecord>? planTasks = null;
await Test("arabic_plan_two_real_processes_dotnet_and_node", async () =>
{
    var p = core.PreviewPlan("حلل الأرقام ١٢، ١٨، ٢٠، ١٠ ثم أنشئ تقريرًا");
    Require(p.Source == "deterministic_rules_not_llm", "false model claim");
    planTasks = core.SubmitPlan(p.Id);
    Require(core.SubmitPlan(p.Id).Select(t => t.Id).SequenceEqual(planTasks.Select(t => t.Id)), "double plan submission duplicated work");
    Require(planTasks.Count == 2, "plan length");
    Require(await core.RunNextAsync(), "stats not selected");
    Require(await core.RunNextAsync(), "report not selected");
    var first = core.TaskDetails(planTasks[0].Id);
    var second = core.TaskDetails(planTasks[1].Id);
    Require(first.Status == "succeeded", first.Error ?? "stats failed");
    Require(second.Status == "succeeded", second.Error ?? "report failed");
    Require(first.Result!["sum"]!.GetValue<decimal>() == 60 && first.Result["mean"]!.GetValue<decimal>() == 15, "incorrect arithmetic");
    Require(File.ReadAllText(second.Artifacts.Single().FullPath).Contains("المتوسط: 15"), "report content mismatch");
    Require(core.Messages(second.Id).Any(m => m.Sender == "stats_dotnet" && m.Receiver == "report_node"), "handoff missing");
});
await Test("idempotency_and_double_plan_submit", () =>
{
    var input = new JsonObject
    {
        ["numbers"] = new JsonArray(1, 2, 3)
    };
    var a = core.Submit(new("stats_dotnet", input, IdempotencyKey: "same-request"));
    var b = core.Submit(new("stats_dotnet", input, IdempotencyKey: "same-request"));
    Require(a.Id == b.Id, "duplicate action queued");
    Throws(() => core.Submit(new("stats_dotnet", new JsonObject { ["numbers"] = new JsonArray(9) }, IdempotencyKey: "same-request")), "changed input accepted");
    core.Cancel(a.Id);
    return Task.CompletedTask;
});
await Test("priority_and_dependency_order", async () =>
{
    var low = core.Submit(new("stats_dotnet", new JsonObject { ["numbers"] = new JsonArray(1, 2) }, Priority: -10));
    var high = core.Submit(new("stats_dotnet", new JsonObject { ["numbers"] = new JsonArray(3, 4) }, Priority: 10));
    await core.RunNextAsync();
    Require(core.TaskDetails(high.Id).Status == "succeeded", "priority ignored");
    Require(core.TaskDetails(low.Id).Status == "queued", "low ran first");
    core.Cancel(low.Id);
    Throws(() => core.Submit(new("stats_dotnet", new(), Dependencies: ["unknown"])), "unknown dependency");
});
await Test("source_change_revokes_execution", async () =>
{
    var task = core.Submit(new("stats_dotnet", new JsonObject { ["numbers"] = new JsonArray(1, 2) }));
    File.AppendAllText(Path.Combine(Path.GetDirectoryName(statsManifest)!, "entry.txt"), " altered");
    await core.RunNextAsync();
    Require(core.TaskDetails(task.Id).Status == "blocked", "modified agent ran");
    Register(core, statsManifest);
});
await Test("output_claim_is_not_success", async () =>
{
    runner.ReturnMissingArtifact = true;
    var task = core.Submit(new("stats_dotnet", new JsonObject { ["numbers"] = new JsonArray(1, 2) }));
    await core.RunNextAsync();
    runner.ReturnMissingArtifact = false;
    Require(core.TaskDetails(task.Id).Status == "failed", "missing file reported success");
});
await Test("output_traversal_rejected", async () =>
{
    runner.ReturnEscapingArtifact = true;
    var task = core.Submit(new("stats_dotnet", new JsonObject { ["numbers"] = new JsonArray(1, 2) }));
    await core.RunNextAsync();
    runner.ReturnEscapingArtifact = false;
    Require(core.TaskDetails(task.Id).Status == "failed", "escaping path accepted");
});
await Test("scoped_knowledge_fts_rollback", () =>
{
    var shared = core.SaveKnowledge(new("instruction", "shared", "تعليمات الجودة", "تحقق من الأرقام قبل التسليم", true));
    core.SaveKnowledge(new("reference", "stats_dotnet", "مرجع التحليل", "الأرقام تحسب محليًا", true));
    core.SaveKnowledge(new("correction", "report_node", "تصحيح خاص", "سر التقرير المميز", true));
    Require(core.SearchKnowledge("سر التقرير", "stats_dotnet").Count == 0, "agent knowledge leaked");
    Require(core.SearchKnowledge("الأرقام", "stats_dotnet").Count >= 1, "Arabic FTS unavailable");
    core.SaveKnowledge(new("instruction", "shared", "عنوان معدل", "قواعد جديدة", true, shared.Id));
    Require(core.KnowledgeHistory(shared.Id).Count == 2, "version not retained");
    var restored = core.RollbackKnowledge(shared.Id, 1);
    Require(restored.Title == "تعليمات الجودة", "rollback title wrong");
    Throws(() => core.SaveKnowledge(new("instruction", "shared", "unapproved", "text", false)), "unapproved instruction");
    return Task.CompletedTask;
});
await Test("backup_restore_database_and_artifact_integrity", () =>
{
    var b = core.CreateBackup();
    core.SaveKnowledge(new("reference", "shared", "بعد النسخ", "يجب ألا يبقى بعد الاستعادة", true));
    core.EmergencyStop();
    core.RestoreBackup(b.Id);
    Require(core.Knowledge().All(k => k.Title != "بعد النسخ"), "backup not restored");
    Require(core.Tasks().Where(t => t.Status == "succeeded").All(t => t.Artifacts.All(a => File.Exists(a.FullPath))), "artifact lost");
    Require(core.Agents().All(a => !a.Enabled), "restore auto-enabled agents");
    core.ControlAgent("stats_dotnet", "start");
    core.ControlAgent("report_node", "start");
    core.Resume();
    return Task.CompletedTask;
});
await Test("tampered_backup_rejected", () =>
{
    var b = core.CreateBackup();
    File.AppendAllText(b.Path, "corruption");
    core.EmergencyStop();
    Throws(() => core.RestoreBackup(b.Id), "corrupt zip accepted");
    core.Resume();
    return Task.CompletedTask;
});
await Test("uncertain_crash_not_reexecuted", () =>
{
    var other = Path.Combine(testingRoot, "recover");
    string id;
    using (var c = new CommandCenter(other, runner))
    {
        Register(c, statsManifest);
        id = c.Submit(new("stats_dotnet", new JsonObject { ["numbers"] = new JsonArray(2, 4) })).Id;
    }

    using (var conn = new SqliteConnection("Data Source=" + Path.Combine(other, "center.sqlite3")))
    {
        conn.Open();
        using var command = conn.CreateCommand();
        command.CommandText = "UPDATE tasks SET status='running',attempts=1 WHERE id=$id";
        command.Parameters.AddWithValue("$id", id);
        command.ExecuteNonQuery();
    }

    using var recovered = new CommandCenter(other, runner);
    Require(recovered.TaskDetails(id).Status == "needs_review", "uncertain action auto-requeued");
    return Task.CompletedTask;
});
await Test("committed_result_recovers_without_reexecution", () =>
{
    var other = Path.Combine(testingRoot, "recover-result");
    string id;
    using (var c = new CommandCenter(other, runner))
    {
        Register(c, statsManifest);
        id = c.Submit(new("stats_dotnet", new JsonObject { ["numbers"] = new JsonArray(5, 7) })).Id;
        c.RunNextAsync().GetAwaiter().GetResult();
        Require(c.TaskDetails(id).Status == "succeeded", "initial fixture failed");
    }

    using (var conn = new SqliteConnection("Data Source=" + Path.Combine(other, "center.sqlite3")))
    {
        conn.Open();
        using var command = conn.CreateCommand();
        command.CommandText = "UPDATE tasks SET status='running',result=NULL,artifacts='[]' WHERE id=$id";
        command.Parameters.AddWithValue("$id", id);
        command.ExecuteNonQuery();
    }

    using var recovered = new CommandCenter(other, runner);
    Require(recovered.TaskDetails(id).Status == "succeeded" && recovered.TaskDetails(id).Result!["sum"]!.GetValue<decimal>() == 12, "committed result not recovered");
    return Task.CompletedTask;
});
await Test("cancellation_kills_only_owned_process", async () =>
{
    var witnessStart = new ProcessStartInfo(Environment.ProcessPath!) { UseShellExecute = false };
    if (Path.GetFileNameWithoutExtension(witnessStart.FileName) == "dotnet")
        witnessStart.ArgumentList.Add(typeof(RealTestRunner).Assembly.Location);
    witnessStart.ArgumentList.Add("--sleep-witness");
    using var unrelated = Process.Start(witnessStart)!;
    var task = core.Submit(new("stats_dotnet", new JsonObject { ["numbers"] = new JsonArray(1, 2), ["wait"] = true }));
    var executing = core.RunNextAsync();
    await Task.Delay(250);
    core.Cancel(task.Id);
    await executing;
    Require(core.TaskDetails(task.Id).Status == "cancelled", "cancel did not settle");
    Require(!unrelated.HasExited, "unrelated process killed");
    unrelated.Kill();
});
await Test("emergency_persists_and_rejects_new_work", async () =>
{
    var task = core.Submit(new("stats_dotnet", new JsonObject { ["numbers"] = new JsonArray(1, 2), ["wait"] = true }));
    var executing = core.RunNextAsync();
    await Task.Delay(250);
    core.EmergencyStop();
    await executing;
    Require(core.Dashboard().Paused, "pause not set");
    Throws(() => core.Submit(new("stats_dotnet", new())), "accepted work while paused");
    core.Resume();
});
await Test("unavailable_isolation_never_executes", async () =>
{
    using var blocked = new CommandCenter(Path.Combine(testingRoot, "blocked"), new UnavailableAgentRunner("Native isolation not proved"));
    Register(blocked, statsManifest);
    var task = blocked.Submit(new("stats_dotnet", new JsonObject { ["numbers"] = new JsonArray(1, 2) }));
    Require(!await blocked.RunNextAsync(), "unisolated execution occurred");
    Require(blocked.TaskDetails(task.Id).Status == "queued", "unexpected task state");
    Throws(() => blocked.ControlAgent("stats_dotnet", "start"), "unisolated agent enabled");
});
await Test("independent_decimal_arithmetic_verification", async () =>
{
    var task = core.Submit(new("stats_dotnet", new JsonObject { ["numbers"] = new JsonArray(JsonValue.Create(0.1m), JsonValue.Create(0.2m)) }));
    await core.RunNextAsync();
    Require(core.TaskDetails(task.Id).Status == "succeeded", core.TaskDetails(task.Id).Error ?? "decimal task failed");
    Require(core.TaskDetails(task.Id).Result!["sum"]!.GetValue<decimal>() == 0.3m, "decimal sum wrong");
});
await Test("explicit_declarations_and_windows_paths", () =>
{
    foreach (var name in new[]
    {
        "cloud",
        "cost",
        "network"
    }

    )
    {
        var path = Manifest(Path.Combine(testingRoot, "missing-" + name), "bad_agent", "node", "misc");
        var o = JsonNode.Parse(File.ReadAllText(path))!.AsObject();
        o.Remove(name);
        File.WriteAllText(path, o.ToJsonString());
        Require(!core.InspectAgent(path).Allowed, "missing declaration accepted");
    }

    foreach (var entry in new[]
    {
        "../entry.txt",
        "..\\entry.txt",
        "NUL",
        "file:stream",
        "C:\\Windows\\test",
        "trailing."
    }

    )
    {
        var path = Manifest(Path.Combine(testingRoot, "path-" + Guid.NewGuid().ToString("N")), "bad_agent", "node", "misc");
        var o = JsonNode.Parse(File.ReadAllText(path))!.AsObject();
        o["entry"] = entry;
        File.WriteAllText(path, o.ToJsonString());
        Require(!core.InspectAgent(path).Allowed, "unsafe Windows path accepted");
    }

    return Task.CompletedTask;
});
await Test("timeout_reaches_real_owned_process", async () =>
{
    var path = Manifest(Path.Combine(testingRoot, "timeout-source"), "stats_dotnet", "dotnet", "numeric_analysis", 1);
    using var c = new CommandCenter(Path.Combine(testingRoot, "timeout"), runner);
    Register(c, path);
    var task = c.Submit(new("stats_dotnet", new JsonObject { ["numbers"] = new JsonArray(1, 2), ["wait"] = true }));
    await c.RunNextAsync();
    Require(c.TaskDetails(task.Id).Status == "timed_out", "wall timeout not applied");
});
await Test("knowledge_and_pause_survive_restart", () =>
{
    var other = Path.Combine(testingRoot, "knowledge-restart");
    string id;
    using (var c = new CommandCenter(other, runner))
    {
        id = c.SaveKnowledge(new("correction", "shared", "تصحيح دائم", "احسب النتيجة من المصدر", true)).Id;
        c.SaveKnowledge(new("correction", "shared", "نسخة ثانية", "نص معدل", true, id));
        c.RollbackKnowledge(id, 1);
        c.EmergencyStop();
    }

    using var restored = new CommandCenter(other, runner);
    Require(restored.Knowledge().Single().Title == "تصحيح دائم" && restored.KnowledgeHistory(id).Count == 2, "knowledge or history lost");
    Require(restored.Dashboard().Paused, "emergency state lost");
    return Task.CompletedTask;
});
await Test("restore_failure_preserves_previous_state", () =>
{
    var backup = core.CreateBackup();
    var marker = core.SaveKnowledge(new("reference", "shared", "حالة يجب الحفاظ عليها", "تبقى عند فشل الاستعادة", true));
    var corruptDb = Path.Combine(testingRoot, "corrupt-restore.sqlite3");
    JsonObject manifest;
    using (var zip = ZipFile.Open(backup.Path, ZipArchiveMode.Read))
    {
        zip.GetEntry("center.sqlite3")!.ExtractToFile(corruptDb);
        using var reader = new StreamReader(zip.GetEntry("manifest.json")!.Open());
        manifest = JsonNode.Parse(reader.ReadToEnd())!.AsObject();
    }

    using (var conn = new SqliteConnection("Data Source=" + corruptDb + ";Pooling=False"))
    {
        conn.Open();
        using var command = conn.CreateCommand();
        command.CommandText = "UPDATE tasks SET artifacts=$artifacts WHERE id=(SELECT id FROM tasks WHERE status='succeeded' LIMIT 1)";
        command.Parameters.AddWithValue("$artifacts", JsonSerializer.Serialize(new[] { new ArtifactRecord("../outside.txt", "outside", "bad", 1, "bad") }, json));
        command.ExecuteNonQuery();
    }

    using (var input = File.OpenRead(corruptDb))
        manifest["files"]!["center.sqlite3"] = Convert.ToHexStringLower(SHA256.HashData(input));
    using (var zip = ZipFile.Open(backup.Path, ZipArchiveMode.Update))
    {
        zip.GetEntry("center.sqlite3")!.Delete();
        zip.CreateEntryFromFile(corruptDb, "center.sqlite3");
        zip.GetEntry("manifest.json")!.Delete();
        using var writer = new StreamWriter(zip.CreateEntry("manifest.json").Open());
        writer.Write(manifest.ToJsonString());
    }

    string newHash;
    using (var input = File.OpenRead(backup.Path))
        newHash = Convert.ToHexStringLower(SHA256.HashData(input));
    File.WriteAllText(Path.ChangeExtension(backup.Path, ".json"), JsonSerializer.Serialize(backup with { Sha256 = newHash, Bytes = new FileInfo(backup.Path).Length }, json));
    core.EmergencyStop();
    Throws(() => core.RestoreBackup(backup.Id), "malformed restored artifact accepted");
    Require(core.Knowledge().Any(k => k.Id == marker.Id), "failed restore lost preexisting data");
    Require(core.Tasks().Any(t => t.Status == "succeeded"), "failed restore lost results");
    core.Resume();
    return Task.CompletedTask;
});
await Test("user_cancel_wins_concurrent_deadline", async () =>
{
    var path = Manifest(Path.Combine(testingRoot, "cancel-deadline-source"), "stats_dotnet", "dotnet", "numeric_analysis", 1);
    var delayed = new RealTestRunner(projectRoot)
    {
        DelayCancellationMs = 500
    };
    using var c = new CommandCenter(Path.Combine(testingRoot, "cancel-deadline"), delayed);
    Register(c, path);
    var task = c.Submit(new("stats_dotnet", new JsonObject { ["numbers"] = new JsonArray(1, 2), ["wait"] = true }));
    var executing = c.RunNextAsync();
    await Task.Delay(800);
    c.Cancel(task.Id);
    await executing;
    Require(c.TaskDetails(task.Id).Status == "cancelled", "explicit user cancellation misclassified as timed_out");
});
var result = new
{
    suite = "HERZ.Core .NET10 managed integration",
    filter,
    executed = evidence.Count,
    passed = evidence.Count - failures,
    failed = failures,
    seconds = timer.Elapsed.TotalSeconds,
    host = System.Runtime.InteropServices.RuntimeInformation.OSDescription,
    windowsExecution = OperatingSystem.IsWindows(),
    nativeIsolationTested = false,
    realDotnetAndNodeProcesses = RealTestRunner.DotnetProcesses > 0 && RealTestRunner.NodeProcesses > 0,
    dotnetProcesses = RealTestRunner.DotnetProcesses,
    nodeProcesses = RealTestRunner.NodeProcesses,
    evidence
};
Directory.CreateDirectory(Path.Combine(projectRoot, "evidence"));
await File.WriteAllTextAsync(Path.Combine(projectRoot, "evidence", filter == null ? "core-tests.json" : "core-tests-focused.json"), JsonSerializer.Serialize(result, new JsonSerializerOptions(json) { WriteIndented = true }));
Console.WriteLine(JsonSerializer.Serialize(result, json));
Environment.ExitCode = failures == 0 ? 0 : 1;
sealed class RealTestRunner(string root) : IAgentRunner
{
    public static int DotnetProcesses;
    public static int NodeProcesses;
    private readonly HashSet<Process> owned = [];
    private readonly object gate = new();
    public bool ReturnMissingArtifact { get; set; }
    public bool ReturnEscapingArtifact { get; set; }
    public int DelayCancellationMs { get; set; }

    private static readonly JsonSerializerOptions Json = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true
    };
    public IsolationStatus Probe() => new(true, "test-only-process-runner", "This test adapter does not assert OS isolation; never included in the Windows runtime.", false);
    public AgentReadiness Check(AgentDefinition agent) => new(agent.Id is "stats_dotnet" or "report_node", agent.Id is "stats_dotnet" or "report_node" ? "Actual local fixture available" : "No fixture");
    public async Task<AgentExecution> ExecuteAsync(AgentDefinition agent, TaskContext context, CancellationToken cancellationToken)
    {
        var start = new ProcessStartInfo
        {
            UseShellExecute = false,
            RedirectStandardInput = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            WorkingDirectory = context.Workspace
        };
        if (agent.Runtime == "dotnet")
        {
            start.FileName = Environment.ProcessPath!;
            if (Path.GetFileNameWithoutExtension(start.FileName) == "dotnet")
                start.ArgumentList.Add(typeof(RealTestRunner).Assembly.Location);
            start.ArgumentList.Add("--stats-worker");
        }
        else
        {
            start.FileName = "node";
            start.ArgumentList.Add(Path.Combine(root, "src/Herz.Tests/fixture_reporter.mjs"));
        }

        using var p = Process.Start(start) ?? throw new Exception("fixture launch failed");
        if (agent.Runtime == "dotnet")
            Interlocked.Increment(ref DotnetProcesses);
        else
            Interlocked.Increment(ref NodeProcesses);
        lock (gate)
            owned.Add(p);
        try
        {
            using var registration = cancellationToken.Register(() =>
            {
                try
                {
                    if (!p.HasExited)
                        p.Kill(true);
                }
                catch (InvalidOperationException)
                {
                }
            });
            var output = p.StandardOutput.ReadToEndAsync(cancellationToken);
            var error = p.StandardError.ReadToEndAsync(cancellationToken);
            await p.StandardInput.WriteAsync(JsonSerializer.Serialize(context, Json));
            p.StandardInput.Close();
            await p.WaitForExitAsync(cancellationToken);
            var text = await output;
            var err = await error;
            cancellationToken.ThrowIfCancellationRequested();
            if (p.ExitCode != 0)
                return new(p.ExitCode, new(), [], err);
            var response = JsonNode.Parse(text)!.AsObject();
            var artifacts = response["artifacts"]!.AsArray().Select(x => x!.GetValue<string>()).ToArray();
            if (ReturnMissingArtifact)
                artifacts = ["missing.txt"];
            if (ReturnEscapingArtifact)
                artifacts = ["../escaped.txt"];
            return new(p.ExitCode, response["result"]!.AsObject(), artifacts, err);
        }
        catch (OperationCanceledException)
        {
            if (DelayCancellationMs > 0)
                await Task.Delay(DelayCancellationMs);
            throw;
        }
        finally
        {
            lock (gate)
                owned.Remove(p);
        }
    }

    public void StopAll()
    {
        lock (gate)
            foreach (var p in owned.ToArray())
                try
                {
                    if (!p.HasExited)
                        p.Kill(true);
                }
                catch (InvalidOperationException)
                {
                }
    }
}
