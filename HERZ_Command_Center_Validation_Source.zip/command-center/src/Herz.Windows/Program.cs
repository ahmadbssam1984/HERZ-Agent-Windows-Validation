using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Herz.Core;

namespace Herz.Windows;
internal static class Program
{
    [DllImport("kernel32.dll")]
    private static extern uint SetErrorMode(uint mode);
    [STAThread]
    private static int Main(string[] args)
    {
        if (!OperatingSystem.IsWindows() || RuntimeInformation.ProcessArchitecture != Architecture.X64)
            return 125;
        SetErrorMode(0x1 | 0x2 | 0x8000); // no OS crash-report UI or automatic fault reporting
        try
        {
            if (args.Length == 8 && args[0] == "--agent-host")
                return WorkerHost.RunAsync(args[1], args[2], args[3], args[4], args[5], args[6], args[7]).GetAwaiter().GetResult();
            if (args.Length == 5 && args[0] == "--probe-child")
            {
                using var p = NativeSandbox.OpenExistingProfile(args[1]);
                var proof = RuntimeChecks.ProbeAsync(p.Sid, args[2], args[3], Wire.Decode<NetworkControl>(Encoding.UTF8.GetString(Convert.FromBase64String(args[4])))).GetAwaiter().GetResult();
                Console.Out.WriteLine(Wire.Encode(proof));
                return proof.Passed ? 0 : 125;
            }

            Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (args.Length == 2 && args[0] == "--manager")
                return RunManager(args[1]);
            if (args.Length != 0)
                throw new InvalidDataException("Unsupported launch arguments.");
            var identity = NativeSandbox.GetCurrentTokenInfo();
            if (identity.IsAppContainer || identity.Elevated)
                throw new InvalidOperationException("افتح HERZ.exe بحساب Windows العادي؛ التجهيز لا يتطلب تشغيلًا كمسؤول.");
            using var form = new PreparationForm();
            Application.Run(form);
            return form.Completed ? 0 : 125;
        }
        catch (Exception e)
        {
            string message = "HERZ: " + e.GetType().Name + ": " + e.Message;
            try
            {
                Console.Error.WriteLine(message);
            }
            catch
            {
            }

            try
            {
                if (NativeSandbox.GetCurrentTokenInfo().IsAppContainer)
                    return 125;
                MessageBox.Show(message, "HERZ — توقف واضح دون تشغيل غير معزول", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
            }

            return 125;
        }
    }

    private static int RunManager(string sessionPath)
    {
        NativeSandbox.EnsureNoReparsePoints(sessionPath);
        var session = Wire.Decode<RuntimeSession>(File.ReadAllText(sessionPath));
        if (!Path.GetFullPath(sessionPath).StartsWith(session.ManagerData + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Invalid session path.");
        NativeSandbox.VerifyCurrentAppContainer(session.ManagerSid);
        NativeSandbox.MakeHandleNonInheritable(new(session.LeaseHandle));
        using var runtimeLease = new Microsoft.Win32.SafeHandles.SafeFileHandle(new(session.LeaseHandle), true);
        foreach (var w in session.Workers)
            foreach (long handle in new[]
            {
                w.InputHandle,
                w.OutputHandle,
                w.ErrorHandle,
                w.JobHandle
            }

            )
                NativeSandbox.MakeHandleNonInheritable(new(handle));
        if (long.TryParse(Environment.GetEnvironmentVariable("HERZ_JOB_HOLD_HANDLE"), out var hold))
            NativeSandbox.MakeHandleNonInheritable(new(hold));
        var proof = RuntimeChecks.ProbeAsync(session.ManagerSid, session.Canary, session.PolicyCanary, session.NetworkControl).GetAwaiter().GetResult();
        string launchNonce = StartupProtocol.CreateNonce();
        Console.Out.WriteLine(StartupProtocol.Encode(new StartupProtocol.Probe("manager-probed", Environment.ProcessId, launchNonce, proof.Passed)));
        Console.Out.Flush();
        // The trusted parent must finish its positive-control checks before this
        // process opens the core, recovers a queue, exposes UI actions or schedules.
        using var startupInput = new StreamReader(Console.OpenStandardInput(), new UTF8Encoding(false, true), false, 1024, false);
        string commit = StartupProtocol.ReadLineAsync(startupInput, TimeSpan.FromSeconds(15)).GetAwaiter().GetResult();
        bool startupAuthorized = StartupProtocol.ValidateCommit(commit, Environment.ProcessId, launchNonce, proof.Passed);
        Wire.WriteJson(Path.Combine(session.ManagerData, "runtime-proof.json"), new { manager = proof, workers = session.Workers.Select(w => w.Hello), baseline = session.Baseline, completeWindowsAcceptance = false, completeKernelDenialAudit = false });
        using var runner = new WindowsPipeRunner(session, proof, startupAuthorized);
        using var core = new CommandCenter(Path.Combine(session.ManagerData, "data"), runner);
        foreach (var check in proof.Checks)
            core.RecordHostCheck("manager/pid=" + Environment.ProcessId, check.Kind, check.Outcome, check.NativeError);
        foreach (var worker in session.Workers)
            foreach (var check in worker.Hello.Proof.Checks)
                core.RecordHostCheck(worker.AgentId + "/pid=" + worker.Pid, check.Kind, check.Outcome, check.NativeError);
        foreach (var name in new[]
        {
            "stats_dotnet",
            "node_reporter"
        }

        )
        {
            string path = Path.Combine(session.Release, "examples", name, "agent.json");
            var inspection = core.InspectAgent(path);
            if (inspection.Allowed && inspection.Definition is not null && !core.Agents().Any(x => x.Definition.Id == inspection.Definition.Id))
                core.RegisterAgent(path, inspection.ApprovalDigest);
        }

        var modelWorker = session.Workers.FirstOrDefault(w => w.AgentId == "local_model");
        bool modelPresent = runner.Probe().Supported && session.Model.Verified && session.Model.Selection.Approved && modelWorker?.Hello.Proof.Passed == true && modelWorker.Hello.ReadinessError is null;
        var host = new UiHostStatus
        {
            WorkspaceRoot = session.ManagerData,
            InboxDirectory = session.Inbox,
            ManagerIsolated = proof.Token.IsAppContainer,
            IsolationVerified = runner.Probe().Supported,
            IsolationSummary = proof.Reason,
            WindowsAcceptanceVerified = false,
            MaxConcurrency = 1,
            ModelStatus = modelWorker?.Hello.ReadinessError ?? session.Model.Reason,
            LocalAssistantAsync = modelPresent ? runner.AskLocalModel : null,
            RunLocalCheckAsync = token => TargetSelfTest.RunAsync(core, runner, session, token)
        };
        using var form = new MainForm(core, host);
        form.Shown += (_, _) =>
        {
            Console.Out.WriteLine(StartupProtocol.Encode(new StartupProtocol.Ready("manager-ready", Environment.ProcessId, launchNonce, runner.Probe().Supported)));
            Console.Out.Flush();
        };
        if (runner.Probe().Supported)
            core.StartScheduler();
        Application.Run(form);
        return 0;
    }
}

internal sealed class PreparationForm : Form
{
    private readonly Label title = new()
    {
        Text = "HERZ  |  تجهيز التشغيل المحلي",
        Dock = DockStyle.Top,
        Height = 68,
        TextAlign = ContentAlignment.MiddleRight,
        Font = new("Segoe UI", 17, FontStyle.Bold)
    };
    private readonly Label status = new()
    {
        Dock = DockStyle.Top,
        Height = 80,
        TextAlign = ContentAlignment.MiddleRight,
        AutoEllipsis = true
    };
    private readonly TextBox details = new()
    {
        Dock = DockStyle.Fill,
        Multiline = true,
        ReadOnly = true,
        ScrollBars = ScrollBars.Vertical,
        RightToLeft = RightToLeft.No,
        BackColor = Color.FromArgb(238, 244, 247)
    };
    private readonly Button cancel = new()
    {
        Text = "إلغاء",
        AutoSize = true,
        MinimumSize = new(100, 38)
    };
    private readonly Button copy = new()
    {
        Text = "نسخ التقرير",
        AutoSize = true,
        MinimumSize = new(120, 38)
    };
    private readonly Button start = new()
    {
        Text = "تجهيز وتشغيل",
        AutoSize = true,
        MinimumSize = new(170, 38)
    };
    private readonly Button withoutModel = new()
    {
        Text = "تشغيل دون نموذج",
        AutoSize = true,
        MinimumSize = new(150, 38),
        Visible = false
    };
    private readonly CancellationTokenSource cancellation = new();
    private bool setupRunning;
    public bool Completed { get; private set; }

    public PreparationForm()
    {
        Text = "HERZ Local Command Center — Windows";
        Font = new("Segoe UI", 10);
        Size = new(820, 530);
        MinimumSize = new(650, 440);
        StartPosition = FormStartPosition.CenterScreen;
        RightToLeft = RightToLeft.Yes;
        RightToLeftLayout = true;
        BackColor = Color.FromArgb(246, 249, 251);
        ForeColor = Color.FromArgb(18, 48, 65);
        Padding = new(22);
        var actions = new FlowLayoutPanel
        {
            Dock = DockStyle.Bottom,
            Height = 98,
            FlowDirection = FlowDirection.RightToLeft
        };
        actions.Controls.Add(start);
        actions.Controls.Add(withoutModel);
        actions.Controls.Add(copy);
        actions.Controls.Add(cancel);
        Controls.Add(details);
        Controls.Add(actions);
        Controls.Add(status);
        Controls.Add(title);
        cancel.Click += (_, _) =>
        {
            if (setupRunning)
                cancellation.Cancel();
            else
                Close();
        };
        copy.Click += (_, _) =>
        {
            try
            {
                Clipboard.SetText(details.Text);
            }
            catch
            {
                status.Text = "تعذر النسخ إلى الحافظة؛ التقرير يبقى في النافذة.";
            }
        };
        FormClosing += (_, _) => cancellation.Cancel();
        start.Click += async (_, _) => await BeginSetup(true);
        withoutModel.Click += async (_, _) => await BeginSetup(false);
        Shown += (_, _) =>
        {
            try
            {
                var selection = LocalModel.ReadSelection(AppContext.BaseDirectory);
                bool needsModel = selection.Approved && !File.Exists(Path.Combine(NativeSandbox.OwnedRoot, "models", selection.File)) && !File.Exists(Path.Combine(AppContext.BaseDirectory, "models", selection.File));
                withoutModel.Visible = needsModel;
                if (needsModel)
                    start.Text = "تنزيل النموذج والتجهيز";
                status.Text = "تجهيز بحسابك العادي. لا تغيير لإعدادات حماية Windows أو حساباته.";
                details.Text = "HERZ Local Command Center 2.0 — Windows x64" + Environment.NewLine + "Runtime: .NET 10.0.15 | Node.js 24.22.3 | llama.cpp b12651 | SQLite local" + Environment.NewLine + "المكونات البرمجية المطلوبة مجانية. استهلاك الكهرباء والذاكرة والمعالج يبقى قائمًا." + Environment.NewLine + "التجهيز ينسخ الملفات إلى %LOCALAPPDATA%\\HERZCommandCenter\\Windows2." + Environment.NewLine + "الفحص الأول يجرب اتصالًا عامًا بلا ملفات شخصية قبل اختبار رفضه داخل العزل." + Environment.NewLine + "نسخة مرشحة: اختبار واجهة Windows والعزل الفعلي على جهازك لم يُنفذ مسبقًا." + Environment.NewLine + Environment.NewLine + "Model: " + selection.Name + Environment.NewLine + "License: " + selection.License + Environment.NewLine + "Size: " + selection.Bytes.ToString("N0") + " bytes" + Environment.NewLine + "Source: " + selection.SourceUrl + Environment.NewLine + "License source: " + selection.LicenseUrl + Environment.NewLine + "SHA-256: " + selection.Sha256 + Environment.NewLine + selection.Reason + Environment.NewLine + (needsModel ? "سيبدأ تنزيل الأوزان بعد ضغط زر تنزيل النموذج والتجهيز فقط. لا تنزيلات أثناء تشغيل الوكلاء." : "لا يلزم تنزيل أوزان عند هذه الخطوة.") + Environment.NewLine + Environment.NewLine;
            }
            catch (Exception e)
            {
                status.Text = e.Message;
                start.Enabled = false;
            }
        };
    }

    private async Task BeginSetup(bool downloadModel)
    {
        setupRunning = true;
        start.Enabled = false;
        withoutModel.Enabled = false;
        var progress = new Progress<string>(s =>
        {
            if (IsDisposed)
                return;
            status.Text = s;
            details.AppendText(DateTime.Now.ToString("HH:mm:ss") + "  " + s + Environment.NewLine);
        });
        try
        {
            await Task.Run(() => Bootstrap.Prepare(progress, cancellation.Token, downloadModel));
            Completed = true;
            Close();
        }
        catch (Exception e)
        {
            string? report = Bootstrap.SaveFailure(e);
            if (IsDisposed)
                return;
            status.Text = "لم يكتمل التشغيل. لم يُستخدم تشغيل غير معزول.";
            details.AppendText(Environment.NewLine + e.GetType().Name + ": " + e.Message);
            if (report is not null)
                details.AppendText(Environment.NewLine + "Local report: " + report);
            cancel.Text = "إغلاق";
        }
        finally
        {
            setupRunning = false;
        }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
            cancellation.Dispose();
        base.Dispose(disposing);
    }
}

internal static class Bootstrap
{
    internal static string? SaveFailure(Exception error)
    {
        try
        {
            string root = NativeSandbox.OwnedRoot;
            NativeSandbox.EnsureNoReparsePoints(root);
            string path = Path.Combine(root, "last-preparation-error.json");
            string message = error.Message;
            string profile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            if (!string.IsNullOrWhiteSpace(profile))
                message = message.Replace(profile, "%USERPROFILE%", StringComparison.OrdinalIgnoreCase);
            Wire.WriteJson(path, new { timeUtc = DateTimeOffset.UtcNow, stage = "preparation", error = error.GetType().Name, message, os = Environment.OSVersion.VersionString, runtime = RuntimeInformation.FrameworkDescription, windowsRuntimeAccepted = false });
            return path;
        }
        catch
        {
            return null;
        }
    }

    private static async Task<string> StartupLine(SandboxProcess child, string name, int seconds, CancellationToken token,
        int maximumCharacters = 1024 * 1024)
    {
        try
        {
            return await StartupProtocol.ReadLineAsync(child.StandardOutput, TimeSpan.FromSeconds(seconds), token, maximumCharacters);
        }
        catch (Exception e)
        {
            try
            {
                child.Terminate(125);
            }
            catch
            {
            }

            string detail = "";
            try
            {
                char[] buffer = new char[4096];
                int count = await child.StandardError.ReadAsync(buffer).AsTask().WaitAsync(TimeSpan.FromSeconds(2));
                detail = new string (buffer, 0, count).Trim();
            }
            catch
            {
            }

            token.ThrowIfCancellationRequested();
            throw new IOException("تعذر بدء " + name + ": " + e.GetType().Name + (detail.Length == 0 ? "؛ لم يصل خطأ إضافي من العملية." : "; " + detail), e);
        }
    }

    internal static async Task Prepare(IProgress<string> progress, CancellationToken cancellation, bool downloadModel)
    {
        string root = NativeSandbox.OwnedRoot;
        Directory.CreateDirectory(root);
        NativeSandbox.EnsureNoReparsePoints(root);
        using var single = new FileStream(Path.Combine(root, "prepare.lock"), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
        string source = AppContext.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar);
        PreparationHardware.Inspect(root, source, progress);
        progress.Report("التحقق من ملفات نسخة Windows الأصلية...");
        string release = Deploy(source, root, cancellation);
        string managerData = Path.Combine(root, "manager"), inbox = Path.Combine(managerData, "inbox"), secrets = Path.Combine(root, "private"), models = Path.Combine(root, "models");
        foreach (var dir in new[]
        {
            managerData,
            inbox,
            secrets,
            models,
            Path.Combine(root, "slots")
        }

        )
        {
            Directory.CreateDirectory(dir);
            NativeSandbox.EnsureNoReparsePoints(dir);
        }

        string canary = Path.Combine(secrets, "access-canary.txt");
        if (!File.Exists(canary))
            File.WriteAllText(canary, "HERZ synthetic access-control canary; no user data.");
        string policy = Path.Combine(release, "policy-canary.json");
        var model = await LocalModel.PrepareAsync(release, source, models, progress, downloadModel, cancellation);
        progress.Report("فحص اتصال عام قبل العزل لإثبات أن الحظر لا يعتمد على فصل الإنترنت؛ لا تُرسل ملفاتك.");
        string preparationSessionId = Guid.NewGuid().ToString("N");
        var baseline = await RuntimeChecks.BaselineAsync(preparationSessionId);
        string baselinePath = Path.Combine(managerData, "online-baseline.json");
        if (baseline.Ipv4Connected)
            Wire.WriteJson(baselinePath, new { os = Environment.OSVersion.VersionString, release = Path.GetFileName(release), result = baseline });
        // This saved observation is history, not an isolation certificate. Never
        // replace the current test session with a result from an earlier launch.

        cancellation.ThrowIfCancellationRequested();
        using var networkWitness = await NetworkWitness.StartAsync(baseline, cancellation);
        var networkControl = networkWitness.Control(baseline);
        progress.Report("تجهيز AppContainer ومجلدات HERZ فقط، دون حسابات جديدة أو تغيير Firewall...");
        using var manager = NativeSandbox.CreateProfile("HERZ.LocalCommandCenter.v2.Manager");
        NativeSandbox.GrantDirectory(root, release, manager, false);
        NativeSandbox.GrantDirectory(root, managerData, manager, true);
        var processes = new List<SandboxProcess>();
        var inherited = new List<IntPtr>();
        var profiles = new List<SandboxProfile>();
        SandboxProcess? managerProcess = null;
        bool handedOff = false;
        try
        {
            var links = new List<WorkerLink>();
            foreach (string id in new[]
            {
                "stats_dotnet",
                "report_node",
                "local_model"
            }

            )
            {
                cancellation.ThrowIfCancellationRequested();
                string slot = Path.Combine(root, "slots", id);
                Directory.CreateDirectory(slot);
                var p = NativeSandbox.CreateProfile("HERZ.LocalCommandCenter.v2." + id);
                profiles.Add(p);
                NativeSandbox.GrantDirectory(root, release, p, false);
                NativeSandbox.GrantDirectory(root, slot, p, true);
                NativeSandbox.GrantDirectory(root, slot, manager, true);
                if (id == "local_model")
                    NativeSandbox.GrantDirectory(root, models, p, false);
                progress.Report("اختبار العامل المعزول: " + id);
                var child = NativeSandbox.Launch(p, Path.Combine(release, "HERZ.exe"), ["--agent-host", id, p.Name, slot, release, canary, policy, Convert.ToBase64String(Encoding.UTF8.GetBytes(Wire.Encode(networkControl)))], slot, null, new(id == "local_model" ? (model.Selection.JobMemoryMiB + 256L) * 1024 * 1024 : 768L * 1024 * 1024, 50, 10));
                processes.Add(child);
                string line = await StartupLine(child, id, 55, cancellation);
                var hello = Wire.Decode<WorkerHello>(line);
                if (hello.Type != "hello" || hello.AgentId != id || hello.Pid != child.Pid)
                    throw new InvalidDataException("Worker handshake identity mismatch.");
                var handles = new[]
                {
                    child.DuplicateInputForChild(),
                    child.DuplicateOutputForChild(),
                    child.DuplicateErrorForChild(),
                    child.DuplicateJobControlForChild()
                };
                inherited.AddRange(handles);
                links.Add(new(id, p.Name, p.Sid, slot, handles[0].ToInt64(), handles[1].ToInt64(), handles[2].ToInt64(), handles[3].ToInt64(), child.Pid, hello));
                Wire.WriteJson(Path.Combine(managerData, "probe-" + id + ".json"), hello);
            }

            string sessionPath = Path.Combine(managerData, "runtime-session.json");
            var leaseHandle = NativeSandbox.DuplicateForChild(single.SafeFileHandle.DangerousGetHandle());
            inherited.Add(leaseHandle);
            var session = new RuntimeSession(root, release, manager.Name, manager.Sid, managerData, inbox, canary, policy, baseline, networkControl, links, leaseHandle.ToInt64(), DateTimeOffset.UtcNow.ToString("O"), model);
            Wire.WriteJson(sessionPath, session);
            NativeSandbox.GrantDirectory(root, managerData, manager, true);
            progress.Report("فتح واجهة Windows داخل العزل...");
            managerProcess = NativeSandbox.Launch(manager, Path.Combine(release, "HERZ.exe"), ["--manager", sessionPath], managerData, null, new(1300L * 1024 * 1024, 25, 10), inherited, showWindow: true, holdJobInChild: true);
            string probed = await StartupLine(managerProcess, "فحص مدير HERZ", 50, cancellation, StartupProtocol.MaximumMessageCharacters);
            var managerProbe = StartupProtocol.ValidateProbe(probed, checked((int)managerProcess.Pid));
            // Revalidate the live, trusted positive controls after all contained probes.
            // A dead witness must never turn ConnectionRefused into an isolation pass.
            await networkWitness.AssertAliveAsync(cancellation);
            cancellation.ThrowIfCancellationRequested();
            bool allowExecution = managerProbe.ProofPassed && baseline.Ipv4Connected;
            await managerProcess.StandardInput.WriteLineAsync(StartupProtocol.Encode(new StartupProtocol.Commit("startup-commit", managerProbe.Pid, managerProbe.Nonce, allowExecution)));
            await managerProcess.StandardInput.FlushAsync(cancellation);
            string ready = await StartupLine(managerProcess, "واجهة HERZ", 30, cancellation, StartupProtocol.MaximumMessageCharacters);
            StartupProtocol.ValidateReady(ready, managerProbe, allowExecution);
            cancellation.ThrowIfCancellationRequested();
            foreach (var process in processes)
                process.DetachForHandoff();
            managerProcess.DetachForHandoff();
            handedOff = true;
        }
        finally
        {
            foreach (var handle in inherited)
                NativeSandbox.CloseHandle(handle);
            foreach (var process in processes)
                process.Dispose();
            managerProcess?.Dispose();
            foreach (var p in profiles)
                p.Dispose();
            if (!handedOff)
                progress.Report("توقفت عمليات HERZ التابعة لمحاولة التشغيل فقط؛ الملفات الأصلية محفوظة.");
        }
    }

    private static string Deploy(string source, string root, CancellationToken token)
    {
        string manifestPath = Path.Combine(source, "release-manifest.json");
        if (!File.Exists(manifestPath))
            throw new FileNotFoundException("استخرج الحزمة كاملة أولًا؛ بيان ملفات التشغيل غير موجود.");
        var manifest = Wire.Decode<Dictionary<string, string>>(File.ReadAllText(manifestPath));
        if (manifest.Count is < 20 or > 1000 || !manifest.ContainsKey("HERZ.exe"))
            throw new InvalidDataException("Incomplete release manifest.");
        string name = "2.0.2-review.1-" + LocalPaths.HashFile(manifestPath)[..16];
        string destination = Path.Combine(root, "releases", name);
        Directory.CreateDirectory(destination);
        NativeSandbox.EnsureNoReparsePoints(destination);
        foreach (var entry in manifest)
        {
            token.ThrowIfCancellationRequested();
            string original = LocalPaths.InDirectory(source, entry.Key), target = LocalPaths.InDirectory(destination, entry.Key);
            if (entry.Value.Length != 64 || LocalPaths.HashFile(original) != entry.Value)
                throw new InvalidDataException("Release integrity failed: " + entry.Key);
            if (File.Exists(target))
            {
                if (LocalPaths.HashFile(target) != entry.Value)
                    throw new InvalidDataException("Installed source changed; it was not overwritten: " + entry.Key);
                continue;
            }

            Directory.CreateDirectory(Path.GetDirectoryName(target)!);
            File.Copy(original, target, false);
            if (LocalPaths.HashFile(target) != entry.Value)
                throw new InvalidDataException("Installed copy verification failed: " + entry.Key);
        }

        foreach (string file in Directory.EnumerateFiles(destination, "*", SearchOption.AllDirectories))
            if (!manifest.ContainsKey(Path.GetRelativePath(destination, file).Replace('\\', '/')))
                throw new InvalidDataException("Unlisted executable-release file; refusing to launch.");
        return destination;
    }
}
