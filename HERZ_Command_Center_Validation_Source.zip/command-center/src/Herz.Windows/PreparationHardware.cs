using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace Herz.Windows;
internal static class PreparationHardware
{
    internal static void Inspect(string root, string source, IProgress<string> progress)
    {
        if (Environment.OSVersion.Version.Build < 22000 || RuntimeInformation.OSArchitecture != Architecture.X64)
            throw new PlatformNotSupportedException("هذه الحزمة تستهدف Windows 11 x64. لم تُعدّل إعدادات الجهاز.");
        var drive = new DriveInfo(Path.GetPathRoot(root)!);
        if (!string.Equals(drive.DriveFormat, "NTFS", StringComparison.OrdinalIgnoreCase))
            throw new PlatformNotSupportedException("مساحة HERZ المحلية تحتاج NTFS لدعم صلاحيات العزل التي يطبقها هذا الإصدار.");
        var model = LocalModel.ReadSelection(source);
        bool haveLocal = File.Exists(Path.Combine(root, "models", model.File));
        long requiredDisk = 1024L * 1024 * 1024 + (model.Approved && !haveLocal ? model.Bytes : 0);
        if (drive.AvailableFreeSpace < requiredDisk)
            throw new IOException($"المساحة الحرة لا تكفي. يلزم {requiredDisk / 1073741824d:N1} GiB تقريبًا للتجهيز المحلي.");
        string cpu = Registry.GetValue(@"HKEY_LOCAL_MACHINE\HARDWARE\DESCRIPTION\System\CentralProcessor\0", "ProcessorNameString", "Unavailable")?.ToString()?.Trim() ?? "Unavailable";
        ulong free = LocalModel.AvailablePhysicalBytes();
        Wire.WriteJson(Path.Combine(root, "preparation-hardware.json"), new { timeUtc = DateTimeOffset.UtcNow, scope = "This Windows device; preparation observations only.", os = Environment.OSVersion.VersionString, architecture = RuntimeInformation.OSArchitecture.ToString(), cpu, logicalProcessors = Environment.ProcessorCount, availablePhysicalBytes = free, diskFormat = drive.DriveFormat, diskAvailableBytes = drive.AvailableFreeSpace, gpuRequired = false, gpuTest = "not_requested_cpu_only", elevated = false, dotnetRuntime = RuntimeInformation.FrameworkDescription, windowsAcceptancePassed = false });
        progress.Report($"فحص الجهاز: {Environment.ProcessorCount} معالجًا منطقيًا، والذاكرة المتاحة {free / 1048576UL:N0} MiB. الاستدلال يستخدم CPU فقط.");
    }
}
