using System.Net;
using System.Security.Cryptography;

namespace Herz.Windows;
// This runs only in the preparation launcher, never in a runtime agent.
internal static class ArtifactDownload
{
    internal static bool AllowedSource(Uri url) => url.IsAbsoluteUri && url.Scheme == "https" && url.IsDefaultPort && url.UserInfo.Length == 0 && (url.Host == "huggingface.co" || url.Host.EndsWith(".huggingface.co", StringComparison.OrdinalIgnoreCase) || url.Host.EndsWith(".hf.co", StringComparison.OrdinalIgnoreCase));
    internal static async Task DownloadAsync(Uri source, string target, long expectedBytes, string expectedSha256, IProgress<string> progress, CancellationToken token)
    {
        if (!AllowedSource(source) || expectedBytes is < 1 or > 3L * 1024 * 1024 * 1024 || expectedSha256.Length != 64)
            throw new InvalidDataException("The reviewed model download definition is invalid.");
        if (File.Exists(target))
            throw new IOException("The destination already exists; it was preserved.");
        // Preparation follows the machine's configured connection path, including
        // a proxy where required. No Windows/default proxy credentials or cookies
        // are supplied. Runtime processes remain network-denied by AppContainer.
        using var handler = new HttpClientHandler
        {
            AllowAutoRedirect = false,
            UseCookies = false,
            UseDefaultCredentials = false,
            UseProxy = true,
            DefaultProxyCredentials = null,
            AutomaticDecompression = DecompressionMethods.None
        };
        using var client = new HttpClient(handler)
        {
            Timeout = TimeSpan.FromMinutes(30)
        };
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(token);
        timeout.CancelAfter(TimeSpan.FromMinutes(30));
        HttpResponseMessage? response = null;
        Uri current = source;
        try
        {
            for (int redirects = 0; redirects <= 6; redirects++)
            {
                response = await client.GetAsync(current, HttpCompletionOption.ResponseHeadersRead, timeout.Token);
                if ((int)response.StatusCode is >= 300 and <= 399)
                {
                    var location = response.Headers.Location ?? throw new InvalidDataException("Download redirect has no location.");
                    current = location.IsAbsoluteUri ? location : new Uri(current, location);
                    response.Dispose();
                    response = null;
                    if (!AllowedSource(current))
                        throw new InvalidDataException("The download redirected to an unapproved host.");
                    continue;
                }

                response.EnsureSuccessStatusCode();
                if (response.Content.Headers.ContentLength is long length && length != expectedBytes)
                    throw new InvalidDataException("The source reported a different model size.");
                await using var input = await response.Content.ReadAsStreamAsync(timeout.Token);
                await CopyVerifiedAsync(input, target, expectedBytes, expectedSha256, progress, timeout.Token);
                return;
            }

            throw new IOException("Too many download redirects.");
        }
        finally
        {
            response?.Dispose();
        }
    }

    internal static async Task CopyVerifiedAsync(Stream input, string target, long expectedBytes, string expectedSha256, IProgress<string> progress, CancellationToken token)
    {
        string temporary = target + "." + Guid.NewGuid().ToString("N") + ".download";
        bool ownsTemporary = false;
        try
        {
            long copied = 0;
            long nextReport = 0;
            using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
            await using (var output = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None, 131072, true))
            {
                ownsTemporary = true;
                byte[] buffer = new byte[131072];
                while (true)
                {
                    int count = await input.ReadAsync(buffer, token);
                    if (count == 0)
                        break;
                    copied += count;
                    if (copied > expectedBytes)
                        throw new InvalidDataException("The download exceeded the reviewed size.");
                    hash.AppendData(buffer, 0, count);
                    await output.WriteAsync(buffer.AsMemory(0, count), token);
                    if (copied >= nextReport)
                    {
                        progress.Report($"تنزيل النموذج: {copied / 1048576d:N1} من {expectedBytes / 1048576d:N1} MiB");
                        nextReport = copied + 8L * 1024 * 1024;
                    }
                }

                if (copied != expectedBytes || Convert.ToHexString(hash.GetHashAndReset()).ToLowerInvariant() != expectedSha256)
                    throw new InvalidDataException("The downloaded model failed its size or SHA-256 check.");
                await output.FlushAsync(token);
                output.Flush(true);
            }

            token.ThrowIfCancellationRequested();
            File.Move(temporary, target, false);
        }
        finally
        {
            // Only the transient file created by this call is removed.
            if (ownsTemporary && File.Exists(temporary))
                File.Delete(temporary);
        }
    }
}
