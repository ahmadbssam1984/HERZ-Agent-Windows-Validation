using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Herz.Windows;
internal sealed class UiTheme
{
    public bool Dark { get; }
    public Color Background => Dark ? Color.FromArgb(12, 20, 33) : Color.FromArgb(241, 245, 249);
    public Color Surface => Dark ? Color.FromArgb(20, 32, 49) : Color.White;
    public Color Alternate => Dark ? Color.FromArgb(25, 40, 58) : Color.FromArgb(247, 250, 252);
    public Color Text => Dark ? Color.FromArgb(232, 239, 247) : Color.FromArgb(19, 38, 58);
    public Color Muted => Dark ? Color.FromArgb(176, 192, 211) : Color.FromArgb(76, 98, 121);
    public Color Border => Dark ? Color.FromArgb(54, 73, 95) : Color.FromArgb(204, 215, 226);
    public Color Green => Dark ? Color.FromArgb(63, 205, 158) : Color.FromArgb(14, 117, 84);
    public Color GreenSurface => Dark ? Color.FromArgb(24, 69, 59) : Color.FromArgb(224, 245, 237);
    public Color Danger => Dark ? Color.FromArgb(255, 161, 164) : Color.FromArgb(172, 29, 44);
    public Color Warning => Dark ? Color.FromArgb(245, 206, 127) : Color.FromArgb(128, 78, 9);

    public UiTheme(bool dark) => Dark = dark;
    public void Apply(Control control)
    {
        if (control is Form or Panel or TableLayoutPanel or FlowLayoutPanel or SplitContainer or TabPage)
            control.BackColor = control.Tag?.ToString() == "surface" ? Surface : Background;
        control.ForeColor = Text;
        switch (control)
        {
            case SurfacePanel panel:
                panel.BackColor = Surface;
                panel.BorderColor = Border;
                break;
            case TextBoxBase box:
                box.BackColor = Alternate;
                box.ForeColor = Text;
                break;
            case ListBox list:
                list.BackColor = Alternate;
                list.ForeColor = Text;
                break;
            case ComboBox combo:
                combo.BackColor = Alternate;
                combo.ForeColor = Text;
                break;
            case Button button:
                StyleButton(button);
                break;
            case DataGridView grid:
                StyleGrid(grid);
                break;
            case Label label:
                label.ForeColor = label.Tag?.ToString() switch
                {
                    "muted" => Muted,
                    "danger" => Danger,
                    "warning" => Warning,
                    "green" => Green,
                    _ => Text
                };
                break;
        }

        foreach (Control child in control.Controls)
            Apply(child);
        control.Invalidate();
    }

    public void StyleButton(Button button)
    {
        button.FlatStyle = FlatStyle.Flat;
        button.FlatAppearance.BorderSize = 1;
        button.FlatAppearance.BorderColor = Border;
        button.FlatAppearance.MouseOverBackColor = Alternate;
        button.FlatAppearance.MouseDownBackColor = GreenSurface;
        button.BackColor = button.Tag?.ToString() switch
        {
            "primary" => GreenSurface,
            "danger" => Dark ? Color.FromArgb(79, 35, 43) : Color.FromArgb(255, 235, 237),
            "selected" => GreenSurface,
            _ => Surface
        };
        button.ForeColor = button.Tag?.ToString() switch
        {
            "danger" => Danger,
            "primary" or "selected" => Green,
            _ => Text
        };
        button.Cursor = button.Enabled ? Cursors.Hand : Cursors.Default;
        button.UseVisualStyleBackColor = false;
    }

    public void StyleGrid(DataGridView grid)
    {
        grid.BackgroundColor = Surface;
        grid.BorderStyle = BorderStyle.None;
        grid.GridColor = Border;
        grid.EnableHeadersVisualStyles = false;
        grid.ColumnHeadersDefaultCellStyle.BackColor = Alternate;
        grid.ColumnHeadersDefaultCellStyle.ForeColor = Text;
        grid.ColumnHeadersDefaultCellStyle.SelectionBackColor = Alternate;
        grid.ColumnHeadersDefaultCellStyle.SelectionForeColor = Text;
        grid.DefaultCellStyle.BackColor = Surface;
        grid.DefaultCellStyle.ForeColor = Text;
        grid.DefaultCellStyle.SelectionBackColor = GreenSurface;
        grid.DefaultCellStyle.SelectionForeColor = Text;
        grid.AlternatingRowsDefaultCellStyle.BackColor = Alternate;
        grid.RowsDefaultCellStyle.Padding = new Padding(7, 5, 7, 5);
    }
}

internal sealed class SurfacePanel : Panel
{
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public Color BorderColor { get; set; } = Color.Gray;

    public SurfacePanel()
    {
        DoubleBuffered = true;
        Padding = new Padding(16);
        Margin = new Padding(0, 0, 0, 12);
        Tag = "surface";
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        using var pen = new Pen(BorderColor);
        e.Graphics.DrawRectangle(pen, 0, 0, Math.Max(0, Width - 1), Math.Max(0, Height - 1));
    }
}

internal sealed class NavigationButton : Button
{
    public NavigationButton(string text)
    {
        Text = text;
        Height = 43;
        Width = 184;
        TextAlign = ContentAlignment.MiddleRight;
        Padding = new Padding(12, 0, 12, 0);
        Margin = new Padding(0, 0, 0, 6);
        AutoEllipsis = false;
        UseMnemonic = false;
        TabStop = true;
        AccessibleName = text;
    }
}

// A one-column stack that gives wrapping labels the actual available width.
// Fixed-height FlowLayoutPanel stacks clipped Arabic text when Windows DPI grew.
internal sealed class WrappingStack : TableLayoutPanel
{
    private bool fitting;
    public WrappingStack()
    {
        ColumnCount = 1;
        ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        GrowStyle = TableLayoutPanelGrowStyle.AddRows;
        AutoSize = true;
        AutoSizeMode = AutoSizeMode.GrowAndShrink;
        Margin = Padding.Empty;
        Padding = Padding.Empty;
    }

    protected override void OnLayout(LayoutEventArgs e)
    {
        if (!fitting)
        {
            fitting = true;
            try
            {
                foreach (Control child in Controls)
                {
                    if (child is not Label label)
                        continue;
                    label.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
                    int available = Math.Max(1, ClientSize.Width - Padding.Horizontal - child.Margin.Horizontal);
                    if (label.MaximumSize.Width != available)
                        label.MaximumSize = new Size(available, 0);
                }
            }
            finally { fitting = false; }
        }
        base.OnLayout(e);
    }
}
