using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;

namespace Herz.Windows;
internal static class RuntimeChecks
{
    internal static async Task<BaselineResult> BaselineAsync(string? sessionId = null)
    {
        sessionId ??= Guid.NewGuid().ToString("N");
        if (!Guid.TryParseExact(sessionId, "N", out var id) || id == Guid.Empty)
            throw new ArgumentException("A fresh preparation session identifier is required.", nameof(sessionId));
        var ipv4 = await NativeSandbox.ProbeTcpAsync("1.1.1.1", 443, 2200);
        var ipv6 = await NativeSandbox.ProbeTcpAsync("2606:4700:4700::1111", 443, 2200);
        bool dns = false;
        try { dns = (await Dns.GetHostAddressesAsync("example.com").WaitAsync(TimeSpan.FromSeconds(3))).Length > 0; }
        catch (Exception e) when (e is SocketException or TimeoutException or OperationCanceledException) { }
        return new(ipv4.Outcome == "allowed", ipv6.Outcome == "allowed", dns,
            DateTimeOffset.UtcNow.ToString("O"),
            "Preparation-only reachability diagnostics for this session. A DNS answer can be cached. These observations do not certify containment or substitute for a native access denial.", sessionId);
    }

    internal static async Task<RuntimeProof> ProbeAsync(string expectedSid, string canary,
        string policyCanary, NetworkControl witness)
    {
        var token = NativeSandbox.GetCurrentTokenInfo();
        var checks = new List<SandboxProbeResult>();
        bool tokenGood = NetworkAdmission.TokenValid(token, expectedSid);
        checks.Add(new("token", tokenGood ? "verified" : "failed", null,
            "AppContainer SID, low integrity S-1-16-4096, no elevation, zero network capabilities"));
        if (!tokenGood)
            return new(token, checks, false, "هوية العملية أو قدراتها غير مطابقة؛ التنفيذ مرفوض.");
        if (!NetworkAdmission.WitnessValid(witness.LocalIpv4Port, witness.LocalIpv6Port,
                witness.SessionId, witness.StartedUtc, DateTimeOffset.UtcNow))
            return new(token, checks, false, "دليل اختبار الشبكة المحلي غير صالح أو قديم؛ التنفيذ مرفوض.");

        // Exact local listeners are held by the trusted preparation parent. They
        // do not convert refusal/no-route errors into security evidence.
        checks.Add(NetworkAdmission.SocketResult("loopback-ipv4", await NativeSandbox.ProbeTcpAsync("127.0.0.1", witness.LocalIpv4Port)));
        checks.Add(NetworkAdmission.SocketResult("loopback-ipv6", await NativeSandbox.ProbeTcpAsync("::1", witness.LocalIpv6Port)));
        checks.Add(NetworkAdmission.SocketResult("tcp-ipv4", await NativeSandbox.ProbeTcpAsync("1.1.1.1", 443)));
        checks.Add(NetworkAdmission.SocketResult("tcp-ipv6", await NativeSandbox.ProbeTcpAsync("2606:4700:4700::1111", 443)));
        checks.Add(await ProbeDnsPacket(IPAddress.Parse("1.1.1.1"), "dns-udp-ipv4"));
        checks.Add(await ProbeDnsPacket(IPAddress.Parse("2606:4700:4700::1111"), "dns-udp-ipv6"));
        // Exercise the DNS API/broker path as well as direct UDP. Timeout and DNS
        // server negative replies never count as Windows permission denial.
        checks.AddRange(await Task.WhenAll(
            NativeDnsProbe.QueryAsync("dns-api-a", 1),
            NativeDnsProbe.QueryAsync("dns-api-aaaa", 28)));
        checks.Add(NativeSandbox.ProbeFileOpen(canary, false));
        checks.Add(NativeSandbox.ProbeFileOpen(policyCanary, true));
        checks.Add(NativeSandbox.ProbeFileSecurityAccess(policyCanary, false) with { Kind = "policy-write-dac" });
        checks.Add(NativeSandbox.ProbeFileSecurityAccess(policyCanary, true) with { Kind = "policy-write-owner" });
        checks.Add(NativeSandbox.ProbeFileSecurityAccess(Environment.CurrentDirectory, false) with { Kind = "workdir-write-dac" });
        checks.Add(NativeSandbox.ProbeFileSecurityAccess(Environment.CurrentDirectory, true) with { Kind = "workdir-write-owner" });
        var admission = NetworkAdmission.Evaluate(tokenGood, checks);
        string reason = admission.Passed
            ? "نجحت اختبارات الرفض الصريح المسجلة لهذه العملية. لا تعني هذه النتيجة اكتمال اعتماد Windows أو تدقيق جميع أحداث النواة."
            : "لم يكتمل إثبات العزل؛ تنفيذ المهام محظور: " + string.Join("؛ ", admission.Problems);
        return new(token, checks, admission.Passed, reason);
    }

    private static async Task<SandboxProbeResult> ProbeDnsPacket(IPAddress address, string kind)
    {
        using var cancel = new CancellationTokenSource(TimeSpan.FromSeconds(2));
        try
        {
            using var socket = new Socket(address.AddressFamily, SocketType.Dgram, ProtocolType.Udp);
            byte[] query = [0x48, 0x5a, 0x01, 0, 0, 1, 0, 0, 0, 0, 0, 0,
                7, (byte)'e', (byte)'x', (byte)'a', (byte)'m', (byte)'p', (byte)'l', (byte)'e',
                3, (byte)'c', (byte)'o', (byte)'m', 0, 0, 1, 0, 1];
            await socket.SendToAsync(query.AsMemory(), SocketFlags.None,
                new IPEndPoint(address, 53), cancel.Token);
            return NetworkAdmission.SocketResult(kind, new(kind, "unexpected-send", null, "UDP send accepted locally."));
        }
        catch (SocketException e)
        { return NetworkAdmission.SocketResult(kind, new(kind, "inconclusive", e.NativeErrorCode, e.SocketErrorCode.ToString())); }
        catch (OperationCanceledException)
        { return new(kind, "inconclusive", null, "UDP probe timed out. No policy denial was established."); }
    }
}

// DnsQueryEx preserves DNS_STATUS and bypasses cache/hosts/NetBIOS. Native
// buffers survive until the callback AND any DnsCancelQuery call return.
// https://learn.microsoft.com/windows/win32/api/windns/nf-windns-dnsqueryex
// https://learn.microsoft.com/windows/win32/api/windns/nf-windns-dnscancelquery
internal static class NativeDnsProbe
{
    internal static async Task<SandboxProbeResult> QueryAsync(string kind, ushort recordType)
    {
        if (!OperatingSystem.IsWindows() || IntPtr.Size != 8)
            return NetworkAdmission.DnsResult(kind, null, "Native Windows x64 DNS probing is unavailable on this platform.");
        if (!HasExpectedLayout())
            return NetworkAdmission.DnsResult(kind, null, "Native DNS structure layout does not match the Windows x64 ABI.");
        var operation = new QueryOperation(recordType);
        _ = Task.Run(operation.Start);
        try
        {
            var answer = await operation.Completion.WaitAsync(TimeSpan.FromSeconds(3));
            return NetworkAdmission.DnsResult(kind, answer.Status, answer.Error);
        }
        catch (TimeoutException)
        {
            operation.RequestCancellation();
            return NetworkAdmission.DnsResult(kind, null,
                "Native DNS probe exceeded three seconds; cancellation requested. Timeout is not a policy denial.");
        }
    }

    internal static (int Request, int Result) StructureSizes() =>
        (Marshal.SizeOf<DnsQueryRequest>(), Marshal.SizeOf<DnsQueryResult>());

    internal static bool HasExpectedLayout() => StructureSizes() == (64, 32) &&
        Marshal.OffsetOf<DnsQueryRequest>(nameof(DnsQueryRequest.QueryName)).ToInt64() == 8 &&
        Marshal.OffsetOf<DnsQueryRequest>(nameof(DnsQueryRequest.QueryType)).ToInt64() == 16 &&
        Marshal.OffsetOf<DnsQueryRequest>(nameof(DnsQueryRequest.QueryOptions)).ToInt64() == 24 &&
        Marshal.OffsetOf<DnsQueryRequest>(nameof(DnsQueryRequest.ServerList)).ToInt64() == 32 &&
        Marshal.OffsetOf<DnsQueryRequest>(nameof(DnsQueryRequest.InterfaceIndex)).ToInt64() == 40 &&
        Marshal.OffsetOf<DnsQueryRequest>(nameof(DnsQueryRequest.CompletionCallback)).ToInt64() == 48 &&
        Marshal.OffsetOf<DnsQueryRequest>(nameof(DnsQueryRequest.Context)).ToInt64() == 56 &&
        Marshal.OffsetOf<DnsQueryResult>(nameof(DnsQueryResult.QueryStatus)).ToInt64() == 4 &&
        Marshal.OffsetOf<DnsQueryResult>(nameof(DnsQueryResult.QueryOptions)).ToInt64() == 8 &&
        Marshal.OffsetOf<DnsQueryResult>(nameof(DnsQueryResult.Records)).ToInt64() == 16 &&
        Marshal.OffsetOf<DnsQueryResult>(nameof(DnsQueryResult.Reserved)).ToInt64() == 24;

    private sealed record Answer(int? Status, string? Error = null);
    private sealed class QueryOperation
    {
        private readonly object gate = new();
        private readonly TaskCompletionSource<Answer> completion = new(TaskCreationOptions.RunContinuationsAsynchronously);
        private IntPtr request, result, cancel, name;
        private GCHandle context;
        private int nativeCalls;
        private bool completed, pending, cancelRequested, cancellationQueued, released;
        internal Task<Answer> Completion => completion.Task;

        internal QueryOperation(ushort recordType)
        {
            try
            {
                request = Allocate(Marshal.SizeOf<DnsQueryRequest>());
                result = Allocate(Marshal.SizeOf<DnsQueryResult>());
                cancel = Allocate(32); // DNS_QUERY_CANCEL: CHAR Reserved[32]
                name = Marshal.StringToHGlobalUni("example.com.");
                context = GCHandle.Alloc(this);
                Marshal.StructureToPtr(new DnsQueryResult { Version = 1 }, result, false);
                Marshal.StructureToPtr(new DnsQueryRequest
                {
                    Version = 1, QueryName = name, QueryType = recordType,
                    // BYPASS_CACHE | NO_LOCAL_NAME | NO_HOSTS_FILE | NO_NETBT |
                    // WIRE_ONLY | NO_MULTICAST | TREAT_AS_FQDN.
                    QueryOptions = 0x8UL | 0x20UL | 0x40UL | 0x80UL | 0x100UL | 0x800UL | 0x1000UL,
                    CompletionCallback = Marshal.GetFunctionPointerForDelegate(CompletedCallback),
                    Context = GCHandle.ToIntPtr(context)
                }, request, false);
            }
            catch
            {
                ReleaseBuffers();
                throw;
            }
        }

        internal void Start()
        {
            lock (gate)
            {
                // Thread-pool saturation must not start a new native request
                // after the caller has already timed out and canceled it.
                if (cancelRequested)
                {
                    Complete(null, "DNS probe canceled before native execution.");
                    return;
                }
                nativeCalls++;
            }
            try
            {
                int status = DnsQueryEx(request, result, cancel);
                if (status != 9506) // DNS_REQUEST_PENDING
                    Complete(status);
                else
                {
                    lock (gate)
                    {
                        pending = true;
                        QueueCancellationLocked();
                    }
                }
            }
            catch (Exception e)
            { Complete(null, "Native DNS probe unavailable: " + e.GetType().Name); }
            finally { EndNativeCall(); }
        }

        internal void RequestCancellation()
        {
            lock (gate)
            {
                cancelRequested = true;
                QueueCancellationLocked();
            }
        }

        private void QueueCancellationLocked()
        {
            if (!pending || completed || !cancelRequested || cancellationQueued) return;
            cancellationQueued = true;
            _ = Task.Run(Cancel);
        }

        private void Cancel()
        {
            lock (gate)
            {
                if (completed) return;
                nativeCalls++;
            }
            try { _ = DnsCancelQuery(cancel); }
            catch (Exception) { /* Caller already reported inconclusive; retain buffers until callback. */ }
            finally { EndNativeCall(); }
        }

        private void EndNativeCall()
        {
            lock (gate)
            {
                nativeCalls--;
                if (completed && nativeCalls == 0) ReleaseBuffers();
            }
        }

        internal void Complete(int? status, string? error = null)
        {
            lock (gate)
            {
                if (completed) return;
                try
                {
                    var response = Marshal.PtrToStructure<DnsQueryResult>(result);
                    if (response.Records != IntPtr.Zero)
                        DnsFree(response.Records, 1); // DnsFreeRecordList
                }
                catch (Exception e)
                {
                    status = null;
                    error = "Native DNS cleanup did not complete: " + e.GetType().Name;
                }
                completed = true;
                completion.TrySetResult(new(status, error));
                if (nativeCalls == 0) ReleaseBuffers();
            }
        }

        private void ReleaseBuffers()
        {
            if (released) return;
            released = true;
            if (context.IsAllocated) context.Free();
            foreach (IntPtr buffer in new[] { request, result, cancel, name })
                if (buffer != IntPtr.Zero) Marshal.FreeHGlobal(buffer);
            request = result = cancel = name = IntPtr.Zero;
        }
    }

    private static IntPtr Allocate(int bytes)
    {
        var pointer = Marshal.AllocHGlobal(bytes);
        Marshal.Copy(new byte[bytes], 0, pointer, bytes);
        return pointer;
    }

    private static readonly DnsCompletion CompletedCallback = OnCompleted;
    private static void OnCompleted(IntPtr context, IntPtr result)
    {
        // Native invokes one completion for a pending query. GCHandle remains
        // rooted until this callback and any concurrent native call finish.
        QueryOperation? operation = null;
        try
        {
            operation = (QueryOperation)GCHandle.FromIntPtr(context).Target!;
            operation.Complete(Marshal.PtrToStructure<DnsQueryResult>(result).QueryStatus);
        }
        catch (Exception e)
        { operation?.Complete(null, "Native DNS callback failed: " + e.GetType().Name); }
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct DnsQueryRequest
    {
        public uint Version;
        public IntPtr QueryName;
        public ushort QueryType;
        public ulong QueryOptions;
        public IntPtr ServerList;
        public uint InterfaceIndex;
        public IntPtr CompletionCallback;
        public IntPtr Context;
    }
    [StructLayout(LayoutKind.Sequential)]
    private struct DnsQueryResult
    {
        public uint Version;
        public int QueryStatus;
        public ulong QueryOptions;
        public IntPtr Records;
        public IntPtr Reserved;
    }
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    private delegate void DnsCompletion(IntPtr context, IntPtr result);
    [DllImport("dnsapi.dll", ExactSpelling = true)]
    private static extern int DnsQueryEx(IntPtr request, IntPtr result, IntPtr cancel);
    [DllImport("dnsapi.dll", ExactSpelling = true)]
    private static extern int DnsCancelQuery(IntPtr cancel);
    [DllImport("dnsapi.dll", ExactSpelling = true)]
    private static extern void DnsFree(IntPtr data, int freeType);
}
