using System.Text;
using System.Text.Json.Nodes;
using Herz.Core;

namespace Herz.Windows;
internal static class WorkerHost
{
    internal static async Task<int> RunAsync(string id, string profileName, string slot, string release, string canary, string policyCanary, string encodedNetworkControl)
    {
        using var profile = NativeSandbox.OpenExistingProfile(profileName);
        NativeSandbox.VerifyCurrentAppContainer(profile.Sid);
        var proof = await RuntimeChecks.ProbeAsync(profile.Sid, canary, policyCanary, Wire.Decode<NetworkControl>(Encoding.UTF8.GetString(Convert.FromBase64String(encodedNetworkControl))));
        if (proof.Passed)
        {
            // Exercise a real descendant: token inheritance alone is not reported
            // as a successful descendant network/file test.
            try
            {
                using var descendant = NativeSandbox.Launch(profile, Path.Combine(release, "HERZ.exe"), ["--probe-child", profileName, canary, policyCanary, encodedNetworkControl], slot, null, new(512L * 1024 * 1024, 50, 3));
                descendant.StandardInput.Close();
                var stderr = ReadBounded(descendant.StandardError, 65536);
                string raw = await descendant.StandardOutput.ReadToEndAsync().WaitAsync(TimeSpan.FromSeconds(22));
                bool ended = descendant.WaitForExit(TimeSpan.FromSeconds(2));
                var childProof = Wire.Decode<RuntimeProof>(raw);
                bool passed = ended && descendant.ExitCode == 0 && childProof.Passed;
                descendant.Terminate();
                proof = proof with
                {
                    Passed = passed,
                    Checks = proof.Checks.Concat(childProof.Checks.Select(c => c with { Kind = "child(pid=" + descendant.Pid + ")/" + c.Kind })).ToArray(),
                    Reason = passed ? proof.Reason : "اختبار العملية الفرعية لم ينجح؛ التنفيذ محظور."
                };
                _ = await stderr.WaitAsync(TimeSpan.FromSeconds(2));
            }
            catch (Exception e)
            {
                proof = proof with
                {
                    Passed = false,
                    Reason = "تعذر اختبار العملية الفرعية: " + e.GetType().Name + ": " + e.Message
                };
            }
        }

        using var input = new StreamReader(Console.OpenStandardInput(), Encoding.UTF8);
        using var output = new StreamWriter(Console.OpenStandardOutput(), new UTF8Encoding(false))
        {
            AutoFlush = true
        };
        object sendLock = new();
        object runLock = new();
        void Send(object frame)
        {
            lock (sendLock)
            {
                output.WriteLine(Wire.Encode(frame));
            }
        }

        string? readinessError = proof.Passed ? await CheckEngineAsync(profile, id, slot, release) : proof.Reason;
        Send(new WorkerHello("hello", id, Environment.ProcessId, proof, readinessError));
        CancellationTokenSource? active = null;
        string? activeId = null;
        Task? running = null;
        while (await input.ReadLineAsync()is { } line)
        {
            if (line.Length > 1024 * 1024)
                return 125;
            WorkerRequest request;
            try
            {
                request = Wire.Decode<WorkerRequest>(line);
            }
            catch
            {
                return 125;
            }

            if (request.Operation == "cancel")
            {
                lock (runLock)
                {
                    if (request.Id == activeId)
                        active?.Cancel();
                }

                continue;
            }

            lock (runLock)
            {
                if (active is not null)
                {
                    Send(new WorkerReply(request.Id, false, Error: "Worker busy."));
                    continue;
                }

                if (!proof.Passed)
                {
                    Send(new WorkerReply(request.Id, false, Error: proof.Reason));
                    continue;
                }

                if (readinessError is not null)
                {
                    Send(new WorkerReply(request.Id, false, Error: readinessError));
                    continue;
                }

                active = new CancellationTokenSource();
                activeId = request.Id;
                var current = active;
                running = Task.Run(async () =>
                {
                    WorkerReply reply;
                    try
                    {
                        if (request.Operation == "model" && id == "local_model")
                        {
                            string text = await ModelAsync(profile, slot, release, request.Prompt ?? "", current.Token);
                            reply = new WorkerReply(request.Id, true, Text: text);
                        }
                        else if (request.Operation == "run" && request.Context is not null)
                        {
                            ValidateWorkspace(slot, request.Context);
                            var result = id switch
                            {
                                "stats_dotnet" => Stats(request.Context, current.Token),
                                "report_node" => await ReportAsync(profile, release, request.Context, current.Token),
                                _ => throw new PolicyException("The external connector has not been approved for execution.")};
                            current.Token.ThrowIfCancellationRequested();
                            reply = new WorkerReply(request.Id, true, Execution: result);
                        }
                        else
                            reply = new WorkerReply(request.Id, false, Error: "Unsupported worker request.");
                    }
                    catch (OperationCanceledException)
                    {
                        reply = new WorkerReply(request.Id, false, Error: "Canceled.", Canceled: true);
                    }
                    catch (Exception e)
                    {
                        reply = new WorkerReply(request.Id, false, Error: e.GetType().Name + ": " + e.Message[..Math.Min(e.Message.Length, 500)]);
                    }

                    // Publish completion only after becoming idle. Otherwise a fast
                    // next request can receive a spurious "busy" response.
                    lock (runLock)
                    {
                        activeId = null;
                        active = null;
                        current.Dispose();
                        Send(reply);
                    }
                });
            }
        }

        lock (runLock)
            active?.Cancel();
        if (running is not null)
        {
            try
            {
                await running.WaitAsync(TimeSpan.FromSeconds(5));
            }
            catch
            {
            }
        }

        return 0;
    }

    private static void ValidateWorkspace(string slot, TaskContext context)
    {
        string root = Path.GetFullPath(slot).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        string full = Path.GetFullPath(context.Workspace);
        if (!full.StartsWith(root, StringComparison.OrdinalIgnoreCase))
            throw new PolicyException("Workspace is outside the assigned slot.");
        NativeSandbox.EnsureNoReparsePoints(full);
        foreach (var item in context.Inputs)
        {
            if (!Path.GetFullPath(item.FullPath).StartsWith(full + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                throw new PolicyException("Input is outside the task workspace.");
            NativeSandbox.EnsureNoReparsePoints(item.FullPath);
            if (LocalPaths.HashFile(item.FullPath) != item.Sha256)
                throw new PolicyException("Input integrity changed.");
        }
    }

    private static AgentExecution Stats(TaskContext context, CancellationToken token)
    {
        var numbers = context.Input["numbers"]?.AsArray().Select(x => x!.GetValue<decimal>()).ToArray() ?? throw new PolicyException("Numbers are required.");
        if (numbers.Length is < 1 or > 200 || numbers.Any(x => Math.Abs(x) > 1000000000m))
            throw new PolicyException("Invalid or excessive numeric input.");
        token.ThrowIfCancellationRequested();
        decimal sum = numbers.Sum();
        var result = new JsonObject
        {
            ["count"] = numbers.Length,
            ["sum"] = sum,
            ["mean"] = sum / numbers.Length,
            ["min"] = numbers.Min(),
            ["max"] = numbers.Max(),
            ["numbers"] = new JsonArray(numbers.Select(x => (JsonNode? )JsonValue.Create(x)).ToArray())
        };
        string target = LocalPaths.InDirectory(context.Workspace, "stats.json");
        if (File.Exists(target))
            throw new IOException("An output file already exists.");
        Wire.WriteJson(target, result);
        return new(0, result, ["stats.json"]);
    }

    private static async Task<AgentExecution> ReportAsync(SandboxProfile profile, string release, TaskContext context, CancellationToken token)
    {
        string executable = Path.Combine(release, "tools", "node", "node.exe");
        string script = Path.Combine(release, "examples", "node_reporter", "agent.js");
        var arguments = new[]
        {
            "--no-addons",
            "--disable-proto=throw",
            "--max-old-space-size=128",
            "--permission",
            "--allow-fs-read=" + context.Workspace,
            "--allow-fs-read=" + script,
            "--allow-fs-write=" + context.Workspace,
            script
        };
        var run = await RunChild(profile, executable, arguments, context.Workspace, Wire.Encode(context), 40, 384L * 1024 * 1024, token);
        if (run.Exit != 0)
            throw new InvalidOperationException("Node report failed: " + run.Error);
        var frame = JsonNode.Parse(run.Output)?.AsObject() ?? throw new InvalidDataException("The report agent returned invalid JSON.");
        var result = frame["result"]?.AsObject() ?? throw new InvalidDataException("Missing report result.");
        var artifacts = frame["artifacts"]?.AsArray().Select(x => x!.GetValue<string>()).ToArray() ?? [];
        return new(0, result, artifacts);
    }

    private static async Task<string> ModelAsync(SandboxProfile profile, string slot, string release, string prompt, CancellationToken token)
    {
        LocalModel.ValidatePrompt(prompt);
        var selection = LocalModel.ReadSelection(release);
        if (!selection.Approved)
            throw new PolicyException(selection.Reason);
        LocalModel.RequireMemoryBudget(selection);
        string model = LocalPaths.InDirectory(Path.Combine(NativeSandbox.OwnedRoot, "models"), selection.File);
        string executable = Path.Combine(release, "tools", "llama", "llama-completion.exe");
        if (!File.Exists(model) || !File.Exists(executable))
            throw new PolicyException("The locally approved model or engine is missing.");
        string promptFile = Path.Combine(slot, "prompt-" + Guid.NewGuid().ToString("N") + ".txt");
        string text = LocalModel.Prompt(selection, prompt);
        await File.WriteAllTextAsync(promptFile, text, new UTF8Encoding(false), token);
        var culture = System.Globalization.CultureInfo.InvariantCulture;
        string[] arguments = ["--offline", "--no-repack", "-m", model, "-ngl", "0", "-t", "4", "-c", "2048", "-b", "128", "-ub", "128", "-n", selection.MaxOutputTokens.ToString(culture), "--temp", selection.Temperature.ToString(culture), "--top-p", selection.TopP.ToString(culture), "--top-k", selection.TopK.ToString(culture), "--min-p", "0", "--presence-penalty", selection.PresencePenalty.ToString(culture), "--repeat-penalty", "1", "--seed", "42", "--no-display-prompt", "--no-conversation", "--no-jinja", "--simple-io", "--color", "off", "-f", promptFile];
        var run = await RunChild(profile, executable, arguments, slot, null, 150, selection.JobMemoryMiB * 1024L * 1024, token);
        if (run.Exit != 0)
            throw new InvalidOperationException("Local inference failed (0x" + unchecked((uint)run.Exit).ToString("X8") + "): " + run.Error);
        string answer = run.Output.Trim();
        const string endMarker = "[end of text]";
        if (answer.EndsWith(endMarker, StringComparison.Ordinal))
            answer = answer[..^endMarker.Length].TrimEnd();
        return answer;
    }

    private static async Task<string?> CheckEngineAsync(SandboxProfile profile, string id, string slot, string release)
    {
        try
        {
            if (id == "stats_dotnet")
                return null;
            if (id == "local_model" && !LocalModel.ReadSelection(release).Approved)
                return LocalModel.ReadSelection(release).Reason;
            string executable = Path.Combine(release, "tools", id == "local_model" ? "llama" : "node", id == "local_model" ? "llama-completion.exe" : "node.exe");
            var probe = await RunChild(profile, executable, ["--version"], slot, null, 15, 384L * 1024 * 1024, CancellationToken.None);
            if (probe.Exit != 0)
            {
                string code = unchecked((uint)probe.Exit).ToString("X8");
                return "فشل اختبار محرك " + id + " داخل Windows؛ الرمز 0x" + code + ". " + (code == "C0000135" ? "أحد ملفات DLL المطلوبة غير موجود، وقد يشمل Microsoft Visual C++ Runtime؛ لم يُثبت شيء تلقائيًا." : probe.Error);
            }

            string expected = id == "local_model" ? "12651" : "v24.22.3";
            if (!(probe.Output + probe.Error).Contains(expected, StringComparison.Ordinal))
                return "لم يطابق محرك التنفيذ الإصدار المعتمد: " + id;
            return null;
        }
        catch (Exception e)
        {
            return "تعذر اختبار المحرك المحلي " + id + ": " + e.GetType().Name + ": " + e.Message;
        }
    }

    private static async Task<(int Exit, string Output, string Error)> RunChild(SandboxProfile profile, string executable, IReadOnlyList<string> arguments, string directory, string? input, int seconds, long memory, CancellationToken token)
    {
        using var child = NativeSandbox.Launch(profile, executable, arguments, directory, null, new(memory, 50, 6));
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(token);
        timeout.CancelAfter(TimeSpan.FromSeconds(seconds));
        using var stop = timeout.Token.Register(() =>
        {
            try
            {
                child.Terminate(124);
            }
            catch
            {
            }
        });
        var stdout = ReadBounded(child.StandardOutput, 1024 * 1024);
        var stderr = ReadBounded(child.StandardError, 1024 * 1024);
        try
        {
            if (input is not null)
                await child.StandardInput.WriteAsync(input);
            child.StandardInput.Close();
            bool exited = await Task.Run(() => child.WaitForExit(TimeSpan.FromSeconds(seconds + 2)));
            if (!exited)
            {
                child.Terminate(124);
                throw new TimeoutException("Worker deadline exceeded.");
            }

            int exit = child.ExitCode ?? 125;
            child.Terminate((uint)Math.Max(0, exit)); // terminate any remaining descendants before reading artifacts
            string output = await stdout.WaitAsync(TimeSpan.FromSeconds(3));
            string error = await stderr.WaitAsync(TimeSpan.FromSeconds(3));
            timeout.Token.ThrowIfCancellationRequested();
            return (exit, output, error[..Math.Min(error.Length, 1000)]);
        }
        finally
        {
            try
            {
                child.Terminate(125);
            }
            catch
            {
            }
        }
    }

    private static async Task<string> ReadBounded(StreamReader reader, int maximum)
    {
        var text = new StringBuilder();
        char[] buffer = new char[4096];
        while (await reader.ReadAsync(buffer)is var count && count > 0)
        {
            if (text.Length + count > maximum)
                throw new InvalidDataException("Worker output exceeded its bound.");
            text.Append(buffer, 0, count);
        }

        return text.ToString();
    }
}
