using System.Globalization;

namespace Herz.Windows;

// Pure decisions shared by production probes and the cross-platform regression
// tests. No socket, process, policy mutation, clock read or OS evidence is invented
// here. A comparable failure is not a Windows access-denied result.
internal static class NetworkAdmission
{
    internal static readonly IReadOnlyList<string> RequiredChecks = Array.AsReadOnly(new[]
    {
        "loopback-ipv4", "loopback-ipv6", "tcp-ipv4", "tcp-ipv6",
        "dns-udp-ipv4", "dns-udp-ipv6", "dns-api-a", "dns-api-aaaa",
        "file-read", "file-write", "policy-write-dac", "policy-write-owner",
        "workdir-write-dac", "workdir-write-owner"
    });

    internal static bool TokenValid(TokenVerificationInfo token, string? expectedSid) =>
        !string.IsNullOrWhiteSpace(expectedSid) && token.IsAppContainer && !token.Elevated &&
        !token.HasNetworkCapabilities && token.CapabilityCount == 0 &&
        string.Equals(token.AppContainerSid, expectedSid, StringComparison.Ordinal) &&
        token.IntegritySid == "S-1-16-4096";

    internal static SandboxProbeResult SocketResult(string kind, SandboxProbeResult raw)
    {
        if (raw.Outcome is "allowed" or "unexpected-send")
        {
            if (kind.StartsWith("dns-udp-", StringComparison.Ordinal))
                return raw with { Kind = kind, Outcome = "inconclusive",
                    Detail = "UDP send was accepted locally. This proves neither remote delivery nor a policy denial." };
            return raw with { Kind = kind, Outcome = "failed",
                Detail = "The forbidden TCP connection succeeded." };
        }
        if (raw.NativeError == 10013)
            return raw with { Kind = kind, Outcome = "denied", Detail = "Explicit WSAEACCES for this socket operation." };
        return raw with { Kind = kind, Outcome = "inconclusive",
            Detail = "No explicit socket access denial. No route, refusal, timeout and a live comparison endpoint do not prove a policy block." };
    }

    internal static SandboxProbeResult DnsResult(string kind, int? status, string? error = null)
    {
        if (status is 5 or 10013)
            return new(kind, "denied", status, "Native DNS query returned explicit access denied.");
        if (status == 0)
            return new(kind, "failed", status, "A wire-only DNS query completed successfully; DNS isolation is not established.");
        return new(kind, "inconclusive", status,
            error ?? "DNS timeout, cancellation, NXDOMAIN, server refusal and missing records are not a policy-denial proof.");
    }

    internal static bool CurrentBaseline(string? baselineSession, string? witnessSession,
        string? recordedUtc, DateTimeOffset now)
    {
        return Guid.TryParseExact(baselineSession, "N", out var baselineId) && baselineId != Guid.Empty &&
            Guid.TryParseExact(witnessSession, "N", out var witnessId) && baselineId == witnessId &&
            DateTimeOffset.TryParse(recordedUtc, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var recorded) &&
            recorded <= now && now - recorded <= TimeSpan.FromMinutes(3);
    }

    internal static bool WitnessValid(int ipv4Port, int ipv6Port, string? sessionId,
        string? startedUtc, DateTimeOffset now)
    {
        return ipv4Port is >= 1024 and <= 65535 && ipv6Port is >= 1024 and <= 65535 &&
            Guid.TryParseExact(sessionId, "N", out var id) && id != Guid.Empty &&
            DateTimeOffset.TryParse(startedUtc, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var started) &&
            started <= now && now - started <= TimeSpan.FromMinutes(5);
    }

    internal static AdmissionDecision Evaluate(bool tokenVerified, IReadOnlyList<SandboxProbeResult> checks)
    {
        var problems = new List<string>();
        if (!tokenVerified)
            problems.Add("token=not-verified");
        var groups = checks.GroupBy(c => c.Kind, StringComparer.Ordinal)
            .ToDictionary(g => g.Key, g => g.ToArray(), StringComparer.Ordinal);
        if (!groups.TryGetValue("token", out var tokens) || tokens.Length != 1 || tokens[0].Outcome != "verified")
            problems.Add("token=missing-or-invalid");
        foreach (string required in RequiredChecks)
        {
            if (!groups.TryGetValue(required, out var entries) || entries.Length != 1)
            {
                problems.Add(required + "=missing-or-duplicate");
                continue;
            }
            var check = entries[0];
            bool correctDenial = check.Outcome == "denied" &&
                (required.StartsWith("dns-api-", StringComparison.Ordinal)
                    ? check.NativeError is 5 or 10013
                    : required.StartsWith("loopback-", StringComparison.Ordinal) ||
                      required.StartsWith("tcp-", StringComparison.Ordinal) ||
                      required.StartsWith("dns-udp-", StringComparison.Ordinal)
                        ? check.NativeError == 10013
                        : check.NativeError is 5 or unchecked((int)0x80070005));
            if (!correctDenial)
                problems.Add(required + "=" + check.Outcome + "/" + check.NativeError);
        }
        foreach (var check in checks.Where(c => c.Kind != "token" && !RequiredChecks.Contains(c.Kind)))
            problems.Add(check.Kind + "=unexpected-check");
        return new(problems.Count == 0, problems.AsReadOnly());
    }
}

internal sealed record AdmissionDecision(bool Passed, IReadOnlyList<string> Problems);
