using System.Text;
using System.Text.Json.Nodes;
using Microsoft.Win32.SafeHandles;
using Herz.Core;

namespace Herz.Windows;
internal sealed class WindowsPipeRunner : IAgentRunner, IDisposable
{
    private sealed class Connection : IDisposable
    {
        public WorkerLink Link { get; }
        public StreamWriter Input { get; }
        public StreamReader Output { get; }
        public StreamReader Error { get; }
        public object WriteGate { get; } = new();

        public volatile string? Active;
        public bool Dead;
        public bool Alive
        {
            get
            {
                try
                {
                    return !Dead && NativeSandbox.ReadJobUsage(job.DangerousGetHandle()).ActiveProcesses > 0;
                }
                catch
                {
                    return false;
                }
            }
        }

        private readonly SafeFileHandle job;
        public Connection(WorkerLink link)
        {
            Link = link;
            Input = new(new FileStream(new SafeFileHandle(new IntPtr(link.InputHandle), true), FileAccess.Write), new UTF8Encoding(false))
            {
                AutoFlush = true
            };
            Output = new(new FileStream(new SafeFileHandle(new IntPtr(link.OutputHandle), true), FileAccess.Read), Encoding.UTF8);
            Error = new(new FileStream(new SafeFileHandle(new IntPtr(link.ErrorHandle), true), FileAccess.Read), Encoding.UTF8);
            job = new(new IntPtr(link.JobHandle), true);
            _ = Task.Run(async () =>
            {
                try
                {
                    var buffer = new char[2048];
                    while (await Error.ReadAsync(buffer) > 0)
                    {
                    }
                }
                catch (IOException)
                {
                }
                catch (ObjectDisposedException)
                {
                }
            });
        }

        public void Send(WorkerRequest message)
        {
            lock (WriteGate)
            {
                if (Dead)
                    throw new IOException("The isolated worker has stopped.");
                Input.WriteLine(Wire.Encode(message));
            }
        }

        public void Kill()
        {
            if (!Dead)
            {
                Dead = true;
                NativeSandbox.TerminateManagedJob(job.DangerousGetHandle(), 125);
            }
        }

        public void Dispose()
        {
            try
            {
                Kill();
            }
            catch
            {
            }

            Input.Dispose();
            Output.Dispose();
            Error.Dispose();
            job.Dispose();
        }
    }

    private readonly RuntimeSession session;
    private readonly RuntimeProof managerProof;
    private readonly bool startupAuthorized;
    private readonly Dictionary<string, Connection> connections;
    private readonly SemaphoreSlim sequential = new(1, 1);
    private bool disposed;
    public WindowsPipeRunner(RuntimeSession session, RuntimeProof managerProof, bool startupAuthorized = false)
    {
        this.session = session;
        this.managerProof = managerProof;
        this.startupAuthorized = startupAuthorized;
        connections = session.Workers.ToDictionary(w => w.AgentId, w => new Connection(w));
    }

    public IsolationStatus Probe() => new(startupAuthorized && managerProof.Passed && session.Baseline.Ipv4Connected, "Windows AppContainer + Job Objects + inherited anonymous pipes", !managerProof.Passed ? managerProof.Reason : !startupAuthorized ? "لم يصل اعتماد بدء التشغيل من المشغل الموثوق؛ تنفيذ المهام محظور." : !session.Baseline.Ipv4Connected ? "لم يُثبت اتصال الإنترنت في جلسة الفحص الحالية. شهادة اعتماد التشغيل دون اتصال لم تُنفذ بعد؛ المهام محظورة." : "اختبار هوية المدير ومنع المقابس وملفات الاختبار نجح في هذه الجلسة. تدقيق كل رفض للنواة واعتماد Windows الكامل ما زالا غير مكتملين.", false);
    public AgentReadiness Check(AgentDefinition agent)
    {
        if (!Probe().Supported)
            return new(false, Probe().Reason);
        if (!new[]
        {
            "stats_dotnet",
            "report_node"
        }.Contains(agent.Id))
            return new(false, "التعريف محفوظ. تشغيل إضافة خارجية يحتاج اعتماد موصل وعزل وتدقيق خاصين بها؛ غير مفعّل في هذا الإصدار.");
        string expectedSource = Path.Combine(session.Release, "examples", agent.Id == "report_node" ? "node_reporter" : "stats_dotnet");
        if (!string.Equals(Path.GetFullPath(agent.SourceRoot), expectedSource, StringComparison.OrdinalIgnoreCase))
            return new(false, "اسم العامل المدمج لا يمنح صلاحية تشغيل مصدر خارجي. استخدم معرفًا مختلفًا للإضافة.");
        if (!connections.TryGetValue(agent.Id, out var c) || !c.Alive)
            return new(false, "العامل المعزول غير متصل. أعد فتح المركز لإعادة تجهيزه.");
        return new(c.Link.Hello.Proof.Passed && c.Link.Hello.ReadinessError is null, c.Link.Hello.ReadinessError ?? c.Link.Hello.Proof.Reason);
    }

    public async Task<AgentExecution> ExecuteAsync(AgentDefinition agent, TaskContext context, CancellationToken cancellationToken)
    {
        var readiness = Check(agent);
        if (!readiness.Ready)
            throw new PolicyException(readiness.Reason);
        await sequential.WaitAsync(cancellationToken);
        try
        {
            var c = connections[agent.Id];
            string directory = LocalPaths.InDirectory(c.Link.Slot, context.TaskId + "-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(directory);
            var inputs = new List<ArtifactRecord>();
            foreach (var source in context.Inputs)
            {
                if (source.Bytes > 16 * 1024 * 1024 || LocalPaths.HashFile(source.FullPath) != source.Sha256)
                    throw new PolicyException("ملف المدخل تغيّر أو تجاوز الحد.");
                string relative = "inputs/" + source.SourceTaskId + "/" + Path.GetFileName(source.RelativePath);
                string destination = LocalPaths.InDirectory(directory, relative);
                Directory.CreateDirectory(Path.GetDirectoryName(destination)!);
                File.Copy(source.FullPath, destination, false);
                inputs.Add(source with { FullPath = destination });
            }

            var privateContext = context with
            {
                Workspace = directory,
                Inputs = inputs
            };
            var reply = await Request(c, new WorkerRequest("run", context.TaskId, privateContext), Math.Clamp(agent.WallSeconds, 5, 300) + 15, cancellationToken);
            if (reply.Canceled)
                throw new OperationCanceledException(cancellationToken);
            if (!reply.Ok || reply.Execution is null)
                throw new InvalidOperationException(reply.Error ?? "العامل لم يقدم نتيجة قابلة للتحقق.");
            var result = reply.Execution;
            if (result.Artifacts.Count > 32)
                throw new InvalidDataException("Too many result files.");
            foreach (var relative in result.Artifacts)
            {
                string source = LocalPaths.InDirectory(directory, relative);
                var info = new FileInfo(source);
                if (!info.Exists || info.Length > 16 * 1024 * 1024)
                    throw new InvalidDataException("A result file is missing or too large.");
                string destination = LocalPaths.InDirectory(context.Workspace, relative);
                Directory.CreateDirectory(Path.GetDirectoryName(destination)!);
                File.Copy(source, destination, false);
                if (LocalPaths.HashFile(source) != LocalPaths.HashFile(destination))
                    throw new InvalidDataException("Result copy failed integrity verification.");
            }

            return result;
        }
        finally
        {
            sequential.Release();
        }
    }

    public async Task<string> AskLocalModel(string prompt, CancellationToken token)
    {
        if (!Probe().Supported)
            throw new PolicyException(Probe().Reason);
        if (!connections.TryGetValue("local_model", out var c) || !c.Alive || !c.Link.Hello.Proof.Passed)
            throw new PolicyException("النموذج المحلي أو اختبار عزله غير جاهز.");
        if (c.Link.Hello.ReadinessError is not null)
            throw new PolicyException(c.Link.Hello.ReadinessError);
        LocalModel.ValidatePrompt(prompt);
        await sequential.WaitAsync(token);
        try
        {
            var reply = await Request(c, new WorkerRequest("model", Guid.NewGuid().ToString("N"), Prompt: prompt), 180, token);
            if (reply.Canceled)
                throw new OperationCanceledException(token);
            if (!reply.Ok)
                throw new InvalidOperationException(reply.Error ?? "توقف النموذج المحلي.");
            return reply.Text ?? "لم ينتج النموذج نصًا.";
        }
        finally
        {
            sequential.Release();
        }
    }

    private static async Task<WorkerReply> Request(Connection c, WorkerRequest request, int timeoutSeconds, CancellationToken token)
    {
        c.Active = request.Id;
        c.Send(request);
        using var cancel = token.Register(() =>
        {
            try
            {
                c.Send(new("cancel", request.Id));
            }
            catch (IOException)
            {
            }
            catch (ObjectDisposedException)
            {
            }
        });
        using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(timeoutSeconds));
        try
        {
            while (true)
            {
                string? line = await c.Output.ReadLineAsync(deadline.Token).AsTask().WaitAsync(deadline.Token);
                if (line is null)
                    throw new IOException("توقفت قناة العامل المعزول.");
                if (line.Length > 1024 * 1024)
                    throw new InvalidDataException("Worker message exceeded its limit.");
                var reply = Wire.Decode<WorkerReply>(line);
                if (reply.Id == request.Id)
                    return reply;
            }
        }
        catch
        {
            try
            {
                c.Kill();
            }
            catch
            {
            }

            throw;
        }
        finally
        {
            c.Active = null;
        }
    }

    public void StopAll()
    {
        foreach (var c in connections.Values)
        {
            var id = c.Active;
            if (id is null)
                continue;
            try
            {
                c.Send(new("cancel", id));
            }
            catch
            {
                try
                {
                    c.Kill();
                }
                catch
                {
                }
            }

            _ = Task.Run(async () =>
            {
                await Task.Delay(2000);
                if (c.Active == id)
                {
                    try
                    {
                        c.Kill();
                    }
                    catch
                    {
                    }
                }
            });
        }
    }

    public void Dispose()
    {
        if (disposed)
            return;
        disposed = true;
        foreach (var c in connections.Values)
            c.Dispose();
        sequential.Dispose();
    }
}
