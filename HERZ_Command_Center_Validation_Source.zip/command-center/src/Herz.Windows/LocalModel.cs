using System.Runtime.InteropServices;
using System.Text;

namespace Herz.Windows;
internal static class LocalModel
{
    internal const int MaximumPromptBytes = 1024;
    internal static LocalModelSelection ReadSelection(string release)
    {
        var value = Wire.Decode<LocalModelSelection>(File.ReadAllText(Path.Combine(release, "model-selection.json")));
        if (value.License != "Apache-2.0" || value.Bytes < 0 || value.Sha256.Length != 64 || value.PromptTemplate is not ("qwen3" or "qwen35") || value.MaxOutputTokens is < 1 or > 512 || value.Temperature is < 0 or > 1.5 || value.TopP is <= 0 or > 1 || value.TopK is < 0 or > 100 || value.PresencePenalty is < 0 or > 2 || value.JobMemoryMiB is < 1024 or > 4096 || value.RequiredFreeMemoryMiB is < 3072 or > 6144 || value.SystemPrompt.Length > 600 || value.File != Path.GetFileName(value.File))
            throw new InvalidDataException("Invalid locally reviewed model selection.");
        return value;
    }

    internal static async Task<LocalModelAvailability> PrepareAsync(string release, string packageRoot, string models, IProgress<string> progress, bool permitDownload, CancellationToken token)
    {
        var model = ReadSelection(release);
        if (!model.Approved)
            return new(model, false, model.Reason);
        string original = LocalPaths.InDirectory(Path.Combine(packageRoot, "models"), model.File);
        string local = LocalPaths.InDirectory(models, model.File);
        if (!File.Exists(local))
        {
            if (File.Exists(original))
            {
                progress.Report("التحقق من أوزان النموذج المحلي ونسخها إلى مساحة HERZ...");
                Verify(original, model);
                token.ThrowIfCancellationRequested();
                string temporary = local + "." + Guid.NewGuid().ToString("N") + ".partial";
                File.Copy(original, temporary, false);
                Verify(temporary, model);
                token.ThrowIfCancellationRequested();
                File.Move(temporary, local, false);
            }
            else if (permitDownload)
            {
                var identity = NativeSandbox.GetCurrentTokenInfo();
                if (identity.IsAppContainer || identity.Elevated)
                    throw new UnauthorizedAccessException("Only ordinary-account preparation can download dependencies.");
                await ArtifactDownload.DownloadAsync(new Uri(model.SourceUrl), local, model.Bytes, model.Sha256, progress, token);
            }
            else
                return new(model, false, "النموذج غير مجهز. أغلق التطبيق ثم افتح HERZ.exe واختر تجهيز النموذج. لا يوجد تحويل إلى خدمة خارجية.");
        }

        Verify(local, model);
        return new(model, true, model.Reason);
    }

    private static void Verify(string path, LocalModelSelection model)
    {
        if (new FileInfo(path).Length != model.Bytes || LocalPaths.HashFile(path) != model.Sha256)
            throw new InvalidDataException("Model checksum mismatch. The existing file was preserved and execution was refused.");
    }

    internal static void ValidatePrompt(string prompt)
    {
        if (string.IsNullOrWhiteSpace(prompt) || Encoding.UTF8.GetByteCount(prompt) > MaximumPromptBytes)
            throw new Herz.Core.PolicyException("اكتب طلبًا قصيرًا ضمن 1024 بايت UTF-8، أي نحو 500 حرف عربي، ليناسب سياق النموذج المحلي.");
        if (prompt.Contains("<|", StringComparison.Ordinal) || prompt.Contains("|>", StringComparison.Ordinal))
            throw new Herz.Core.PolicyException("لا يُسمح بإدخال رموز التحكم الخاصة بقالب النموذج.");
    }

    internal static string Prompt(LocalModelSelection model, string user)
    {
        ValidatePrompt(user);
        return "<|im_start|>system\n" + model.SystemPrompt + "<|im_end|>\n<|im_start|>user\n" + user + (model.PromptTemplate == "qwen3" ? "\n/no_think" : "") + "<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n";
    }

    internal static ulong AvailablePhysicalBytes()
    {
        var memory = new MemoryStatus
        {
            Length = (uint)Marshal.SizeOf<MemoryStatus>()
        };
        if (!GlobalMemoryStatusEx(ref memory))
            throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
        return memory.AvailablePhysical;
    }

    internal static void RequireMemoryBudget(LocalModelSelection model)
    {
        ulong available = AvailablePhysicalBytes();
        if (available < (ulong)model.RequiredFreeMemoryMiB * 1024 * 1024)
            throw new Herz.Core.PolicyException($"الذاكرة المتاحة الآن {available / 1048576UL:N0} MiB. يلزم {model.RequiredFreeMemoryMiB} MiB متاحة لبدء النموذج؛ أغلق بعض البرامج ثم أعد المحاولة.");
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct MemoryStatus
    {
        public uint Length, Load;
        public ulong TotalPhysical, AvailablePhysical, TotalPageFile, AvailablePageFile, TotalVirtual, AvailableVirtual, AvailableExtendedVirtual;
    }

    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GlobalMemoryStatusEx(ref MemoryStatus value);
}
