using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;

namespace Herz.Windows;

// A positive control held by the trusted launcher only during preparation.
// The ports are ephemeral and bound to loopback. No private files are transmitted.
internal sealed class NetworkWitness : IDisposable
{
    private readonly TcpListener ipv4;
    private readonly TcpListener ipv6;
    private readonly CancellationTokenSource stop = new();
    private readonly Task[] servers;
    private readonly byte[] challenge = RandomNumberGenerator.GetBytes(24);
    private readonly string sessionId;
    private readonly string startedUtc = DateTimeOffset.UtcNow.ToString("O");
    private bool disposed;

    private NetworkWitness(TcpListener v4, TcpListener v6, string session)
    {
        ipv4 = v4;
        ipv6 = v6;
        sessionId = session;
        servers = [Serve(v4), Serve(v6)];
    }

    private async Task Serve(TcpListener listener)
    {
        var token = stop.Token;
        while (!token.IsCancellationRequested)
        {
            TcpClient client;
            try { client = await listener.AcceptTcpClientAsync(token).ConfigureAwait(false); }
            catch (OperationCanceledException) { return; }
            catch (ObjectDisposedException) { return; }
            catch (SocketException) when (token.IsCancellationRequested) { return; }
            using (client)
            {
                try
                {
                    using NetworkStream stream = client.GetStream();
                    await stream.WriteAsync(challenge, token).ConfigureAwait(false);
                    await stream.FlushAsync(token).ConfigureAwait(false);
                }
                catch (IOException) { }
                catch (SocketException) { }
                catch (OperationCanceledException) { return; }
            }
        }
    }

    internal static async Task<NetworkWitness> StartAsync(BaselineResult internet, CancellationToken ct)
    {
        if (!Guid.TryParseExact(internet.SessionId, "N", out var session) || session == Guid.Empty)
            throw new InvalidDataException("A baseline from this preparation session is required; legacy cached results cannot start a witness.");
        var v4 = new TcpListener(IPAddress.Loopback, 0);
        var v6 = new TcpListener(IPAddress.IPv6Loopback, 0);
        v6.Server.DualMode = false;
        try
        {
            v4.Start(16);
            v6.Start(16);
            var instance = new NetworkWitness(v4, v6, internet.SessionId);
            try
            {
                await instance.AssertAliveAsync(ct);
                return instance;
            }
            catch { instance.Dispose(); throw; }
        }
        catch
        {
            v4.Stop(); v6.Stop();
            throw;
        }
    }

    internal NetworkControl Control(BaselineResult b)
    {
        // Session identity AND age must match. A previous launch can be only
        // seconds old and still is not this launch's connectivity observation.
        bool fresh = NetworkAdmission.CurrentBaseline(b.SessionId, sessionId, b.TimeUtc, DateTimeOffset.UtcNow);
        return new(
            ((IPEndPoint)ipv4.LocalEndpoint).Port,
            ((IPEndPoint)ipv6.LocalEndpoint).Port,
            fresh && b.Ipv4Connected,
            fresh && b.Ipv6Connected,
            fresh && b.DnsResolved,
            startedUtc, sessionId, b.TimeUtc);
    }

    internal async Task AssertAliveAsync(CancellationToken ct)
    {
        await PositiveTest(IPAddress.Loopback, ((IPEndPoint)ipv4.LocalEndpoint).Port, ct);
        await PositiveTest(IPAddress.IPv6Loopback, ((IPEndPoint)ipv6.LocalEndpoint).Port, ct);
    }

    private async Task PositiveTest(IPAddress address, int port, CancellationToken ct)
    {
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeout.CancelAfter(TimeSpan.FromSeconds(3));
        using var socket = new TcpClient(address.AddressFamily);
        await socket.ConnectAsync(address, port, timeout.Token);
        var received = new byte[challenge.Length];
        await socket.GetStream().ReadExactlyAsync(received, timeout.Token);
        if (!CryptographicOperations.FixedTimeEquals(received, challenge))
            throw new IOException("The loopback witness did not return the expected positive-control marker.");
    }

    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        stop.Cancel();
        ipv4.Stop(); ipv6.Stop();
        // Do not dispose a source still used by either asynchronous listener.
        // Observe shutdown faults without blocking the Windows UI thread.
        _ = Task.WhenAll(servers).ContinueWith(completed =>
        {
            _ = completed.Exception;
            stop.Dispose();
        }, CancellationToken.None, TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
        GC.SuppressFinalize(this);
    }
}

internal sealed record NetworkControl(
    int LocalIpv4Port,
    int LocalIpv6Port,
    bool ExternalIpv4Connected,
    bool ExternalIpv6Connected,
    bool ExternalDnsResolved,
    string StartedUtc,
    string SessionId = "",
    string BaselineTimeUtc = "");
