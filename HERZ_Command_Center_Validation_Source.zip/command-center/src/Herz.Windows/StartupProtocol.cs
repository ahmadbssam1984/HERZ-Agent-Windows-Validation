using System.Security.Cryptography;
using System.Text.Json;

namespace Herz.Windows;

// A one-use decision carried over the launcher's inherited anonymous input pipe.
// No file, worker reply, persisted baseline or UI toggle grants this authority.
internal static class StartupProtocol
{
    internal const int MaximumMessageCharacters = 4096;
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    internal sealed record Probe(string Type, int Pid, string Nonce, bool ProofPassed);
    internal sealed record Commit(string Type, int Pid, string Nonce, bool AllowExecution);
    internal sealed record Ready(string Type, int Pid, string Nonce, bool TasksEnabled);

    internal static string CreateNonce() => Convert.ToHexString(RandomNumberGenerator.GetBytes(32));

    internal static string Encode<T>(T message) => JsonSerializer.Serialize(message, Json);

    internal static T Decode<T>(string line) where T : class
    {
        if (string.IsNullOrWhiteSpace(line) || line.Length > MaximumMessageCharacters)
            throw new InvalidDataException("Invalid startup frame length.");
        return JsonSerializer.Deserialize<T>(line, Json) ?? throw new InvalidDataException("Empty startup frame.");
    }

    internal static Probe ValidateProbe(string line, int expectedPid)
    {
        var message = Decode<Probe>(line);
        if (message.Type != "manager-probed" || message.Pid != expectedPid || !ValidNonce(message.Nonce))
            throw new InvalidDataException("Manager probe identity mismatch.");
        return message;
    }

    internal static bool ValidateCommit(string line, int expectedPid, string expectedNonce, bool proofPassed)
    {
        var message = Decode<Commit>(line);
        if (message.Type != "startup-commit" || message.Pid != expectedPid ||
            !ValidNonce(message.Nonce) || !ValidNonce(expectedNonce) ||
            !CryptographicOperations.FixedTimeEquals(Convert.FromHexString(message.Nonce), Convert.FromHexString(expectedNonce)))
            throw new InvalidDataException("Startup authorization identity mismatch.");
        // Even the trusted launcher cannot make a failed manager proof pass.
        return message.AllowExecution && proofPassed;
    }

    internal static void ValidateReady(string line, Probe probe, bool allowed)
    {
        var message = Decode<Ready>(line);
        if (message.Type != "manager-ready" || message.Pid != probe.Pid || message.Nonce != probe.Nonce ||
            (message.TasksEnabled && (!allowed || !probe.ProofPassed)))
            throw new InvalidDataException("Manager readiness did not match startup authorization.");
    }

    internal static async Task<string> ReadLineAsync(TextReader input, TimeSpan timeout, CancellationToken token = default,
        int maximumCharacters = MaximumMessageCharacters)
    {
        if (maximumCharacters is < 1 or > 1024 * 1024)
            throw new ArgumentOutOfRangeException(nameof(maximumCharacters));
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(token);
        deadline.CancelAfter(timeout);
        var buffer = new char[1];
        var line = new System.Text.StringBuilder();
        while (true)
        {
            int read = await input.ReadAsync(buffer.AsMemory(), deadline.Token).AsTask().WaitAsync(deadline.Token);
            if (read == 0)
                throw new EndOfStreamException("The trusted launcher closed before startup authorization.");
            if (buffer[0] == '\n')
                return line.ToString().TrimEnd('\r');
            if (line.Length == maximumCharacters)
                throw new InvalidDataException("Startup frame exceeded its size limit.");
            line.Append(buffer[0]);
        }
    }

    private static bool ValidNonce(string? value) => value is { Length: 64 } && value.All(Uri.IsHexDigit);
}
