// HERZ native Windows containment candidate. MIT. No Windows runtime success is implied.
// Preparation changes ACLs only beneath the fixed HERZ-owned directory. Runtime
// uses zero-capability AppContainers, explicit handle inheritance and atomic jobs.
using System.ComponentModel;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;
using Microsoft.Win32.SafeHandles;

namespace Herz.Windows;
public sealed record SandboxLimits(long MemoryBytes = 512L * 1024 * 1024, int CpuPercent = 25, int ActiveProcesses = 8);
public sealed record TokenVerificationInfo(bool IsAppContainer, bool HasNetworkCapabilities, string? AppContainerSid, bool Elevated, uint CapabilityCount, string IntegritySid);
public sealed record SandboxProbeResult(string Kind, string Outcome, int? NativeError, string Detail);
public sealed record SandboxJobUsage(uint ActiveProcesses, ulong PeakCommittedBytes, long UserTime100ns, long KernelTime100ns);
public sealed class SandboxProfile : IDisposable
{
    internal IntPtr SidPointer { get; private set; }
    public string Name { get; }
    public string Sid { get; }
    public string FolderPath { get; }
    public bool CreatedHere { get; }

    internal SandboxProfile(string name, IntPtr sid, string folder, bool created)
    {
        Name = name;
        SidPointer = sid;
        Sid = new SecurityIdentifier(sid).Value;
        FolderPath = folder;
        CreatedHere = created;
    }

    public void Dispose()
    {
        if (SidPointer == IntPtr.Zero)
            return;
        NativeSandbox.FreeSidPointer(SidPointer);
        SidPointer = IntPtr.Zero;
        // Never delete a persistent AppContainer profile or its user data here.
        GC.SuppressFinalize(this);
    }

    ~SandboxProfile()
    {
        Dispose();
    }
}

public sealed class SandboxProcess : IDisposable
{
    private IntPtr process, job;
    private bool detached, disposed;
    public uint Pid { get; }
    public FileStream InputStream { get; }
    public FileStream OutputStream { get; }
    public FileStream ErrorStream { get; }
    public StreamWriter StandardInput { get; }
    public StreamReader StandardOutput { get; }
    public StreamReader StandardError { get; }
    public IntPtr JobControlHandle => job;
    public IntPtr ProcessHandle => process;
    public TokenVerificationInfo VerifiedToken { get; }

    internal SandboxProcess(uint pid, IntPtr processHandle, IntPtr jobHandle, IntPtr input, IntPtr output, IntPtr error, TokenVerificationInfo identity)
    {
        Pid = pid;
        process = processHandle;
        job = jobHandle;
        VerifiedToken = identity;
        var ih = new SafeFileHandle(input, true);
        var oh = new SafeFileHandle(output, true);
        var eh = new SafeFileHandle(error, true);
        FileStream? inputStream = null, outputStream = null, errorStream = null;
        try
        {
            InputStream = inputStream = new FileStream(ih, FileAccess.Write, 4096, false);
            OutputStream = outputStream = new FileStream(oh, FileAccess.Read, 4096, false);
            ErrorStream = errorStream = new FileStream(eh, FileAccess.Read, 4096, false);
            StandardInput = new StreamWriter(InputStream, new UTF8Encoding(false), 4096, false)
            {
                AutoFlush = true,
                NewLine = "\n"
            };
            StandardOutput = new StreamReader(OutputStream, new UTF8Encoding(false, true), true, 4096, true);
            StandardError = new StreamReader(ErrorStream, new UTF8Encoding(false, true), true, 4096, true);
        }
        catch
        {
            inputStream?.Dispose();
            outputStream?.Dispose();
            errorStream?.Dispose();
            ih.Dispose();
            oh.Dispose();
            eh.Dispose();
            throw;
        }
    }

    public IntPtr DuplicateInputForChild() => NativeSandbox.DuplicateForChild(InputStream.SafeFileHandle.DangerousGetHandle());
    public IntPtr DuplicateOutputForChild() => NativeSandbox.DuplicateForChild(OutputStream.SafeFileHandle.DangerousGetHandle());
    public IntPtr DuplicateErrorForChild() => NativeSandbox.DuplicateForChild(ErrorStream.SafeFileHandle.DangerousGetHandle());
    public IntPtr DuplicateJobControlForChild() => NativeSandbox.DuplicateJobControl(job);
    public bool WaitForExit(TimeSpan timeout) => NativeSandbox.WaitProcess(process, timeout);
    public int? ExitCode => NativeSandbox.ReadExitCode(process);

    public SandboxJobUsage GetUsage() => NativeSandbox.ReadJobUsage(job);
    public void Terminate(uint exitCode = 125)
    {
        if (job != IntPtr.Zero)
            NativeSandbox.TerminateManagedJob(job, exitCode);
    }

    // Call ONLY after the new manager has inherited pipe/job duplicates successfully.
    // Dispose then closes this parent's handles without terminating the handed-off job.
    public void DetachForHandoff() => detached = true;
    public void Dispose()
    {
        if (disposed)
            return;
        disposed = true;
        if (!detached && job != IntPtr.Zero)
            NativeSandbox.TerminateManagedJobNoThrow(job, 125);
        try
        {
            StandardInput.Dispose();
        }
        catch (IOException)
        {
        }

        try
        {
            StandardOutput.Dispose();
        }
        catch (IOException)
        {
        }

        try
        {
            StandardError.Dispose();
        }
        catch (IOException)
        {
        }

        InputStream.Dispose();
        OutputStream.Dispose();
        ErrorStream.Dispose();
        NativeSandbox.CloseHandle(process);
        process = IntPtr.Zero;
        NativeSandbox.CloseHandle(job);
        job = IntPtr.Zero;
        GC.SuppressFinalize(this);
    }
}

public static class NativeSandbox
{
    private const uint TokenQuery = 0x0008, ErrorNoToken = 1008, HandleFlagInherit = 1;
    private const uint CreateSuspended = 0x4, CreateUnicodeEnvironment = 0x400, ExtendedStartupInfoPresent = 0x80000, CreateNoWindow = 0x08000000, StartfUseStdHandles = 0x100;
    private const uint KillOnClose = 0x2000, JobMemoryLimit = 0x200, JobActiveProcessLimit = 0x8;
    private const uint JobQuery = 0x4, JobTerminate = 0x8, Synchronize = 0x100000;
    private static readonly IntPtr AttributeSecurityCapabilities = new(0x20009), AttributeHandles = new(0x20002), AttributeJobs = new(0x2000D);
    private static readonly object LaunchLock = new();
    public static string OwnedRoot
    {
        get
        {
            if (!OperatingSystem.IsWindows())
                throw new PlatformNotSupportedException("Windows is required for native containment.");
            var token = GetCurrentTokenInfo();
            if (token.IsAppContainer)
            {
                // The trusted launcher supplies this before entering AppContainer, where
                // LOCALAPPDATA is redirected. It cannot grant rights: the kernel token still applies.
                var configured = Environment.GetEnvironmentVariable("HERZ_ROOT");
                if (string.IsNullOrWhiteSpace(configured))
                    throw new InvalidOperationException("HERZ_ROOT was not supplied by the launcher.");
                return CheckedLocalFullPath(configured);
            }

            return Path.GetFullPath(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HERZCommandCenter", "Windows2"));
        }
    }

    public static SandboxProfile CreateProfile(string name)
    {
        RequirePreparationIdentity();
        ValidateProfileName(name);
        var result = CreateAppContainerProfile(name, name, "HERZ local-only isolated process", IntPtr.Zero, 0, out var sid);
        bool created = result == 0;
        if (result == unchecked((int)0x800700B7))
            result = DeriveAppContainerSidFromAppContainerName(name, out sid);
        if (result < 0)
            Marshal.ThrowExceptionForHR(result);
        if (sid == IntPtr.Zero)
            throw new InvalidOperationException("AppContainer returned no SID.");
        return FinishProfile(name, sid, created);
    }

    public static SandboxProfile OpenExistingProfile(string name)
    {
        ValidateProfileName(name);
        var result = DeriveAppContainerSidFromAppContainerName(name, out var sid);
        if (result < 0)
            Marshal.ThrowExceptionForHR(result);
        if (sid == IntPtr.Zero)
            throw new InvalidOperationException("AppContainer SID could not be derived.");
        var current = GetCurrentTokenInfo();
        if (current.IsAppContainer && (current.AppContainerSid != new SecurityIdentifier(sid).Value || current.CapabilityCount != 0 || current.Elevated))
        {
            FreeSid(sid);
            throw new UnauthorizedAccessException("An isolated host may only open its own zero-capability profile.");
        }

        // Derivation alone is NOT evidence that a profile exists. Folder API must succeed.
        return FinishProfile(name, sid, false);
    }

    private static SandboxProfile FinishProfile(string name, IntPtr sid, bool created)
    {
        IntPtr folder = IntPtr.Zero;
        try
        {
            var sidText = new SecurityIdentifier(sid).Value;
            var hr = GetAppContainerFolderPath(sidText, out folder);
            if (hr < 0)
                Marshal.ThrowExceptionForHR(hr);
            var folderPath = Marshal.PtrToStringUni(folder) ?? throw new InvalidOperationException("Profile folder was not returned.");
            if (!Directory.Exists(folderPath))
                throw new DirectoryNotFoundException("AppContainer profile storage does not exist.");
            var identity = GetCurrentTokenInfo();
            if (!identity.IsAppContainer)
            {
                // Global configuration and all profile-path ancestors are checked by
                // preparation before any isolated process starts.
                EnsureNoReparsePoints(folderPath);
                EnsureNoLoopbackExemption(sid);
            }
            else
            {
                VerifyToken(identity, sidText);
                if ((File.GetAttributes(folderPath) & FileAttributes.ReparsePoint) != 0)
                    throw new UnauthorizedAccessException("The existing profile storage is linked.");
            // An already isolated host does not require global FirewallAPI/RPC
            // enumeration rights. It cannot choose another SID or grant capability.
            }

            return new SandboxProfile(name, sid, folderPath, created);
        }
        catch
        {
            FreeSid(sid);
            throw;
        }
        finally
        {
            if (folder != IntPtr.Zero)
                Marshal.FreeCoTaskMem(folder);
        }
    }

    // Only the owner's preparation process can modify ACLs. Never call concurrently
    // with running agents; grants are applied to the immutable source copy/task staging.
    public static void GrantDirectory(string ownedRoot, string path, SandboxProfile profile, bool writable)
    {
        RequirePreparationIdentity();
        var expected = OwnedRoot;
        if (!string.Equals(Path.GetFullPath(ownedRoot).TrimEnd('\\'), expected.TrimEnd('\\'), StringComparison.OrdinalIgnoreCase))
            throw new UnauthorizedAccessException("ACL preparation is restricted to the fixed HERZ data root.");
        var full = CheckedOwnedPath(path, expected);
        if (!Directory.Exists(full))
            throw new DirectoryNotFoundException("Create HERZ staging directories before granting access.");
        EnsureNoReparsePoints(full);
        if (!string.Equals(new DriveInfo(Path.GetPathRoot(full)!).DriveFormat, "NTFS", StringComparison.OrdinalIgnoreCase))
            throw new NotSupportedException("This build requires NTFS for verified directory ACL behavior.");
        using var windowsIdentity = WindowsIdentity.GetCurrent();
        var owner = windowsIdentity.User ?? throw new UnauthorizedAccessException("Windows owner SID unavailable.");
        var package = new SecurityIdentifier(profile.Sid);
        // An OWNER RIGHTS ACE suppresses the owner's otherwise implicit WRITE_DAC.
        // The signed-in user's explicit ACL rights remain in place for preparation;
        // an AppContainer still has to pass its separate package-SID access check.
        var ownerRights = new SecurityIdentifier("S-1-3-4");
        // Grant traversal on parents without inheritable read/write grants to siblings.
        // HERZCommandCenter is also our fixed app-owned parent. It needs a traverse-
        // only ACE; never extend this loop into LocalAppData or the user's profile.
        string applicationParent = Directory.GetParent(expected)?.FullName ?? throw new InvalidOperationException("Missing fixed HERZ application parent.");
        var parent = Directory.GetParent(full);
        while (parent != null && (IsWithin(parent.FullName, expected) || string.Equals(parent.FullName, applicationParent, StringComparison.OrdinalIgnoreCase)))
        {
            EnsureOwnedDirectory(parent.FullName, owner);
            var acl = parent.GetAccessControl(AccessControlSections.Access | AccessControlSections.Owner);
            var parentRights = string.Equals(parent.FullName, applicationParent, StringComparison.OrdinalIgnoreCase) ? FileSystemRights.Traverse : FileSystemRights.Traverse | FileSystemRights.ReadAttributes | FileSystemRights.Synchronize;
            acl.AddAccessRule(new FileSystemAccessRule(package, parentRights, InheritanceFlags.None, PropagationFlags.None, AccessControlType.Allow));
            parent.SetAccessControl(acl);
            parent = parent.Parent;
        }

        var all = new List<string>
        {
            full
        };
        var pending = new Stack<string>();
        pending.Push(full);
        while (pending.Count != 0)
        {
            foreach (var entry in Directory.EnumerateFileSystemEntries(pending.Pop(), "*", new EnumerationOptions { RecurseSubdirectories = false, AttributesToSkip = 0, IgnoreInaccessible = false }))
            {
                var attributes = File.GetAttributes(entry);
                if ((attributes & FileAttributes.ReparsePoint) != 0)
                    throw new UnauthorizedAccessException("Reparse points are not accepted in HERZ staging.");
                all.Add(entry);
                if ((attributes & FileAttributes.Directory) != 0)
                    pending.Push(entry);
            }
        }

        // Apply to each existing item as well as inheritance, so protected child ACLs
        // cannot make the apparent grant differ silently from the copied source tree.
        foreach (var entry in all)
        {
            EnsureNoReparsePoints(entry);
            bool directory = Directory.Exists(entry);
            var rights = FileSystemRights.ReadAndExecute | FileSystemRights.Synchronize;
            var denied = FileSystemRights.ChangePermissions | FileSystemRights.TakeOwnership;
            if (writable)
                rights |= FileSystemRights.Write | FileSystemRights.Delete | FileSystemRights.DeleteSubdirectoriesAndFiles;
            else
                denied |= FileSystemRights.Write | FileSystemRights.Delete | FileSystemRights.DeleteSubdirectoriesAndFiles;
            if (directory)
            {
                EnsureOwnedDirectory(entry, owner);
                var info = new DirectoryInfo(entry);
                var acl = info.GetAccessControl(AccessControlSections.Access | AccessControlSections.Owner);
                acl.SetAccessRule(new FileSystemAccessRule(owner, FileSystemRights.FullControl, InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow));
                acl.SetAccessRule(new FileSystemAccessRule(package, rights, InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow));
                acl.SetAccessRule(new FileSystemAccessRule(package, denied, InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Deny));
                acl.SetAccessRule(new FileSystemAccessRule(ownerRights, FileSystemRights.ReadPermissions, InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow));
                info.SetAccessControl(acl);
            }
            else
            {
                var info = new FileInfo(entry);
                var acl = info.GetAccessControl(AccessControlSections.Access | AccessControlSections.Owner);
                if (!owner.Equals(acl.GetOwner(typeof(SecurityIdentifier))))
                    throw new UnauthorizedAccessException("HERZ copied-file owner mismatch.");
                acl.SetAccessRule(new FileSystemAccessRule(owner, FileSystemRights.FullControl, AccessControlType.Allow));
                acl.SetAccessRule(new FileSystemAccessRule(package, rights, AccessControlType.Allow));
                acl.SetAccessRule(new FileSystemAccessRule(package, denied, AccessControlType.Deny));
                acl.SetAccessRule(new FileSystemAccessRule(ownerRights, FileSystemRights.ReadPermissions, AccessControlType.Allow));
                info.SetAccessControl(acl);
            }

            if (writable)
                SetLowIntegrity(entry, directory);
        }
    }

    public static SandboxProcess Launch(SandboxProfile profile, string executable, IReadOnlyList<string> arguments, string workingDirectory, IReadOnlyDictionary<string, string>? environment = null, SandboxLimits? limits = null, IReadOnlyList<IntPtr>? extraInheritedHandles = null, bool showWindow = false, bool holdJobInChild = false)
    {
        lock (LaunchLock)
            return LaunchCore(profile, executable, arguments, workingDirectory, environment, limits ?? new(), extraInheritedHandles, showWindow, holdJobInChild);
    }

    private static SandboxProcess LaunchCore(SandboxProfile profile, string executable, IReadOnlyList<string> arguments, string workingDirectory, IReadOnlyDictionary<string, string>? environment, SandboxLimits limits, IReadOnlyList<IntPtr>? extras, bool showWindow, bool holdJobInChild)
    {
        var current = GetCurrentTokenInfo();
        if (current.Elevated)
            throw new UnauthorizedAccessException("HERZ runtime must not be launched elevated.");
        if (current.IsAppContainer && (current.AppContainerSid != profile.Sid || current.CapabilityCount != 0))
            throw new UnauthorizedAccessException("An isolated host may only launch children in its own zero-capability container.");
        RejectThreadImpersonation();
        if (profile.SidPointer == IntPtr.Zero)
            throw new ObjectDisposedException(nameof(profile));
        string root = OwnedRoot;
        executable = CheckedOwnedPath(executable, root);
        workingDirectory = CheckedOwnedPath(workingDirectory, root);
        EnsureNoReparsePoints(executable);
        EnsureNoReparsePoints(workingDirectory);
        if (!File.Exists(executable) || !Directory.Exists(workingDirectory))
            throw new FileNotFoundException("Approved executable or working directory is missing.");
        if (limits.MemoryBytes < 64L * 1024 * 1024 || limits.MemoryBytes > 8L * 1024 * 1024 * 1024 || limits.CpuPercent is < 1 or > 75 || limits.ActiveProcesses is < 1 or > 64)
            throw new ArgumentOutOfRangeException(nameof(limits), "Memory/CPU/process limits are outside the approved range.");
        if (current.IsAppContainer)
            VerifyToken(current, profile.Sid);
        else
            EnsureNoLoopbackExemption(profile.SidPointer);
        string command = string.Join(" ", new[] { QuoteArgument(executable) }.Concat(arguments.Select(QuoteArgument)));
        if (command.Length > 32760)
            throw new ArgumentException("Windows command line is too long.");
        var env = BuildEnvironment(profile, workingDirectory, root, environment);
        var owned = new HashSet<IntPtr>();
        IntPtr attributes = IntPtr.Zero, capabilities = IntPtr.Zero, handlesArray = IntPtr.Zero, jobsArray = IntPtr.Zero, envBlock = IntPtr.Zero;
        IntPtr job = IntPtr.Zero, proc = IntPtr.Zero, thread = IntPtr.Zero;
        bool attributesInitialized = false, successful = false;
        try
        {
            job = CreateJobObject(IntPtr.Zero, null);
            CheckHandle(job, "CreateJobObject");
            owned.Add(job);
            var extended = new JobExtendedLimitInformation
            {
                BasicLimitInformation = new JobBasicLimitInformation
                {
                    LimitFlags = KillOnClose | JobMemoryLimit | JobActiveProcessLimit,
                    ActiveProcessLimit = (uint)limits.ActiveProcesses
                },
                JobMemoryLimit = (UIntPtr)(ulong)limits.MemoryBytes
            };
            SetJobStructure(job, 9, extended);
            SetJobStructure(job, 15, new JobCpuRateControlInformation { ControlFlags = 0x1 | 0x4, CpuRate = (uint)(limits.CpuPercent * 100) });
            CreateAnonymousPipe(out var childInput, out var parentInput);
            owned.Add(childInput);
            owned.Add(parentInput);
            CreateAnonymousPipe(out var parentOutput, out var childOutput);
            owned.Add(parentOutput);
            owned.Add(childOutput);
            CreateAnonymousPipe(out var parentError, out var childError);
            owned.Add(parentError);
            owned.Add(childError);
            foreach (var h in new[]
            {
                parentInput,
                parentOutput,
                parentError
            }

            )
                Check(SetHandleInformation(h, HandleFlagInherit, 0), "SetHandleInformation");
            var inherited = new List<IntPtr>
            {
                childInput,
                childOutput,
                childError
            };
            if (extras != null)
                inherited.AddRange(extras);
            if (holdJobInChild)
            {
                var hold = DuplicateWithAccess(job, JobQuery | Synchronize, true);
                owned.Add(hold);
                inherited.Add(hold);
                env["HERZ_JOB_HOLD_HANDLE"] = hold.ToInt64().ToString(System.Globalization.CultureInfo.InvariantCulture);
            }

            if (inherited.Count > 64 || inherited.Distinct().Count() != inherited.Count)
                throw new ArgumentException("Invalid inherited handle list.");
            foreach (var h in inherited)
            {
                if (h == IntPtr.Zero || h == new IntPtr(-1))
                    throw new ArgumentException("Invalid or pseudo handle in inheritance list.");
                Check(GetHandleInformation(h, out var flags), "GetHandleInformation");
                if ((flags & HandleFlagInherit) == 0)
                    throw new ArgumentException("Every explicitly inherited handle must be an inheritable duplicate.");
            }

            // A verified unpackaged AppContainer parent already supplies the exact
            // low-integrity token to CreateProcess. Inherit that token instead of
            // requesting a second LowBox token from inside the container. The actual
            // child token and job are still verified before the first thread resumes.
            int attributeCount = current.IsAppContainer ? 2 : 3;
            nuint bytes = 0;
            InitializeProcThreadAttributeList(IntPtr.Zero, attributeCount, 0, ref bytes);
            if (bytes == 0 || bytes > 1024 * 1024)
                throw WinError("InitializeProcThreadAttributeList size");
            attributes = Marshal.AllocHGlobal(checked((int)bytes));
            Check(InitializeProcThreadAttributeList(attributes, attributeCount, 0, ref bytes), "InitializeProcThreadAttributeList");
            attributesInitialized = true;
            if (!current.IsAppContainer)
            {
                capabilities = AllocateStructure(new SecurityCapabilities { AppContainerSid = profile.SidPointer, Capabilities = IntPtr.Zero, CapabilityCount = 0, Reserved = 0 });
                Check(UpdateProcThreadAttribute(attributes, 0, AttributeSecurityCapabilities, capabilities, (nuint)Marshal.SizeOf<SecurityCapabilities>(), IntPtr.Zero, IntPtr.Zero), "Security capabilities");
            }

            handlesArray = Marshal.AllocHGlobal(inherited.Count * IntPtr.Size);
            Marshal.Copy(inherited.ToArray(), 0, handlesArray, inherited.Count);
            Check(UpdateProcThreadAttribute(attributes, 0, AttributeHandles, handlesArray, (nuint)(inherited.Count * IntPtr.Size), IntPtr.Zero, IntPtr.Zero), "Explicit handle inheritance");
            jobsArray = Marshal.AllocHGlobal(IntPtr.Size);
            Marshal.WriteIntPtr(jobsArray, job);
            Check(UpdateProcThreadAttribute(attributes, 0, AttributeJobs, jobsArray, (nuint)IntPtr.Size, IntPtr.Zero, IntPtr.Zero), "Atomic job assignment");
            var startup = new StartupInfoEx
            {
                StartupInfo = new StartupInfo
                {
                    cb = (uint)Marshal.SizeOf<StartupInfoEx>(),
                    dwFlags = StartfUseStdHandles,
                    hStdInput = childInput,
                    hStdOutput = childOutput,
                    hStdError = childError
                },
                AttributeList = attributes
            };
            envBlock = Marshal.StringToHGlobalUni(string.Join('\0', env.Select(p => p.Key + "=" + p.Value)) + '\0');
            uint flagsCreate = CreateSuspended | CreateUnicodeEnvironment | ExtendedStartupInfoPresent | (showWindow ? 0u : CreateNoWindow);
            Check(CreateProcessW(executable, new StringBuilder(command), IntPtr.Zero, IntPtr.Zero, true, flagsCreate, envBlock, workingDirectory, ref startup, out var info), "CreateProcess AppContainer");
            proc = info.hProcess;
            thread = info.hThread;
            owned.Add(proc);
            owned.Add(thread);
            var verified = ReadTokenInfo(proc);
            VerifyToken(verified, profile.Sid);
            Check(IsProcessInJob(proc, job, out var assigned), "IsProcessInJob");
            if (!assigned)
                throw new UnauthorizedAccessException("Created process was not assigned to its private job.");
            if (ResumeThread(thread) == uint.MaxValue)
                throw WinError("ResumeThread");
            // Constructor takes exclusive ownership of pipe handles, including on failure.
            foreach (var h in new[]
            {
                parentInput,
                parentOutput,
                parentError
            }

            )
                owned.Remove(h);
            var launched = new SandboxProcess(info.dwProcessId, proc, job, parentInput, parentOutput, parentError, verified);
            foreach (var h in new[]
            {
                proc,
                job
            }

            )
                owned.Remove(h);
            successful = true;
            return launched;
        }
        finally
        {
            if (!successful && job != IntPtr.Zero)
                TerminateManagedJobNoThrow(job, 125);
            foreach (var h in owned)
                CloseHandle(h);
            if (attributesInitialized)
                DeleteProcThreadAttributeList(attributes);
            foreach (var p in new[]
            {
                attributes,
                capabilities,
                handlesArray,
                jobsArray,
                envBlock
            }

            )
                if (p != IntPtr.Zero)
                    Marshal.FreeHGlobal(p);
        }
    }

    public static TokenVerificationInfo GetCurrentTokenInfo()
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("Windows tokens are unavailable on this platform.");
        return ReadTokenInfo(GetCurrentProcess());
    }

    public static void VerifyCurrentAppContainer(string expectedSid) => VerifyToken(GetCurrentTokenInfo(), expectedSid);
    private static void VerifyToken(TokenVerificationInfo identity, string expectedSid)
    {
        if (!identity.IsAppContainer || identity.Elevated || identity.CapabilityCount != 0 || identity.AppContainerSid != expectedSid || identity.IntegritySid != "S-1-16-4096")
            throw new UnauthorizedAccessException("The actual process token does not match the zero-capability, low-integrity AppContainer profile.");
    }

    private static TokenVerificationInfo ReadTokenInfo(IntPtr process)
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("Windows tokens are unavailable on this platform.");
        Check(OpenProcessToken(process, TokenQuery, out var token), "OpenProcessToken");
        try
        {
            bool app = ReadTokenUInt(token, 29) != 0, elevated = ReadTokenUInt(token, 20) != 0;
            uint count;
            bool network = false;
            using (var capabilities = TokenBuffer(token, 30))
            {
                count = (uint)Marshal.ReadInt32(capabilities.Pointer);
                if (count > 1024)
                    throw new InvalidOperationException("Unexpected capability count.");
                int offset = IntPtr.Size == 8 ? 8 : 4, size = Marshal.SizeOf<SidAndAttributes>();
                if (count != 0 && (ulong)offset + (ulong)size * count > (ulong)capabilities.Length)
                    throw new InvalidOperationException("Invalid capability token buffer.");
                for (uint i = 0; i < count; i++)
                {
                    var item = Marshal.PtrToStructure<SidAndAttributes>(capabilities.Pointer + offset + checked((int)i * size));
                    string sid = new SecurityIdentifier(item.Sid).Value;
                    if (sid is "S-1-15-3-1" or "S-1-15-3-2" or "S-1-15-3-3")
                        network = true;
                }
            }

            string? appSid = null;
            if (app)
            {
                using var value = TokenBuffer(token, 31);
                appSid = new SecurityIdentifier(Marshal.ReadIntPtr(value.Pointer)).Value;
            }

            using var integrity = TokenBuffer(token, 25);
            var integritySid = new SecurityIdentifier(Marshal.ReadIntPtr(integrity.Pointer)).Value;
            return new(app, network, appSid, elevated, count, integritySid);
        }
        finally
        {
            CloseHandle(token);
        }
    }

    private static uint ReadTokenUInt(IntPtr token, int kind)
    {
        using var data = TokenBuffer(token, kind);
        if (data.Length < 4)
            throw new InvalidOperationException("Short token result.");
        return (uint)Marshal.ReadInt32(data.Pointer);
    }

    private static NativeBuffer TokenBuffer(IntPtr token, int kind)
    {
        GetTokenInformation(token, kind, IntPtr.Zero, 0, out uint bytes);
        if (bytes < 4 || bytes > 1024 * 1024)
            throw WinError("GetTokenInformation size");
        var data = new NativeBuffer(checked((int)bytes));
        if (!GetTokenInformation(token, kind, data.Pointer, bytes, out var returned))
        {
            data.Dispose();
            throw WinError("GetTokenInformation");
        }

        if (returned > bytes)
        {
            data.Dispose();
            throw new InvalidOperationException("Token result exceeded buffer.");
        }

        return data;
    }

    private static void RequirePreparationIdentity()
    {
        var identity = GetCurrentTokenInfo();
        RejectThreadImpersonation();
        if (identity.IsAppContainer || identity.Elevated)
            throw new UnauthorizedAccessException("Preparation requires the ordinary signed-in Windows account, outside AppContainer.");
    }

    private static void RejectThreadImpersonation()
    {
        if (OpenThreadToken(GetCurrentThread(), TokenQuery, true, out var token))
        {
            CloseHandle(token);
            throw new UnauthorizedAccessException("Impersonation is not allowed during sandbox preparation or creation.");
        }

        var error = (uint)Marshal.GetLastWin32Error();
        if (error != ErrorNoToken)
            throw new Win32Exception((int)error, "Cannot verify thread identity.");
    }

    public static string QuoteArgument(string value)
    {
        ArgumentNullException.ThrowIfNull(value);
        if (value.IndexOf('\0') >= 0)
            throw new ArgumentException("NUL is not permitted in a Windows argument.");
        var result = new StringBuilder("\"");
        int slashes = 0;
        foreach (char c in value)
        {
            if (c == '\\')
            {
                slashes++;
                continue;
            }

            if (c == '"')
            {
                result.Append('\\', slashes * 2 + 1);
                result.Append('"');
                slashes = 0;
                continue;
            }

            result.Append('\\', slashes);
            slashes = 0;
            result.Append(c);
        }

        result.Append('\\', slashes * 2);
        return result.Append('"').ToString();
    }

    private static SortedDictionary<string, string> BuildEnvironment(SandboxProfile profile, string directory, string root, IReadOnlyDictionary<string, string>? extra)
    {
        var result = new SortedDictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var key in new[]
        {
            "SystemRoot",
            "WINDIR",
            "SystemDrive",
            "USERPROFILE"
        }

        )
        {
            var value = Environment.GetEnvironmentVariable(key);
            if (!string.IsNullOrEmpty(value))
                result[key] = value;
        }

        if (extra != null)
            foreach (var pair in extra)
            {
                if (string.IsNullOrWhiteSpace(pair.Key) || pair.Key.IndexOfAny(['=', '\0']) >= 0 || pair.Value.IndexOf('\0') >= 0)
                    throw new ArgumentException("Invalid environment entry.");
                if (pair.Key.Contains("PROXY", StringComparison.OrdinalIgnoreCase))
                    continue;
                result[pair.Key] = pair.Value;
            }

        result["PATH"] = directory;
        result["TEMP"] = directory;
        result["TMP"] = directory;
        result["LOCALAPPDATA"] = profile.FolderPath;
        result["HERZ_ROOT"] = root;
        result["HERZ_APPCONTAINER_SID"] = profile.Sid;
        result["DOTNET_EnableDiagnostics"] = "0";
        result["DOTNET_CLI_TELEMETRY_OPTOUT"] = "1";
        result["DOTNET_NOLOGO"] = "1";
        result["OLLAMA_NO_CLOUD"] = "1";
        if (result.Sum(x => x.Key.Length + x.Value.Length + 2) > 30000)
            throw new ArgumentException("Environment exceeds the bounded size.");
        return result;
    }

    private static void ValidateProfileName(string name)
    {
        if (name.Length is < 6 or > 64 || !name.StartsWith("HERZ.", StringComparison.Ordinal) || name.Any(c => !char.IsAsciiLetterOrDigit(c) && c is not '.' and not '-' and not '_'))
            throw new ArgumentException("Use a HERZ-prefixed ASCII AppContainer profile name.");
    }

    private static string CheckedLocalFullPath(string path)
    {
        if (string.IsNullOrWhiteSpace(path) || path.StartsWith("\\\\", StringComparison.Ordinal) || path.IndexOf('\0') >= 0 || !Path.IsPathFullyQualified(path))
            throw new UnauthorizedAccessException("A local fully-qualified Windows path is required.");
        var full = Path.GetFullPath(path);
        if (full.Length < 3 || full[1] != ':' || full[2] != '\\' || full.AsSpan(2).Contains(':'))
            throw new UnauthorizedAccessException("Device, UNC and alternate-data-stream paths are not accepted.");
        return full.TrimEnd('\\');
    }

    private static bool IsWithin(string path, string root) => path.Equals(root, StringComparison.OrdinalIgnoreCase) || path.StartsWith(root.TrimEnd('\\') + "\\", StringComparison.OrdinalIgnoreCase);
    private static string CheckedOwnedPath(string path, string root)
    {
        var full = CheckedLocalFullPath(path);
        if (!IsWithin(full, root))
            throw new UnauthorizedAccessException("The path is outside HERZ-owned storage.");
        return full;
    }

    public static void EnsureNoReparsePoints(string path)
    {
        var full = CheckedLocalFullPath(path);
        string current = full[..3];
        string remainder = full[3..];
        if (GetCurrentTokenInfo().IsAppContainer)
        {
            // The launcher's complete ancestry check precedes launch. A worker may
            // traverse but cannot rewrite the directories above the HERZ-owned root.
            // Do not demand read-attributes access to the rest of the user's profile.
            string root = CheckedLocalFullPath(Environment.GetEnvironmentVariable("HERZ_ROOT") ?? throw new UnauthorizedAccessException("Missing trusted HERZ root."));
            if (!IsWithin(full, root))
                throw new UnauthorizedAccessException("Isolated path inspection is confined to HERZ-owned storage.");
            current = root;
            remainder = full[root.Length..].TrimStart('\\');
            if (!Directory.Exists(root) || (File.GetAttributes(root) & FileAttributes.ReparsePoint) != 0)
                throw new UnauthorizedAccessException("The HERZ root is missing or linked.");
        }

        var parts = remainder.Split('\\', StringSplitOptions.RemoveEmptyEntries);
        foreach (var part in parts)
        {
            current = Path.Combine(current, part);
            if (!File.Exists(current) && !Directory.Exists(current))
                throw new FileNotFoundException("A required path component is missing.");
            if ((File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0)
                throw new UnauthorizedAccessException("Junctions, symlinks and reparse points are refused.");
        }
    }

    private static void EnsureOwnedDirectory(string path, SecurityIdentifier owner)
    {
        var info = new DirectoryInfo(path);
        var acl = info.GetAccessControl(AccessControlSections.Owner);
        if (!owner.Equals(acl.GetOwner(typeof(SecurityIdentifier))))
            throw new UnauthorizedAccessException("HERZ directory is not owned by the signed-in account.");
    }

    private static void SetLowIntegrity(string path, bool directory)
    {
        IntPtr descriptor = IntPtr.Zero;
        try
        {
            string sddl = directory ? "S:(ML;OICI;NW;;;LW)" : "S:(ML;;NW;;;LW)";
            Check(ConvertStringSecurityDescriptorToSecurityDescriptor(sddl, 1, out descriptor, out _), "Build low-integrity label");
            Check(GetSecurityDescriptorSacl(descriptor, out bool present, out var sacl, out _), "Read low-integrity label");
            if (!present || sacl == IntPtr.Zero)
                throw new InvalidOperationException("Mandatory label is missing.");
            uint error = SetNamedSecurityInfo(path, 1, 0x10, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, sacl);
            if (error != 0)
                throw new Win32Exception((int)error, "Cannot set low-integrity label on HERZ-owned storage.");
        }
        finally
        {
            if (descriptor != IntPtr.Zero)
                LocalFree(descriptor);
        }
    }

    private static void EnsureNoLoopbackExemption(IntPtr sid)
    {
        uint count = 0;
        IntPtr list = IntPtr.Zero;
        try
        {
            uint error = NetworkIsolationGetAppContainerConfig(out count, out list);
            if (error != 0)
                throw new Win32Exception((int)error, "Cannot verify that the profile has no loopback exemption.");
            if (count > 65536 || (count != 0 && list == IntPtr.Zero))
                throw new InvalidOperationException("Unexpected AppContainer configuration.");
            for (uint i = 0; i < count; i++)
            {
                var item = Marshal.PtrToStructure<SidAndAttributes>(list + checked((int)i * Marshal.SizeOf<SidAndAttributes>()));
                if (EqualSid(sid, item.Sid))
                    throw new UnauthorizedAccessException("The profile has a loopback exemption; isolation is refused.");
            }
        }
        finally
        {
            if (list != IntPtr.Zero)
            {
                if (count <= 65536)
                    for (uint i = 0; i < count; i++)
                    {
                        var item = Marshal.PtrToStructure<SidAndAttributes>(list + checked((int)i * Marshal.SizeOf<SidAndAttributes>()));
                        if (item.Sid != IntPtr.Zero)
                            HeapFree(GetProcessHeap(), 0, item.Sid);
                    }

                HeapFree(GetProcessHeap(), 0, list);
            }
        }
    }

    public static IntPtr DuplicateForChild(IntPtr handle) => DuplicateWithAccess(handle, 0, true, true);
    public static void MakeHandleNonInheritable(IntPtr handle) => Check(SetHandleInformation(handle, HandleFlagInherit, 0), "Clear inherited handle propagation");
    internal static IntPtr DuplicateJobControl(IntPtr handle) => DuplicateWithAccess(handle, JobQuery | JobTerminate | Synchronize, true);
    private static IntPtr DuplicateWithAccess(IntPtr handle, uint access, bool inherit, bool sameAccess = false)
    {
        if (handle == IntPtr.Zero || handle == new IntPtr(-1))
            throw new ArgumentException("Invalid source handle.");
        Check(DuplicateHandle(GetCurrentProcess(), handle, GetCurrentProcess(), out var duplicate, access, inherit, sameAccess ? 2u : 0u), "DuplicateHandle");
        return duplicate;
    }

    public static void CloseHandle(IntPtr handle)
    {
        if (handle != IntPtr.Zero && handle != new IntPtr(-1))
            KernelCloseHandle(handle);
    }

    internal static void FreeSidPointer(IntPtr pointer)
    {
        if (pointer != IntPtr.Zero)
            FreeSid(pointer);
    }

    public static void TerminateManagedJob(IntPtr job, uint code = 125) => Check(TerminateJobObject(job, code), "Terminate HERZ job");
    internal static void TerminateManagedJobNoThrow(IntPtr job, uint code)
    {
        if (job != IntPtr.Zero)
            TerminateJobObject(job, code);
    }

    internal static bool WaitProcess(IntPtr process, TimeSpan timeout)
    {
        uint ms = timeout == Timeout.InfiniteTimeSpan ? uint.MaxValue : (uint)Math.Clamp(timeout.TotalMilliseconds, 0, uint.MaxValue - 1d);
        uint result = WaitForSingleObject(process, ms);
        if (result == uint.MaxValue)
            throw WinError("WaitForSingleObject");
        return result == 0;
    }

    internal static int? ReadExitCode(IntPtr process)
    {
        Check(GetExitCodeProcess(process, out var code), "GetExitCodeProcess");
        return code == 259 ? null : unchecked((int)code);
    }

    public static SandboxJobUsage ReadJobUsage(IntPtr job)
    {
        using var basic = new NativeBuffer(Marshal.SizeOf<JobBasicAccountingInformation>());
        Check(QueryInformationJobObject(job, 1, basic.Pointer, (uint)basic.Length, out _), "Query job accounting");
        using var memory = new NativeBuffer(Marshal.SizeOf<JobExtendedLimitInformation>());
        Check(QueryInformationJobObject(job, 9, memory.Pointer, (uint)memory.Length, out _), "Query job memory");
        var b = Marshal.PtrToStructure<JobBasicAccountingInformation>(basic.Pointer);
        var m = Marshal.PtrToStructure<JobExtendedLimitInformation>(memory.Pointer);
        return new(b.ActiveProcesses, m.PeakJobMemoryUsed.ToUInt64(), b.TotalUserTime, b.TotalKernelTime);
    }

    private static void SetJobStructure<T>(IntPtr job, int type, T value)
        where T : struct
    {
        IntPtr data = AllocateStructure(value);
        try
        {
            Check(SetInformationJobObject(job, type, data, (uint)Marshal.SizeOf<T>()), "SetInformationJobObject");
        }
        finally
        {
            Marshal.FreeHGlobal(data);
        }
    }

    private static void CreateAnonymousPipe(out IntPtr read, out IntPtr write)
    {
        var security = new SecurityAttributes
        {
            Length = Marshal.SizeOf<SecurityAttributes>(),
            InheritHandle = true
        };
        Check(CreatePipe(out read, out write, ref security, 0), "CreatePipe");
    }

    private static IntPtr AllocateStructure<T>(T data)
        where T : struct
    {
        var p = Marshal.AllocHGlobal(Marshal.SizeOf<T>());
        Marshal.StructureToPtr(data, p, false);
        return p;
    }

    private static void Check(bool value, string operation)
    {
        if (!value)
            throw WinError(operation);
    }

    private static void CheckHandle(IntPtr value, string operation)
    {
        if (value == IntPtr.Zero || value == new IntPtr(-1))
            throw WinError(operation);
    }

    private static Win32Exception WinError(string operation) => new(Marshal.GetLastWin32Error(), operation);
    // Probe helpers report denial only for explicit access-denied results. Offline,
    // timeout, missing file and unreachable-route results are INCONCLUSIVE, not a pass.
    public static async Task<SandboxProbeResult> ProbeTcpAsync(string numericAddress, int port, int timeoutMilliseconds = 2500)
    {
        if (!IPAddress.TryParse(numericAddress, out var address) || port is < 1 or > 65535)
            throw new ArgumentException("Probe needs a numeric IPv4/IPv6 address and port.");
        using var cancel = new CancellationTokenSource(Math.Clamp(timeoutMilliseconds, 100, 10000));
        try
        {
            using var socket = new Socket(address.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            await socket.ConnectAsync(address, port, cancel.Token);
            return new("tcp", "allowed", null, "Connection succeeded; denial is not proven.");
        }
        catch (SocketException ex)
        {
            return new("tcp", ex.SocketErrorCode == SocketError.AccessDenied ? "denied" : "inconclusive", ex.ErrorCode, ex.SocketErrorCode.ToString());
        }
        catch (OperationCanceledException)
        {
            return new("tcp", "inconclusive", null, "Timeout does not prove a policy denial.");
        }
    }

    public static async Task<SandboxProbeResult> ProbeDnsAsync(string hostname, int timeoutMilliseconds = 2500)
    {
        if (string.IsNullOrWhiteSpace(hostname) || hostname.Length > 253 || hostname.Any(c => !char.IsAsciiLetterOrDigit(c) && c is not '.' and not '-'))
            throw new ArgumentException("Invalid probe hostname.");
        using var cancel = new CancellationTokenSource(Math.Clamp(timeoutMilliseconds, 100, 10000));
        try
        {
            await Dns.GetHostAddressesAsync(hostname, cancel.Token);
            return new("dns", "inconclusive", null, "Name resolved; this can be cached and does not establish blocked DNS egress.");
        }
        catch (SocketException ex)
        {
            return new("dns", ex.SocketErrorCode == SocketError.AccessDenied ? "denied" : "inconclusive", ex.ErrorCode, ex.SocketErrorCode.ToString());
        }
        catch (OperationCanceledException)
        {
            return new("dns", "inconclusive", null, "Timeout does not prove DNS isolation.");
        }
    }

    public static SandboxProbeResult ProbeFileOpen(string preparedCanaryPath, bool write)
    {
        try
        {
            using var stream = new FileStream(preparedCanaryPath, FileMode.Open, write ? FileAccess.Write : FileAccess.Read, FileShare.ReadWrite);
            return new(write ? "file-write" : "file-read", "allowed", null, "Canary opened; no file bytes were changed.");
        }
        catch (UnauthorizedAccessException ex)
        {
            return new(write ? "file-write" : "file-read", "denied", ex.HResult, "Access was denied.");
        }
        catch (IOException ex)
        {
            return new(write ? "file-write" : "file-read", "inconclusive", ex.HResult, "Missing, locked or inaccessible canary is not proof of access control.");
        }
    }

    // Ask for a security-edit handle without changing any descriptor. Probe the
    // rights separately: denial of a combination does not prove denial of both.
    public static SandboxProbeResult ProbeFileSecurityAccess(string preparedCanaryPath, bool changeOwner)
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("Windows file-security handles are unavailable on this platform.");
        uint desired = changeOwner ? 0x00080000u : 0x00040000u;
        string kind = changeOwner ? "file-write-owner" : "file-write-dac";
        IntPtr handle = CreateFileW(preparedCanaryPath, desired, 0x7, IntPtr.Zero, 3, 0x02000000, IntPtr.Zero);
        if (handle != new IntPtr(-1))
        {
            CloseHandle(handle);
            return new(kind, "allowed", null, "Security-edit handle opened; no ACL, owner or file bytes were changed.");
        }

        int error = Marshal.GetLastWin32Error();
        return error == 5 ? new(kind, "denied", error, "Windows refused the requested security-edit access.") : new(kind, "inconclusive", error, "A missing path, locked file or another error does not prove security-edit denial.");
    }

    private sealed class NativeBuffer : IDisposable
    {
        public IntPtr Pointer { get; private set; }
        public int Length { get; }

        public NativeBuffer(int length)
        {
            Length = length;
            Pointer = Marshal.AllocHGlobal(length);
        }

        public void Dispose()
        {
            if (Pointer != IntPtr.Zero)
                Marshal.FreeHGlobal(Pointer);
            Pointer = IntPtr.Zero;
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct SecurityAttributes
    {
        public int Length;
        public IntPtr SecurityDescriptor;
        [MarshalAs(UnmanagedType.Bool)]
        public bool InheritHandle;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct SidAndAttributes
    {
        public IntPtr Sid;
        public uint Attributes;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct SecurityCapabilities
    {
        public IntPtr AppContainerSid, Capabilities;
        public uint CapabilityCount, Reserved;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct StartupInfo
    {
        public uint cb;
        public string? lpReserved, lpDesktop, lpTitle;
        public uint dwX, dwY, dwXSize, dwYSize, dwXCountChars, dwYCountChars, dwFillAttribute, dwFlags;
        public ushort wShowWindow, cbReserved2;
        public IntPtr lpReserved2, hStdInput, hStdOutput, hStdError;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct StartupInfoEx
    {
        public StartupInfo StartupInfo;
        public IntPtr AttributeList;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct ProcessInformation
    {
        public IntPtr hProcess, hThread;
        public uint dwProcessId, dwThreadId;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct JobBasicLimitInformation
    {
        public long PerProcessUserTimeLimit, PerJobUserTimeLimit;
        public uint LimitFlags;
        public UIntPtr MinimumWorkingSetSize, MaximumWorkingSetSize;
        public uint ActiveProcessLimit;
        public UIntPtr Affinity;
        public uint PriorityClass, SchedulingClass;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct IoCounters
    {
        public ulong ReadOperationCount, WriteOperationCount, OtherOperationCount, ReadTransferCount, WriteTransferCount, OtherTransferCount;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct JobExtendedLimitInformation
    {
        public JobBasicLimitInformation BasicLimitInformation;
        public IoCounters IoInfo;
        public UIntPtr ProcessMemoryLimit, JobMemoryLimit, PeakProcessMemoryUsed, PeakJobMemoryUsed;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct JobCpuRateControlInformation
    {
        public uint ControlFlags, CpuRate;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct JobBasicAccountingInformation
    {
        public long TotalUserTime, TotalKernelTime, ThisPeriodTotalUserTime, ThisPeriodTotalKernelTime;
        public uint TotalPageFaultCount, TotalProcesses, ActiveProcesses, TotalTerminatedProcesses;
    }

    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("userenv.dll", CharSet = CharSet.Unicode)]
    private static extern int CreateAppContainerProfile(string name, string display, string description, IntPtr capabilities, uint count, out IntPtr sid);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("userenv.dll", CharSet = CharSet.Unicode)]
    private static extern int DeriveAppContainerSidFromAppContainerName(string name, out IntPtr sid);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("userenv.dll", CharSet = CharSet.Unicode)]
    private static extern int GetAppContainerFolderPath(string sid, out IntPtr path);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("advapi32.dll")]
    private static extern IntPtr FreeSid(IntPtr sid);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("advapi32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool OpenProcessToken(IntPtr process, uint desiredAccess, out IntPtr token);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("advapi32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool OpenThreadToken(IntPtr thread, uint desiredAccess, [MarshalAs(UnmanagedType.Bool)] bool openAsSelf, out IntPtr token);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("advapi32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetTokenInformation(IntPtr token, int type, IntPtr information, uint length, out uint returnedLength);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll")]
    private static extern IntPtr GetCurrentProcess();
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll")]
    private static extern IntPtr GetCurrentThread();
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll", EntryPoint = "CloseHandle", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool KernelCloseHandle(IntPtr handle);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr CreateJobObject(IntPtr security, string? name);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetInformationJobObject(IntPtr job, int type, IntPtr information, uint length);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool QueryInformationJobObject(IntPtr job, int type, IntPtr information, uint length, out uint returned);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool TerminateJobObject(IntPtr job, uint exitCode);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool IsProcessInJob(IntPtr process, IntPtr job, [MarshalAs(UnmanagedType.Bool)] out bool result);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CreatePipe(out IntPtr read, out IntPtr write, ref SecurityAttributes security, uint size);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true, ExactSpelling = true)]
    private static extern IntPtr CreateFileW(string fileName, uint desiredAccess, uint shareMode, IntPtr security, uint disposition, uint attributes, IntPtr template);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetHandleInformation(IntPtr handle, uint mask, uint flags);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetHandleInformation(IntPtr handle, out uint flags);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool DuplicateHandle(IntPtr sourceProcess, IntPtr source, IntPtr targetProcess, out IntPtr target, uint access, [MarshalAs(UnmanagedType.Bool)] bool inherit, uint options);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool InitializeProcThreadAttributeList(IntPtr list, int count, uint flags, ref nuint size);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool UpdateProcThreadAttribute(IntPtr list, uint flags, IntPtr attribute, IntPtr value, nuint size, IntPtr previous, IntPtr returnSize);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll")]
    private static extern void DeleteProcThreadAttributeList(IntPtr list);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CreateProcessW(string application, StringBuilder commandLine, IntPtr processSecurity, IntPtr threadSecurity, [MarshalAs(UnmanagedType.Bool)] bool inherit, uint flags, IntPtr environment, string directory, ref StartupInfoEx startup, out ProcessInformation process);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern uint ResumeThread(IntPtr thread);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern uint WaitForSingleObject(IntPtr handle, uint milliseconds);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetExitCodeProcess(IntPtr process, out uint code);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool ConvertStringSecurityDescriptorToSecurityDescriptor(string text, uint revision, out IntPtr descriptor, out uint size);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("advapi32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetSecurityDescriptorSacl(IntPtr descriptor, [MarshalAs(UnmanagedType.Bool)] out bool present, out IntPtr sacl, [MarshalAs(UnmanagedType.Bool)] out bool defaulted);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("advapi32.dll", EntryPoint = "SetNamedSecurityInfoW", CharSet = CharSet.Unicode)]
    private static extern uint SetNamedSecurityInfo(string path, int type, uint information, IntPtr owner, IntPtr group, IntPtr dacl, IntPtr sacl);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll")]
    private static extern IntPtr LocalFree(IntPtr pointer);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("FirewallAPI.dll")]
    private static extern uint NetworkIsolationGetAppContainerConfig(out uint count, out IntPtr sids);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("advapi32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool EqualSid(IntPtr first, IntPtr second);
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll")]
    private static extern IntPtr GetProcessHeap();
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    [DllImport("kernel32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool HeapFree(IntPtr heap, uint flags, IntPtr memory);
}
