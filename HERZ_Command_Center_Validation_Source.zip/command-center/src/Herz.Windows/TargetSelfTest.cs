using System.Diagnostics;
using System.Text.Json;
using System.Text.Json.Nodes;
using Herz.Core;

namespace Herz.Windows;
internal static class TargetSelfTest
{
    internal static async Task<string> RunAsync(CommandCenter core, WindowsPipeRunner runner, RuntimeSession session, CancellationToken token)
    {
        var results = new List<object>();
        var tasks = new List<string>();
        string report = Path.Combine(session.ManagerData, "target-self-test.json");
        var watch = Stopwatch.StartNew();
        try
        {
            if (core.Dashboard().Paused)
                throw new PolicyException("المدير متوقف مؤقتًا؛ استأنف استقبال المهام أولًا إذا أردت تنفيذ الاختبار.");
            if (!runner.Probe().Supported)
                throw new PolicyException(runner.Probe().Reason);
            string runId = Guid.NewGuid().ToString("N");
            var first = core.Submit(new TaskSubmission("stats_dotnet", new JsonObject { ["numbers"] = new JsonArray(12, 18, 20, 10), ["title"] = "اختبار محلي" }, "اختبار محلي: الحساب", IdempotencyKey: "check-" + runId + "-stats"));
            tasks.Add(first.Id);
            var second = core.Submit(new TaskSubmission("report_node", new JsonObject { ["title"] = "تقرير اختبار HERZ المحلي" }, "اختبار محلي: التقرير", IdempotencyKey: "check-" + runId + "-report", Dependencies: [first.Id]));
            tasks.Add(second.Id);
            var stats = await Completed(core, first.Id, token);
            if (stats.Result?["sum"]?.GetValue<decimal>() != 60m || stats.Result?["mean"]?.GetValue<decimal>() != 15m)
                throw new InvalidDataException("The numeric result is not 60 / 15.");
            results.Add(new { name = "dotnet_numeric_analysis", passed = true, taskId = first.Id, sum = 60, mean = 15 });
            var htmlTask = await Completed(core, second.Id, token);
            var artifact = htmlTask.Artifacts.Single(x => x.RelativePath == "report.html");
            string html = await File.ReadAllTextAsync(artifact.FullPath, token);
            if (LocalPaths.HashFile(artifact.FullPath) != artifact.Sha256 || !html.Contains("<td>60</td>", StringComparison.Ordinal) || !html.Contains("<td>15</td>", StringComparison.Ordinal))
                throw new InvalidDataException("The report content or SHA-256 did not match.");
            results.Add(new { name = "node_report_and_handoff", passed = true, taskId = second.Id, artifact.RelativePath, artifact.Sha256, artifact.Bytes });
            if (session.Model.Verified && session.Model.Selection.Approved)
            {
                var modelTime = Stopwatch.StartNew();
                string answer = await runner.AskLocalModel("اكتب كلمة جاهز فقط دون نقطة أو شرح أو علامات اقتباس.", token);
                results.Add(new { name = "local_model_smoke", passed = answer.Trim() == "جاهز", response = answer, seconds = modelTime.Elapsed.TotalSeconds, note = "One real offline-capable isolated inference; not a full quality evaluation." });
            }
            else
                results.Add(new { name = "local_model_smoke", status = "not_run", reason = session.Model.Reason });
        }
        catch (Exception error)
        {
            foreach (string id in tasks)
            {
                try
                {
                    core.Cancel(id);
                }
                catch
                {
                }
            }

            results.Add(new { name = "completion", status = token.IsCancellationRequested ? "cancelled" : "failed", error = error.GetType().Name, reason = error.Message });
        }

        var output = new
        {
            scope = "Actual execution on this Windows device; results are recorded only after execution.",
            timeUtc = DateTimeOffset.UtcNow,
            os = Environment.OSVersion.VersionString,
            results,
            seconds = watch.Elapsed.TotalSeconds,
            managerWorkingSetAtEndBytes = Process.GetCurrentProcess().WorkingSet64,
            completeWindowsAcceptance = false,
            guiInteractionAcceptance = "not_executed_by_this_check",
            completeKernelDenialAudit = false,
            note = "This checks two agents and one model response. It does not certify all UI controls, backup restoration, or every network denial."
        };
        Wire.WriteJson(report, output);
        return JsonSerializer.Serialize(output, new JsonSerializerOptions(Wire.Json) { WriteIndented = true, Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping }) + Environment.NewLine + "Local report: " + report;
    }

    private static async Task<TaskRecord> Completed(CommandCenter core, string id, CancellationToken token)
    {
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(token);
        deadline.CancelAfter(TimeSpan.FromSeconds(100));
        while (true)
        {
            deadline.Token.ThrowIfCancellationRequested();
            var item = core.TaskDetails(id);
            if (item.Status == "succeeded")
                return item;
            if (item.Status is "failed" or "cancelled" or "timed_out" or "needs_review" or "blocked")
                throw new InvalidOperationException(item.Status + ": " + item.Error);
            await Task.Delay(250, deadline.Token);
        }
    }
}
