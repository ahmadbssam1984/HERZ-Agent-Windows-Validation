using System.Diagnostics;
using System.Globalization;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Windows.Forms;
using Herz.Core;

namespace Herz.Windows;
public sealed class UiHostStatus
{
    public string WorkspaceRoot { get; init; } = "";
    public string InboxDirectory { get; init; } = "";
    public bool ManagerIsolated { get; init; }
    // Being inside an AppContainer does not mean the isolation checks passed.
    public bool IsolationVerified { get; init; }
    public string IsolationSummary { get; init; } = "لم يكتمل التحقق من العزل.";
    public bool WindowsAcceptanceVerified { get; init; }
    public string ModelStatus { get; init; } = "لم يُجهز نموذج محلي معتمد بعد.";
    public int MaxConcurrency { get; init; } = 1;
    public Func<string, CancellationToken, Task<string>>? LocalAssistantAsync { get; init; }
    public Func<CancellationToken, Task<string>>? RunLocalCheckAsync { get; init; }
}

public sealed class MainForm : Form
{
    private static readonly JsonSerializerOptions PrettyJson = new()
    {
        WriteIndented = true,
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.Create(System.Text.Unicode.UnicodeRanges.All)
    };
    private readonly CommandCenter _core;
    private readonly UiHostStatus _host;
    private readonly Panel _content = new()
    {
        Dock = DockStyle.Fill,
        Padding = new Padding(24, 18, 24, 18),
        AutoScroll = true
    };
    private readonly FlowLayoutPanel _navigation = new()
    {
        Dock = DockStyle.Fill,
        FlowDirection = FlowDirection.TopDown,
        WrapContents = false,
        AutoScroll = true,
        Padding = new Padding(12, 14, 12, 10)
    };
    private readonly Label _notice = new()
    {
        Dock = DockStyle.Fill,
        AutoEllipsis = true,
        TextAlign = ContentAlignment.MiddleRight,
        Padding = new Padding(16, 5, 16, 5)
    };
    private readonly Label _runtime = new()
    {
        Name = "runtimeStatus",
        AutoSize = true,
        Dock = DockStyle.Fill,
        TextAlign = ContentAlignment.MiddleRight,
        Padding = new Padding(16, 3, 16, 3)
    };
    private readonly Dictionary<string, NavigationButton> _navButtons = new();
    private readonly System.Windows.Forms.Timer _refreshTimer = new()
    {
        Interval = 2000
    };
    private UiTheme _theme;
    private string _page = "dashboard";
    private Action? _refreshPage;
    private bool _updating;
    private int _busyOperations;
    private CancellationTokenSource? _assistantCancellation;
    private CancellationTokenSource? _localCheckCancellation;
    private readonly ToolTip _tips = new()
    {
        AutoPopDelay = 20000,
        InitialDelay = 300,
        ReshowDelay = 150
    };
    private DateTime _lastCpuTime = DateTime.UtcNow;
    private double _lastCpuSeconds;
    private double _cpuPercent;
    public MainForm(CommandCenter core, UiHostStatus host)
    {
        _core = core;
        _host = host;
        _theme = new UiTheme(ReadTheme());
        Text = "HERZ Local Command Center — مركز إدارة الوكلاء المحليين";
        Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
        AutoScaleDimensions = new SizeF(96F, 96F);
        AutoScaleMode = AutoScaleMode.Dpi;
        MinimumSize = new Size(900, 620);
        Size = new Size(1280, 840);
        StartPosition = FormStartPosition.CenterScreen;
        RightToLeft = RightToLeft.Yes;
        RightToLeftLayout = true;
        KeyPreview = true;
        BuildShell();
        Navigate("dashboard");
        using (var process = Process.GetCurrentProcess())
            _lastCpuSeconds = process.TotalProcessorTime.TotalSeconds;
        _lastCpuTime = DateTime.UtcNow;
        _refreshTimer.Tick += (_, _) => RefreshCurrent();
        _refreshTimer.Start();
        Shown += (_, _) =>
        {
            var area = Screen.FromControl(this).WorkingArea;
            MinimumSize = new Size(Math.Min(MinimumSize.Width, area.Width), Math.Min(MinimumSize.Height, area.Height));
            Size = new Size(Math.Min(Width, area.Width), Math.Min(Height, area.Height));
            Location = new Point(area.Left + (area.Width - Width) / 2, area.Top + (area.Height - Height) / 2);
            RefreshCurrent();
        };
        FormClosing += (_, _) =>
        {
            _assistantCancellation?.Cancel();
            _localCheckCancellation?.Cancel();
            try
            {
                _core.EmergencyStop();
            }
            catch (Exception ex)
            {
                Trace.WriteLine("HERZ shutdown: " + ex.GetType().Name);
            }
        };
        FormClosed += (_, _) =>
        {
            _refreshTimer.Dispose();
            _tips.Dispose();
            _assistantCancellation?.Dispose();
            _localCheckCancellation?.Dispose();
        };
        KeyDown += (_, e) =>
        {
            if (e.Control && e.KeyCode == Keys.L)
            {
                Navigate("commands");
                e.Handled = true;
            }

            if (e.Control && e.Shift && e.KeyCode == Keys.E)
            {
                EmergencyStop();
                e.Handled = true;
            }
        };
    }

    private void BuildShell()
    {
        var shell = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 4,
            Margin = Padding.Empty
        };
        shell.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        shell.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        shell.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        shell.RowStyles.Add(new RowStyle(SizeType.Absolute, 41));
        Controls.Add(shell);
        var header = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 3,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            Padding = new Padding(22, 13, 22, 10),
            Tag = "surface"
        };
        header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        header.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        header.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        var titles = Stack();
        titles.Controls.Add(Label("HERZ  |  مركز إدارة الوكلاء المحليين", 17, FontStyle.Bold));
        titles.Controls.Add(Label("عمل محلي • ملفاتك تحت إشرافك • تنفيذ واحد في كل مرة", 9, tag: "muted"));
        header.Controls.Add(titles, 0, 0);
        var themeButton = Button("تبديل المظهر", (_, _) =>
        {
            _theme = new UiTheme(!_theme.Dark);
            _theme.Apply(this);
            SaveTheme();
        });
        themeButton.Dock = DockStyle.Fill;
        header.Controls.Add(themeButton, 1, 0);
        var emergency = Button("إيقاف طارئ", (_, _) => EmergencyStop(), "danger");
        emergency.Dock = DockStyle.Fill;
        emergency.AccessibleDescription = "إيقاف استقبال المهام وإلغاء العمليات التابعة للمركز فقط. اختصار Ctrl Shift E.";
        _tips.SetToolTip(emergency, emergency.AccessibleDescription);
        header.Controls.Add(emergency, 2, 0);
        shell.Controls.Add(header, 0, 0);
        _runtime.Text = RuntimeText();
        _runtime.AccessibleDescription = _runtime.Text + " " + _host.IsolationSummary;
        _tips.SetToolTip(_runtime, _runtime.AccessibleDescription);
        _runtime.Tag = _host.IsolationVerified ? "green" : "warning";
        shell.Controls.Add(_runtime, 0, 1);
        shell.SizeChanged += (_, _) => _runtime.MaximumSize = new Size(Math.Max(1, shell.ClientSize.Width - _runtime.Margin.Horizontal), 0);
        var body = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            Margin = Padding.Empty
        };
        body.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 214));
        body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        _navigation.Tag = "surface";
        foreach (var(id, text)in new[]
        {
            ("dashboard", "الرئيسية"),
            ("commands", "مساحة الأوامر"),
            ("agents", "الوكلاء والموصلات"),
            ("tasks", "المهام والنتائج"),
            ("messages", "اتصالات الوكلاء"),
            ("knowledge", "المعرفة والتعليمات"),
            ("models", "النماذج والموارد"),
            ("security", "الحظر وسجل التنفيذ"),
            ("backup", "النسخ والاستعادة")
        }

        )
        {
            var key = id;
            var nav = new NavigationButton(text);
            nav.Click += (_, _) => Navigate(key);
            _navigation.Controls.Add(nav);
            _navButtons.Add(key, nav);
        }

        var footer = Label("Windows x64\nتظل الملفات محلية.\nيلزم بقاء الجهاز يعمل ومستيقظًا.", 9, tag: "muted");
        footer.MaximumSize = new Size(180, 0);
        footer.Margin = new Padding(4, 22, 4, 4);
        _navigation.Controls.Add(footer);
        void FitNavigation()
        {
            if (_navigation.IsDisposed || body.IsDisposed)
                return;
            int widest = _navButtons.Values.Select(n => TextRenderer.MeasureText(n.Text, n.Font).Width + n.Padding.Horizontal + 12).DefaultIfEmpty(184).Max();
            int width = widest + _navigation.Padding.Horizontal + SystemInformation.VerticalScrollBarWidth + 4;
            body.ColumnStyles[0].Width = width;
            foreach (var nav in _navButtons.Values)
            {
                nav.Width = widest;
                nav.Height = Math.Max(nav.Font.Height + nav.Padding.Vertical + 18, Metric(43));
            }
            footer.MaximumSize = new Size(widest, 0);
        }
        Shown += (_, _) => FitNavigation();
        DpiChanged += (_, _) => FitNavigation();
        body.Controls.Add(_navigation, 0, 0);
        body.Controls.Add(_content, 1, 0);
        shell.Controls.Add(body, 0, 2);
        _notice.Text = "جاهز لعرض الحالة. لا تُعد نتيجة أي مهمة ناجحة حتى يتحقق المركز من مخرجاتها.";
        _notice.Tag = "muted";
        shell.Controls.Add(_notice, 0, 3);
    }

    private string RuntimeText() =>
        (_host.IsolationVerified
            ? "اجتاز فحص العزل الحالي. "
            : "لم يجتز فحص العزل — تشغيل الوكلاء محظور. التفاصيل في قسم الحظر وسجل التنفيذ. ") +
        (_host.WindowsAcceptanceVerified ? "" : "اختبارات القبول الكاملة على Windows لم تكتمل.");
    private void Navigate(string page)
    {
        if (_busyOperations > 0)
            return;
        _page = page;
        _refreshPage = null;
        _content.SuspendLayout();
        foreach (Control child in _content.Controls.Cast<Control>().ToArray())
            child.Dispose();
        _content.Controls.Clear();
        foreach (var entry in _navButtons)
            entry.Value.Tag = entry.Key == page ? "selected" : null;
        try
        {
            switch (page)
            {
                case "commands":
                    BuildCommands();
                    break;
                case "agents":
                    BuildAgents();
                    break;
                case "tasks":
                    BuildTasks();
                    break;
                case "messages":
                    BuildMessages();
                    break;
                case "knowledge":
                    BuildKnowledge();
                    break;
                case "models":
                    BuildModels();
                    break;
                case "security":
                    BuildSecurity();
                    break;
                case "backup":
                    BuildBackup();
                    break;
                default:
                    BuildDashboard();
                    break;
            }
        }
        catch (Exception ex)
        {
            _content.Controls.Add(Label("تعذر فتح القسم: " + FriendlyError(ex), 12, tag: "danger"));
        }

        _theme.Apply(this);
        _content.ResumeLayout(true);
        RefreshCurrent();
    }

    private TableLayoutPanel Page(string title, string subtitle, params RowStyle[] rows)
    {
        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = rows.Length + 1,
            MinimumSize = new Size(0, IsHandleCreated ? Metric(480) : 480),
            Margin = Padding.Empty
        };
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        foreach (var row in rows)
        {
            // Pages are also built after initial DPI autoscaling when navigating.
            // Action rows grow to fit wrapped controls instead of hiding a scrollbar.
            if (row.SizeType == SizeType.Absolute && row.Height <= 52)
                row.SizeType = SizeType.AutoSize;
            else if (row.SizeType == SizeType.Absolute && IsHandleCreated)
                row.Height = Metric((int)row.Height);
            layout.RowStyles.Add(row);
        }
        var heading = Stack();
        heading.Controls.Add(Label(title, 19, FontStyle.Bold));
        var help = Label(subtitle, 9, tag: "muted");
        heading.Controls.Add(help);
        layout.Controls.Add(heading, 0, 0);
        _content.Controls.Add(layout);
        return layout;
    }

    private void BuildDashboard()
    {
        var layout = Page("لوحة المتابعة", "حالة فعلية من قاعدة المركز والعمليات؛ لا توجد نسب تقدم تقديرية.", new RowStyle(SizeType.AutoSize), new RowStyle(SizeType.AutoSize), new RowStyle(SizeType.Percent, 100));
        var cards = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 4,
            RowCount = 1,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink
        };
        for (var i = 0; i < 4; i++)
            cards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
        var values = new Label[4];
        var captions = new[]
        {
            "وكلاء جاهزون",
            "مهام قيد التنفيذ",
            "مهام بالانتظار",
            "مهام تحتاج الانتباه"
        };
        for (var i = 0; i < 4; i++)
        {
            var card = new SurfacePanel
            {
                Dock = DockStyle.Fill,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Margin = new Padding(0, 0, 8, 12)
            };
            var stack = Stack();
            values[i] = Label("—", 24, FontStyle.Bold, "green");
            values[i].RightToLeft = RightToLeft.No;
            stack.Controls.Add(values[i]);
            stack.Controls.Add(Label(captions[i], 9, tag: "muted"));
            card.Controls.Add(stack);
            cards.Controls.Add(card, i, 0);
        }

        layout.Controls.Add(cards, 0, 1);
        var state = new SurfacePanel
        {
            Dock = DockStyle.Fill,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink
        };
        var stateLayout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 3,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink
        };
        stateLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        stateLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        stateLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        var status = Label("", 11, FontStyle.Bold);
        status.Dock = DockStyle.Fill;
        var resource = Label("", 9, tag: "muted");
        resource.Dock = DockStyle.Fill;
        stateLayout.SizeChanged += (_, _) =>
        {
            int width = Math.Max(1, stateLayout.ClientSize.Width - stateLayout.Padding.Horizontal);
            status.MaximumSize = new Size(width, 0);
            resource.MaximumSize = new Size(width, 0);
        };
        var actions = Actions();
        actions.Controls.Add(Button("فتح مساحة الأوامر", (_, _) => Navigate("commands"), "primary"));
        actions.Controls.Add(Button("متابعة المهام", (_, _) => Navigate("tasks")));
        var resume = Button("استئناف استقبال المهام", (_, _) => Run(() =>
        {
            _core.Resume();
            RefreshCurrent();
        }, "استؤنف استقبال المهام وفق قيود العزل."));
        actions.Controls.Add(resume);
        stateLayout.Controls.Add(status, 0, 0);
        stateLayout.Controls.Add(resource, 0, 1);
        stateLayout.Controls.Add(actions, 0, 2);
        state.Controls.Add(stateLayout);
        layout.Controls.Add(state, 0, 2);
        var grid = Grid(("title", "أحدث المهام", 40), ("agent", "الوكيل", 25), ("status", "الحالة", 20), ("date", "آخر تحديث", 25));
        layout.Controls.Add(grid, 0, 3);
        grid.CellDoubleClick += (_, e) =>
        {
            if (e.RowIndex >= 0)
                Navigate("tasks");
        };
        _refreshPage = () =>
        {
            var d = _core.Dashboard();
            values[0].Text = $"{d.ReadyAgents} / {d.Agents}";
            values[1].Text = d.Running.ToString();
            values[2].Text = d.Queued.ToString();
            values[3].Text = d.Errors.ToString();
            status.Text = d.Paused ? "استقبال المهام متوقف — يمكنك مراجعة الملفات والتعليمات." : d.Isolation.Supported ? "التنفيذ المحلي متاح حسب جاهزية كل وكيل." : "تنفيذ الوكلاء محظور: " + d.Isolation.Reason;
            status.Tag = d.Isolation.Supported && !d.Paused ? "green" : "warning";
            status.ForeColor = status.Tag?.ToString() == "green" ? _theme.Green : _theme.Warning;
            resource.Text = $"ذاكرة المدير: {Ltr($"{d.WorkingSetBytes / 1048576d:F1} MiB")}   •   المعالج: {Ltr($"{_cpuPercent:F1}%")}   •   حد التوازي: {Ltr(_host.MaxConcurrency.ToString(CultureInfo.InvariantCulture))}\n" + d.Notice;
            resume.Enabled = d.Paused && d.Isolation.Supported && _host.IsolationVerified;
            _tips.SetToolTip(resume, d.Isolation.Supported ? "استئناف المهام بعد توقفها." : d.Isolation.Reason);
            Fill(grid, _core.Tasks().Take(8).Select(t => Row(t.Id, t, t.Title, t.AgentId, TaskStatus(t.Status), LocalTime(t.UpdatedAt))));
        };
    }

    private void BuildCommands()
    {
        var layout = Page("مساحة الأوامر", "اكتب طلبك، راجع الخطة، ثم وافق على إرسال مهامها. رد النموذج المحلي استشارة لا تنفذ إجراءات تلقائيًا.", new RowStyle(SizeType.Absolute, 138), new RowStyle(SizeType.Absolute, 48), new RowStyle(SizeType.Percent, 100));
        var request = Input(multiline: true);
        request.Dock = DockStyle.Fill;
        request.PlaceholderText = "مثال للمسار المحدد: حلل الأرقام 12، 18، 20، 10 ثم أنشئ تقريرًا";
        request.AccessibleName = "الطلب العربي للمدير";
        layout.Controls.Add(request, 0, 1);
        var actions = Actions();
        PlanRecord? plan = null;
        var submit = Button("اعتماد الخطة وإرسالها", (_, _) =>
        {
            if (plan == null)
                return;
            Run(() =>
            {
                var tasks = _core.SubmitPlan(plan.Id);
                Say($"أُرسلت {tasks.Count} مهام. تابع حالتها في قسم المهام والنتائج.");
                plan = null;
            }, null);
        }, "primary");
        submit.Enabled = false;
        var output = ReadOnlyText(arabic: true);
        output.Dock = DockStyle.Fill;
        actions.Controls.Add(Button("عرض خطة قابلة للتنفيذ", (_, _) => Run(() =>
        {
            plan = _core.PreviewPlan(request.Text);
            var text = new StringBuilder("مصدر الخطة: " + plan.Source + "\n\n");
            text.AppendLine("هذا المسار يطبق قواعد محلية محددة. لا يُعد استدلالًا لغويًا عامًا.\n");
            for (var i = 0; i < plan.Steps.Count; i++)
            {
                var step = plan.Steps[i];
                text.AppendLine($"{i + 1}. {step.Title}");
                text.AppendLine("الوكيل: " + step.AgentId);
                text.AppendLine("يعتمد على: " + (step.DependsOn.Length == 0 ? "لا شيء" : string.Join("، ", step.DependsOn.Select(n => n + 1))));
                text.AppendLine(step.Input.ToJsonString(PrettyJson));
                text.AppendLine();
            }

            output.Text = text.ToString();
            submit.Enabled = plan.Steps.Count > 0;
        }, "عُرضت الخطة للمراجعة ولم تُرسل بعد.")));
        actions.Controls.Add(submit);
        var askModel = Button("استشارة النموذج المحلي", null);
        askModel.Enabled = _host.LocalAssistantAsync != null;
        _tips.SetToolTip(askModel, _host.ModelStatus);
        var stopModel = Button("إلغاء الاستشارة", (_, _) => _assistantCancellation?.Cancel());
        stopModel.Enabled = false;
        askModel.Click += async (_, _) =>
        {
            if (_host.LocalAssistantAsync == null)
                return;
            if (string.IsNullOrWhiteSpace(request.Text))
            {
                Say("اكتب طلبك أولًا قبل استشارة النموذج.", true);
                return;
            }

            _assistantCancellation?.Dispose();
            _assistantCancellation = new CancellationTokenSource();
            askModel.Enabled = false;
            stopModel.Enabled = true;
            submit.Enabled = false;
            Say("يجري الاستدلال المحلي. يمكن إلغاؤه دون إغلاق المركز.");
            try
            {
                output.Text = await _host.LocalAssistantAsync(request.Text, _assistantCancellation.Token);
                Say("اكتملت الاستشارة المحلية. لم تنفذ إجراءات على الملفات.");
            }
            catch (OperationCanceledException)
            {
                Say("أُلغيت الاستشارة المحلية.");
            }
            catch (Exception ex)
            {
                Error(ex);
            }
            finally
            {
                askModel.Enabled = true;
                stopModel.Enabled = false;
            }
        };
        actions.Controls.Add(askModel);
        actions.Controls.Add(stopModel);
        layout.Controls.Add(actions, 0, 2);
        layout.Controls.Add(output, 0, 3);
        output.Text = "ستظهر الخطة أو إجابة النموذج هنا.\n\n" + _host.ModelStatus;
        request.TextChanged += (_, _) =>
        {
            plan = null;
            submit.Enabled = false;
        };
        submit.Click += (_, _) =>
        {
            if (plan == null)
                submit.Enabled = false;
        };
    }

    private void BuildAgents()
    {
        var layout = Page("الوكلاء والموصلات", "تسجل الإضافات الخارجية للمراجعة وتبقى غير مفعلة في هذا الإصدار. الأزرار تتحكم في مهام العامل المجهز؛ إعادة إنشاء مضيف متوقف تحتاج إعادة فتح المركز.", new RowStyle(SizeType.Absolute, 84), new RowStyle(SizeType.Percent, 45), new RowStyle(SizeType.Absolute, 49), new RowStyle(SizeType.Percent, 55));
        var intro = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 2
        };
        intro.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        intro.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150));
        intro.Controls.Add(Label("صندوق الاستيراد المحلي: انسخ إليه مجلد الوكيل وملف تعريفه.", 9, tag: "muted"), 0, 0);
        var inbox = Input(ltr: true);
        inbox.ReadOnly = true;
        inbox.Text = _host.InboxDirectory;
        inbox.Dock = DockStyle.Fill;
        intro.Controls.Add(inbox, 0, 1);
        var add = Button("إضافة وكيل", (_, _) => ShowAgentWizard(), "primary");
        add.Dock = DockStyle.Fill;
        intro.Controls.Add(add, 1, 0);
        intro.SetRowSpan(add, 2);
        layout.Controls.Add(intro, 0, 1);
        var grid = Grid(("name", "الوكيل", 28), ("runtime", "التقنية", 12), ("status", "الحالة", 17), ("caps", "القدرات", 30), ("version", "الإصدار", 12));
        layout.Controls.Add(grid, 0, 2);
        var detail = ReadOnlyText(arabic: true);
        detail.Dock = DockStyle.Fill;
        var actions = Actions();
        var controls = new Dictionary<string, Button>();
        var direct = Button("إرسال مهمة مباشرة", (_, _) =>
        {
            if (Selected<AgentRecord>(grid)is { } selected)
                ShowTaskDialog(selected.Definition.Id, null);
        }, "primary");
        direct.Enabled = false;
        foreach (var(action, label)in new[]
        {
            ("start", "تفعيل المهام"),
            ("stop", "تعطيل المهام"),
            ("restart", "إعادة التفعيل"),
            ("cancel", "إلغاء مهام الوكيل")
        }

        )
        {
            var captured = action;
            var button = Button(label, (_, _) =>
            {
                if (Selected<AgentRecord>(grid)is not { } agent)
                    return;
                Run(() =>
                {
                    var state = _core.ControlAgent(agent.Definition.Id, captured);
                    Say(state.Readiness.Reason);
                    RefreshCurrent();
                }, null);
            });
            button.Enabled = false;
            actions.Controls.Add(button);
            controls.Add(action, button);
        }

        actions.Controls.Add(direct);
        actions.Controls.Add(Button("فحص الجاهزية", (_, _) =>
        {
            RefreshCurrent();
            Say("حُدّثت حالة اتصال الوكلاء وقيودهم.");
        }));
        layout.Controls.Add(actions, 0, 3);
        layout.Controls.Add(detail, 0, 4);
        void ShowSelected()
        {
            var a = Selected<AgentRecord>(grid);
            direct.Enabled = a != null && a.Enabled && a.Readiness.Ready;
            _tips.SetToolTip(direct, a?.Readiness.Reason ?? "اختر وكيلًا جاهزًا للتنفيذ.");
            foreach (var entry in controls)
                entry.Value.Enabled = a != null && a.Definition.Controls.Contains(entry.Key, StringComparer.Ordinal);
            if (a == null)
            {
                detail.Text = "لا وكلاء مسجلون بعد. استخدم «إضافة وكيل» لاختيار ملف تعريف محلي وفحصه.";
                return;
            }

            detail.Text = $"{a.Definition.Name}\n{a.Definition.Description}\n\nالحالة: {(a.Enabled ? "مفعّل في السجل" : "موقوف في السجل")}\nالجاهزية: {a.Readiness.Reason}\n\nالمعرف: {a.Definition.Id}\nالترخيص: {a.Definition.LicenseSpdx}\nمصدر الترخيص: {a.Definition.LicenseSource}\nالموصل: {a.Definition.Connector}\nالقدرات: {string.Join("، ", a.Definition.Capabilities)}\nحد الذاكرة: {a.Definition.MemoryMb} MiB\nالمهلة: {a.Definition.WallSeconds} ثانية\nالشبكة: {a.Definition.Network}\n\nالإيقاف المؤقت والاستئناف غير متاحين إلا لموصل يثبت دعمهما.\n";
        }

        grid.SelectionChanged += (_, _) => ShowSelected();
        _refreshPage = () =>
        {
            Fill(grid, _core.Agents().Select(a => Row(a.Definition.Id, a, a.Definition.Name, a.Definition.Runtime, !a.Enabled ? "موقوف" : a.Readiness.Ready ? "جاهز" : "غير متاح", string.Join("، ", a.Definition.Capabilities), a.Definition.Version)));
            ShowSelected();
        };
    }

    private void ShowAgentWizard()
    {
        using var dialog = Dialog("إضافة وكيل", 800, 680);
        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 6,
            Padding = new Padding(20)
        };
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 60));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 43));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 58));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 45));
        layout.Controls.Add(Label("1. اختر ملف التعريف من صندوق الاستيراد.\n2. افحص المتطلبات والترخيص والاتصال.  3. اعتمد التسجيل بعد المراجعة.", 10), 0, 0);
        var path = Input(ltr: true);
        path.Dock = DockStyle.Fill;
        path.PlaceholderText = Path.Combine(_host.InboxDirectory, "agent-folder", "agent.json");
        layout.Controls.Add(path, 0, 1);
        var actions = Actions();
        var result = ReadOnlyText(arabic: true);
        result.Dock = DockStyle.Fill;
        AgentInspection? inspection = null;
        var approve = new CheckBox
        {
            Text = "راجعت مصدر الوكيل وترخيصه وصلاحياته، وأعتمد تسجيل هذا الإصدار.",
            AutoSize = false,
            Dock = DockStyle.Fill
        };
        var register = Button("تسجيل الوكيل", (_, _) =>
        {
            if (inspection == null || !inspection.Allowed || !approve.Checked)
                return;
            try
            {
                _core.RegisterAgent(path.Text.Trim(), inspection.ApprovalDigest);
                dialog.DialogResult = DialogResult.OK;
                dialog.Close();
                Say("سُجل الوكيل. إتاحته للتنفيذ تعتمد على الجاهزية والعزل.");
                RefreshCurrent();
            }
            catch (Exception ex)
            {
                result.Text = FriendlyError(ex);
            }
        }, "primary");
        register.Enabled = false;
        actions.Controls.Add(Button("اختيار من صندوق الاستيراد", (_, _) =>
        {
            var selected = PickInboxFile();
            if (selected != null)
                path.Text = selected;
        }));
        var inspectButton = Button("فحص المتطلبات والاتصال", null);
        inspectButton.Click += async (_, _) =>
        {
            inspectButton.Enabled = false;
            register.Enabled = false;
            path.Enabled = false;
            actions.Enabled = false;
            BeginBusy();
            result.Text = "يجري فحص ملفات المصدر والترخيص…";
            try
            {
                var manifestPath = path.Text.Trim();
                inspection = await System.Threading.Tasks.Task.Run(() => _core.InspectAgent(manifestPath));
                var b = new StringBuilder(inspection.Allowed ? "اجتاز شروط التسجيل.\n" : "التسجيل مرفوض.\n");
                foreach (var check in inspection.Checks)
                    b.AppendLine($"{(check.Passed ? "✓" : "×")} {check.Name}: {check.Reason}");
                b.AppendLine("\nاختبار الاتصال: " + inspection.Readiness.Reason);
                b.AppendLine("\n" + inspection.Reason);
                if (inspection.Definition is { } a)
                    b.AppendLine($"\nالاسم: {a.Name}\nالترخيص: {a.LicenseSpdx}\nالمصدر: {a.LicenseSource}\nالقدرات: {string.Join("، ", a.Capabilities)}\nحد الذاكرة: {a.MemoryMb} MiB\nالمهلة: {a.WallSeconds} ثانية\nالشبكة: {a.Network}\nملفات المصدر المثبتة بالبصمة: {a.FileHashes.Count}\n\nنص الترخيص المقدم للمراجعة:\n{a.LicenseText}");
                result.Text = b.ToString();
                register.Enabled = inspection.Allowed && approve.Checked;
            }
            catch (Exception ex)
            {
                result.Text = FriendlyError(ex);
                inspection = null;
            }
            finally
            {
                if (!dialog.IsDisposed)
                {
                    inspectButton.Enabled = true;
                    path.Enabled = true;
                    actions.Enabled = true;
                }

                EndBusy();
            }
        };
        actions.Controls.Add(inspectButton);
        layout.Controls.Add(actions, 0, 2);
        layout.Controls.Add(result, 0, 3);
        layout.Controls.Add(approve, 0, 4);
        layout.Controls.Add(register, 0, 5);
        approve.CheckedChanged += (_, _) => register.Enabled = approve.Checked && inspection?.Allowed == true;
        path.TextChanged += (_, _) =>
        {
            inspection = null;
            register.Enabled = false;
            approve.Checked = false;
        };
        dialog.Controls.Add(layout);
        _theme.Apply(dialog);
        dialog.ShowDialog(this);
    }

    private void BuildTasks()
    {
        var layout = Page("المهام والنتائج", "تعرض الحالة المحفوظة والاعتماديات والنتائج المتحقق منها. المهمة غير المحسومة بعد تعطل سابق لا تُكرر آثارها تلقائيًا.", new RowStyle(SizeType.Percent, 42), new RowStyle(SizeType.Absolute, 48), new RowStyle(SizeType.Percent, 58));
        var grid = Grid(("title", "المهمة", 30), ("agent", "الوكيل", 22), ("status", "الحالة", 18), ("attempts", "المحاولات", 10), ("updated", "آخر تحديث", 20));
        layout.Controls.Add(grid, 0, 1);
        var actions = Actions();
        var cancel = Button("إلغاء المهمة المحددة", (_, _) =>
        {
            if (Selected<TaskRecord>(grid)is { } t)
                Run(() =>
                {
                    _core.Cancel(t.Id);
                    RefreshCurrent();
                }, "أُرسل الإلغاء للمهمة المحددة.");
        }, "danger");
        cancel.Enabled = false;
        var handoff = Button("تسليم النتيجة لوكيل آخر", (_, _) =>
        {
            if (Selected<TaskRecord>(grid)is { } selected)
                ShowTaskDialog(null, selected);
        }, "primary");
        handoff.Enabled = false;
        actions.Controls.Add(cancel);
        actions.Controls.Add(handoff);
        actions.Controls.Add(Button("تحديث الحالة", (_, _) => RefreshCurrent()));
        layout.Controls.Add(actions, 0, 2);
        var tabs = new TabControl
        {
            Dock = DockStyle.Fill,
            RightToLeft = RightToLeft.Yes,
            RightToLeftLayout = true
        };
        var detail = ReadOnlyText(arabic: true);
        detail.Dock = DockStyle.Fill;
        var files = Grid(("name", "الملف", 35), ("size", "الحجم بالبايت", 18), ("sha", "SHA-256", 47));
        var detailsPage = new TabPage("التفاصيل والسجل");
        detailsPage.Controls.Add(detail);
        tabs.TabPages.Add(detailsPage);
        var filePage = new TabPage("الملفات الناتجة");
        var fileLayout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2
        };
        fileLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        fileLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 45));
        fileLayout.Controls.Add(files, 0, 0);
        var preview = Button("قراءة الملف كنص آمن", (_, _) =>
        {
            if (Selected<ArtifactRecord>(files)is { } artifact)
                PreviewArtifact(artifact);
        });
        preview.Enabled = false;
        files.SelectionChanged += (_, _) => preview.Enabled = Selected<ArtifactRecord>(files) != null;
        fileLayout.Controls.Add(preview, 0, 1);
        filePage.Controls.Add(fileLayout);
        tabs.TabPages.Add(filePage);
        layout.Controls.Add(tabs, 0, 3);
        void ShowTask()
        {
            var selected = Selected<TaskRecord>(grid);
            handoff.Enabled = selected?.Status == "succeeded" && selected.Artifacts.Count > 0;
            cancel.Enabled = selected != null && new[]
            {
                "queued",
                "running",
                "waiting",
                "pending"
            }.Contains(selected.Status);
            if (selected == null)
            {
                detail.Text = "لم تُسجل مهام بعد. أنشئ خطة في مساحة الأوامر وراجعها قبل الإرسال.";
                Fill(files, []);
                return;
            }

            var task = _core.TaskDetails(selected.Id);
            var b = new StringBuilder($"{task.Title}\nالحالة: {TaskStatus(task.Status)}\nالمعرف: {task.Id}\nالوكيل: {task.AgentId}\nالمحاولات: {task.Attempts}\nالأولوية: {task.Priority}\nالاعتماديات: {string.Join("، ", task.Dependencies)}\n");
            if (!string.IsNullOrEmpty(task.Error))
                b.AppendLine("\nسبب التعطل: " + task.Error);
            if (task.Result != null)
                b.AppendLine("\nالنتيجة:\n" + task.Result.ToJsonString(PrettyJson));
            b.AppendLine("\nسجل الرسائل:");
            foreach (var m in _core.Messages(task.Id).TakeLast(30))
                b.AppendLine($"{LocalTime(m.CreatedAt)} | المرسل: {m.Sender} | المستقبل: {m.Receiver} | {m.Status}\n{m.Body}\n");
            detail.Text = b.ToString();
            Fill(files, task.Artifacts.Select(a => Row(a.RelativePath, a, a.RelativePath, a.Bytes.ToString("N0"), a.Sha256)));
        }

        grid.SelectionChanged += (_, _) => Run(ShowTask, null);
        _refreshPage = () =>
        {
            Fill(grid, _core.Tasks().Take(300).Select(t => Row(t.Id, t, t.Title, t.AgentId, TaskStatus(t.Status), t.Attempts, LocalTime(t.UpdatedAt))));
            ShowTask();
        };
    }

    private void ShowTaskDialog(string? selectedAgentId, TaskRecord? dependency)
    {
        var available = _core.Agents().Where(a => a.Enabled && a.Readiness.Ready).ToArray();
        if (available.Length == 0)
        {
            Say("لا يوجد وكيل جاهز لاستقبال المهمة. راجع حالة الوكلاء وسبب الحظر.", true);
            return;
        }

        using var dialog = Dialog(dependency == null ? "إرسال مهمة محلية" : "تسليم نتيجة موثقة لوكيل آخر", 820, 730);
        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 7,
            Padding = new Padding(20)
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 66));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 43));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 43));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 43));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
        var explanation = Label(dependency == null ? "تُراجع المدخلات وفق مخطط الوكيل قبل إرسالها. الرقم الأعلى يعني أولوية أعلى؛ التوازي يبقى محدودًا." : "ستستخدم المهمة نسخة من ملفات النتيجة المتحقق منها عبر اعتمادية محفوظة. تبقى الملفات الأصلية محفوظة.\nالمهمة المصدر: " + dependency.Id, 9, tag: "muted");
        explanation.Dock = DockStyle.Fill;
        explanation.AutoSize = false;
        layout.Controls.Add(explanation, 0, 0);
        layout.SetColumnSpan(explanation, 2);
        layout.Controls.Add(Label("الوكيل المستلم", 9), 0, 1);
        var agents = new ComboBox
        {
            DropDownStyle = ComboBoxStyle.DropDownList,
            Dock = DockStyle.Fill
        };
        foreach (var agent in available)
            agents.Items.Add(new Choice(agent.Definition.Id, agent.Definition.Name + " — " + agent.Definition.Id));
        agents.SelectedIndex = Math.Max(0, Array.FindIndex(available, a => a.Definition.Id == selectedAgentId));
        layout.Controls.Add(agents, 1, 1);
        layout.Controls.Add(Label("عنوان المهمة", 9), 0, 2);
        var title = Input();
        title.Dock = DockStyle.Fill;
        title.Text = dependency == null ? "مهمة محلية" : "متابعة: " + dependency.Title;
        title.MaxLength = 200;
        layout.Controls.Add(title, 1, 2);
        layout.Controls.Add(Label("الأولوية", 9), 0, 3);
        var priority = new NumericUpDown
        {
            Minimum = -100,
            Maximum = 100,
            Value = 0,
            Width = 120,
            RightToLeft = RightToLeft.No
        };
        layout.Controls.Add(priority, 1, 3);
        layout.Controls.Add(Label("مدخلات JSON", 9), 0, 4);
        var input = Input(multiline: true, ltr: true);
        input.Dock = DockStyle.Fill;
        input.Text = "{}";
        input.Font = new Font("Consolas", 10);
        layout.Controls.Add(input, 1, 4);
        layout.Controls.Add(Label("مخطط المدخلات", 9), 0, 5);
        var schema = ReadOnlyText();
        schema.Dock = DockStyle.Fill;
        layout.Controls.Add(schema, 1, 5);
        void ShowSchema()
        {
            schema.Text = available[agents.SelectedIndex].Definition.InputSchema.ToJsonString(PrettyJson);
        }

        agents.SelectedIndexChanged += (_, _) => ShowSchema();
        ShowSchema();
        var submit = Button("اعتماد المهمة وإرسالها", (_, _) =>
        {
            try
            {
                if (JsonNode.Parse(input.Text)is not JsonObject value)
                    throw new PolicyException("يجب أن تكون المدخلات كائن JSON مطابقًا للمخطط المعروض.");
                var task = _core.Submit(new TaskSubmission(((Choice)agents.SelectedItem!).Id, value, title.Text.Trim(), (int)priority.Value, Guid.NewGuid().ToString("N"), dependency == null ? null : [dependency.Id]));
                Say("سُجلت المهمة: " + task.Id + ". تابع النتيجة في صفحة المهام.");
                dialog.Close();
                RefreshCurrent();
            }
            catch (Exception ex)
            {
                explanation.Text = FriendlyError(ex);
                explanation.Tag = "danger";
                explanation.ForeColor = _theme.Danger;
            }
        }, "primary");
        layout.Controls.Add(submit, 0, 6);
        layout.SetColumnSpan(submit, 2);
        dialog.Controls.Add(layout);
        _theme.Apply(dialog);
        dialog.ShowDialog(this);
    }

    private void BuildMessages()
    {
        var layout = Page("اتصالات الوكلاء", "كل رسالة مرتبطة بمعرف مهمة ومرسل ومستقبل. اختر رسالة لعرض محتواها المحلي الكامل.", new RowStyle(SizeType.Percent, 55), new RowStyle(SizeType.Percent, 45));
        var grid = Grid(("time", "الوقت", 20), ("from", "المرسل", 20), ("to", "المستقبل", 20), ("status", "الحالة", 15), ("task", "معرف المهمة", 25));
        var detail = ReadOnlyText();
        detail.Dock = DockStyle.Fill;
        layout.Controls.Add(grid, 0, 1);
        layout.Controls.Add(detail, 0, 2);
        grid.SelectionChanged += (_, _) =>
        {
            var m = Selected<MessageRecord>(grid);
            detail.Text = m == null ? "لا رسائل بعد." : JsonSerializer.Serialize(m, PrettyJson);
        };
        _refreshPage = () => Fill(grid, _core.Messages().TakeLast(300).Reverse().Select(m => Row(m.Id, m, LocalTime(m.CreatedAt), m.Sender, m.Receiver, m.Status, m.TaskId)));
    }

    private void BuildKnowledge()
    {
        var layout = Page("المعرفة والتعليمات", "تعليمات ومراجع وتصحيحات محلية مع إصدارات ومصادر. حفظ الملفات واسترجاعها لا يغير أوزان النموذج ولا يُعد تدريبًا.", new RowStyle(SizeType.Absolute, 47), new RowStyle(SizeType.Percent, 100));
        var filter = Actions();
        var kinds = new ComboBox
        {
            DropDownStyle = ComboBoxStyle.DropDownList,
            Width = 180
        };
        kinds.Items.AddRange([new Choice("instruction", "التعليمات الدائمة"), new Choice("reference", "المراجع والأمثلة"), new Choice("correction", "التصحيحات المعتمدة")]);
        kinds.SelectedIndex = 0;
        var query = Input();
        query.Width = 235;
        query.PlaceholderText = "بحث محلي داخل النطاق المحدد";
        var scope = new ComboBox
        {
            DropDownStyle = ComboBoxStyle.DropDownList,
            Width = 165
        };
        scope.Items.Add(new Choice("shared", "معرفة مشتركة"));
        foreach (var a in _core.Agents())
            scope.Items.Add(new Choice(a.Definition.Id, a.Definition.Name));
        scope.SelectedIndex = 0;
        filter.Controls.Add(kinds);
        filter.Controls.Add(scope);
        filter.Controls.Add(query);
        var search = Button("بحث", null);
        filter.Controls.Add(search);
        layout.Controls.Add(filter, 0, 1);
        var columns = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1
        };
        columns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 38));
        columns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 62));
        var grid = Grid(("title", "العنوان", 70), ("version", "الإصدار", 30));
        columns.Controls.Add(grid, 0, 0);
        var edit = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 6,
            Padding = new Padding(0, 0, 14, 0)
        };
        edit.RowStyles.Add(new RowStyle(SizeType.Absolute, 39));
        edit.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
        edit.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        edit.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
        edit.RowStyles.Add(new RowStyle(SizeType.Absolute, 52));
        edit.RowStyles.Add(new RowStyle(SizeType.Absolute, 45));
        var title = Input();
        title.PlaceholderText = "عنوان واضح للمعلومة";
        title.Dock = DockStyle.Fill;
        var source = Label("اختر سجلًا أو أنشئ سجلًا جديدًا.", 8, tag: "muted");
        source.Dock = DockStyle.Fill;
        source.AutoSize = false;
        var body = Input(multiline: true);
        body.Dock = DockStyle.Fill;
        var approved = new CheckBox
        {
            Text = "أعتمد هذا المحتوى ضمن النطاق المحدد.",
            Dock = DockStyle.Fill
        };
        var versions = new ComboBox
        {
            DropDownStyle = ComboBoxStyle.DropDownList,
            Width = 160
        };
        string? editingId = null;
        string? editingScope = null;
        var editorActions = Actions();
        editorActions.Controls.Add(Button("حفظ إصدار معتمد", (_, _) => Run(() =>
        {
            if (!approved.Checked)
                throw new PolicyException("يلزم اعتماد المحتوى صراحة قبل حفظه كمعرفة معتمدة.");
            var saved = _core.SaveKnowledge(new KnowledgeInput(((Choice)kinds.SelectedItem!).Id, editingId == null ? ((Choice)scope.SelectedItem!).Id : editingScope!, title.Text, body.Text, true, editingId));
            editingId = saved.Id;
            ReloadKnowledge();
            SelectByKey(grid, saved.Id);
            Say("حُفظ إصدار محلي معتمد مع مصدره.");
        }, null), "primary"));
        editorActions.Controls.Add(Button("سجل جديد", (_, _) =>
        {
            grid.ClearSelection();
            editingId = null;
            title.Clear();
            body.Clear();
            approved.Checked = false;
            versions.Items.Clear();
            source.Text = "سجل جديد — سيحفظ في النطاق المحدد.";
        }));
        var rollback = Button("استرجاع الإصدار", (_, _) => Run(() =>
        {
            if (editingId == null || versions.SelectedItem is not KnowledgeVersion v)
                return;
            var restored = _core.RollbackKnowledge(editingId, v.Version);
            ReloadKnowledge();
            SelectByKey(grid, restored.Id);
            Say("استُرجع الإصدار المحدد مع حفظ سجل التغييرات.");
        }, null));
        var versionActions = Actions();
        versionActions.Controls.Add(Label("سجل الإصدارات:", 9));
        versionActions.Controls.Add(versions);
        versionActions.Controls.Add(rollback);
        edit.Controls.Add(title, 0, 0);
        edit.Controls.Add(source, 0, 1);
        edit.Controls.Add(body, 0, 2);
        edit.Controls.Add(approved, 0, 3);
        edit.Controls.Add(editorActions, 0, 4);
        edit.Controls.Add(versionActions, 0, 5);
        columns.Controls.Add(edit, 1, 0);
        layout.Controls.Add(columns, 0, 2);
        void ReloadKnowledge()
        {
            var selectedKind = ((Choice)kinds.SelectedItem!).Id;
            var selectedScope = ((Choice)scope.SelectedItem!).Id;
            IEnumerable<KnowledgeRecord> items = string.IsNullOrWhiteSpace(query.Text) ? _core.Knowledge(selectedScope) : _core.SearchKnowledge(query.Text, selectedScope).Select(h => h.Item);
            Fill(grid, items.Where(k => k.Kind == selectedKind).Select(k => Row(k.Id, k, k.Title, k.Version)));
        }

        grid.SelectionChanged += (_, _) =>
        {
            if (Selected<KnowledgeRecord>(grid)is not { } item)
            {
                editingId = null;
                title.Clear();
                body.Clear();
                approved.Checked = false;
                versions.Items.Clear();
                source.Text = "لا سجل محدد. يمكنك إنشاء سجل جديد في النطاق المختار.";
                return;
            }

            editingId = item.Id;
            editingScope = item.Scope;
            title.Text = item.Title;
            body.Text = item.Content;
            approved.Checked = item.Approved;
            source.Text = $"النطاق: {item.Scope} • المصدر: {item.Source} • الإصدار {item.Version} • {LocalTime(item.CreatedAt)}";
            versions.Items.Clear();
            foreach (var v in _core.KnowledgeHistory(item.Id))
                versions.Items.Add(new KnowledgeVersion(v.Version, LocalTime(v.CreatedAt)));
            if (versions.Items.Count > 0)
                versions.SelectedIndex = 0;
        };
        search.Click += (_, _) => Run(ReloadKnowledge, "عُرضت النتائج المحلية ضمن النطاق المحدد.");
        void ChangeScope()
        {
            editingId = null;
            title.Clear();
            body.Clear();
            approved.Checked = false;
            versions.Items.Clear();
            source.Text = "اختر سجلًا في النطاق الجديد أو احفظ سجلًا جديدًا.";
            ReloadKnowledge();
        }

        kinds.SelectedIndexChanged += (_, _) => Run(ChangeScope, null);
        scope.SelectedIndexChanged += (_, _) => Run(ChangeScope, null);
        query.KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Enter)
            {
                Run(ReloadKnowledge, null);
                e.SuppressKeyPress = true;
            }
        };
        ReloadKnowledge();
    }

    private void BuildModels()
    {
        var layout = Page("النماذج والموارد", "استدلال محلي فقط. تسجيل ملف نموذج لا يثبت جودة العربية أو استدعاء الأدوات؛ تظل نتائج التقييم شرطًا منفصلًا.", new RowStyle(SizeType.Absolute, 150), new RowStyle(SizeType.Percent, 50), new RowStyle(SizeType.Absolute, 46), new RowStyle(SizeType.Percent, 50));
        var status = new SurfacePanel
        {
            Dock = DockStyle.Fill
        };
        var statusText = Label(_host.ModelStatus + "\n\nملف الجهاز المستهدف: Windows 11 Home x64 • Ryzen 7 5825U • ذاكرة مثبتة 16 GB.\nملف التشغيل المحافظ: عامل واحد؛ نموذج مشترك؛ سياق 2048؛ 4 خيوط CPU؛ لا اختيار تلقائي لمزود سحابي.", 10);
        statusText.Dock = DockStyle.Fill;
        statusText.AutoSize = false;
        status.Controls.Add(statusText);
        layout.Controls.Add(status, 0, 1);
        var grid = Grid(("name", "النموذج", 25), ("status", "الحالة", 20), ("reason", "سبب الحالة", 55));
        layout.Controls.Add(grid, 0, 2);
        var actions = Actions();
        actions.Controls.Add(Button("تسجيل نموذج محلي", (_, _) => ShowModelDialog()));
        actions.Controls.Add(Button("تحديث الموارد", (_, _) => RefreshCurrent()));
        var localCheck = Button("اختبار التشغيل المحلي", null, "primary");
        localCheck.Enabled = _host.RunLocalCheckAsync != null;
        _tips.SetToolTip(localCheck, _host.RunLocalCheckAsync == null ? "غير متاح: لم يربط المضيف اختبار التشغيل المحلي." : "يشغل مهمة تحقق ويحفظ نتائجها الفعلية. لا يختبر جميع أزرار الواجهة أو اعتماد Windows الكامل.");
        localCheck.Click += async (_, _) =>
        {
            if (_host.RunLocalCheckAsync == null)
                return;
            _localCheckCancellation?.Dispose();
            _localCheckCancellation = new CancellationTokenSource();
            var token = _localCheckCancellation.Token;
            localCheck.Enabled = false;
            BeginBusy();
            Say("يجري اختبار تشغيل محلي حقيقي؛ يمكنك إيقافه بالزر الطارئ.");
            try
            {
                var result = await System.Threading.Tasks.Task.Run(() => _host.RunLocalCheckAsync(token), token);
                if (IsDisposed || Disposing)
                    return;
                using var dialog = Dialog("نتيجة اختبار التشغيل المحلي", 950, 680);
                var output = ReadOnlyText();
                output.Dock = DockStyle.Fill;
                output.Text = "اختبار تشغيل محدد؛ لا يختبر جميع أزرار الواجهة أو اعتماد Windows الكامل.\r\n\r\n" + result;
                dialog.Controls.Add(output);
                _theme.Apply(dialog);
                dialog.ShowDialog(this);
                Say("انتهى الاختبار المحلي. راجع الحالات المسجلة في التقرير لتحديد النجاح والفشل.");
            }
            catch (OperationCanceledException)
            {
                if (!IsDisposed && !Disposing)
                    Say("أُلغي اختبار التشغيل المحلي؛ لا يُعد الإلغاء نجاحًا.");
            }
            catch (Exception ex)
            {
                if (!IsDisposed && !Disposing)
                    Error(ex);
            }
            finally
            {
                if (!localCheck.IsDisposed)
                    localCheck.Enabled = _host.RunLocalCheckAsync != null;
                EndBusy();
            }
        };
        actions.Controls.Add(localCheck);
        layout.Controls.Add(actions, 0, 3);
        var details = ReadOnlyText();
        details.Dock = DockStyle.Fill;
        layout.Controls.Add(details, 0, 4);
        grid.SelectionChanged += (_, _) => details.Text = Selected<ModelState>(grid)is { } m ? JsonSerializer.Serialize(m, PrettyJson) : "لم تُسجل نماذج بعد. لا تنزيلات تلقائية من هذه الصفحة.";
        _refreshPage = () => Fill(grid, _core.Models().Select(m => Row(m.Configuration.Id, m, m.Configuration.Name, m.Enabled ? "معتمد" : "غير مفعّل", m.Reason)));
    }

    private void ShowModelDialog()
    {
        using var dialog = Dialog("تسجيل ملفات نموذج محلي", 760, 610);
        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 9,
            Padding = new Padding(20)
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 145));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        var fields = new Dictionary<string, TextBox>();
        var rows = new[]
        {
            ("id", "معرف النموذج"),
            ("name", "الاسم"),
            ("runner", "مسار محرك CLI"),
            ("model", "مسار ملف GGUF"),
            ("sha", "SHA-256 للملف"),
            ("license", "الترخيص SPDX"),
            ("licensePath", "ملف الترخيص المحلي")
        };
        for (var i = 0; i < rows.Length; i++)
        {
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
            layout.Controls.Add(Label(rows[i].Item2, 9), 0, i);
            var field = Input(ltr: rows[i].Item1 != "name");
            field.Dock = DockStyle.Fill;
            layout.Controls.Add(field, 1, i);
            fields.Add(rows[i].Item1, field);
        }

        var note = Label("استخدم ملفات موجودة داخل مجلدات HERZ المسموح بها. تسجيل البيانات لا يفعّل نموذجًا غير مقاس أو يمنح اتصالًا خارجيًا.", 9, tag: "warning");
        note.Dock = DockStyle.Fill;
        note.AutoSize = false;
        layout.Controls.Add(note, 0, 7);
        layout.SetColumnSpan(note, 2);
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        var button = Button("فحص الملفات وتسجيلها", null, "primary");
        button.Click += async (_, _) =>
        {
            button.Enabled = false;
            BeginBusy();
            try
            {
                var configuration = new ModelConfiguration(fields["id"].Text.Trim(), fields["name"].Text.Trim(), fields["runner"].Text.Trim(), fields["model"].Text.Trim(), fields["sha"].Text.Trim(), fields["license"].Text.Trim(), fields["licensePath"].Text.Trim());
                var result = await System.Threading.Tasks.Task.Run(() => _core.RegisterModel(configuration));
                Say(result.Reason);
                dialog.Close();
                RefreshCurrent();
            }
            catch (Exception ex)
            {
                note.Text = FriendlyError(ex);
            }
            finally
            {
                if (!dialog.IsDisposed)
                    button.Enabled = true;
                EndBusy();
            }
        };
        layout.Controls.Add(button, 0, 8);
        layout.SetColumnSpan(button, 2);
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 45));
        dialog.Controls.Add(layout);
        _theme.Apply(dialog);
        dialog.ShowDialog(this);
    }

    private void BuildSecurity()
    {
        var layout = Page("الحظر وسجل التنفيذ", "السجل يعرض ما رصده المركز فعليًا. لا يُساوى بسجل شامل لكل رفض من نواة Windows؛ تفاصيل حدود التدقيق مذكورة بوضوح.", new RowStyle(SizeType.Absolute, 91), new RowStyle(SizeType.Absolute, 45), new RowStyle(SizeType.Percent, 60), new RowStyle(SizeType.Percent, 40));
        var status = Label(_host.IsolationSummary + "\nالحظر التنفيذي والاعتماديات والصلاحيات مستقلة عن اقتراحات النموذج. الإضافات السحابية والمدفوعة ومجهولة الترخيص لا تُعتمد تلقائيًا.", 10, tag: "warning");
        status.Dock = DockStyle.Fill;
        status.AutoSize = false;
        layout.Controls.Add(status, 0, 1);
        var controls = Actions();
        var filter = new ComboBox
        {
            DropDownStyle = ComboBoxStyle.DropDownList,
            Width = 230
        };
        filter.Items.AddRange([new Choice("all", "كل أحداث التنفيذ والسياسات"), new Choice("blocked", "أحداث الحظر المعلّمة فقط")]);
        filter.SelectedIndex = 0;
        controls.Controls.Add(filter);
        controls.Controls.Add(Button("تحديث السجل", (_, _) => RefreshCurrent()));
        layout.Controls.Add(controls, 0, 2);
        var grid = Grid(("time", "الوقت", 20), ("kind", "النوع", 20), ("entity", "الوكيل / المهمة", 25), ("reason", "السبب", 45));
        var detail = ReadOnlyText(arabic: true);
        detail.Dock = DockStyle.Fill;
        layout.Controls.Add(grid, 0, 3);
        layout.Controls.Add(detail, 0, 4);
        grid.SelectionChanged += (_, _) =>
        {
            var item = Selected<AuditRecord>(grid);
            detail.Text = item == null ? "لا أحداث مطابقة." : $"الحدث {item.Id}\n{item.CreatedAt}\nالنوع: {item.Kind}\nالمصدر: {item.Entity}\n\n{item.Reason}";
        };
        filter.SelectedIndexChanged += (_, _) => RefreshCurrent();
        _refreshPage = () =>
        {
            var records = _core.Audit();
            if (((Choice)filter.SelectedItem!).Id == "blocked")
                records = records.Where(a => a.Kind.Contains("block", StringComparison.OrdinalIgnoreCase) || a.Kind.Contains("denied", StringComparison.OrdinalIgnoreCase) || a.Kind.Contains("reject", StringComparison.OrdinalIgnoreCase)).ToArray();
            Fill(grid, records.Take(500).Select(a => Row(a.Id.ToString(), a, LocalTime(a.CreatedAt), a.Kind, a.Entity, a.Reason)));
        };
    }

    private void BuildBackup()
    {
        var layout = Page("النسخ الاحتياطي والاستعادة", "نسخ محلية مع بصمات تحقق. الاستعادة تمر بفحص سلامة البيانات وتحتاج توقف المهام؛ لا تُرفع النسخ إلى خدمة خارجية.", new RowStyle(SizeType.Absolute, 48), new RowStyle(SizeType.Percent, 65), new RowStyle(SizeType.Percent, 35));
        var actions = Actions();
        var grid = Grid(("date", "وقت الإنشاء", 22), ("size", "الحجم بالبايت", 16), ("sha", "SHA-256", 47), ("id", "المعرف", 15));
        var detail = ReadOnlyText();
        detail.Dock = DockStyle.Fill;
        var create = Button("إنشاء نسخة احتياطية", null, "primary");
        create.Click += async (_, _) =>
        {
            create.Enabled = false;
            BeginBusy();
            Say("يجري إنشاء النسخة المحلية والتحقق منها…");
            try
            {
                var backup = await System.Threading.Tasks.Task.Run(() => _core.CreateBackup());
                RefreshCurrent();
                SelectByKey(grid, backup.Id);
                Say("أُنشئت نسخة محلية مع بصمة تحقق.");
            }
            catch (Exception ex)
            {
                Error(ex);
            }
            finally
            {
                create.Enabled = true;
                EndBusy();
            }
        };
        var restore = Button("استعادة النسخة المحددة", null);
        restore.Enabled = false;
        restore.Click += async (_, _) =>
        {
            if (Selected<BackupRecord>(grid)is not { } backup)
                return;
            var answer = MessageBox.Show(this, "ستُستعاد بيانات المركز من النسخة المحددة. أوقف المهام أولًا، وتحقق من التاريخ.\n\n" + LocalTime(backup.CreatedAt) + "\n\nهل تريد تنفيذ الاستعادة؟", "استعادة محلية", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading | MessageBoxOptions.RightAlign);
            if (answer != DialogResult.OK)
                return;
            restore.Enabled = false;
            BeginBusy();
            Say("يجري فحص النسخة واستعادة البيانات المحلية…");
            try
            {
                await System.Threading.Tasks.Task.Run(() => _core.RestoreBackup(backup.Id));
                RefreshCurrent();
                Say("اكتملت الاستعادة بعد التحقق من النسخة.");
            }
            catch (Exception ex)
            {
                Error(ex);
            }
            finally
            {
                restore.Enabled = Selected<BackupRecord>(grid) != null;
                EndBusy();
            }
        };
        actions.Controls.Add(create);
        actions.Controls.Add(restore);
        actions.Controls.Add(Button("تحديث القائمة", (_, _) => RefreshCurrent()));
        layout.Controls.Add(actions, 0, 1);
        layout.Controls.Add(grid, 0, 2);
        layout.Controls.Add(detail, 0, 3);
        grid.SelectionChanged += (_, _) =>
        {
            var backup = Selected<BackupRecord>(grid);
            restore.Enabled = backup != null;
            detail.Text = backup == null ? "لم تُنشأ نسخ احتياطية بعد." : JsonSerializer.Serialize(backup, PrettyJson);
        };
        _refreshPage = () => Fill(grid, _core.Backups().Select(b => Row(b.Id, b, LocalTime(b.CreatedAt), b.Bytes.ToString("N0"), b.Sha256, b.Id)));
    }

    private void PreviewArtifact(ArtifactRecord artifact)
    {
        Run(() =>
        {
            var dataRoot = Path.GetFullPath(_core.Dashboard().DataRoot);
            var path = Path.GetFullPath(artifact.FullPath);
            if (!path.StartsWith(dataRoot.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                throw new PolicyException("مسار المعاينة خارج بيانات المركز.");
            for (var p = new FileInfo(path) as FileSystemInfo; p != null && p.FullName.Length >= dataRoot.Length; p = p is FileInfo f ? f.Directory : ((DirectoryInfo)p).Parent)
                if ((p.Attributes & FileAttributes.ReparsePoint) != 0)
                    throw new PolicyException("رُفضت معاينة رابط أو مسار معاد توجيهه.");
            var ext = Path.GetExtension(path).ToLowerInvariant();
            if (!new[]
            {
                ".txt",
                ".json",
                ".md",
                ".csv",
                ".html",
                ".log"
            }.Contains(ext))
                throw new PolicyException("المعاينة النصية لا تدعم هذا النوع. الملف محفوظ في مجلد النتائج.");
            using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
            using var reader = new StreamReader(stream, Encoding.UTF8, true);
            var buffer = new char[65536];
            var count = reader.ReadBlock(buffer, 0, buffer.Length);
            using var dialog = Dialog("معاينة نصية آمنة — " + artifact.RelativePath, 950, 650);
            var box = ReadOnlyText();
            box.Dock = DockStyle.Fill;
            box.Text = new string (buffer, 0, count) + (reader.Peek() >= 0 ? "\n\n[توقفت المعاينة عند 65536 محرفًا؛ الملف الأصلي محفوظ كاملًا.]" : "");
            dialog.Controls.Add(box);
            _theme.Apply(dialog);
            dialog.ShowDialog(this);
        }, null);
    }

    private string? PickInboxFile()
    {
        if (!Directory.Exists(_host.InboxDirectory))
        {
            Say("صندوق الاستيراد غير متاح: " + _host.InboxDirectory, true);
            return null;
        }

        using var dialog = Dialog("اختيار ملف تعريف من صندوق الاستيراد", 760, 500);
        var panel = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 3,
            Padding = new Padding(16)
        };
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 55));
        panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));
        panel.Controls.Add(Label("انسخ مجلد الوكيل إلى صندوق الاستيراد ثم اختر agent.json أو ملف تعريف JSON آخر.\n" + _host.InboxDirectory, 9, tag: "muted"), 0, 0);
        var list = new ListBox
        {
            Dock = DockStyle.Fill,
            RightToLeft = RightToLeft.No,
            HorizontalScrollbar = true
        };
        var options = new EnumerationOptions
        {
            RecurseSubdirectories = true,
            AttributesToSkip = FileAttributes.ReparsePoint | FileAttributes.System,
            IgnoreInaccessible = true,
            MaxRecursionDepth = 8
        };
        foreach (var path in Directory.EnumerateFiles(_host.InboxDirectory, "*.json", options).Take(500))
            list.Items.Add(path);
        panel.Controls.Add(list, 0, 1);
        var pick = Button("اختيار الملف", (_, _) =>
        {
            if (list.SelectedItem != null)
            {
                dialog.DialogResult = DialogResult.OK;
                dialog.Close();
            }
        }, "primary");
        panel.Controls.Add(pick, 0, 2);
        dialog.Controls.Add(panel);
        _theme.Apply(dialog);
        return dialog.ShowDialog(this) == DialogResult.OK ? list.SelectedItem?.ToString() : null;
    }

    private void EmergencyStop()
    {
        _assistantCancellation?.Cancel();
        _localCheckCancellation?.Cancel();
        Run(() =>
        {
            _core.EmergencyStop();
            RefreshCurrent();
        }, "توقف استقبال المهام، وأُرسلت أوامر الإلغاء للعمليات المدارة التابعة للمركز فقط.");
    }

    private void RefreshCurrent()
    {
        if (_updating || _busyOperations > 0 || IsDisposed || Disposing)
            return;
        _updating = true;
        try
        {
            using var process = Process.GetCurrentProcess();
            var now = DateTime.UtcNow;
            var total = process.TotalProcessorTime.TotalSeconds;
            var seconds = (now - _lastCpuTime).TotalSeconds;
            if (seconds >= .5)
                _cpuPercent = Math.Clamp((total - _lastCpuSeconds) / seconds / Environment.ProcessorCount * 100, 0, 100);
            _lastCpuTime = now;
            _lastCpuSeconds = total;
            _refreshPage?.Invoke();
        }
        catch (Exception ex)
        {
            Error(ex);
        }
        finally
        {
            _updating = false;
        }
    }

    private void BeginBusy()
    {
        _busyOperations++;
        _refreshTimer.Stop();
        _navigation.Enabled = false;
        _content.Enabled = false;
    }

    private void EndBusy()
    {
        _busyOperations = Math.Max(0, _busyOperations - 1);
        if (_busyOperations == 0 && !IsDisposed && !Disposing)
        {
            _navigation.Enabled = true;
            _content.Enabled = true;
            _refreshTimer.Start();
            RefreshCurrent();
        }
    }

    private void Run(Action action, string? success)
    {
        try
        {
            action();
            if (success != null)
                Say(success);
        }
        catch (Exception ex)
        {
            Error(ex);
        }
    }

    private void Error(Exception error) => Say(FriendlyError(error), true);
    private static string FriendlyError(Exception error) => error is UnauthorizedAccessException ? "رفض Windows الوصول إلى الملف أو المورد المطلوب. بقيت الصلاحيات دون تغيير." : error is IOException ? "تعذر الوصول إلى مورد محلي: " + error.Message : error.Message;
    private void Say(string text, bool error = false)
    {
        _notice.Text = text.Replace('\r', ' ').Replace('\n', ' ');
        _notice.Tag = error ? "danger" : "muted";
        _notice.ForeColor = error ? _theme.Danger : _theme.Muted;
        _tips.SetToolTip(_notice, text);
    }

    private bool ReadTheme()
    {
        try
        {
            var path = Path.Combine(_core.Dashboard().DataRoot, "ui-theme.json");
            return !File.Exists(path) || JsonSerializer.Deserialize<bool>(File.ReadAllText(path));
        }
        catch
        {
            return true;
        }
    }

    private void SaveTheme()
    {
        try
        {
            File.WriteAllText(Path.Combine(_core.Dashboard().DataRoot, "ui-theme.json"), JsonSerializer.Serialize(_theme.Dark));
        }
        catch (Exception ex)
        {
            Say("تغير المظهر لهذه الجلسة؛ تعذر حفظ التفضيل: " + FriendlyError(ex), true);
        }
    }

    private static string LocalTime(string value) => DateTimeOffset.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var date) ? date.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) : value;
    private static string TaskStatus(string status) => status switch
    {
        "queued" => "بالانتظار",
        "running" => "قيد التنفيذ",
        "succeeded" => "نجحت",
        "completed" => "اكتملت",
        "failed" => "فشلت",
        "cancelled" or "canceled" => "أُلغيت",
        "blocked" => "محظورة",
        "interrupted" => "توقفت دون حسم",
        "waiting" => "تنتظر اعتماديات",
        "uncertain" or "needs_review" => "تحتاج مراجعة الأثر",
        "timed_out" => "انتهت المهلة",
        "cancelling" => "يجري الإلغاء",
        _ => status
    };
    private static WrappingStack Stack() => new()
    {
        Dock = DockStyle.Fill,
        AutoSize = true,
        AutoSizeMode = AutoSizeMode.GrowAndShrink,
        Margin = Padding.Empty
    };
    private static FlowLayoutPanel Actions() => new()
    {
        Dock = DockStyle.Fill,
        FlowDirection = FlowDirection.LeftToRight,
        WrapContents = true,
        AutoSize = true,
        AutoSizeMode = AutoSizeMode.GrowAndShrink,
        AutoScroll = false,
        Padding = new Padding(0, 4, 0, 3),
        Margin = Padding.Empty
    };
    private static Label Label(string text, float size = 10, FontStyle style = FontStyle.Regular, string? tag = null) => new()
    {
        Text = text,
        AutoSize = true,
        Font = new Font("Segoe UI", size, style),
        Margin = new Padding(0, 1, 0, 4),
        Tag = tag,
        TextAlign = ContentAlignment.MiddleRight,
        UseMnemonic = false
    };
    private static Button Button(string text, EventHandler? click, string? tag = null)
    {
        var b = new Button
        {
            Text = text,
            AutoSize = true,
            MinimumSize = new Size(114, 35),
            Height = 36,
            Padding = new Padding(12, 3, 12, 3),
            Margin = new Padding(0, 0, 7, 0),
            Tag = tag,
            AccessibleName = text,
            UseMnemonic = false
        };
        if (click != null)
            b.Click += click;
        return b;
    }

    private static TextBox Input(bool multiline = false, bool ltr = false) => new()
    {
        Multiline = multiline,
        AcceptsReturn = multiline,
        ScrollBars = multiline ? ScrollBars.Vertical : ScrollBars.None,
        RightToLeft = ltr ? RightToLeft.No : RightToLeft.Yes,
        BorderStyle = BorderStyle.FixedSingle,
        Margin = new Padding(0, 3, 7, 6),
        Font = new Font("Segoe UI", 10),
        MaxLength = multiline ? 1000000 : 8192
    };
    private static RichTextBox ReadOnlyText(bool arabic = false) => new()
    {
        ReadOnly = true,
        DetectUrls = false,
        BorderStyle = BorderStyle.FixedSingle,
        WordWrap = arabic,
        RightToLeft = arabic ? RightToLeft.Yes : RightToLeft.No,
        Font = new Font(arabic ? "Segoe UI" : "Consolas", 10),
        Margin = new Padding(0, 5, 0, 5),
        ScrollBars = RichTextBoxScrollBars.Both,
        AccessibleName = "تفاصيل محلية للقراءة"
    };
    private Form Dialog(string title, int width, int height) => new()
    {
        Text = title,
        Font = Font,
        Size = new Size(width, height),
        MinimumSize = new Size(Math.Min(650, width), Math.Min(420, height)),
        StartPosition = FormStartPosition.CenterParent,
        RightToLeft = RightToLeft.Yes,
        RightToLeftLayout = true,
        MinimizeBox = false,
        ShowInTaskbar = false,
        AutoScaleDimensions = new SizeF(96F, 96F),
        AutoScaleMode = AutoScaleMode.Dpi
    };
    private int Metric(int pixels) => (int)Math.Round(pixels * DeviceDpi / 96d);
    private static string Ltr(string value) => "\u202A" + value + "\u202C";
    private static DataGridView Grid(params (string id, string label, float weight)[] columns)
    {
        var grid = new DataGridView
        {
            Dock = DockStyle.Fill,
            AutoGenerateColumns = false,
            AllowUserToAddRows = false,
            AllowUserToDeleteRows = false,
            AllowUserToResizeRows = false,
            ReadOnly = true,
            MultiSelect = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            RowHeadersVisible = false,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            ColumnHeadersHeight = 38,
            ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
            RightToLeft = RightToLeft.Yes,
            Margin = new Padding(0, 5, 0, 5),
            ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText
        };
        grid.RowTemplate.Height = 37;
        foreach (var(id, label, weight)in columns)
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = id, HeaderText = label, FillWeight = weight, MinimumWidth = id == "sha" ? 120 : 65, SortMode = DataGridViewColumnSortMode.NotSortable });
        return grid;
    }

    private sealed record GridRow(string Key, object Value, object? [] Cells);
    private static GridRow Row(string key, object value, params object? [] cells) => new(key, value, cells);
    private static T? Selected<T>(DataGridView grid)
        where T : class => grid.SelectedRows.Count == 0 ? null : (grid.SelectedRows[0].Tag as GridRow)?.Value as T;
    private static void Fill(DataGridView grid, IEnumerable<GridRow> sequence)
    {
        var rows = sequence.ToArray();
        var priorKey = grid.SelectedRows.Count > 0 ? (grid.SelectedRows[0].Tag as GridRow)?.Key : null;
        bool same = grid.Rows.Count == rows.Length;
        if (same)
            for (int i = 0; i < rows.Length; i++)
                if (grid.Rows[i].Tag is not GridRow old || old.Key != rows[i].Key || !old.Cells.SequenceEqual(rows[i].Cells))
                {
                    same = false;
                    break;
                }

        if (same)
        {
            for (int i = 0; i < rows.Length; i++)
                grid.Rows[i].Tag = rows[i];
            return;
        }

        grid.SuspendLayout();
        grid.Rows.Clear();
        foreach (var row in rows)
        {
            var i = grid.Rows.Add(row.Cells.Select(value => value ?? "").ToArray());
            grid.Rows[i].Tag = row;
        }

        grid.ClearSelection();
        if (priorKey != null && rows.Any(r => r.Key == priorKey))
            SelectByKey(grid, priorKey);
        else if (grid.Rows.Count > 0)
        {
            grid.Rows[0].Selected = true;
            grid.CurrentCell = grid.Rows[0].Cells[0];
        }

        grid.ResumeLayout();
    }

    private static void SelectByKey(DataGridView grid, string key)
    {
        foreach (DataGridViewRow row in grid.Rows)
            if (row.Tag is GridRow value && value.Key == key)
            {
                row.Selected = true;
                grid.CurrentCell = row.Cells[0];
                return;
            }
    }

    private sealed record Choice(string Id, string Title)
    {
        public override string ToString() => Title;
    }

    private sealed record KnowledgeVersion(int Version, string Date)
    {
        public override string ToString() => $"الإصدار {Version} • {Date}";
    }
}
