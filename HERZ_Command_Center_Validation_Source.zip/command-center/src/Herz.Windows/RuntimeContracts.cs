using System.Text.Json;
using System.Text.Json.Nodes;
using Herz.Core;

namespace Herz.Windows;
internal static class Wire
{
    internal static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web)
    {
        WriteIndented = false,
        PropertyNameCaseInsensitive = true
    };
    internal static string Encode<T>(T value) => JsonSerializer.Serialize(value, Json);
    internal static T Decode<T>(string value) => JsonSerializer.Deserialize<T>(value, Json) ?? throw new InvalidDataException("Invalid local message.");
    internal static void WriteJson<T>(string path, T value)
    {
        var temporary = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
        {
            JsonSerializer.Serialize(stream, value, Json);
            stream.Flush(true);
        }

        File.Move(temporary, path, true);
    }
}

internal sealed record BaselineResult(bool Ipv4Connected, bool Ipv6Connected, bool DnsResolved, string TimeUtc, string Note, string SessionId = "");
internal sealed record RuntimeProof(TokenVerificationInfo Token, IReadOnlyList<SandboxProbeResult> Checks, bool Passed, string Reason);
internal sealed record WorkerHello(string Type, string AgentId, int Pid, RuntimeProof Proof, string? ReadinessError = null);
internal sealed record WorkerLink(string AgentId, string ProfileName, string Sid, string Slot, long InputHandle, long OutputHandle, long ErrorHandle, long JobHandle, uint Pid, WorkerHello Hello);
internal sealed record LocalModelSelection(string Id, string Name, string File, string Sha256, long Bytes, string License, bool Approved, string PromptTemplate, string SystemPrompt, string Reason, int MaxOutputTokens = 192, string SourceUrl = "", string LicenseUrl = "", double Temperature = 0, double TopP = 1, int TopK = 0, double PresencePenalty = 0, int RequiredFreeMemoryMiB = 3072, int JobMemoryMiB = 2304);
internal sealed record LocalModelAvailability(LocalModelSelection Selection, bool Verified, string Reason);
internal sealed record RuntimeSession(string Root, string Release, string ManagerProfile, string ManagerSid, string ManagerData, string Inbox, string Canary, string PolicyCanary, BaselineResult Baseline, NetworkControl NetworkControl, List<WorkerLink> Workers, long LeaseHandle, string CreatedAt, LocalModelAvailability Model);
internal sealed record WorkerRequest(string Operation, string Id, TaskContext? Context = null, string? Prompt = null);
internal sealed record WorkerReply(string Id, bool Ok, AgentExecution? Execution = null, string? Text = null, string? Error = null, bool Canceled = false);
internal static class LocalPaths
{
    internal static string InDirectory(string directory, string relative)
    {
        if (string.IsNullOrWhiteSpace(relative) || Path.IsPathFullyQualified(relative) || relative.Contains(':') || relative.Contains('\0'))
            throw new InvalidDataException("An output path is invalid.");
        var parts = relative.Replace('\\', '/').Split('/');
        foreach (var part in parts)
        {
            if (part is "" or "." or ".." || part.EndsWith(' ') || part.EndsWith('.'))
                throw new InvalidDataException("An output path is invalid.");
            string stem = part.Split('.')[0].ToUpperInvariant();
            if (new[]
            {
                "CON",
                "PRN",
                "AUX",
                "NUL",
                "CONIN$",
                "CONOUT$"
            }.Contains(stem) || System.Text.RegularExpressions.Regex.IsMatch(stem, "^(COM|LPT)[0-9]$"))
                throw new InvalidDataException("Reserved Windows name.");
        }

        string full = Path.GetFullPath(Path.Combine(directory, Path.Combine(parts)));
        string root = Path.GetFullPath(directory).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        if (!full.StartsWith(root, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Path escaped the task directory.");
        for (var cursor = full; !string.IsNullOrEmpty(cursor) && cursor.Length >= root.Length - 1; cursor = Path.GetDirectoryName(cursor)!)
            if ((File.Exists(cursor) || Directory.Exists(cursor)) && (File.GetAttributes(cursor) & FileAttributes.ReparsePoint) != 0)
                throw new InvalidDataException("Links and junctions are not permitted.");
        return full;
    }

    internal static string HashFile(string path)
    {
        using var stream = File.OpenRead(path);
        return Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(stream)).ToLowerInvariant();
    }
}
