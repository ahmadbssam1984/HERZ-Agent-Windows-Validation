using Microsoft.Data.Sqlite;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;

namespace Herz.Core;
internal static class Data
{
    internal static readonly JsonSerializerOptions Json = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true,
        WriteIndented = false,
        MaxDepth = 32
    };
    internal static string Encode<T>(T value) => JsonSerializer.Serialize(value, Json);
    internal static T Decode<T>(string value) => JsonSerializer.Deserialize<T>(value, Json) ?? throw new PolicyException("بيانات محلية غير صالحة");
    internal static string Now() => DateTimeOffset.UtcNow.ToString("O");
    internal static string Id() => Guid.NewGuid().ToString("N");
    internal static string HashText(string text) => Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(text)));
    internal static string HashFile(string path)
    {
        using var f = File.OpenRead(path);
        return Convert.ToHexStringLower(SHA256.HashData(f));
    }

    internal static string Canonical(JsonNode? node) => node switch
    {
        JsonObject o => "{" + string.Join(",", o.OrderBy(p => p.Key, StringComparer.Ordinal).Select(p => Encode(p.Key) + ":" + Canonical(p.Value))) + "}",
        JsonArray a => "[" + string.Join(",", a.Select(Canonical)) + "]",
        _ => node?.ToJsonString(Json) ?? "null"
    };
    internal static string Redact(string value)
    {
        var clean = Regex.Replace(value, @"(?i)(api[_-]?key|token|password|secret|authorization)\s*[:=]\s*[^\s,;]+", "$1=[redacted]");
        return clean[..Math.Min(2000, clean.Length)];
    }

    internal static void AtomicText(string path, string text)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        var temp = path + "." + Id() + ".tmp";
        try
        {
            using (var f = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                var b = Encoding.UTF8.GetBytes(text);
                f.Write(b);
                f.Flush(true);
            }

            File.Move(temp, path, true);
        }
        finally
        {
            if (File.Exists(temp))
                File.Delete(temp);
        }
    }

    internal static string SafePath(string root, string relative, bool requireFile = false)
    {
        if (string.IsNullOrWhiteSpace(relative) || relative.Length > 240 || relative.Any(c => char.IsControl(c) || "<>|?*\":".Contains(c)) || relative.StartsWith('/') || relative.StartsWith('\\'))
            throw new PolicyException("مسار ملف غير مسموح");
        var parts = relative.Replace('\\', '/').Split('/');
        foreach (var part in parts)
            if (string.IsNullOrEmpty(part) || part is "." or ".." || part.EndsWith(' ') || part.EndsWith('.') || Regex.IsMatch(part.Split('.')[0], @"^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$", RegexOptions.IgnoreCase))
                throw new PolicyException("اسم ملف غير مسموح على Windows");
        root = Path.GetFullPath(root);
        var path = Path.GetFullPath(Path.Combine([root, ..parts]));
        var comparison = OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;
        if (!path.StartsWith(root.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar, comparison))
            throw new PolicyException("الملف خارج المساحة المصرح بها");
        NoLinks(root);
        string walk = root;
        foreach (var part in parts)
        {
            walk = Path.Combine(walk, part);
            NoLinks(walk);
        }

        if (requireFile && !File.Exists(path))
            throw new PolicyException("ملف ناتج مطلوب مفقود");
        return path;
    }

    internal static void NoLinks(string path)
    {
        if ((File.Exists(path) || Directory.Exists(path)) && (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0)
            throw new PolicyException("الروابط ومسارات إعادة التوجيه غير مسموحة");
    }
}

internal sealed class Store : IDisposable
{
    internal SqliteConnection Connection { get; private set; }

    private SqliteTransaction? transaction;
    internal Store(string path)
    {
        Connection = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = path, Mode = SqliteOpenMode.ReadWriteCreate, Pooling = false }.ToString());
        Connection.Open();
        Execute("PRAGMA journal_mode=WAL");
        Execute("PRAGMA synchronous=FULL");
        Execute("PRAGMA foreign_keys=ON");
        Execute("PRAGMA busy_timeout=5000");
        Execute("""
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS agents(id TEXT PRIMARY KEY,definition TEXT NOT NULL,enabled INTEGER NOT NULL DEFAULT 0,created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS tasks(id TEXT PRIMARY KEY,agent TEXT NOT NULL,title TEXT NOT NULL,status TEXT NOT NULL,priority INTEGER NOT NULL,input TEXT NOT NULL,dependencies TEXT NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,idempotency TEXT UNIQUE NOT NULL,digest TEXT NOT NULL,agent_digest TEXT NOT NULL,locks TEXT NOT NULL,depth INTEGER NOT NULL,created TEXT NOT NULL,updated TEXT NOT NULL,error TEXT,result TEXT,artifacts TEXT NOT NULL DEFAULT '[]');
CREATE INDEX IF NOT EXISTS task_queue ON tasks(status,priority DESC,created);
CREATE TABLE IF NOT EXISTS locks(name TEXT PRIMARY KEY,task TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS plans(id TEXT PRIMARY KEY,body TEXT NOT NULL,submitted INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY,task TEXT NOT NULL,sender TEXT NOT NULL,receiver TEXT NOT NULL,status TEXT NOT NULL,body TEXT NOT NULL,created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,entity TEXT NOT NULL,reason TEXT NOT NULL,created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS knowledge(id TEXT PRIMARY KEY,kind TEXT NOT NULL,scope TEXT NOT NULL,current INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS knowledge_versions(id TEXT NOT NULL,version INTEGER NOT NULL,title TEXT NOT NULL,content TEXT NOT NULL,approved INTEGER NOT NULL,source TEXT NOT NULL,created TEXT NOT NULL,PRIMARY KEY(id,version));
CREATE VIRTUAL TABLE IF NOT EXISTS knowledge_fts USING fts5(id UNINDEXED,title,content,tokenize='unicode61');
CREATE TABLE IF NOT EXISTS models(id TEXT PRIMARY KEY,body TEXT NOT NULL);
""");
    }

    private SqliteCommand Command(string sql, object? [] args)
    {
        var c = Connection.CreateCommand();
        c.CommandText = sql;
        c.Transaction = transaction;
        for (int i = 0; i < args.Length; i++)
            c.Parameters.AddWithValue("@p" + i, args[i] ?? DBNull.Value);
        return c;
    }

    internal int Execute(string sql, params object? [] args)
    {
        using var c = Command(sql, args);
        return c.ExecuteNonQuery();
    }

    internal object? Scalar(string sql, params object? [] args)
    {
        using var c = Command(sql, args);
        return c.ExecuteScalar();
    }

    internal List<Dictionary<string, object?>> Rows(string sql, params object? [] args)
    {
        using var c = Command(sql, args);
        using var r = c.ExecuteReader();
        var rows = new List<Dictionary<string, object?>>();
        while (r.Read())
        {
            var row = new Dictionary<string, object?>();
            for (int i = 0; i < r.FieldCount; i++)
                row[r.GetName(i)] = r.IsDBNull(i) ? null : r.GetValue(i);
            rows.Add(row);
        }

        return rows;
    }

    internal void Atomic(Action action)
    {
        if (transaction != null)
        {
            action();
            return;
        }

        using var t = Connection.BeginTransaction();
        transaction = t;
        try
        {
            action();
            t.Commit();
        }
        catch
        {
            t.Rollback();
            throw;
        }
        finally
        {
            transaction = null;
        }
    }

    internal string Setting(string key, string fallback = "") => Scalar("SELECT value FROM settings WHERE key=@p0", key)?.ToString() ?? fallback;
    internal void Set(string key, string value) => Execute("INSERT INTO settings VALUES(@p0,@p1) ON CONFLICT(key) DO UPDATE SET value=excluded.value", key, value);
    internal void Event(string kind, string entity, string reason) => Execute("INSERT INTO audit(kind,entity,reason,created) VALUES(@p0,@p1,@p2,@p3)", kind, entity, Data.Redact(reason), Data.Now());
    public void Dispose()
    {
        transaction?.Dispose();
        Connection.Dispose();
    }
}
