using System.Globalization;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;

namespace Herz.Core;
public sealed partial class CommandCenter
{
    public KnowledgeRecord SaveKnowledge(KnowledgeInput input)
    {
        lock (gate)
        {
            if (input.Kind is not ("instruction" or "reference" or "correction") || !input.Approved)
                throw new PolicyException("النوع غير صالح أو لم يعتمد المالك المحتوى");
            if (input.Scope != "shared")
                _ = Definition(input.Scope);
            var title = input.Title.Trim();
            var content = input.Content.Trim();
            if (title.Length is < 1 or > 160 || content.Length is < 1 or > 100000)
                throw new PolicyException("عنوان أو محتوى معرفة غير صالح");
            var id = input.Id ?? Data.Id();
            if (!Regex.IsMatch(id, "^[A-Za-z0-9_-]{1,64}$"))
                throw new PolicyException("معرف غير صالح");
            var previous = db.Rows("SELECT * FROM knowledge WHERE id=@p0", id).SingleOrDefault();
            if (previous != null && (Text(previous, "kind") != input.Kind || Text(previous, "scope") != input.Scope))
                throw new PolicyException("لا يمكن تغيير نوع أو نطاق سجل قائم");
            var version = Convert.ToInt32(db.Scalar("SELECT COALESCE(MAX(version),0)+1 FROM knowledge_versions WHERE id=@p0", id), CultureInfo.InvariantCulture);
            db.Atomic(() =>
            {
                db.Execute("INSERT INTO knowledge_versions VALUES(@p0,@p1,@p2,@p3,1,'owner_ui',@p4)", id, version, title, content, Data.Now());
                db.Execute("INSERT INTO knowledge VALUES(@p0,@p1,@p2,@p3) ON CONFLICT(id) DO UPDATE SET current=excluded.current", id, input.Kind, input.Scope, version);
                IndexKnowledge(id, title, content);
            });
            db.Event("knowledge_saved", id, input.Kind + " version " + version);
            return Knowledge().Single(k => k.Id == id);
        }
    }

    private void IndexKnowledge(string id, string title, string content)
    {
        db.Execute("DELETE FROM knowledge_fts WHERE id=@p0", id);
        db.Execute("INSERT INTO knowledge_fts(id,title,content) VALUES(@p0,@p1,@p2)", id, title, content);
    }

    private static KnowledgeRecord ToKnowledge(Dictionary<string, object?> r) => new(Text(r, "id"), Text(r, "kind"), Text(r, "scope"), Text(r, "title"), Convert.ToInt32(r["version"], CultureInfo.InvariantCulture), Text(r, "content"), Convert.ToInt64(r["approved"], CultureInfo.InvariantCulture) == 1, Text(r, "source"), Text(r, "created"));
    public IReadOnlyList<KnowledgeRecord> Knowledge(string? scope = null)
    {
        lock (gate)
        {
            var rows = db.Rows("SELECT k.id,k.kind,k.scope,v.* FROM knowledge k JOIN knowledge_versions v ON k.id=v.id AND k.current=v.version ORDER BY v.created DESC");
            return rows.Select(ToKnowledge).Where(k => scope == null || k.Scope == "shared" || k.Scope == scope).ToArray();
        }
    }

    public IReadOnlyList<KnowledgeRecord> KnowledgeHistory(string id)
    {
        lock (gate)
            return db.Rows("SELECT k.kind,k.scope,v.* FROM knowledge k JOIN knowledge_versions v ON k.id=v.id WHERE k.id=@p0 ORDER BY v.version DESC", id).Select(ToKnowledge).ToArray();
    }

    public KnowledgeRecord RollbackKnowledge(string id, int version)
    {
        lock (gate)
        {
            var item = KnowledgeHistory(id).SingleOrDefault(v => v.Version == version) ?? throw new PolicyException("إصدار المعرفة غير موجود");
            db.Atomic(() =>
            {
                db.Execute("UPDATE knowledge SET current=@p1 WHERE id=@p0", id, version);
                IndexKnowledge(id, item.Title, item.Content);
            });
            db.Event("knowledge_rollback", id, "version " + version);
            return item;
        }
    }

    public IReadOnlyList<KnowledgeHit> SearchKnowledge(string query, string scope = "shared")
    {
        lock (gate)
        {
            if (scope != "shared")
                _ = Definition(scope);
            var tokens = Regex.Matches(query, @"[\p{L}\p{N}_]+").Select(m => m.Value).Distinct().Take(20).ToArray();
            if (tokens.Length == 0)
                return[];
            var expression = string.Join(" OR ", tokens.Select(t => "\"" + t.Replace("\"", "\"\"") + "\""));
            var rows = db.Rows("SELECT k.id,k.kind,k.scope,v.*,bm25(knowledge_fts) AS rank FROM knowledge_fts JOIN knowledge k ON k.id=knowledge_fts.id JOIN knowledge_versions v ON v.id=k.id AND v.version=k.current WHERE knowledge_fts MATCH @p0 AND (k.scope='shared' OR k.scope=@p1) AND v.approved=1 ORDER BY rank LIMIT 20", expression, scope);
            return rows.Select(r =>
            {
                var item = ToKnowledge(r);
                var index = tokens.Select(t => item.Content.IndexOf(t, StringComparison.OrdinalIgnoreCase)).Where(i => i >= 0).DefaultIfEmpty(0).Min();
                var start = Math.Max(0, index - 40);
                return new KnowledgeHit(item, -Convert.ToDouble(r["rank"], CultureInfo.InvariantCulture), item.Content.Substring(start, Math.Min(280, item.Content.Length - start)));
            }).ToArray();
        }
    }

    public PlanRecord PreviewPlan(string arabicRequest)
    {
        lock (gate)
        {
            if (arabicRequest.Length is < 1 or > 4000)
                throw new PolicyException("اكتب طلبًا بين 1 و4000 حرف");
            if (!Regex.IsMatch(arabicRequest, @"حلل|تحليل|أرقام|ارقام|متوسط|مجموع|تقرير"))
                throw new PolicyException("المسار الحالي يحلل الأرقام ثم ينتج تقريرًا فقط؛ الطلب العام يحتاج نموذجًا محليًا مُقيّمًا");
            var translated = new string (arabicRequest.Select(c => c >= '٠' && c <= '٩' ? (char)('0' + c - '٠') : c >= '۰' && c <= '۹' ? (char)('0' + c - '۰') : c == '٫' ? '.' : c).ToArray());
            var numbers = Regex.Matches(translated, @"(?<![\p{L}\d])[-+]?\d+(?:\.\d+)?").Select(m => decimal.Parse(m.Value, CultureInfo.InvariantCulture)).ToArray();
            if (numbers.Length is < 1 or > 200 || numbers.Any(n => Math.Abs(n) > 1000000000m))
                throw new PolicyException("أدخل 1–200 عدد، ضمن مليار بالقيمة المطلقة");
            var agents = Agents();
            var stats = agents.FirstOrDefault(a => a.Definition.Capabilities.Contains("numeric_analysis"));
            var report = agents.FirstOrDefault(a => a.Definition.Capabilities.Contains("html_reporting"));
            if (stats == null || report == null)
                throw new PolicyException("يلزم تسجيل وكيل تحليل الأرقام ووكيل التقرير أولًا");
            var plan = new PlanRecord(Data.Id(), arabicRequest, "deterministic_rules_not_llm", [new(stats.Definition.Id, "تحليل الأرقام", new JsonObject { ["numbers"] = new JsonArray(numbers.Select(n => (JsonNode? )JsonValue.Create(n)).ToArray()), ["title"] = "تحليل محلي" }, []), new(report.Definition.Id, "إنشاء تقرير عربي من النتيجة المتحققة", new JsonObject { ["title"] = "تقرير HERZ المحلي" }, [0])], false, Data.Now());
            db.Execute("INSERT INTO plans VALUES(@p0,@p1,0)", plan.Id, Data.Encode(plan));
            return plan;
        }
    }

    public IReadOnlyList<TaskRecord> SubmitPlan(string planId)
    {
        lock (gate)
        {
            var row = db.Rows("SELECT * FROM plans WHERE id=@p0", planId).SingleOrDefault() ?? throw new PolicyException("الخطة غير موجودة");
            var plan = Data.Decode<PlanRecord>(Text(row, "body"));
            var output = new List<TaskRecord>();
            db.Atomic(() =>
            {
                foreach (var step in plan.Steps)
                {
                    var dependencies = step.DependsOn.Select(i => i >= 0 && i < output.Count ? output[i].Id : throw new PolicyException("اعتمادية خطة غير صالحة")).ToArray();
                    output.Add(Submit(new(step.AgentId, step.Input, step.Title, IdempotencyKey: plan.Id + ":" + output.Count, Dependencies: dependencies)));
                }

                db.Execute("UPDATE plans SET submitted=1 WHERE id=@p0", planId);
            });
            return output;
        }
    }

    public ModelState RegisterModel(ModelConfiguration model)
    {
        lock (gate)
        {
            if (!Regex.IsMatch(model.Id, "^[a-z][a-z0-9_-]{2,63}$") || model.License != "Apache-2.0" || model.ContextSize is < 256 or > 4096 || model.Threads is < 1 or > 4 || model.MaxOutputTokens is < 32 or > 1024)
                throw new PolicyException("تعريف أو موارد أو ترخيص نموذج غير معتمد");
            foreach (var path in new[]
            {
                model.ModelPath,
                model.RunnerPath,
                model.LicensePath
            }

            )
            {
                Data.NoLinks(path);
                if (!File.Exists(path))
                    throw new PolicyException("ملف النموذج أو محركه أو ترخيصه غير موجود");
            }

            if (!Regex.IsMatch(model.Sha256, "^[a-f0-9]{64}$") || Data.HashFile(model.ModelPath) != model.Sha256 || !File.ReadAllText(model.LicensePath).Contains("Apache License", StringComparison.Ordinal))
                throw new PolicyException("تعذر توثيق بصمة النموذج أو ترخيصه");
            db.Execute("INSERT INTO models VALUES(@p0,@p1) ON CONFLICT(id) DO UPDATE SET body=excluded.body", model.Id, Data.Encode(model));
            db.Event("model_registered", model.Id, "سُجلت الملفات فقط؛ التفعيل يحتاج قياس العربية والأدوات والعزل");
            return Model(model);
        }
    }

    private static ModelState Model(ModelConfiguration model) => new(model, false, "ملفات محلية مسجلة؛ لا تفعيل تلقائي قبل تقييم الاستدلال والعزل. لا تحويل سحابي.");
    public IReadOnlyList<ModelState> Models()
    {
        lock (gate)
            return db.Rows("SELECT body FROM models ORDER BY id").Select(r => Model(Data.Decode<ModelConfiguration>(Text(r, "body")))).ToArray();
    }
}
