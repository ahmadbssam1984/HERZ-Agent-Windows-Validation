using System.Text.Json.Nodes;

namespace Herz.Core;
public sealed record IsolationStatus(bool Supported, string Backend, string Reason, bool WindowsRuntimeVerified = false);
public sealed record AgentReadiness(bool Ready, string Reason);
public sealed record PolicyCheck(string Name, bool Passed, string Reason);
public sealed record AgentDefinition
{
    public string Id { get; init; } = "";
    public string Name { get; init; } = "";
    public string Version { get; init; } = "1.0.0";
    public string Description { get; init; } = "";
    public string[] Capabilities { get; init; } = [];
    public string Runtime { get; init; } = "";
    public string Connector { get; init; } = "cli_json";
    public string Entry { get; init; } = "";
    public string SourceRoot { get; init; } = "";
    public string ManifestPath { get; init; } = "";
    public string LicenseSpdx { get; init; } = "";
    public string LicenseText { get; init; } = "";
    public string LicenseSource { get; init; } = "";
    public string Cost { get; init; } = "free";
    public bool Cloud { get; init; }
    public string Network { get; init; } = "deny";
    public bool Idempotent { get; init; }
    public int MaxAttempts { get; init; } = 1;
    public int MemoryMb { get; init; } = 512;
    public int CpuSeconds { get; init; } = 30;
    public int WallSeconds { get; init; } = 90;
    public int MaxProcesses { get; init; } = 8;
    public string[] Controls { get; init; } = ["start", "stop", "cancel", "restart"];
    public JsonObject InputSchema { get; init; } = new();
    public JsonObject OutputSchema { get; init; } = new();
    public Dictionary<string, string> FileHashes { get; init; } = new(StringComparer.Ordinal);
    public string ApprovalDigest { get; init; } = "";
}

public sealed record AgentInspection(bool Allowed, AgentDefinition? Definition, AgentReadiness Readiness, string ApprovalDigest, string Reason, IReadOnlyList<PolicyCheck> Checks);
public sealed record AgentRecord(AgentDefinition Definition, bool Enabled, AgentReadiness Readiness, string CreatedAt);
public sealed record ArtifactRecord(string RelativePath, string FullPath, string Sha256, long Bytes, string SourceTaskId);
public sealed record TaskContext(string TaskId, JsonObject Input, string Workspace, IReadOnlyList<ArtifactRecord> Inputs, IReadOnlyList<KnowledgeRecord> Knowledge);
public sealed record AgentExecution(int ExitCode, JsonObject Result, IReadOnlyList<string> Artifacts, string StandardError = "");
public interface IAgentRunner
{
    IsolationStatus Probe();
    AgentReadiness Check(AgentDefinition agent);
    Task<AgentExecution> ExecuteAsync(AgentDefinition agent, TaskContext context, CancellationToken cancellationToken);
    void StopAll();
}

public sealed class UnavailableAgentRunner(string reason) : IAgentRunner
{
    public IsolationStatus Probe() => new(false, "unavailable", reason);
    public AgentReadiness Check(AgentDefinition agent) => new(false, reason);
    public Task<AgentExecution> ExecuteAsync(AgentDefinition agent, TaskContext context, CancellationToken cancellationToken) => throw new PolicyException(reason);
    public void StopAll()
    {
    }
}

public sealed class PolicyException(string message) : InvalidOperationException(message);
public sealed record TaskSubmission(string AgentId, JsonObject Input, string Title = "مهمة محلية", int Priority = 0, string? IdempotencyKey = null, string[]? Dependencies = null, string[]? LockNames = null, int DelegationDepth = 0);
public sealed record TaskRecord(string Id, string Title, string AgentId, string Status, int Priority, JsonObject Input, string[] Dependencies, int Attempts, string CreatedAt, string UpdatedAt, string? Error, JsonObject? Result, IReadOnlyList<ArtifactRecord> Artifacts, string IdempotencyKey);
public sealed record MessageRecord(string Id, string TaskId, string Sender, string Receiver, string Status, string Body, string CreatedAt);
public sealed record AuditRecord(long Id, string Kind, string Entity, string Reason, string CreatedAt);
public sealed record KnowledgeRecord(string Id, string Kind, string Scope, string Title, int Version, string Content, bool Approved, string Source, string CreatedAt);
public sealed record KnowledgeInput(string Kind, string Scope, string Title, string Content, bool Approved, string? Id = null);
public sealed record KnowledgeHit(KnowledgeRecord Item, double Score, string Snippet);
public sealed record BackupRecord(string Id, string Path, string Sha256, long Bytes, string CreatedAt);
public sealed record ModelConfiguration(string Id, string Name, string RunnerPath, string ModelPath, string Sha256, string License, string LicensePath, int ContextSize = 2048, int Threads = 4, int MaxOutputTokens = 512);
public sealed record ModelState(ModelConfiguration Configuration, bool Enabled, string Reason);
public sealed record PlanStep(string AgentId, string Title, JsonObject Input, int[] DependsOn);
public sealed record PlanRecord(string Id, string Request, string Source, IReadOnlyList<PlanStep> Steps, bool Submitted, string CreatedAt);
public sealed record DashboardSnapshot(bool Paused, IsolationStatus Isolation, int Agents, int ReadyAgents, int Queued, int Running, int Succeeded, int Errors, long WorkingSetBytes, double ProcessCpuSeconds, string DataRoot, string Notice);
