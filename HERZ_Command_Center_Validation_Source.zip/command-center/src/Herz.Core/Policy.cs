using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Text.Json;

namespace Herz.Core;
internal static class Policy
{
    private static readonly Dictionary<string, string[]> Licenses = new(StringComparer.Ordinal)
    {
        ["MIT"] = ["Permission is hereby granted", "WITHOUT WARRANTY"],
        ["Apache-2.0"] = ["Apache License", "Version 2.0"],
        ["BSD-3-Clause"] = ["Redistribution and use", "contributors"],
        ["BSD-2-Clause"] = ["Redistribution and use", "DISCLAIMER"],
        ["ISC"] = ["Permission to use", "DISCLAIMS ALL WARRANTIES"],
        ["CC0-1.0"] = ["CC0"]
    };
    internal static AgentDefinition Inspect(string manifestPath)
    {
        if (Directory.Exists(manifestPath))
            manifestPath = Path.Combine(manifestPath, "agent.json");
        manifestPath = Path.GetFullPath(manifestPath);
        Data.NoLinks(manifestPath);
        if (!File.Exists(manifestPath) || new FileInfo(manifestPath).Length > 128000 || !Path.GetExtension(manifestPath).Equals(".json", StringComparison.OrdinalIgnoreCase))
            throw new PolicyException("اختر تعريف agent.json محليًا أقل من 128 KB");
        var raw = File.ReadAllText(manifestPath);
        using (var document = System.Text.Json.JsonDocument.Parse(raw, new System.Text.Json.JsonDocumentOptions { MaxDepth = 20 }))
        {
            if (document.RootElement.ValueKind != System.Text.Json.JsonValueKind.Object)
                throw new PolicyException("تعريف الوكيل يجب أن يكون كائنًا");
            var declared = new Dictionary<string, System.Text.Json.JsonElement>(StringComparer.OrdinalIgnoreCase);
            var known = typeof(AgentDefinition).GetProperties().Select(p => p.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
            foreach (var item in document.RootElement.EnumerateObject())
                if (!known.Contains(item.Name) || !declared.TryAdd(item.Name, item.Value))
                    throw new PolicyException("حقل تعريف مجهول أو مكرر: " + item.Name);
            if (!declared.TryGetValue("Cost", out var cost) || cost.ValueKind != System.Text.Json.JsonValueKind.String || cost.GetString() != "free" || !declared.TryGetValue("Cloud", out var cloud) || cloud.ValueKind != System.Text.Json.JsonValueKind.False || !declared.TryGetValue("Network", out var network) || network.ValueKind != System.Text.Json.JsonValueKind.String || network.GetString() != "deny")
                throw new PolicyException("يلزم تصريح صريح: cost=free وcloud=false وnetwork=deny");
        }

        var a = Data.Decode<AgentDefinition>(raw);
        var root = Path.GetDirectoryName(manifestPath)!;
        if (!Regex.IsMatch(a.Id, "^[a-z][a-z0-9_-]{2,63}$") || string.IsNullOrWhiteSpace(a.Name) || a.Name.Length > 160)
            throw new PolicyException("اسم الوكيل أو معرفه غير صالح");
        if (a.Cloud || a.Cost != "free" || a.Network != "deny")
            throw new PolicyException("يُرفض الوكيل المدفوع أو السحابي أو الذي يطلب شبكة");
        if (!Licenses.TryGetValue(a.LicenseSpdx, out var markers) || string.IsNullOrWhiteSpace(a.LicenseSource) || !markers.All(m => a.LicenseText.Contains(m, StringComparison.OrdinalIgnoreCase)))
            throw new PolicyException("ترخيص مجهول أو نص الترخيص غير متحقق؛ المكون غير مفعّل");
        if (a.Runtime is not ("dotnet" or "node" or "python") || a.Connector is not ("cli_json" or "mcp_stdio"))
            throw new PolicyException("موصل أو مشغل غير معتمد؛ خدمات API غير المدارة محظورة");
        if (a.Capabilities.Length is < 1 or > 30 || a.Capabilities.Any(c => string.IsNullOrWhiteSpace(c) || c.Length > 90))
            throw new PolicyException("قدرات الوكيل غير صالحة");
        if (a.Controls.Any(c => c is not ("start" or "stop" or "cancel" or "restart")))
            throw new PolicyException("الإيقاف المؤقت والاستئناف غير مدعومين دون بروتوكول فعلي");
        if (a.MemoryMb is < 32 or > 2048 || a.CpuSeconds is < 1 or > 300 || a.WallSeconds is < 1 or > 600 || a.MaxProcesses is < 1 or > 16 || a.MaxAttempts is < 1 or > 3 || (!a.Idempotent && a.MaxAttempts != 1))
            throw new PolicyException("حدود الموارد أو إعادة المحاولة غير معتمدة");
        _ = Data.SafePath(root, a.Entry, true);
        ValidateSchema(a.InputSchema);
        ValidateSchema(a.OutputSchema);
        var hashes = new Dictionary<string, string>(StringComparer.Ordinal);
        long total = 0;
        void Walk(string dir)
        {
            foreach (var p in Directory.EnumerateFileSystemEntries(dir))
            {
                Data.NoLinks(p);
                var relative = Path.GetRelativePath(root, p).Replace('\\', '/');
                _ = Data.SafePath(root, relative);
                if (Directory.Exists(p))
                {
                    Walk(p);
                    continue;
                }

                total += new FileInfo(p).Length;
                if (hashes.Count >= 256 || total > 64L * 1024 * 1024)
                    throw new PolicyException("حزمة الوكيل تتجاوز 256 ملفًا أو 64 MiB");
                hashes[relative] = Data.HashFile(p);
            }
        }

        Walk(root);
        a = a with
        {
            SourceRoot = root,
            ManifestPath = manifestPath,
            FileHashes = hashes,
            ApprovalDigest = ""
        };
        return a with
        {
            ApprovalDigest = Data.HashText(Data.Encode(a))
        };
    }

    internal static void Verify(AgentDefinition a)
    {
        var current = Inspect(a.ManifestPath);
        if (current.ApprovalDigest != a.ApprovalDigest)
            throw new PolicyException("تغيرت ملفات الوكيل بعد اعتمادها؛ أعد فحصه وتسجيله");
    }

    private static readonly HashSet<string> SchemaKeys = ["type", "properties", "required", "additionalProperties", "items", "maxItems", "minItems", "maxLength", "minimum", "maximum", "enum", "description"];
    internal static void ValidateSchema(JsonObject schema, int depth = 0)
    {
        if (depth > 8 || schema.Any(p => !SchemaKeys.Contains(p.Key)))
            throw new PolicyException("يتضمن المخطط حقولًا غير مدعومة");
        var type = schema["type"]?.GetValue<string>();
        if (type is not ("object" or "array" or "string" or "number" or "integer" or "boolean" or null))
            throw new PolicyException("نوع مخطط غير مدعوم");
        if (schema["properties"] is JsonObject props)
            foreach (var item in props)
                ValidateSchema(item.Value as JsonObject ?? throw new PolicyException("مخطط خاصية غير صالح"), depth + 1);
        if (schema["items"] is JsonObject items)
            ValidateSchema(items, depth + 1);
    }

    private static bool Number(JsonNode? node, out double number)
    {
        number = 0;
        return node?.GetValueKind() == JsonValueKind.Number && double.TryParse(node.ToJsonString(), NumberStyles.Float, CultureInfo.InvariantCulture, out number) && double.IsFinite(number);
    }

    internal static void ValidateValue(JsonNode? value, JsonObject schema, string path = "input", int depth = 0)
    {
        if (depth > 12)
            throw new PolicyException("تداخل JSON زائد");
        var type = schema["type"]?.GetValue<string>();
        bool ok = type switch
        {
            "object" => value is JsonObject,
            "array" => value is JsonArray,
            "string" => value is JsonValue v && v.TryGetValue<string>(out _),
            "boolean" => value is JsonValue v && v.TryGetValue<bool>(out _),
            "number" => Number(value, out _),
            "integer" => Number(value, out var n) && Math.Truncate(n) == n,
            _ => true
        };
        if (!ok)
            throw new PolicyException("نوع قيمة غير صحيح: " + path);
        if (value is JsonObject obj)
        {
            var props = schema["properties"] as JsonObject ?? new();
            if (schema["required"] is JsonArray req)
                foreach (var key in req)
                    if (!obj.ContainsKey(key!.GetValue<string>()))
                        throw new PolicyException("حقل مطلوب: " + key);
            if (schema["additionalProperties"]?.ToString() == "false" && obj.Any(p => !props.ContainsKey(p.Key)))
                throw new PolicyException("حقل إضافي غير مسموح: " + path);
            foreach (var p in obj)
                if (props[p.Key] is JsonObject sub)
                    ValidateValue(p.Value, sub, path + "." + p.Key, depth + 1);
        }

        if (value is JsonArray arr)
        {
            if (arr.Count > (schema["maxItems"]?.GetValue<int>() ?? 1000) || arr.Count < (schema["minItems"]?.GetValue<int>() ?? 0))
                throw new PolicyException("عدد عناصر غير صالح");
            if (schema["items"] is JsonObject item)
                foreach (var v in arr)
                    ValidateValue(v, item, path + "[]", depth + 1);
        }

        if (value is JsonValue scalar && scalar.TryGetValue<string>(out var text) && text.Length > (schema["maxLength"]?.GetValue<int>() ?? 100000))
            throw new PolicyException("النص طويل جدًا");
        if (Number(value, out var d))
        {
            var minimum = Number(schema["minimum"], out var min) ? min : double.MinValue;
            var maximum = Number(schema["maximum"], out var max) ? max : double.MaxValue;
            if (d < minimum || d > maximum)
                throw new PolicyException("قيمة خارج النطاق");
        }

        if (schema["enum"] is JsonArray choices && !choices.Any(x => JsonNode.DeepEquals(x, value)))
            throw new PolicyException("قيمة غير مدرجة");
    }
}
