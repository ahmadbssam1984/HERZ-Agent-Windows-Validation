# Core binding contract

Namespace `Herz.Core`. `CommandCenter(string dataRoot, IAgentRunner runner)` implements `IDisposable`.

Synchronous read/mutation API (all storage local):

- `DashboardSnapshot Dashboard()`
- `IReadOnlyList<AgentRecord> Agents()`
- `AgentInspection InspectAgent(string manifestPath)`
- `AgentRecord RegisterAgent(string manifestPath, string approvalDigest)`
- `AgentRecord ControlAgent(string id, string action)` (`start/stop/restart/cancel`; no pretend pause)
- `IReadOnlyList<TaskRecord> Tasks()`; `TaskRecord TaskDetails(string id)`
- `TaskRecord Submit(TaskSubmission request)`
- `void Cancel(string id)`; `void EmergencyStop()`; `void Resume()`
- `Task<bool> RunNextAsync(CancellationToken token = default)`; `void StartScheduler()`
- `PlanRecord PreviewPlan(string arabicRequest)`; `IReadOnlyList<TaskRecord> SubmitPlan(string planId)`
- `IReadOnlyList<MessageRecord> Messages(string? taskId = null)`
- `IReadOnlyList<AuditRecord> Audit(string? kind = null)`
- `KnowledgeRecord SaveKnowledge(KnowledgeInput input)`
- `IReadOnlyList<KnowledgeRecord> Knowledge(string? scope = null)`
- `IReadOnlyList<KnowledgeRecord> KnowledgeHistory(string id)`
- `KnowledgeRecord RollbackKnowledge(string id, int version)`
- `IReadOnlyList<KnowledgeHit> SearchKnowledge(string query, string scope = "shared")`
- `BackupRecord CreateBackup()`; `IReadOnlyList<BackupRecord> Backups()`; `void RestoreBackup(string backupId)`
- `IReadOnlyList<ModelState> Models()`; `ModelState RegisterModel(ModelConfiguration model)`

`PreviewPlan` explicitly labels its narrow Arabic numbers→report path as deterministic rules, **not model inference**. General instructions require a separately verified local model and remain unavailable in this core route. Artifact outputs are only accepted after SHA/size/path/schema checks, not a success string.

`IAgentRunner` lives in Models.cs. `Check` must report actual prestarted isolated worker/handshake readiness. `Probe().Supported` gates every execution; the default runner refuses. `StopAll` closes only managed job handles. Core never creates unisolated fallback processes.
