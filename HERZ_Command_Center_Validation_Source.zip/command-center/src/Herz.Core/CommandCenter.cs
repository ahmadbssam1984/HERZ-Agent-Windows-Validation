using System.Diagnostics;
using System.Globalization;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;

namespace Herz.Core;
public sealed partial class CommandCenter : IDisposable
{
    private readonly object gate = new();
    private readonly SemaphoreSlim execution = new(1, 1);
    private readonly IAgentRunner runner;
    private readonly FileStream instance;
    private Store db;
    private CancellationTokenSource? runningCancellation;
    private string? runningId;
    private CancellationTokenSource? schedulerCancellation;
    private Task? scheduler;
    private bool disposed;
    public string DataRoot { get; }

    public CommandCenter(string dataRoot, IAgentRunner runner)
    {
        DataRoot = Path.GetFullPath(dataRoot);
        Directory.CreateDirectory(DataRoot);
        Data.NoLinks(DataRoot);
        this.runner = runner;
        instance = new FileStream(Path.Combine(DataRoot, "manager.lock"), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
        try
        {
            db = new Store(Path.Combine(DataRoot, "center.sqlite3"));
            Directory.CreateDirectory(Path.Combine(DataRoot, "results"));
            Directory.CreateDirectory(Path.Combine(DataRoot, "work"));
            Directory.CreateDirectory(Path.Combine(DataRoot, "backups"));
            Recover();
        }
        catch
        {
            instance.Dispose();
            throw;
        }
    }

    private bool Paused => db.Setting("paused", "false") == "true";

    private AgentDefinition Definition(string id) => Data.Decode<AgentDefinition>(db.Scalar("SELECT definition FROM agents WHERE id=@p0", id)?.ToString() ?? throw new PolicyException("الوكيل غير مسجل"));
    private AgentReadiness Check(AgentDefinition a)
    {
        try
        {
            var p = runner.Probe();
            if (!p.Supported)
                return new(false, p.Reason);
            return runner.Check(a);
        }
        catch (Exception e)
        {
            return new(false, Data.Redact(e.Message));
        }
    }

    public DashboardSnapshot Dashboard()
    {
        lock (gate)
        {
            using var p = Process.GetCurrentProcess();
            var agents = Agents();
            int Count(string status) => Convert.ToInt32(db.Scalar("SELECT COUNT(*) FROM tasks WHERE status=@p0", status), CultureInfo.InvariantCulture);
            return new(Paused, runner.Probe(), agents.Count, agents.Count(a => a.Enabled && a.Readiness.Ready), Count("queued"), Count("running"), Count("succeeded"), Count("failed") + Count("needs_review") + Count("timed_out"), p.WorkingSet64, p.TotalProcessorTime.TotalSeconds, DataRoot, "خطة الأرقام محددة بالقواعد؛ الاستدلال المحلي العام يتطلب نموذجًا مُجهزًا ومُقاسًا.");
        }
    }

    public IReadOnlyList<AgentRecord> Agents()
    {
        lock (gate)
            return db.Rows("SELECT * FROM agents ORDER BY created").Select(r =>
            {
                var a = Data.Decode<AgentDefinition>((string)r["definition"]!);
                return new AgentRecord(a, Convert.ToInt64(r["enabled"], CultureInfo.InvariantCulture) == 1, Check(a), (string)r["created"]!);
            }).ToArray();
    }

    // Trusted host evidence only. This records observations and never changes policy.
    public void RecordHostCheck(string entity, string check, string outcome, int? nativeError)
    {
        if (entity.Length is < 1 or > 160 || check.Length is < 1 or > 200 || outcome.Length is < 1 or > 40)
            throw new PolicyException("دليل تشغيل غير صالح");
        lock (gate)
            db.Event(outcome == "denied" ? "runtime_denied" : "runtime_check", entity, "startup probe: " + check + " = " + outcome + "; nativeError=" + nativeError);
    }

    public AgentInspection InspectAgent(string manifestPath)
    {
        lock (gate)
        {
            try
            {
                var a = Policy.Inspect(manifestPath);
                var readiness = Check(a);
                return new(true, a, readiness, a.ApprovalDigest, "", [new("التكلفة والسحابة والترخيص والمصدر", true, "يتطلب التسجيل مراجعة المالك للمصدر والترخيص"), new("جاهزية التنفيذ المعزول", readiness.Ready, readiness.Reason)]);
            }
            catch (Exception e)when (e is PolicyException or IOException or UnauthorizedAccessException or System.Text.Json.JsonException or FormatException or InvalidOperationException)
            {
                db.Event("blocked", "registration", e.Message);
                return new(false, null, new(false, e.Message), "", Data.Redact(e.Message), []);
            }
        }
    }

    public AgentRecord RegisterAgent(string manifestPath, string approvalDigest)
    {
        lock (gate)
        {
            var inspected = InspectAgent(manifestPath);
            if (!inspected.Allowed || inspected.Definition == null || string.IsNullOrEmpty(approvalDigest) || inspected.ApprovalDigest != approvalDigest)
                throw new PolicyException("الفحص أو اعتماد المصدر غير صالح؛ أعد المعاينة");
            var a = inspected.Definition;
            if (db.Scalar("SELECT 1 FROM tasks WHERE agent=@p0 AND status='running'", a.Id) != null)
                throw new PolicyException("أوقف مهمة الوكيل قبل تغيير تعريفه");
            db.Execute("INSERT INTO agents VALUES(@p0,@p1,@p2,@p3) ON CONFLICT(id) DO UPDATE SET definition=excluded.definition,enabled=excluded.enabled", a.Id, Data.Encode(a), inspected.Readiness.Ready ? 1 : 0, Data.Now());
            db.Event("agent_registered", a.Id, "مصدر مرجَع ببصمة وترخيص؛ جاهزية: " + inspected.Readiness.Reason);
            return Agents().Single(x => x.Definition.Id == a.Id);
        }
    }

    public AgentRecord ControlAgent(string id, string action)
    {
        lock (gate)
        {
            var a = Definition(id);
            if (!a.Controls.Contains(action))
                throw new PolicyException("أمر تحكم غير مدعوم فعليًا");
            if (action is "stop" or "cancel" or "restart")
            {
                db.Execute("UPDATE agents SET enabled=0 WHERE id=@p0", id);
                foreach (var t in Tasks().Where(t => t.AgentId == id && t.Status == "running"))
                    Cancel(t.Id);
            }

            if (action is "start" or "restart")
            {
                Policy.Verify(a);
                var check = Check(a);
                if (!check.Ready)
                {
                    db.Event("blocked", id, check.Reason);
                    throw new PolicyException(check.Reason);
                }

                db.Execute("UPDATE agents SET enabled=1 WHERE id=@p0", id);
            }

            db.Event("agent_control", id, action);
            return Agents().Single(x => x.Definition.Id == id);
        }
    }

    public TaskRecord Submit(TaskSubmission request)
    {
        lock (gate)
        {
            if (Paused)
                throw new PolicyException("استقبال المهام موقوف");
            var a = Definition(request.AgentId);
            var input = (JsonObject)request.Input.DeepClone();
            Policy.ValidateValue(input, a.InputSchema);
            if (System.Text.Encoding.UTF8.GetByteCount(Data.Encode(input)) > 1024 * 1024)
                throw new PolicyException("مدخلات المهمة تتجاوز 1 MiB");
            if (request.Priority is < -100 or > 100 || request.DelegationDepth is < 0 or > 8 || string.IsNullOrWhiteSpace(request.Title) || request.Title.Length > 200)
                throw new PolicyException("أولوية أو عنوان أو حد تفويض غير صالح");
            var deps = (request.Dependencies ?? []).Distinct(StringComparer.Ordinal).ToArray();
            if (deps.Length > 16)
                throw new PolicyException("عدد الاعتماديات تجاوز الحد");
            foreach (var d in deps)
                _ = TaskDetails(d);
            var locks = (request.LockNames ?? []).Select(x => x.Trim().ToLowerInvariant()).Distinct().ToArray();
            if (locks.Length > 16 || locks.Any(x => x.Length is < 1 or > 180 || x.Any(char.IsControl)))
                throw new PolicyException("أقفال كتابة غير صالحة");
            var key = request.IdempotencyKey ?? Data.Id();
            if (key.Length is < 1 or > 160)
                throw new PolicyException("مفتاح منع التكرار غير صالح");
            var digest = Data.HashText(Data.Canonical(new JsonObject { ["agent"] = a.Id, ["input"] = input.DeepClone(), ["deps"] = new JsonArray(deps.Select(x => (JsonNode? )JsonValue.Create(x)).ToArray()), ["locks"] = new JsonArray(locks.Select(x => (JsonNode? )JsonValue.Create(x)).ToArray()) }));
            var existing = db.Rows("SELECT id,digest FROM tasks WHERE idempotency=@p0", key).SingleOrDefault();
            if (existing != null)
            {
                if ((string)existing["digest"]! != digest)
                    throw new PolicyException("استُخدم مفتاح منع التكرار لمدخلات مختلفة");
                return TaskDetails((string)existing["id"]!);
            }

            var id = Data.Id();
            var now = Data.Now();
            db.Execute("INSERT INTO tasks(id,agent,title,status,priority,input,dependencies,idempotency,digest,agent_digest,locks,depth,created,updated) VALUES(@p0,@p1,@p2,'queued',@p3,@p4,@p5,@p6,@p7,@p8,@p9,@p10,@p11,@p11)", id, a.Id, request.Title, request.Priority, Data.Encode(input), Data.Encode(deps), key, digest, a.ApprovalDigest, Data.Encode(locks), request.DelegationDepth, now);
            Message(id, "manager", a.Id, "queued", "مهمة محفوظة محليًا");
            return TaskDetails(id);
        }
    }

    private static string Text(Dictionary<string, object?> row, string name) => row[name]?.ToString() ?? "";
    private TaskRecord ToTask(Dictionary<string, object?> r) => new(Text(r, "id"), Text(r, "title"), Text(r, "agent"), Text(r, "status"), Convert.ToInt32(r["priority"], CultureInfo.InvariantCulture), Data.Decode<JsonObject>(Text(r, "input")), Data.Decode<string[]>(Text(r, "dependencies")), Convert.ToInt32(r["attempts"], CultureInfo.InvariantCulture), Text(r, "created"), Text(r, "updated"), r["error"]?.ToString(), r["result"] == null ? null : Data.Decode<JsonObject>(Text(r, "result")), Data.Decode<List<ArtifactRecord>>(Text(r, "artifacts")), Text(r, "idempotency"));
    public IReadOnlyList<TaskRecord> Tasks()
    {
        lock (gate)
            return db.Rows("SELECT * FROM tasks ORDER BY created DESC,rowid DESC LIMIT 2000").Select(ToTask).ToArray();
    }

    public TaskRecord TaskDetails(string id)
    {
        lock (gate)
            return ToTask(db.Rows("SELECT * FROM tasks WHERE id=@p0", id).SingleOrDefault() ?? throw new PolicyException("المهمة غير موجودة"));
    }

    public void Cancel(string id)
    {
        lock (gate)
        {
            var task = TaskDetails(id);
            if (task.Status == "running")
            {
                db.Execute("UPDATE tasks SET status='cancelling',updated=@p1 WHERE id=@p0", id, Data.Now());
                if (runningId == id)
                    runningCancellation?.Cancel();
                runner.StopAll();
            }
            else if (task.Status == "queued")
                db.Execute("UPDATE tasks SET status='cancelled',updated=@p1 WHERE id=@p0", id, Data.Now());
            db.Event("task_cancel", id, "طلب إلغاء للعمليات المدارة فقط");
        }
    }

    public void EmergencyStop()
    {
        lock (gate)
        {
            db.Set("paused", "true");
            runningCancellation?.Cancel();
            runner.StopAll();
            db.Event("emergency", "manager", "أوقف استقبال المهام وأُرسلت إشارة الإلغاء للعمليات المدارة");
        }
    }

    public void Resume()
    {
        lock (gate)
        {
            var state = runner.Probe();
            if (!state.Supported)
                throw new PolicyException(state.Reason);
            db.Set("paused", "false");
            db.Event("resumed", "manager", "استئناف الاستقبال بعد تحقق العزل");
        }
    }

    private void Message(string task, string sender, string receiver, string status, string body) => db.Execute("INSERT INTO messages VALUES(@p0,@p1,@p2,@p3,@p4,@p5,@p6)", Data.Id(), task, sender, receiver, status, body, Data.Now());
    public IReadOnlyList<MessageRecord> Messages(string? taskId = null)
    {
        lock (gate)
            return db.Rows(taskId == null ? "SELECT * FROM messages ORDER BY created DESC LIMIT 2000" : "SELECT * FROM messages WHERE task=@p0 ORDER BY created", taskId == null ? [] : [taskId]).Select(r => new MessageRecord(Text(r, "id"), Text(r, "task"), Text(r, "sender"), Text(r, "receiver"), Text(r, "status"), Text(r, "body"), Text(r, "created"))).ToArray();
    }

    public IReadOnlyList<AuditRecord> Audit(string? kind = null)
    {
        lock (gate)
            return db.Rows(kind == null ? "SELECT * FROM audit ORDER BY id DESC LIMIT 2000" : "SELECT * FROM audit WHERE kind=@p0 ORDER BY id DESC LIMIT 2000", kind == null ? [] : [kind]).Select(r => new AuditRecord(Convert.ToInt64(r["id"], CultureInfo.InvariantCulture), Text(r, "kind"), Text(r, "entity"), Text(r, "reason"), Text(r, "created"))).ToArray();
    }

    public void StartScheduler()
    {
        lock (gate)
        {
            if (scheduler != null)
                return;
            schedulerCancellation = new();
            var token = schedulerCancellation.Token;
            scheduler = Task.Run(async () =>
            {
                while (!token.IsCancellationRequested)
                {
                    try
                    {
                        await RunNextAsync(token);
                        await Task.Delay(250, token);
                    }
                    catch (OperationCanceledException)
                    {
                        break;
                    }
                    catch (Exception e)
                    {
                        lock (gate)
                            db.Event("scheduler_error", "manager", e.Message);
                        await Task.Delay(1000, token);
                    }
                }
            }, token);
        }
    }

    public async Task<bool> RunNextAsync(CancellationToken cancellationToken = default)
    {
        if (!await execution.WaitAsync(0, cancellationToken))
            return false;
        TaskRecord? task = null;
        AgentDefinition? agent = null;
        string? workspace = null;
        CancellationTokenSource? deadline = null;
        try
        {
            lock (gate)
            {
                if (Paused)
                    return false;
                var isolation = runner.Probe();
                if (!isolation.Supported)
                    return false;
                foreach (var row in db.Rows("SELECT * FROM tasks WHERE status='queued' ORDER BY priority DESC,created,rowid"))
                {
                    var candidate = ToTask(row);
                    var dependencies = candidate.Dependencies.Select(TaskDetails).ToArray();
                    if (dependencies.Any(t => t.Status is "failed" or "cancelled" or "timed_out" or "needs_review" or "blocked"))
                    {
                        db.Execute("UPDATE tasks SET status='blocked',error=@p1,updated=@p2 WHERE id=@p0", candidate.Id, "فشلت اعتمادية أو تحتاج مراجعة", Data.Now());
                        continue;
                    }

                    if (dependencies.Any(t => t.Status != "succeeded"))
                        continue;
                    var a = Definition(candidate.AgentId);
                    if (Convert.ToInt32(db.Scalar("SELECT enabled FROM agents WHERE id=@p0", a.Id), CultureInfo.InvariantCulture) != 1)
                        continue;
                    var lockNames = Data.Decode<string[]>(Text(row, "locks"));
                    if (lockNames.Any(n => db.Scalar("SELECT 1 FROM locks WHERE name=@p0", n) != null))
                        continue;
                    try
                    {
                        Policy.Verify(a);
                        var ready = Check(a);
                        if (!ready.Ready)
                            throw new PolicyException(ready.Reason);
                        if (a.ApprovalDigest != Text(row, "agent_digest"))
                            throw new PolicyException("تغير تعريف الوكيل منذ إنشاء المهمة");
                    }
                    catch (Exception e)
                    {
                        db.Execute("UPDATE tasks SET status='blocked',error=@p1,updated=@p2 WHERE id=@p0", candidate.Id, Data.Redact(e.Message), Data.Now());
                        db.Event("blocked", candidate.Id, e.Message);
                        continue;
                    }

                    db.Atomic(() =>
                    {
                        db.Execute("UPDATE tasks SET status='running',attempts=attempts+1,updated=@p1 WHERE id=@p0 AND status='queued'", candidate.Id, Data.Now());
                        foreach (var n in lockNames)
                            db.Execute("INSERT INTO locks VALUES(@p0,@p1)", n, candidate.Id);
                    });
                    task = TaskDetails(candidate.Id);
                    agent = a;
                    break;
                }

                if (task == null || agent == null)
                    return false;
                workspace = Path.Combine(DataRoot, "work", task.Id + "-" + Data.Id());
                Directory.CreateDirectory(workspace);
                deadline = new CancellationTokenSource(TimeSpan.FromSeconds(agent.WallSeconds));
                runningCancellation = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, deadline.Token);
                runningId = task.Id;
                Message(task.Id, "manager", agent.Id, "running", "بدأ التنفيذ المعزول");
            }

            var inputs = new List<ArtifactRecord>();
            lock (gate)
            {
                foreach (var dependencyId in task.Dependencies)
                {
                    var dep = TaskDetails(dependencyId);
                    foreach (var artifact in dep.Artifacts)
                    {
                        VerifyArtifact(artifact);
                        var relative = "inputs/" + dependencyId + "/" + artifact.RelativePath;
                        var dest = Data.SafePath(workspace, relative);
                        Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
                        File.Copy(artifact.FullPath, dest, false);
                        inputs.Add(artifact with { FullPath = dest });
                    }

                    Message(task.Id, dep.AgentId, agent.Id, "input_ready", "نتيجة موثقة من المهمة " + dependencyId);
                }
            }

            IReadOnlyList<KnowledgeRecord> knowledge;
            lock (gate)
                knowledge = Knowledge(agent.Id).Where(k => k.Kind == "instruction").Concat(SearchKnowledge(task.Title, agent.Id).Select(x => x.Item)).DistinctBy(x => x.Id).ToArray();
            var result = await runner.ExecuteAsync(agent, new(task.Id, task.Input, workspace, inputs, knowledge), runningCancellation.Token);
            runningCancellation.Token.ThrowIfCancellationRequested();
            if (result.ExitCode != 0)
                throw new PolicyException("فشل الوكيل: " + Data.Redact(result.StandardError));
            Policy.ValidateValue(result.Result, agent.OutputSchema, "output");
            if (System.Text.Encoding.UTF8.GetByteCount(Data.Encode(result.Result)) > 1024 * 1024)
                throw new PolicyException("بيانات النتيجة تتجاوز 1 MiB");
            var artifacts = VerifyOutputs(task.Id, workspace, result.Artifacts);
            VerifyKnownNumericResult(agent, task.Input, result.Result, artifacts);
            if (artifacts.Count == 0)
                throw new PolicyException("لم يقدم الوكيل ملفًا قابلاً للتحقق");
            lock (gate)
            {
                runningCancellation.Token.ThrowIfCancellationRequested();
                if (Paused || TaskDetails(task.Id).Status == "cancelling")
                    throw new OperationCanceledException();
                var target = Path.Combine(DataRoot, "results", task.Id);
                if (Directory.Exists(target))
                    throw new PolicyException("مساحة نتيجة موجودة؛ لن تُستبدل");
                var digest = db.Scalar("SELECT digest FROM tasks WHERE id=@p0", task.Id)!.ToString()!;
                Data.AtomicText(Path.Combine(workspace, "_completion.json"), Data.Encode(new Completion(task.Id, digest, result.Result, artifacts.Select(a => a with { FullPath = Path.Combine(target, a.RelativePath) }).ToArray())));
                Directory.Move(workspace, target);
                var saved = ReadCompletion(task.Id, digest);
                db.Atomic(() =>
                {
                    db.Execute("UPDATE tasks SET status='succeeded',result=@p1,artifacts=@p2,error=NULL,updated=@p3 WHERE id=@p0", task.Id, Data.Encode(saved.Result), Data.Encode(saved.Artifacts), Data.Now());
                    db.Execute("DELETE FROM locks WHERE task=@p0", task.Id);
                    Message(task.Id, agent.Id, "manager", "succeeded", "تحققت الملفات والبصمات ومخطط النتيجة");
                });
            }

            return true;
        }
        catch (OperationCanceledException)
        {
            if (task != null)
                lock (gate)
                {
                    runner.StopAll();
                    var timed = deadline?.IsCancellationRequested == true && !cancellationToken.IsCancellationRequested && !Paused && TaskDetails(task.Id).Status != "cancelling";
                    db.Execute("UPDATE tasks SET status=@p1,error=@p2,updated=@p3 WHERE id=@p0", task.Id, timed ? "timed_out" : "cancelled", timed ? "انتهت المهلة" : "أُلغي التنفيذ", Data.Now());
                    Message(task.Id, task.AgentId, "manager", timed ? "timed_out" : "cancelled", "انتهى التنفيذ دون اعتماد نتيجة");
                }

            return task != null;
        }
        catch (Exception e)
        {
            if (task != null)
                lock (gate)
                {
                    db.Execute("UPDATE tasks SET status='failed',error=@p1,updated=@p2 WHERE id=@p0", task.Id, Data.Redact(e.Message), Data.Now());
                    db.Event(e is PolicyException ? "blocked" : "task_error", task.Id, e.Message);
                    Message(task.Id, task.AgentId, "manager", "failed", Data.Redact(e.Message));
                }

            return task != null;
        }
        finally
        {
            lock (gate)
            {
                if (task != null)
                    db.Execute("DELETE FROM locks WHERE task=@p0", task.Id);
                runningCancellation?.Dispose();
                runningCancellation = null;
                runningId = null;
            }

            deadline?.Dispose();
            execution.Release();
        }
    }

    private sealed record Completion(string TaskId, string InputDigest, JsonObject Result, IReadOnlyList<ArtifactRecord> Artifacts);
    private static IReadOnlyList<ArtifactRecord> VerifyOutputs(string taskId, string workspace, IReadOnlyList<string> paths)
    {
        if (paths.Count > 128 || paths.Distinct(StringComparer.OrdinalIgnoreCase).Count() != paths.Count)
            throw new PolicyException("قائمة الملفات مكررة أو أكبر من الحد");
        long bytes = 0;
        var result = new List<ArtifactRecord>();
        foreach (var relative in paths)
        {
            if (relative.StartsWith("inputs/", StringComparison.OrdinalIgnoreCase) || relative == "_completion.json")
                throw new PolicyException("لا تُعتمد ملفات التحكم والمدخلات كنتيجة جديدة");
            var full = Data.SafePath(workspace, relative, true);
            var length = new FileInfo(full).Length;
            bytes += length;
            if (length > 1024L * 1024 * 1024 || bytes > 2L * 1024 * 1024 * 1024)
                throw new PolicyException("الملفات الناتجة تتجاوز حد التسليم");
            result.Add(new(relative.Replace('\\', '/'), full, Data.HashFile(full), length, taskId));
        }

        return result;
    }

    private static void VerifyKnownNumericResult(AgentDefinition agent, JsonObject input, JsonObject result, IReadOnlyList<ArtifactRecord> artifacts)
    {
        if (!agent.Capabilities.Contains("numeric_analysis"))
            return;
        if (input["numbers"] is not JsonArray source || source.Count is < 1 or > 200)
            throw new PolicyException("التحليل الرقمي يتطلب 1–200 قيمة");
        static decimal DecimalValue(JsonNode? n)
        {
            if (n?.GetValueKind() != System.Text.Json.JsonValueKind.Number || !decimal.TryParse(n.ToJsonString(), NumberStyles.Float, CultureInfo.InvariantCulture, out var d))
                throw new PolicyException("قيمة حسابية غير صالحة");
            return d;
        }

        var values = source.Select(DecimalValue).ToArray();
        if (values.Any(v => Math.Abs(v) > 1000000000m))
            throw new PolicyException("قيمة التحليل تتجاوز مليارًا");
        var stats = artifacts.SingleOrDefault(a => a.RelativePath == "stats.json") ?? throw new PolicyException("ملف stats.json مطلوب للتحقق من الحساب");
        if (stats.Bytes > 1024 * 1024)
            throw new PolicyException("ملف الحساب كبير جدًا");
        var file = Data.Decode<JsonObject>(File.ReadAllText(stats.FullPath));
        var expected = new Dictionary<string, decimal>
        {
            {
                "count",
                values.Length
            },
            {
                "sum",
                values.Sum()
            },
            {
                "mean",
                values.Average()
            },
            {
                "min",
                values.Min()
            },
            {
                "max",
                values.Max()
            }
        };
        foreach (var field in expected)
            if (DecimalValue(file[field.Key]) != field.Value || DecimalValue(result[field.Key]) != field.Value)
                throw new PolicyException("فشل التحقق المستقل من الحساب: " + field.Key);
        if (file["numbers"] is not JsonArray written || !written.Select(DecimalValue).SequenceEqual(values))
            throw new PolicyException("قيم المصدر داخل ملف الحساب غير مطابقة");
    }

    private void VerifyArtifact(ArtifactRecord a)
    {
        if (!Regex.IsMatch(a.SourceTaskId, "^[a-f0-9]{32}$"))
            throw new PolicyException("معرف مصدر الأثر غير صالح");
        var expected = Data.SafePath(Path.Combine(DataRoot, "results", a.SourceTaskId), a.RelativePath, true);
        if (!Path.GetFullPath(a.FullPath).Equals(expected, OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal) || new FileInfo(expected).Length != a.Bytes || Data.HashFile(expected) != a.Sha256)
            throw new PolicyException("الملف أو بصمته تغيرا بعد الاعتماد");
    }

    private Completion ReadCompletion(string id, string digest)
    {
        var path = Path.Combine(DataRoot, "results", id, "_completion.json");
        Data.NoLinks(path);
        if (new FileInfo(path).Length > 1024 * 1024)
            throw new PolicyException("إيصال نتيجة زائد الحجم");
        var c = Data.Decode<Completion>(File.ReadAllText(path));
        if (c.TaskId != id || c.InputDigest != digest || c.Artifacts.Count == 0)
            throw new PolicyException("إيصال النتيجة لا يطابق المهمة");
        foreach (var a in c.Artifacts)
        {
            if (a.SourceTaskId != id)
                throw new PolicyException("مصدر أثر غير مطابق");
            VerifyArtifact(a);
        }

        return c;
    }

    private void Recover()
    {
        lock (gate)
        {
            foreach (var row in db.Rows("SELECT * FROM tasks WHERE status IN ('running','cancelling')"))
            {
                var id = Text(row, "id");
                try
                {
                    var c = ReadCompletion(id, Text(row, "digest"));
                    db.Execute("UPDATE tasks SET status='succeeded',result=@p1,artifacts=@p2,updated=@p3 WHERE id=@p0", id, Data.Encode(c.Result), Data.Encode(c.Artifacts), Data.Now());
                    db.Event("recovered", id, "استعيدت نتيجة مكتملة وموثقة دون إعادة الفعل");
                }
                catch (Exception)
                {
                    db.Execute("UPDATE tasks SET status='needs_review',error=@p1,updated=@p2 WHERE id=@p0", id, "انقطع المدير أثناء التنفيذ؛ الأثر غير مؤكد ولن يعاد تلقائيًا", Data.Now());
                    db.Event("recovery_hold", id, "لا إعادة تلقائية لأثر غير مؤكد");
                }
            }

            db.Execute("DELETE FROM locks");
        }
    }

    public void Dispose()
    {
        if (disposed)
            return;
        disposed = true;
        schedulerCancellation?.Cancel();
        lock (gate)
        {
            runningCancellation?.Cancel();
            runner.StopAll();
        }

        try
        {
            scheduler?.Wait(TimeSpan.FromSeconds(5));
        }
        catch (AggregateException)
        {
        }

        if (!execution.Wait(TimeSpan.FromSeconds(5)))
            return;
        lock (gate)
        {
            db.Dispose();
            instance.Dispose();
        }

        execution.Release();
        schedulerCancellation?.Dispose();
    }
}
