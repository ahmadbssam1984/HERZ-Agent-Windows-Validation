using Microsoft.Data.Sqlite;
using System.IO.Compression;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;

namespace Herz.Core;
public sealed partial class CommandCenter
{
    private IReadOnlyList<TaskRecord> AllCompletedTasks() => db.Rows("SELECT * FROM tasks WHERE status='succeeded'").Select(ToTask).ToArray();
    private sealed record BackupManifest(int Format, string CreatedAt, Dictionary<string, string> Files, string Excluded = "External agent originals, runtime executables and model weights are not included.");
    public BackupRecord CreateBackup()
    {
        lock (gate)
        {
            if (runningId != null || Tasks().Any(t => t.Status is "running" or "cancelling"))
                throw new PolicyException("أوقف المهام الجارية قبل النسخ");
            var id = Data.Id();
            var created = Data.Now();
            var folder = Path.Combine(DataRoot, "backups");
            var staging = Path.Combine(folder, id + ".staging");
            Directory.CreateDirectory(staging);
            var zipPath = Path.Combine(folder, id + ".zip");
            try
            {
                var snapshot = Path.Combine(staging, "center.sqlite3");
                using (var dest = new SqliteConnection("Data Source=" + snapshot + ";Pooling=False"))
                {
                    dest.Open();
                    db.Connection.BackupDatabase(dest);
                }

                var hashes = new Dictionary<string, string>
                {
                    {
                        "center.sqlite3",
                        Data.HashFile(snapshot)
                    }
                };
                long totalBytes = new FileInfo(snapshot).Length;
                using (var z = ZipFile.Open(zipPath, ZipArchiveMode.Create))
                {
                    z.CreateEntryFromFile(snapshot, "center.sqlite3", CompressionLevel.Optimal);
                    foreach (var task in AllCompletedTasks())
                    {
                        foreach (var artifact in task.Artifacts)
                        {
                            VerifyArtifact(artifact);
                            var relative = "results/" + task.Id + "/" + artifact.RelativePath;
                            if (hashes.ContainsKey(relative))
                                continue;
                            totalBytes += artifact.Bytes;
                            if (totalBytes > 2L * 1024 * 1024 * 1024 || hashes.Count >= 4095)
                                throw new PolicyException("النسخة تتجاوز الحد الحالي: 2 GiB أو 4096 ملفًا");
                            z.CreateEntryFromFile(artifact.FullPath, relative, CompressionLevel.Optimal);
                            hashes[relative] = artifact.Sha256;
                        }

                        var receipt = Path.Combine(DataRoot, "results", task.Id, "_completion.json");
                        if (File.Exists(receipt))
                        {
                            var relative = "results/" + task.Id + "/_completion.json";
                            z.CreateEntryFromFile(receipt, relative, CompressionLevel.Optimal);
                            hashes[relative] = Data.HashFile(receipt);
                        }
                    }

                    using var writer = new StreamWriter(z.CreateEntry("manifest.json").Open());
                    writer.Write(Data.Encode(new BackupManifest(1, created, hashes)));
                }

                var record = new BackupRecord(id, zipPath, Data.HashFile(zipPath), new FileInfo(zipPath).Length, created);
                Data.AtomicText(Path.Combine(folder, id + ".json"), Data.Encode(record));
                db.Event("backup_created", id, "نسخة SQLite متسقة وملفات نتائج متحققة");
                return record;
            }
            finally
            {
                if (Directory.Exists(staging))
                    Directory.Delete(staging, true);
            }
        }
    }

    public IReadOnlyList<BackupRecord> Backups()
    {
        lock (gate)
        {
            var result = new List<BackupRecord>();
            foreach (var path in Directory.EnumerateFiles(Path.Combine(DataRoot, "backups"), "*.json"))
            {
                try
                {
                    Data.NoLinks(path);
                    var b = Data.Decode<BackupRecord>(File.ReadAllText(path));
                    if (Regex.IsMatch(b.Id, "^[a-f0-9]{32}$") && File.Exists(Path.Combine(DataRoot, "backups", b.Id + ".zip")))
                        result.Add(b with { Path = Path.Combine(DataRoot, "backups", b.Id + ".zip") });
                }
                catch (Exception e)when (e is IOException or System.Text.Json.JsonException or PolicyException)
                { /* Corrupt catalog entries are not silently trusted. */
                }
            }

            return result.OrderByDescending(x => x.CreatedAt).ToArray();
        }
    }

    public void RestoreBackup(string backupId)
    {
        lock (gate)
        {
            if (!Paused || runningId != null || Tasks().Any(t => t.Status is "running" or "cancelling"))
                throw new PolicyException("فعّل الإيقاف الطارئ وانتظر توقف المهام قبل الاستعادة");
            var backup = Backups().SingleOrDefault(x => x.Id == backupId) ?? throw new PolicyException("النسخة غير موجودة");
            Data.NoLinks(backup.Path);
            if (Data.HashFile(backup.Path) != backup.Sha256)
                throw new PolicyException("بصمة النسخة الاحتياطية لا تطابق السجل");
            var staging = Path.Combine(DataRoot, "restore-" + Data.Id());
            Directory.CreateDirectory(staging);
            string? old = null;
            bool closed = false;
            bool swapping = false;
            var moved = new HashSet<string>();
            var originallyAbsent = new HashSet<string>();
            try
            {
                using (var z = ZipFile.OpenRead(backup.Path))
                {
                    var manifestEntry = z.GetEntry("manifest.json") ?? throw new PolicyException("بيان النسخة مفقود");
                    if (manifestEntry.Length > 2 * 1024 * 1024)
                        throw new PolicyException("بيان النسخة كبير جدًا");
                    BackupManifest manifest;
                    using (var reader = new StreamReader(manifestEntry.Open()))
                        manifest = Data.Decode<BackupManifest>(reader.ReadToEnd());
                    if (manifest.Format != 1 || manifest.Files.Count > 4096 || !manifest.Files.ContainsKey("center.sqlite3"))
                        throw new PolicyException("صيغة النسخة غير مدعومة");
                    var entries = z.Entries.Where(e => e.FullName != "manifest.json").ToArray();
                    if (entries.Length != manifest.Files.Count || entries.Select(e => e.FullName).Distinct(StringComparer.OrdinalIgnoreCase).Count() != entries.Length)
                        throw new PolicyException("قائمة ملفات النسخة لا تطابق البيان");
                    long total = 0;
                    foreach (var entry in entries)
                    {
                        if (entry.FullName != "center.sqlite3" && !entry.FullName.StartsWith("results/", StringComparison.Ordinal))
                            throw new PolicyException("ملف غير مسموح في النسخة");
                        if (!manifest.Files.TryGetValue(entry.FullName, out var expected))
                            throw new PolicyException("ملف غير موثق");
                        total += entry.Length;
                        if (entry.Length > 1024L * 1024 * 1024 || total > 2L * 1024 * 1024 * 1024)
                            throw new PolicyException("نسخة تتجاوز الحد");
                        var target = Data.SafePath(staging, entry.FullName);
                        Directory.CreateDirectory(Path.GetDirectoryName(target)!);
                        entry.ExtractToFile(target, false);
                        if (Data.HashFile(target) != expected)
                            throw new PolicyException("فشل تحقق ملف النسخة");
                    }
                }

                var stagedDb = Path.Combine(staging, "center.sqlite3");
                using (var check = new SqliteConnection("Data Source=" + stagedDb + ";Mode=ReadOnly;Pooling=False"))
                {
                    check.Open();
                    using var command = check.CreateCommand();
                    command.CommandText = "PRAGMA integrity_check";
                    if (command.ExecuteScalar()?.ToString() != "ok")
                        throw new PolicyException("قاعدة النسخة تالفة");
                    command.CommandText = "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name IN ('agents','tasks','knowledge','knowledge_versions','settings','messages','plans','audit','models')";
                    if (Convert.ToInt32(command.ExecuteScalar(), System.Globalization.CultureInfo.InvariantCulture) != 9)
                        throw new PolicyException("مخطط قاعدة النسخة غير متوافق");
                }

                _ = CreateBackup();
                old = Path.Combine(DataRoot, "before-restore-" + Data.Id());
                Directory.CreateDirectory(old);
                db.Dispose();
                closed = true;
                swapping = true;
                foreach (var name in new[]
                {
                    "center.sqlite3",
                    "center.sqlite3-wal",
                    "center.sqlite3-shm",
                    "results"
                }

                )
                {
                    var source = Path.Combine(DataRoot, name);
                    var target = Path.Combine(old, name);
                    if (File.Exists(source))
                    {
                        File.Move(source, target);
                        moved.Add(name);
                    }
                    else if (Directory.Exists(source))
                    {
                        Directory.Move(source, target);
                        moved.Add(name);
                    }
                    else
                        originallyAbsent.Add(name);
                }

                File.Move(stagedDb, Path.Combine(DataRoot, "center.sqlite3"));
                var stagedResults = Path.Combine(staging, "results");
                if (Directory.Exists(stagedResults))
                    Directory.Move(stagedResults, Path.Combine(DataRoot, "results"));
                else
                    Directory.CreateDirectory(Path.Combine(DataRoot, "results"));
                db = new Store(Path.Combine(DataRoot, "center.sqlite3"));
                closed = false;
                db.Set("paused", "true");
                db.Execute("UPDATE agents SET enabled=0");
                RebaseRestoredArtifacts();
                Recover();
                db.Event("backup_restored", backupId, "استعيدت البيانات؛ الوكلاء معطلون حتى إعادة التحقق. الحالة السابقة محفوظة.");
                swapping = false;
            }
            catch
            {
                if (swapping && old != null)
                {
                    if (!closed)
                        db.Dispose();
                    foreach (var name in new[]
                    {
                        "center.sqlite3",
                        "center.sqlite3-wal",
                        "center.sqlite3-shm",
                        "results"
                    }

                    )
                    {
                        if (!moved.Contains(name) && !originallyAbsent.Contains(name))
                            continue;
                        var current = Path.Combine(DataRoot, name);
                        if (File.Exists(current))
                            File.Move(current, current + ".failed-" + Data.Id());
                        else if (Directory.Exists(current))
                            Directory.Move(current, current + ".failed-" + Data.Id());
                        var previous = Path.Combine(old, name);
                        if (File.Exists(previous))
                            File.Move(previous, current);
                        else if (Directory.Exists(previous))
                            Directory.Move(previous, current);
                    }

                    db = new Store(Path.Combine(DataRoot, "center.sqlite3"));
                    closed = false;
                }

                throw;
            }
            finally
            {
                if (Directory.Exists(staging))
                    Directory.Delete(staging, true);
            }
        }
    }

    private void RebaseRestoredArtifacts()
    {
        foreach (var task in AllCompletedTasks())
        {
            var artifacts = task.Artifacts.Select(a => a with { FullPath = Data.SafePath(Path.Combine(DataRoot, "results", task.Id), a.RelativePath, true) }).ToArray();
            foreach (var a in artifacts)
                VerifyArtifact(a);
            db.Execute("UPDATE tasks SET artifacts=@p1 WHERE id=@p0", task.Id, Data.Encode(artifacts));
            var receipt = Path.Combine(DataRoot, "results", task.Id, "_completion.json");
            if (File.Exists(receipt))
            {
                var c = Data.Decode<Completion>(File.ReadAllText(receipt));
                Data.AtomicText(receipt, Data.Encode(c with { Artifacts = artifacts }));
            }
        }
    }
}
