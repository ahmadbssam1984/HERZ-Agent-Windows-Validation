# HERZ Windows acceptance source

Public source for independent Windows startup, application-guard, resource-limit, HTTP and recovery tests. This contains no learner files, accounts, home-device details, private central source evidence, logs, tokens, runtime binaries or old repair payloads.

Dependency setup downloads only the exact official Python and pypdf files pinned by size and SHA256 in docs/DEPENDENCY_LOCK.json. It preserves their license files and builds a fresh offline recovery seed. The application uses no pip or paid services. The optional CI browser driver installs pinned Playwright into the separate host Python; it does not install packages into the bundled application runtime.

The public profile is generic and central integration is disabled. Parser, worker guard, Windows Job Object code, HTTP handlers and lesson player are otherwise the reviewed implementation. Passing on a CI Windows Server does not establish identical home-device performance or full platform import compatibility.
