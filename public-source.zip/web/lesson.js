(() => {
  'use strict';
  const data = JSON.parse(document.getElementById('lesson-data').textContent);
  const root = document.getElementById('lesson-app');
  const storageKey = `herz-lesson:${data.bundle_id}:${data.version}`;
  let storageAvailable = true;
  let state = {lesson: 0, mode: 'learn', example: 0, steps: {}, answers: {}, attempts: {}, correct: {}, helped: {}, examAnswers: {}, exams: {}, muted: false, filter: null, sourcePage: 0, labNumber: 356};
  try {
    const saved = JSON.parse(localStorage.getItem(storageKey) || 'null');
    if (saved && saved.version === data.version && saved.state && typeof saved.state === 'object') state = {...state, ...saved.state};
    localStorage.setItem(storageKey + ':probe', '1');
    localStorage.removeItem(storageKey + ':probe');
  } catch (_) { storageAvailable = false; }
  state.lesson = Math.max(0, Math.min(Number(state.lesson) || 0, data.lessons.length - 1));
  if (!['learn', 'practice', 'exam', 'source', 'lab'].includes(state.mode)) state.mode = 'learn';
  for (const key of ['steps', 'answers', 'attempts', 'correct', 'helped', 'examAnswers', 'exams']) if (!state[key] || typeof state[key] !== 'object' || Array.isArray(state[key])) state[key] = {};
  const sound = new Audio(data.tone);
  sound.volume = .45;
  let selected = null;
  let pointer = null;
  let suppressClickUntil = 0;
  let notice = '';
  let celebrating = false;
  let lastTouchActivation = -Infinity;
  function el(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  }
  function button(text, action, className = 'btn') {
    const result = el('button', className, text);
    result.type = 'button';
    let touchStart = null;
    result.addEventListener('pointerdown', event => {
      touchStart = event.pointerType === 'touch' ? {x: event.clientX, y: event.clientY} : null;
    });
    result.addEventListener('pointercancel', () => { touchStart = null; });
    result.addEventListener('pointerup', event => {
      if (!touchStart || event.pointerType !== 'touch' || result.disabled) return;
      const distance = Math.hypot(event.clientX - touchStart.x, event.clientY - touchStart.y);
      touchStart = null;
      if (distance > 8) return;
      // Some mobile browsers suppress the compatibility click just after a drag.
      // Activate an actual tap once, while retaining click for mouse/keyboard.
      lastTouchActivation = performance.now();
      event.preventDefault(); action(event);
    });
    result.addEventListener('click', event => {
      // Suppression belongs to the player, not a replaced button instance.
      // A mobile compatibility click may target the newly rendered button.
      if (event.detail !== 0 && performance.now() - lastTouchActivation < 700) return;
      action(event);
    });
    return result;
  }
  function save() {
    if (!storageAvailable) return;
    try { localStorage.setItem(storageKey, JSON.stringify({version: data.version, state})); }
    catch (_) { storageAvailable = false; }
  }
  function stopSound() { sound.pause(); sound.currentTime = 0; }
  function celebrate() {
    celebrating = true;
    if (!state.muted) { stopSound(); sound.play().catch(() => {}); }
    const box = el('div', 'celebration');
    box.setAttribute('aria-hidden', 'true');
    for (let index = 0; index < 7; index++) box.append(el('span', `star star-${index}`, '✦'));
    document.body.append(box);
    setTimeout(() => { box.remove(); celebrating = false; }, 900);
  }
  function normalize(value) {
    return String(value ?? '').trim().replace(/[٠-٩]/g, char => char.charCodeAt(0) - 1632).replace(/[۰-۹]/g, char => char.charCodeAt(0) - 1776).replace(/٫/g, '.').replace(/−/g, '-').replace(/\s/g, '');
  }
  function equal(a, b) {
    const x = normalize(a), y = normalize(b);
    if (/^[+-]?\d+(?:\.\d+)?$/.test(x) && /^[+-]?\d+(?:\.\d+)?$/.test(y)) return Number.isFinite(Number(x)) && Number(x) === Number(y);
    return x === y;
  }
  function lesson() { return data.lessons[state.lesson]; }
  function questionState(q, exam = false) {
    const answers = exam ? state.examAnswers : state.answers;
    if (!answers[q.id] || typeof answers[q.id] !== 'object') answers[q.id] = {value: '', matches: {}, order: q.type === 'ordering' ? q.items.map((_, index) => q.items.length - 1 - index) : [], touched: false};
    return answers[q.id];
  }
  function answered(q, raw) {
    if (q.type === 'matching') return q.pairs.every(pair => raw.matches && raw.matches[pair.id]);
    if (q.type === 'ordering') return Boolean(raw.touched);
    return String(raw.value ?? '').trim().length > 0;
  }
  function correct(q, raw) {
    if (q.type === 'matching') return q.pairs.every(pair => raw.matches && raw.matches[pair.id] === pair.id);
    if (q.type === 'ordering') return Array.isArray(raw.order) && raw.order.length === q.items.length && raw.order.every((index, position) => index === position);
    return equal(raw.value, q.answer);
  }
  function answerText(q) {
    if (q.type === 'matching') return q.pairs.map(pair => `${pair.label} ← ${pair.target}`).join('؛ ');
    if (q.type === 'ordering') return q.items.join(' ← ');
    return q.answer;
  }
  function moveMode(mode) {
    stopSound(); selected = null; notice = ''; state.mode = mode; state.filter = null; save(); render();
  }
  function check(q, focusNext = false) {
    const raw = questionState(q);
    if (!answered(q, raw)) { notice = 'أكمل الإجابة أولًا، ثم اضغط تحقق.'; render(); focusInput(q.id); return; }
    notice = '';
    if (state.correct[q.id]) return;
    if (correct(q, raw)) {
      state.correct[q.id] = true;
      if (!state.helped[q.id]) celebrate();
    } else {
      state.attempts[q.id] = (state.attempts[q.id] || 0) + 1;
      if (state.attempts[q.id] >= 3) state.helped[q.id] = true;
    }
    save(); render();
    if (state.correct[q.id] && focusNext) {
      const inputs = Array.from(root.querySelectorAll('input[data-question]'));
      const next = inputs.find(input => !input.disabled && input.dataset.question !== q.id);
      if (next) next.focus();
    } else focusInput(q.id);
  }
  function focusInput(id) {
    const input = Array.from(root.querySelectorAll('input[data-question]')).find(element => element.dataset.question === id);
    if (input && !input.disabled) { input.focus(); input.setSelectionRange(input.value.length, input.value.length); }
  }
  function assign(q, target, source, exam, deferRender = false) {
    const raw = questionState(q, exam);
    for (const id of Object.keys(raw.matches)) if (raw.matches[id] === source) delete raw.matches[id];
    raw.matches[target] = source;
    raw.touched = true; selected = null; save();
    // Preserve the active touch target until the gesture fully finishes.
    // Replacing it during pointerup can swallow the next tap in Chromium.
    if (deferRender) {
      for (const slot of root.querySelectorAll('.match-slot')) {
        if (slot.dataset.qid !== q.id) continue;
        const pair = q.pairs.find(item => item.id === raw.matches[slot.dataset.slot]);
        slot.textContent = pair ? pair.label : 'ضع البطاقة هنا';
        slot.classList.toggle('filled', Boolean(pair));
      }
      for (const token of root.querySelectorAll('.match-token')) {
        if (token.dataset.qid !== q.id) continue;
        token.classList.toggle('assigned', Object.values(raw.matches).includes(token.dataset.dragId));
        token.classList.remove('selected'); token.setAttribute('aria-pressed', 'false');
      }
    } else render();
  }
  function renderQuestion(q, index, exam = false) {
    const submitted = exam && Boolean(state.exams[lesson().id]?.submitted);
    const raw = questionState(q, exam);
    const done = !exam && Boolean(state.correct[q.id]);
    const result = submitted ? correct(q, raw) : done;
    const attempts = state.attempts[q.id] || 0;
    const revealed = !exam && attempts >= 3;
    const card = el('article', 'question');
    card.dataset.questionCard = q.id;
    const heading = el('div', 'question-heading');
    heading.append(el('span', 'question-number', String(index + 1)), el('h3', '', q.prompt));
    card.append(heading);
    const locked = submitted || done;
    if (q.expression) card.append(el('p', 'math question-expression', q.expression.replace(/\*/g, '×').replace(/\//g, '÷')));
    const controls = el('div', 'answer-controls');
    if (q.type === 'input') {
      const label = el('label', 'input-label', 'إجابتك');
      const input = el('input', 'answer-input math');
      input.type = 'text'; input.inputMode = 'decimal'; input.autocomplete = 'off'; input.spellcheck = false;
      input.setAttribute('aria-label', `إجابة السؤال ${index + 1}`);
      input.dataset.question = q.id; input.value = String(raw.value || ''); input.disabled = locked; input.maxLength = 80;
      if (submitted || done) input.classList.add(result ? 'is-correct' : 'is-wrong');
      else if (!exam && attempts && !revealed) input.classList.add('is-wrong');
      input.addEventListener('input', event => {
        raw.value = input.value; raw.touched = true; save();
        if (!exam && !event.isComposing && equal(raw.value, q.answer)) check(q, true);
      });
      input.addEventListener('keydown', event => { if (event.key === 'Enter' && !exam) { event.preventDefault(); check(q, true); } });
      label.append(input); controls.append(label);
    } else if (q.type === 'mcq') {
      const options = el('div', 'options');
      q.options.forEach((option, optionIndex) => {
        const choose = button('', () => { raw.value = option; raw.touched = true; save(); if (exam) render(); else check(q); }, 'option');
        choose.append(el('b', 'choice-letter', 'ABCD'[optionIndex]), el('span', 'math', option));
        choose.disabled = locked;
        choose.setAttribute('aria-pressed', String(raw.value === option));
        if (raw.value === option) choose.classList.add('selected');
        if ((submitted || done) && raw.value === option) choose.classList.add(result ? 'is-correct' : 'is-wrong');
        options.append(choose);
      });
      controls.append(options);
    } else if (q.type === 'matching') {
      controls.append(el('p', 'small muted', 'اسحب البطاقة إلى مكانها، أو انقر البطاقة ثم مكان الإجابة. تعمل الطريقة أيضًا بلوحة المفاتيح.'));
      const grid = el('div', 'matching');
      const pool = el('div', 'matching-pool');
      [...q.pairs].reverse().forEach(pair => {
        const used = Object.values(raw.matches).includes(pair.id);
        const item = button(pair.label, () => { if (Date.now() < suppressClickUntil) return; selected = {qid: q.id, source: pair.id}; render(); }, 'match-token');
        item.disabled = locked;
        item.dataset.dragId = pair.id;
        item.dataset.qid = q.id;
        if (selected?.qid === q.id && selected.source === pair.id) item.classList.add('selected');
        if (used) item.classList.add('assigned');
        item.setAttribute('aria-pressed', String(selected?.qid === q.id && selected.source === pair.id));
        item.addEventListener('pointerdown', event => { if (locked) return; pointer = {qid: q.id, source: pair.id, question: q, exam, startX: event.clientX, startY: event.clientY}; item.setPointerCapture(event.pointerId); });
        pool.append(item);
      });
      const slots = el('div', 'matching-slots');
      q.pairs.forEach(pair => {
        const row = el('div', 'match-row');
        row.append(el('b', 'math match-target', pair.target));
        const existing = q.pairs.find(item => item.id === raw.matches[pair.id]);
        const slot = button(existing ? existing.label : 'ضع البطاقة هنا', () => {
          if (locked) return;
          if (selected?.qid === q.id) assign(q, pair.id, selected.source, exam);
          else if (existing) { delete raw.matches[pair.id]; save(); render(); }
        }, 'match-slot');
        slot.dataset.slot = pair.id; slot.dataset.qid = q.id;
        slot.disabled = locked;
        slot.setAttribute('aria-label', `المكان المقابل لـ ${pair.target}${existing ? '، ' + existing.label : ''}`);
        if (existing) slot.classList.add('filled');
        if (submitted || done) slot.classList.add(raw.matches[pair.id] === pair.id ? 'is-correct' : 'is-wrong');
        row.append(slot); slots.append(row);
      });
      grid.append(pool, slots); controls.append(grid);
    } else if (q.type === 'ordering') {
      const list = el('ol', 'ordering');
      raw.order.forEach((itemIndex, position) => {
        const row = el('li', 'ordering-item');
        row.append(el('span', '', q.items[itemIndex]));
        for (const [delta, label] of [[-1, '↑'], [1, '↓']]) {
          const move = button(label, () => {
            const next = position + delta;
            [raw.order[position], raw.order[next]] = [raw.order[next], raw.order[position]];
            raw.touched = true; save(); render();
          }, 'icon-btn');
          move.disabled = locked || position + delta < 0 || position + delta >= raw.order.length;
          move.setAttribute('aria-label', `${delta < 0 ? 'حرّك للأعلى' : 'حرّك للأسفل'}: ${q.items[itemIndex]}`);
          row.append(move);
        }
        list.append(row);
      });
      controls.append(list);
    }
    card.append(controls);
    if (!exam && q.type !== 'mcq' && !done) card.append(button('تحقّق من إجابتي', () => check(q, true), 'btn primary'));
    const feedback = el('div', 'feedback');
    feedback.setAttribute('aria-live', 'polite');
    if (submitted) {
      feedback.classList.add(result ? 'success' : 'error');
      feedback.append(el('strong', '', result ? '✓ إجابة صحيحة' : 'راجع هذه الإجابة'), el('p', '', `الإجابة: ${answerText(q)}`), el('p', '', q.explanation || ''));
    } else if (!exam && done) {
      feedback.classList.add('success');
      feedback.append(el('strong', '', state.helped[q.id] ? '✓ أكملت السؤال بمساعدة.' : ['أحسنت! إجابة رائعة ✦', 'ممتاز! واصل التقدم ✦', 'رائع! فهمك يتطور ✦'][index % 3]));
      if (state.helped[q.id]) feedback.append(el('p', '', 'لا تُحتسب الإجابة المكشوفة نقطة مستقلة.'));
    } else if (!exam && revealed) {
      feedback.classList.add('help');
      feedback.append(el('strong', '', 'لنتعلم من المحاولات الثلاث'), el('p', '', `الإجابة: ${answerText(q)}`), el('p', '', q.explanation || ''));
    } else if (!exam && attempts) {
      feedback.classList.add('error');
      feedback.append(el('strong', '', `جرّب مرة أخرى · المحاولة ${attempts} من 3`), el('p', '', q.hint || 'راجع أعداد السؤال وإشارة العملية.'));
    }
    if (feedback.childNodes.length) card.append(feedback);
    return card;
  }
  document.addEventListener('pointerup', event => {
    if (!pointer) return;
    const active = pointer; pointer = null;
    if (Math.hypot(event.clientX - active.startX, event.clientY - active.startY) < 8) return;
    suppressClickUntil = Date.now() + 250;
    const target = document.elementFromPoint(event.clientX, event.clientY)?.closest('[data-slot]');
    if (target && target.dataset.qid === active.qid && !target.disabled) assign(active.question, target.dataset.slot, active.source, active.exam, true);
  });
  document.addEventListener('pointercancel', () => { pointer = null; });
  function renderLearn(container) {
    const current = lesson();
    container.append(el('p', 'intro', current.explanation));
    if (!current.examples.length) { container.append(el('div', 'empty-state', 'افتح تبويب المصدر لمراجعة النص والتغطية.')); return; }
    state.example = Math.max(0, Math.min(Number(state.example) || 0, current.examples.length - 1));
    const tabs = el('nav', 'example-tabs'); tabs.setAttribute('aria-label', 'الأمثلة');
    current.examples.forEach((example, index) => {
      const tab = button(example.title, () => { stopSound(); state.example = index; notice = ''; save(); render(); }, 'example-tab');
      if (index === state.example) { tab.classList.add('active'); tab.setAttribute('aria-current', 'true'); }
      tabs.append(tab);
    });
    container.append(tabs);
    const example = current.examples[state.example];
    const count = Math.min(state.steps[example.id] || 0, example.steps.length);
    const card = el('article', 'example-card');
    card.append(el('span', 'eyebrow', 'نحل معًا · خطوة بخطوة'), el('h2', '', example.title), el('p', '', example.description));
    if (example.math) card.append(el('div', 'math main-equation', example.math));
    for (let index = 0; index < count; index++) {
      const step = example.steps[index];
      const row = el('div', 'step');
      row.append(el('span', 'step-number', String(index + 1)));
      const body = el('div'); body.append(el('p', '', step.text));
      if (step.math) body.append(el('p', 'math', step.math));
      row.append(body); card.append(row);
    }
    const actions = el('div', 'actions');
    if (count < example.steps.length) actions.append(button(count ? 'الخطوة التالية ←' : 'ابدأ الحل ←', () => { state.steps[example.id] = count + 1; save(); render(); }, 'btn primary'));
    else actions.append(el('span', 'complete-badge', '✓ انتهى المثال — حان دورك'));
    if (count) actions.append(button('أعد الشرح', () => { state.steps[example.id] = 0; save(); render(); }, 'btn subtle'));
    card.append(actions); container.append(card);
    if (count === example.steps.length) {
      const formative = current.questions.filter(q => q.role === 'formative' && q.example_id === example.id);
      if (formative.length) container.append(el('h2', 'section-title', 'تقييم بنائي · جرّب ما تعلمته'));
      formative.forEach((q, index) => container.append(renderQuestion(q, index)));
      const nav = el('div', 'actions');
      if (state.example + 1 < current.examples.length) nav.append(button('انتقل للمثال التالي ←', () => { state.example++; stopSound(); save(); render(); }, 'btn primary'));
      else nav.append(button('انتقل إلى التدريبات ←', () => moveMode('practice'), 'btn primary'));
      container.append(nav);
    }
  }
  function renderPractice(container) {
    const questions = state.filter ? lesson().questions.filter(q => state.filter.includes(q.id)) : lesson().questions.filter(q => q.role !== 'exam');
    container.append(el('h2', '', state.filter ? 'نتعلم من الأخطاء' : 'مساحة التدريب'), el('p', 'intro', 'كل سؤال فرصة جديدة للفهم. بعد ثلاث محاولات خاطئة يظهر الحل مع الشرح.'));
    const earned = questions.filter(q => state.correct[q.id] && !state.helped[q.id]).length;
    const assisted = questions.filter(q => state.helped[q.id]).length;
    container.append(el('div', 'score-strip', `إنجاز مستقل: ${earned} من ${questions.length} · أسئلة بمساعدة: ${assisted}`));
    if (!questions.length) container.append(el('div', 'empty-state', 'لا توجد تدريبات متاحة في هذا الجزء.'));
    questions.forEach((q, index) => container.append(renderQuestion(q, index)));
    if (state.filter) container.append(button('عرض جميع التدريبات', () => { state.filter = null; save(); render(); }, 'btn subtle'));
    if (lesson().questions.some(q => q.role === 'exam')) container.append(button('أنا مستعد للاختبار ←', () => moveMode('exam'), 'btn primary'));
  }
  function submitExam() {
    const questions = lesson().questions.filter(q => q.role === 'exam');
    if (state.exams[lesson().id]?.submitted) return;
    const missing = questions.filter(q => !answered(q, questionState(q, true)));
    if (missing.length) { notice = `بقي ${missing.length} سؤالًا دون إجابة. أكملها ثم سلّم الاختبار.`; render(); return; }
    state.exams[lesson().id] = {submitted: true, submittedAt: new Date().toISOString()}; notice = ''; save(); render();
  }
  function renderExam(container) {
    const questions = lesson().questions.filter(q => q.role === 'exam');
    const submitted = Boolean(state.exams[lesson().id]?.submitted);
    container.append(el('h2', '', 'اختبار الدرس'), el('p', 'intro', submitted ? 'انتهى الاختبار. راجع النتيجة ثم تدرب على أخطائك.' : 'أجب بنفسك. لا تظهر التلميحات أو صحة الإجابات قبل تسليم الاختبار. جميع الأسئلة متساوية الدرجة.'));
    if (!questions.length) { container.append(el('div', 'empty-state', 'لا يوجد اختبار مُعدّ لهذا الجزء.')); return; }
    if (submitted) {
      const earned = questions.filter(q => correct(q, questionState(q, true))).length;
      const summary = el('div', 'exam-summary');
      summary.append(el('span', '', 'نتيجتك'), el('strong', 'math', `${earned} / ${questions.length}`), el('span', '', `${Math.round(earned / questions.length * 100)}٪`));
      container.append(summary);
      const mistakes = questions.filter(q => !correct(q, questionState(q, true)));
      const actions = el('div', 'actions');
      if (mistakes.length) actions.append(button('إعادة التدرب على الأخطاء', () => {
        state.filter = mistakes.map(q => q.id); state.mode = 'practice';
        for (const q of mistakes) { delete state.answers[q.id]; delete state.attempts[q.id]; delete state.correct[q.id]; state.helped[q.id] = true; }
        save(); render();
      }, 'btn primary'));
      actions.append(button('محاولة اختبار جديدة', () => {
        for (const q of questions) delete state.examAnswers[q.id];
        delete state.exams[lesson().id]; save(); render();
      }, 'btn subtle'));
      container.append(actions);
    }
    questions.forEach((q, index) => container.append(renderQuestion(q, index, true)));
    if (!submitted) container.append(button('تسليم الاختبار وعرض النتيجة', submitExam, 'btn primary submit-exam'));
    container.append(el('p', 'small muted', 'هذه درجات تدريبية محفوظة داخل المتصفح، وليست امتحانًا رسميًا محميًا من تعديل بيانات الجهاز.'));
  }
  function renderSource(container) {
    container.append(el('h2', '', 'المصدر وسجل التغطية'));
    const warning = el('div', 'source-warning');
    warning.append(el('strong', '', data.source_format === 'original_demo' ? 'محتوى أصلي توضيحي' : 'مسودة تحويل تحتاج مراجعة التغطية'));
    for (const item of data.warnings) warning.append(el('p', '', item));
    container.append(warning);
    if (!data.pages.length) { container.append(el('p', 'intro', 'صُممت أمثلة هذا النموذج وتدريباته أصلًا لتوضيح وظائف البرنامج؛ لا يعتمد على صور كتاب.')); return; }
    state.sourcePage = Math.max(0, Math.min(Number(state.sourcePage) || 0, data.pages.length - 1));
    const select = el('select', 'page-select'); select.setAttribute('aria-label', 'اختر صفحة المصدر');
    data.pages.forEach((page, index) => { const option = el('option', '', `الصفحة / الجزء ${page.number}`); option.value = index; option.selected = index === state.sourcePage; select.append(option); });
    select.addEventListener('change', () => { state.sourcePage = Number(select.value); save(); render(); });
    container.append(select);
    const page = data.pages[state.sourcePage];
    if (page.issues.length) container.append(el('p', 'source-warning', page.issues.map(issue => typeof issue === 'string' ? issue : JSON.stringify(issue)).join(' · ')));
    const source = el('pre', 'source-text', page.text || 'لا يوجد نص مستخرج في هذا الجزء.');
    source.dir = 'auto'; container.append(source);
  }
  function svg(tag, attributes, text) {
    const node = document.createElementNS('http://www.w3.org/2000/svg', tag);
    for (const [key, value] of Object.entries(attributes)) node.setAttribute(key, value);
    if (text !== undefined) node.textContent = text;
    return node;
  }
  function renderLab(container) {
    if (!lesson().lab) { container.append(el('div', 'empty-state', 'لا يوجد مختبر معدّ لهذا الدرس.')); return; }
    container.append(el('h2', '', 'مختبر القيمة المنزلية'), el('p', 'intro', 'غيّر العدد وشاهد المئات والعشرات والآحاد. كل مربع كبير يمثل مئة، وكل عمود عشرة، وكل مربع صغير واحدًا.'));
    const box = el('div', 'lab-card');
    const label = el('label', 'lab-label', 'اختر عددًا من 0 إلى 999');
    const input = el('input', 'answer-input math'); input.type = 'number'; input.min = 0; input.max = 999; input.step = 1; input.value = state.labNumber; input.setAttribute('aria-label', 'عدد المختبر');
    const range = el('input', 'lab-range'); range.type = 'range'; range.min = 0; range.max = 999; range.value = state.labNumber; range.setAttribute('aria-label', 'حرّك لتغيير العدد');
    const output = el('div', 'lab-output');
    function draw(value) {
      const number = Math.max(0, Math.min(999, Math.floor(Number(value) || 0)));
      state.labNumber = number; input.value = number; range.value = number; output.replaceChildren();
      const h = Math.floor(number / 100), t = Math.floor(number / 10) % 10, o = number % 10;
      output.append(el('p', 'math lab-equation', `${number} = ${h * 100} + ${t * 10} + ${o}`));
      const visual = svg('svg', {viewBox: '0 0 600 230', role: 'img', 'aria-label': `${h} مئات، ${t} عشرات، ${o} آحاد`});
      visual.append(svg('text', {x: 110, y: 22, 'text-anchor': 'middle', class: 'svg-label'}, `${h} مئات`), svg('text', {x: 325, y: 22, 'text-anchor': 'middle', class: 'svg-label'}, `${t} عشرات`), svg('text', {x: 510, y: 22, 'text-anchor': 'middle', class: 'svg-label'}, `${o} آحاد`));
      for (let index = 0; index < h; index++) {
        const x = 10 + index % 3 * 62, y = 40 + Math.floor(index / 3) * 62;
        visual.append(svg('rect', {x, y, width: 54, height: 54, rx: 3, class: 'hundred-block'}));
        for (let line = 1; line < 10; line++) { visual.append(svg('path', {d: `M${x + line * 5.4},${y}v54 M${x},${y + line * 5.4}h54`, class: 'block-grid'})); }
      }
      for (let index = 0; index < t; index++) {
        const x = 225 + index * 22;
        visual.append(svg('rect', {x, y: 45, width: 15, height: 150, rx: 3, class: 'ten-block'}));
        for (let line = 1; line < 10; line++) visual.append(svg('path', {d: `M${x},${45 + line * 15}h15`, class: 'block-grid'}));
      }
      for (let index = 0; index < o; index++) visual.append(svg('rect', {x: 465 + index % 3 * 32, y: 55 + Math.floor(index / 3) * 42, width: 24, height: 24, rx: 4, class: 'one-block'}));
      output.append(visual); save();
    }
    input.addEventListener('change', () => draw(input.value)); range.addEventListener('input', () => draw(range.value));
    label.append(input); box.append(label, range, output, button('إعادة إلى 356', () => draw(356), 'btn subtle')); container.append(box); draw(state.labNumber);
  }
  function render() {
    if (!celebrating) stopSound();
    root.replaceChildren();
    const shell = el('div', 'lesson-shell');
    const top = el('header', 'topbar');
    const brand = el('div', 'brand'); brand.append(el('span', 'brand-mark', 'H'), el('div', '', 'HERZ Academy'));
    const topActions = el('div', 'top-actions'); topActions.append(el('span', 'offline-badge', '● يعمل دون إنترنت'));
    const mute = button(state.muted ? 'الصوت مكتوم' : 'نغمة التشجيع مفعّلة', () => { state.muted = !state.muted; stopSound(); save(); render(); }, 'btn subtle small'); mute.setAttribute('aria-pressed', String(state.muted)); topActions.append(mute);
    top.append(brand, topActions); shell.append(top);
    const hero = el('section', 'hero');
    hero.append(el('span', 'eyebrow', data.source_format === 'original_demo' ? 'تعلّم بفهم · خطوة بخطوة' : 'معاينة تأليف محلية · تحويل أولي'), el('h1', '', data.title), el('p', '', lesson().title === data.title ? 'أمثلة تفاعلية · تدريب ذاتي · اختبار بلا تلميحات' : lesson().title));
    const allPractice = lesson().questions.filter(q => q.role !== 'exam');
    const done = allPractice.filter(q => state.correct[q.id] && !state.helped[q.id]).length;
    const progressLabel = el('div', 'progress-label'); progressLabel.append(el('span', '', 'تقدم التدريب المستقل'), el('b', 'math', `${done} / ${allPractice.length}`));
    const progress = el('progress'); progress.max = Math.max(1, allPractice.length); progress.value = done; progress.setAttribute('aria-label', 'التقدم في التدريب');
    hero.append(progressLabel, progress); shell.append(hero);
    if (data.lessons.length > 1) {
      const select = el('select', 'lesson-select'); select.setAttribute('aria-label', 'اختر الدرس');
      data.lessons.forEach((item, index) => { const option = el('option', '', item.title); option.value = index; option.selected = state.lesson === index; select.append(option); });
      select.addEventListener('change', () => { stopSound(); state.lesson = Number(select.value); state.example = 0; state.mode = 'learn'; state.filter = null; notice = ''; save(); render(); }); shell.append(select);
    }
    const nav = el('nav', 'mode-tabs'); nav.setAttribute('aria-label', 'أجزاء الدرس');
    const modes = [['learn', '١', 'نتعلم معًا'], ['practice', '٢', 'نتدرب'], ['exam', '٣', 'اختبار الدرس']];
    if (lesson().lab) modes.push(['lab', '✦', 'المختبر']);
    modes.push(['source', '≡', 'المصدر والتغطية']);
    for (const [mode, number, label] of modes) {
      const tab = button('', () => moveMode(mode), 'mode-tab'); tab.append(el('span', 'mode-number', number), el('span', '', label));
      if (state.mode === mode) { tab.classList.add('active'); tab.setAttribute('aria-current', 'page'); }
      nav.append(tab);
    }
    shell.append(nav);
    if (!storageAvailable) shell.append(el('div', 'storage-notice', 'الحفظ الدائم غير متاح في هذه المعاينة المعزولة. يبقى التقدم أثناء فتح الصفحة؛ افتح الملف المُصدّر مباشرة لتجربة حفظ المتصفح.'));
    if (notice) { const n = el('div', 'notice', notice); n.setAttribute('role', 'status'); shell.append(n); }
    const main = el('main', 'content');
    if (state.mode === 'learn') renderLearn(main);
    if (state.mode === 'practice') renderPractice(main);
    if (state.mode === 'exam') renderExam(main);
    if (state.mode === 'source') renderSource(main);
    if (state.mode === 'lab') renderLab(main);
    shell.append(main, el('footer', '', 'HERZ Educational Agent · محتوى مستقل · توافق استيراد المنصة غير متحقق'));
    root.append(shell);
  }
  window.addEventListener('pagehide', stopSound);
  document.addEventListener('visibilitychange', () => { if (document.hidden) stopSound(); });
  render();
})();
