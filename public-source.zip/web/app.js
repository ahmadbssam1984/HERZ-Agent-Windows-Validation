/* HERZ Educational Agent — local dashboard, no third-party client dependencies. */
'use strict';
(() => {
  const $ = (id) => document.getElementById(id);
  const titles = {
    overview: ['لوحة القيادة', 'تابع ملفاتك، راجع النتائج، واصنع تجربتك التعليمية.', 'مساحة للإبداع، وأدوات للإنجاز'],
    workspace: ['الملفات والمهمات', 'أضف مستندًا، وتابع كل خطوة حتى المعاينة والتصدير.', 'من المصدر إلى المحتوى'],
    memory: ['الذاكرة والتعليمات', 'قواعدك وملاحظاتك في مكان واحد، محفوظة على جهازك.', 'كل تصحيح، خطوة إلى الأمام'],
    chat: ['المحادثة', 'أصدر تعليمات واضحة، وتابع ما نُفّذ فعليًا.', 'تواصل مع مساحة عملك'],
    diagnostics: ['الفحص والتشخيص', 'راجع حالة المكونات ونتائج الفحص قبل الاعتماد.', 'الجودة تبدأ من التحقق'],
    settings: ['الاتصالات والإعدادات', 'خصص مساحة العمل، واعرف حالة المحركات والتكاملات.', 'تحكم واضح، وإمكانات معلنة']
  };
  const statuses = {
    queued: ['في الانتظار', 'neutral'], running: ['قيد المعالجة', 'running'],
    paused: ['متوقفة مؤقتًا', 'warning'], cancelled: ['ملغاة', 'neutral'],
    failed: ['تحتاج إصلاحًا', 'danger'], completed: ['مكتملة محليًا', 'success'],
    needs_review: ['تحتاج مراجعة', 'warning']
  };
  const checkStatuses = {
    pass: ['نجح', 'success', '✓'], passed: ['نجح', 'success', '✓'],
    fail: ['لم ينجح', 'danger', '×'], failed: ['لم ينجح', 'danger', '×'],
    warning: ['تنبيه', 'warning', '!'], blocked: ['متعذر', 'warning', '!'],
    not_run: ['لم يُختبر', 'neutral', '—'], not_verified: ['غير متحقق', 'warning', '!'],
    not_applicable: ['لا ينطبق', 'neutral', '—'], unavailable: ['غير متاح', 'neutral', '—']
  };
  const capabilities = {
    pdf: ['استخراج PDF', 'استخراج النص المتاح؛ الصور الممسوحة تحتاج محرك OCR.'],
    docx: ['مستندات Word', 'قراءة DOCX مع الإبلاغ عن العناصر التي تحتاج إعادة بناء.'],
    ocr: ['التعرف الضوئي OCR', 'يتطلب محركًا محليًا ولغات مثبتة؛ لا يُفترض توفره.'],
    local_ai: ['الذكاء الاصطناعي المحلي', 'غير متاح في هذه النسخة؛ لم يُعتمد محرك اجتاز اختبارات العزل والتوافق.'],
    central: ['HERZ Command Center', 'التكامل يحتاج مشغّلًا معتمدًا في الوكيل المركزي.'],
    platform_import: ['استيراد HERZ Academy', 'يحتاج اجتياز المستورد الرسمي للإصدار المستهدف.'],
    speech: ['القراءة الصوتية', 'أصوات التشجيع متاحة؛ قراءة النصوص العربية والإنجليزية تحتاج محركًا معتمدًا.'],
    free_services: ['الخدمات والحسابات', 'لا تسجيل تلقائي في الخدمات ولا اتصال بحسابات خارجية في هذه النسخة.']
  };
  const categories = {permanent: 'تعليمات دائمة', feedback: 'تصحيح معتمد', reference: 'مرجع وملاحظة'};
  let state = null;
  let activeTab = 'overview';
  let currentToken = '';
  let polling = null;
  let refreshing = false;
  let shuttingDown = false;
  let uploadOperation = null;
  let previewURL = null;
  let previewSequence = 0;
  let lastJobs = '';
  let lastRules = '';
  let lastEvents = '';
  let lastCapabilities = '';
  let settingsDirty = false;
  let lastChecks = [];
  let explicitDiagnostics = false;

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined && text !== null) node.textContent = String(text);
    return node;
  }

  function icon(name) {
    const node = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    use.setAttribute('href', '#i-' + name);
    node.setAttribute('aria-hidden', 'true');
    node.append(use);
    return node;
  }

  function text(id, value) { $(id).textContent = value; }
  function finite(value) { return Number.isFinite(Number(value)) && value !== null && value !== '' ? Number(value) : null; }
  function number(value, digits = 0) {
    const v = finite(value);
    return v === null ? '—' : v.toLocaleString('en-US', {maximumFractionDigits: digits});
  }
  function date(value, short = false) {
    if (!value) return '';
    const timestamp = new Date(value);
    if (Number.isNaN(timestamp.valueOf())) return String(value);
    return timestamp.toLocaleString('ar', short ? {hour: '2-digit', minute: '2-digit'} : {month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'});
  }

  function toast(message, isError = false) {
    const box = el('div', 'toast' + (isError ? ' error' : ''));
    box.append(el('span', '', message));
    const close = el('button', '', '×');
    close.type = 'button';
    close.setAttribute('aria-label', 'إغلاق التنبيه');
    close.addEventListener('click', () => box.remove());
    box.append(close);
    $('toast-region').append(box);
    window.setTimeout(() => box.remove(), isError ? 14000 : 6500);
  }

  function readToken() {
    const fragment = new URLSearchParams(location.hash.slice(1));
    const fromHash = fragment.get('token');
    if (fromHash) {
      currentToken = fromHash;
      try { sessionStorage.setItem('herz.session.token', fromHash); } catch (_) { /* Memory fallback remains active. */ }
      history.replaceState(null, '', location.pathname + location.search);
    } else {
      try { currentToken = sessionStorage.getItem('herz.session.token') || ''; } catch (_) { currentToken = ''; }
    }
  }

  async function request(path, options = {}) {
    if (!currentToken) throw new Error('افتح البرنامج من ملف START للحصول على جلسة محلية مصرح بها.');
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), options.timeout || 45000);
    const abortOuter = () => controller.abort();
    if (options.signal) {
      if (options.signal.aborted) controller.abort();
      else options.signal.addEventListener('abort', abortOuter, {once: true});
    }
    const headers = {'Authorization': 'Bearer ' + currentToken};
    let body;
    if (options.raw !== undefined) {
      body = options.raw;
      headers['Content-Type'] = 'application/octet-stream';
    } else if (options.body !== undefined) {
      headers['Content-Type'] = 'application/json';
      body = JSON.stringify(options.body);
    }
    try {
      const response = await fetch(path, {method: options.method || 'GET', headers, body, signal: controller.signal, cache: 'no-store', credentials: 'omit', redirect: 'error'});
      if (!response.ok) {
        let message = 'تعذر إكمال الطلب (' + response.status + ').';
        try {
          const errorBody = await response.json();
          const details = errorBody.error || errorBody.message || errorBody.detail;
          if (details) message = typeof details === 'string' ? details : JSON.stringify(details);
        } catch (_) { /* Keep useful HTTP status without rendering arbitrary error HTML. */ }
        if (response.status === 401 || response.status === 403) message += ' أعد فتح البرنامج من START إذا انتهت الجلسة.';
        throw new Error(message);
      }
      if (options.response === 'blob') return await response.blob();
      if (options.response === 'text') return await response.text();
      if (response.status === 204) return {};
      return await response.json();
    } catch (error) {
      if (error.name === 'AbortError') {
        if (options.signal && options.signal.aborted) throw new Error('أُلغي الطلب.');
        throw new Error('انتهت مهلة الاتصال. تحقق من تشغيل البرنامج ثم أعد المحاولة.');
      }
      if (error instanceof TypeError) throw new Error('تعذر الاتصال بالبرنامج المحلي. تحقق من نافذة التشغيل ثم حدّث الصفحة.');
      throw error;
    } finally {
      clearTimeout(timeout);
      if (options.signal) options.signal.removeEventListener('abort', abortOuter);
    }
  }

  async function act(button, callback) {
    if (button && button.disabled) return;
    if (button) { button.disabled = true; button.setAttribute('aria-busy', 'true'); }
    try { await callback(); }
    catch (error) { toast(error.message || String(error), true); }
    finally { if (button) { button.disabled = false; button.removeAttribute('aria-busy'); } }
  }

  function showTab(tab, moveFocus = false) {
    if (!titles[tab]) return;
    activeTab = tab;
    document.querySelectorAll('.tab-panel').forEach((panel) => { panel.hidden = panel.id !== 'panel-' + tab; });
    document.querySelectorAll('[data-tab]').forEach((button) => {
      const active = button.dataset.tab === tab;
      button.classList.toggle('active', active);
      if (active) button.setAttribute('aria-current', 'page'); else button.removeAttribute('aria-current');
    });
    text('page-title', titles[tab][0]);
    text('breadcrumb-current', titles[tab][0]);
    text('page-description', titles[tab][1]);
    text('page-eyebrow', titles[tab][2]);
    document.title = titles[tab][0] + ' · HERZ';
    closeSidebar();
    if (moveFocus) { window.scrollTo(0, 0); $('main').focus({preventScroll: true}); }
  }

  function closeSidebar() {
    $('sidebar').classList.remove('open');
    $('sidebar-shade').hidden = true;
    $('menu-button').setAttribute('aria-expanded', 'false');
  }

  function empty(container, title, description, iconName = 'folder', action) {
    const box = el('div', 'empty-state');
    const symbol = el('span', 'empty-icon'); symbol.append(icon(iconName));
    box.append(symbol, el('strong', '', title), el('p', '', description));
    if (action) {
      const button = el('button', 'text-button', action.title);
      button.type = 'button';
      button.addEventListener('click', action.callback);
      box.append(button);
    }
    container.replaceChildren(box);
  }

  function statusPill(status) {
    const description = statuses[status] || [status || 'غير محددة', 'neutral'];
    return el('span', 'pill ' + description[1], description[0]);
  }

  function jobButton(job, action, title, iconName, extraClass = '') {
    const button = el('button', extraClass, '');
    button.type = 'button';
    button.dataset.jobId = job.id;
    button.dataset.jobAction = action;
    if (iconName) button.append(icon(iconName));
    button.append(document.createTextNode(title));
    return button;
  }

  function renderJob(job, compact = false) {
    const row = el('article', 'job');
    const fileIcon = el('span', 'job-file-icon'); fileIcon.append(icon('file'));
    const content = el('div', 'job-content');
    content.append(el('h3', 'job-title', job.title || job.filename || 'مهمة تعليمية'));
    content.append(el('p', 'job-filename', job.filename || 'نموذج أصلي'));
    const progress = Math.max(0, Math.min(100, finite(job.progress) || 0));
    content.append(el('p', 'job-stage', job.stage || (job.status === 'queued' ? 'بانتظار المعالجة' : '')));
    const progressRow = el('div', 'job-progress-row');
    const track = el('div', 'job-progress');
    track.setAttribute('role', 'progressbar');
    track.setAttribute('aria-valuemin', '0'); track.setAttribute('aria-valuemax', '100');
    track.setAttribute('aria-valuenow', String(Math.round(progress)));
    track.setAttribute('aria-label', 'تقدم ' + (job.title || 'المهمة'));
    const fill = el('span'); fill.style.width = progress + '%'; track.append(fill);
    progressRow.append(track, el('span', 'job-percent', Math.round(progress) + '%'));
    content.append(progressRow);
    if (job.error) content.append(el('p', 'job-error', job.error));
    const warnings = Array.isArray(job.warnings) ? job.warnings : [];
    if (!compact && warnings.length) {
      const message = typeof warnings[0] === 'string' ? warnings[0] : JSON.stringify(warnings[0]);
      content.append(el('p', 'job-warning', message + (warnings.length > 1 ? ' · و' + (warnings.length - 1) + ' ملاحظات في التقرير.' : '')));
    }
    const actions = el('div', 'job-actions');
    if (job.output_ready) {
      actions.append(jobButton(job, 'preview', 'معاينة', 'eye', 'preview-action'));
      actions.append(jobButton(job, 'download', 'تنزيل ZIP', 'download'));
      if (!compact) {
        actions.append(jobButton(job, 'validate', 'فحص الحزمة', 'shield'));
        actions.append(jobButton(job, 'report', 'التقرير', 'file'));
      }
    }
    if (job.status === 'running' || job.status === 'queued') actions.append(jobButton(job, 'pause', 'إيقاف مؤقت'));
    if (job.status === 'paused') actions.append(jobButton(job, 'resume', 'استئناف', 'play'));
    if (['failed', 'cancelled'].includes(job.status)) actions.append(jobButton(job, 'retry', 'إعادة المحاولة'));
    if (['running', 'queued', 'paused'].includes(job.status) && !compact) actions.append(jobButton(job, 'cancel', 'إلغاء'));
    if (actions.childNodes.length) content.append(actions);
    const meta = el('div', 'job-meta');
    meta.append(statusPill(job.status));
    const counts = job.counts || {};
    if (finite(job.pages_total) > 0) meta.append(el('span', 'job-counts', number(job.pages_done || 0) + ' / ' + number(job.pages_total) + ' صفحة'));
    else if (finite(counts.questions) > 0) meta.append(el('span', 'job-counts', number(counts.questions) + ' تدريبات'));
    row.append(fileIcon, content, meta);
    return row;
  }

  function renderJobs(jobs) {
    const fingerprint = JSON.stringify(jobs);
    if (fingerprint === lastJobs) return;
    lastJobs = fingerprint;
    const sorted = jobs.slice().sort((a, b) => String(b.created_at || '').localeCompare(String(a.created_at || '')));
    ['recent-jobs', 'all-jobs'].forEach((id) => {
      const target = $(id);
      if (!sorted.length) {
        empty(target, 'ابدأ بمهمتك الأولى', 'أضف ملف PDF أو Word، أو جرّب نموذجًا تفاعليًا قبل البدء.', 'folder', {title: 'إضافة ملف جديد ←', callback: openUpload});
      } else target.replaceChildren(...(id === 'recent-jobs' ? sorted.slice(0, 3) : sorted).map((job) => renderJob(job, id === 'recent-jobs')));
    });
    const selected = $('chat-job').value;
    const all = el('option', '', 'المساحة كاملة'); all.value = '';
    const options = sorted.map((job) => { const option = el('option', '', job.title || job.filename); option.value = job.id; return option; });
    $('chat-job').replaceChildren(all, ...options);
    if (sorted.some((job) => job.id === selected)) $('chat-job').value = selected;
  }

  function renderRules(rules, force = false) {
    const query = $('rule-search').value.trim().toLocaleLowerCase();
    const fingerprint = JSON.stringify(rules) + query;
    if (!force && fingerprint === lastRules) return;
    lastRules = fingerprint;
    const filtered = rules.filter((rule) => (rule.text + ' ' + (rule.tags || []).join(' ')).toLocaleLowerCase().includes(query));
    text('rules-subtitle', number(rules.length) + ' سجل محفوظ · ' + number(rules.filter((rule) => rule.enabled !== false).length) + ' مفعّل');
    if (!filtered.length) {
      empty($('rules-list'), query ? 'لا توجد نتائج مطابقة' : 'ذاكرتك جاهزة لاستقبال التعليمات', query ? 'جرّب كلمات أخرى للبحث.' : 'أضف التعليمات والتصحيحات التي تريد الاحتفاظ بها.', 'book');
      return;
    }
    const nodes = filtered.map((rule) => {
      const row = el('article', 'rule-item' + (rule.enabled === false ? ' disabled' : ''));
      const content = el('div', 'rule-content');
      const header = el('div', 'rule-header');
      header.append(el('span', 'pill running', categories[rule.category] || rule.category || 'تعليمة'));
      header.append(el('span', 'rule-date', date(rule.created_at)));
      if (rule.enabled === false) header.append(el('span', 'pill neutral', 'معطّلة'));
      content.append(header, el('p', 'rule-text', rule.text));
      const tags = el('div', 'rule-tags');
      (Array.isArray(rule.tags) ? rule.tags : []).forEach((tag) => tags.append(el('span', '', tag)));
      if (tags.childNodes.length) content.append(tags);
      const button = el('button', 'rule-toggle', rule.enabled === false ? 'تفعيل' : 'تعطيل');
      button.type = 'button'; button.dataset.ruleId = rule.id; button.dataset.enabled = rule.enabled === false ? 'true' : 'false';
      row.append(content, button); return row;
    });
    $('rules-list').replaceChildren(...nodes);
  }

  function renderEvents(events) {
    const fingerprint = JSON.stringify(events);
    if (fingerprint === lastEvents) return;
    lastEvents = fingerprint;
    if (!events.length) {
      const line = el('li'); line.append(el('span', 'event-dot'), el('span', 'event-text', 'سيظهر سجل النشاط هنا عند بدء العمل.'));
      $('events-list').replaceChildren(line); return;
    }
    $('events-list').replaceChildren(...events.slice().sort((a, b) => String(b.time || '').localeCompare(String(a.time || ''))).slice(0, 8).map((event) => {
      const li = el('li');
      const level = ['error', 'warning'].includes(event.level) ? event.level : '';
      li.append(el('span', 'event-dot ' + level), el('span', 'event-text', event.message || ''), el('time', 'event-time', date(event.time, true)));
      return li;
    }));
  }

  function capabilityDetails(value, fallback) {
    if (typeof value === 'boolean') return {ready: value, title: value ? 'متاح' : 'غير متاح', detail: fallback};
    if (!value) return {ready: false, title: 'غير متاح', detail: fallback};
    if (typeof value === 'string') {
      const ready = ['available', 'ready', 'enabled', 'connected', 'pass', 'verified'].includes(value);
      return {ready, title: ready ? 'متاح' : 'غير متحقق', detail: fallback};
    }
    const ready = value.available === true || value.ready === true || value.connected === true || ['available', 'ready', 'connected', 'verified'].includes(value.status);
    return {ready, title: ready ? 'متاح' : (value.status === 'blocked' ? 'متعذر' : 'غير متاح'), detail: value.detail || value.reason || value.message || fallback};
  }

  function renderCapabilities(values) {
    const fingerprint = JSON.stringify(values);
    if (fingerprint === lastCapabilities) return;
    lastCapabilities = fingerprint;
    $('capabilities-list').replaceChildren(...Object.entries(capabilities).map(([key, labels]) => {
      const data = capabilityDetails(values[key], labels[1]);
      const card = el('article', 'capability');
      const header = el('div', 'capability-header');
      header.append(el('h3', '', labels[0]), el('span', 'pill ' + (data.ready ? 'success' : 'neutral'), data.title));
      card.append(header, el('p', '', data.detail)); return card;
    }));
    const model = capabilityDetails(values.local_ai, '');
    text('chat-engine-label', model.ready ? 'النموذج المحلي متاح وفق حالة الاتصال الحالية.' : 'أوامر محلية · التوليد الحر غير متصل حاليًا');
  }

  function renderChecks(checks) {
    lastChecks = Array.isArray(checks) ? checks : [];
    if (!lastChecks.length) {
      empty($('checks-list'), 'ابدأ بفحص مساحة العمل', 'اضغط «تشغيل التشخيص» لعرض النتائج الفعلية، وأي مكونات غير متاحة.', 'shield');
      text('checks-summary', 'لم يُشغّل بعد'); $('checks-summary').className = 'pill neutral'; return;
    }
    const passed = lastChecks.filter((check) => ['pass', 'passed'].includes(check.status)).length;
    const failed = lastChecks.filter((check) => ['fail', 'failed'].includes(check.status)).length;
    text('checks-summary', number(passed) + ' ناجح من ' + number(lastChecks.length));
    $('checks-summary').className = 'pill ' + (failed ? 'danger' : passed === lastChecks.length ? 'success' : 'warning');
    $('checks-list').replaceChildren(...lastChecks.map((check) => {
      const status = checkStatuses[check.status] || [check.status || 'غير محدد', 'neutral', '—'];
      const row = el('article', 'check-row');
      const detail = el('div', 'check-text');
      detail.append(el('strong', '', check.name || check.title || 'فحص'), el('p', '', check.detail || check.evidence || check.message || ''));
      row.append(el('span', 'check-symbol ' + status[1], status[2]), detail, el('span', 'pill ' + status[1], status[0])); return row;
    }));
  }

  function applyTheme(theme) {
    document.body.dataset.theme = ['violet', 'ocean', 'emerald'].includes(theme) ? theme : 'violet';
  }

  function renderState(data) {
    state = data;
    const jobs = Array.isArray(data.jobs) ? data.jobs : [];
    const rules = Array.isArray(data.rules) ? data.rules : [];
    text('stat-jobs', number(jobs.length)); text('nav-job-count', number(jobs.length));
    text('stat-active', number(jobs.filter((job) => ['running', 'queued'].includes(job.status)).length));
    text('stat-ready', number(jobs.filter((job) => job.output_ready).length));
    text('stat-rules', number(rules.filter((rule) => rule.enabled !== false).length));
    renderJobs(jobs); renderRules(rules); renderEvents(Array.isArray(data.events) ? data.events : []);
    renderCapabilities(data.capabilities || {});
    const resources = data.resources || {};
    text('memory-free', number(resources.memory_available_gb, 1));
    text('memory-total', number(resources.memory_total_gb, 1) + ' GB');
    text('disk-free', number(resources.disk_free_gb, 1) + ' GB');
    text('cpu-count', number(resources.cpu_count));
    const total = finite(resources.memory_total_gb);
    const free = finite(resources.memory_available_gb);
    const used = total > 0 && free !== null ? Math.max(0, Math.min(100, (1 - free / total) * 100)) : 0;
    $('memory-ring').style.setProperty('--used', used + '%');
    text('system-version', data.version || '—'); text('system-platform', resources.platform || '—');
    const settings = data.settings || {};
    applyTheme(settings.theme || 'violet');
    if (!settingsDirty) {
      const choice = document.querySelector('input[name="theme"][value="' + (['violet', 'ocean', 'emerald'].includes(settings.theme) ? settings.theme : 'violet') + '"]');
      if (choice) choice.checked = true;
    }
    if (!explicitDiagnostics && Array.isArray(data.checks) && data.checks.length) renderChecks(data.checks);
  }

  async function refresh(manual = false) {
    if (refreshing || shuttingDown) return;
    refreshing = true;
    try {
      const data = await request('/api/state', {timeout: 15000});
      renderState(data);
      $('connection-state').className = 'connection-state connected';
      $('connection-state').replaceChildren(el('span'), document.createTextNode('متصل محليًا'));
      $('connection-banner').hidden = true;
      if (manual) toast('تم تحديث حالة مساحة العمل.');
    } catch (error) {
      $('connection-state').className = 'connection-state failed';
      $('connection-state').replaceChildren(el('span'), document.createTextNode('غير متصل'));
      $('connection-banner').hidden = false;
      text('connection-banner', error.message);
      if (manual) toast(error.message, true);
    } finally { refreshing = false; }
  }

  function openUpload() {
    showTab('workspace', true);
    $('upload-form').scrollIntoView({block: 'start', behavior: 'smooth'});
    $('source-file').focus({preventScroll: true});
  }

  function selectedFile() {
    const file = $('source-file').files[0];
    if (!file) { text('file-label', 'اسحب ملفك هنا، أو اضغط للاختيار'); text('file-detail', 'لن نرفع مستندك إلى خدمة خارجية'); return; }
    text('file-label', file.name);
    text('file-detail', number(file.size / 1024 / 1024, 2) + ' MB · جاهز للإضافة');
    if (!$('upload-title').value.trim()) $('upload-title').value = file.name.replace(/\.(pdf|docx)$/i, '');
  }

  async function upload(event) {
    event.preventDefault();
    if (uploadOperation) return;
    const file = $('source-file').files[0];
    if (!file) return toast('اختر ملفًا أولًا.', true);
    if (!/\.(pdf|docx)$/i.test(file.name)) return toast('اختر ملف PDF أو DOCX فقط.', true);
    if (!file.size || file.size > 500 * 1024 * 1024) return toast('يجب أن يكون الملف غير فارغ وألا يتجاوز 500 MB.', true);
    if (!$('rights-confirmed').checked) return toast('أكد حقك في استخدام المستند قبل المعالجة.', true);
    const operation = {id: null, controller: new AbortController(), cancelled: false};
    uploadOperation = operation;
    $('upload-submit').disabled = true; $('source-file').disabled = true;
    $('cancel-upload').hidden = false; $('upload-progress').hidden = false;
    $('upload-meter').value = 0; text('upload-percent', '0%'); text('upload-stage', 'تجهيز نقل الملف إلى مساحة العمل');
    try {
      const opened = await request('/api/uploads', {method: 'POST', body: {filename: file.name, size: file.size, title: $('upload-title').value.trim() || file.name, rights_confirmed: true}, signal: operation.controller.signal});
      operation.id = opened.id;
      let offset = Number(opened.offset) || 0;
      const chunkSize = Math.min(4194304, Math.max(1, Number(opened.chunk_bytes) || 4194304));
      text('upload-stage', 'جارٍ نقل الملف إلى مساحة العمل المحلية');
      while (offset < file.size) {
        if (operation.cancelled) throw new Error('أُلغي رفع الملف.');
        const end = Math.min(offset + chunkSize, file.size);
        const result = await request('/api/uploads/' + encodeURIComponent(operation.id) + '?offset=' + offset, {method: 'PUT', raw: file.slice(offset, end), signal: operation.controller.signal, timeout: 90000});
        if (Number(result.offset) !== end) throw new Error('لم يتطابق حجم الجزء المحفوظ. أُلغي الرفع لمنع إنتاج ملف ناقص.');
        offset = end;
        const percent = Math.floor(offset / file.size * 100);
        $('upload-meter').value = percent; text('upload-percent', percent + '%');
      }
      operation.committing = true; $('cancel-upload').hidden = true;
      text('upload-stage', 'اكتمل النقل؛ جارٍ تسجيل مهمة المعالجة');
      await request('/api/uploads/' + encodeURIComponent(operation.id) + '/complete', {method: 'POST', body: {}, signal: operation.controller.signal, timeout: 90000});
      operation.id = null;
      $('upload-form').reset(); selectedFile();
      toast('أُضيفت المهمة. تابع تقدمها في قائمة المهمات.');
      await refresh();
    } catch (error) {
      if (operation.id) {
        try { await request('/api/uploads/' + encodeURIComponent(operation.id), {method: 'DELETE', body: {}}); }
        catch (_) { /* Incomplete upload cleanup is best effort; never declare it completed. */ }
      }
      toast(operation.cancelled ? 'أُلغي رفع الملف.' : error.message, !operation.cancelled);
    } finally {
      uploadOperation = null;
      $('upload-submit').disabled = false; $('source-file').disabled = false;
      $('cancel-upload').hidden = true; $('upload-progress').hidden = true;
    }
  }

  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const anchor = el('a'); anchor.href = url; anchor.download = filename;
    document.body.append(anchor); anchor.click(); anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 60000);
  }

  async function preview(jobId) {
    const sequence = ++previewSequence;
    const html = await request('/api/jobs/' + encodeURIComponent(jobId) + '/preview', {response: 'text'});
    if (sequence !== previewSequence) return;
    if (previewURL) URL.revokeObjectURL(previewURL);
    previewURL = URL.createObjectURL(new Blob([html], {type: 'text/html;charset=utf-8'}));
    const job = state && state.jobs.find((entry) => entry.id === jobId);
    text('preview-title', job ? job.title : 'معاينة الدرس');
    $('lesson-preview').src = previewURL;
    $('preview-surface').classList.remove('phone'); text('preview-device', 'عرض الهاتف');
    $('preview-dialog').showModal();
  }

  function closePreview() {
    previewSequence++;
    if ($('preview-dialog').open) $('preview-dialog').close();
    $('lesson-preview').removeAttribute('src');
    if (previewURL) { URL.revokeObjectURL(previewURL); previewURL = null; }
  }

  function openReport(title, report) {
    text('report-title', title);
    text('report-content', typeof report === 'string' ? report : JSON.stringify(report, null, 2));
    $('report-dialog').showModal();
  }

  async function jobAction(event) {
    const button = event.target.closest('[data-job-action]');
    if (!button) return;
    const id = button.dataset.jobId;
    const action = button.dataset.jobAction;
    await act(button, async () => {
      const base = '/api/jobs/' + encodeURIComponent(id);
      if (action === 'preview') await preview(id);
      else if (action === 'download') {
        const blob = await request(base + '/download', {response: 'blob', timeout: 120000});
        downloadBlob(blob, 'HERZ_Lesson_' + id + '.zip');
        toast('بدأ تنزيل الحزمة المستقلة. توافق استيراد المنصة يحتاج تحققًا منفصلًا.');
      } else if (action === 'report') openReport('تقرير التغطية والملاحظات', await request(base + '/report'));
      else if (action === 'validate') {
        const result = await request(base + '/validate', {method: 'POST', body: {}});
        openReport('نتائج فحص الحزمة', result);
      } else {
        await request(base + '/' + action, {method: 'POST', body: {}});
        const labels = {pause: 'طُلب الإيقاف المؤقت.', resume: 'طُلب استئناف المهمة.', cancel: 'أُلغيت المهمة.', retry: 'أُعيدت المهمة إلى المعالجة.'};
        toast(labels[action] || 'تم تحديث المهمة.'); await refresh();
      }
    });
  }

  function addMessage(role, value) {
    const message = el('article', 'chat-message ' + role);
    message.append(el('span', 'message-author', role === 'user' ? 'أنت' : 'مساعد HERZ'), el('p', '', value));
    $('chat-messages').append(message); $('chat-messages').scrollTop = $('chat-messages').scrollHeight;
  }

  function attachEvents() {
    document.querySelectorAll('[data-tab]').forEach((button) => button.addEventListener('click', () => showTab(button.dataset.tab, true)));
    document.querySelectorAll('[data-go]').forEach((button) => button.addEventListener('click', () => showTab(button.dataset.go, true)));
    document.querySelector('.brand').addEventListener('click', (event) => { event.preventDefault(); showTab('overview', true); });
    document.querySelectorAll('[data-open-upload]').forEach((button) => button.addEventListener('click', openUpload));
    $('menu-button').addEventListener('click', () => {
      const opened = $('sidebar').classList.toggle('open'); $('sidebar-shade').hidden = !opened;
      $('menu-button').setAttribute('aria-expanded', String(opened));
    });
    $('sidebar-shade').addEventListener('click', closeSidebar);
    document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeSidebar(); });
    $('refresh-button').addEventListener('click', () => refresh(true));
    document.querySelectorAll('[data-demo]').forEach((button) => button.addEventListener('click', () => act(button, async () => {
      await request('/api/jobs/demo', {method: 'POST', body: {}});
      toast('أُضيف النموذج الأصلي للتجربة.'); await refresh(); showTab('workspace', true);
    })));
    $('source-file').addEventListener('change', selectedFile);
    $('dropzone').addEventListener('dragover', (event) => { event.preventDefault(); if (!uploadOperation) $('dropzone').classList.add('drag-over'); });
    $('dropzone').addEventListener('dragleave', () => $('dropzone').classList.remove('drag-over'));
    $('dropzone').addEventListener('drop', (event) => {
      event.preventDefault(); $('dropzone').classList.remove('drag-over');
      if (uploadOperation) return;
      const files = event.dataTransfer && event.dataTransfer.files;
      if (!files || !files.length) return;
      if (files.length > 1) return toast('أضف مستندًا واحدًا لكل مهمة.', true);
      const transfer = new DataTransfer(); transfer.items.add(files[0]); $('source-file').files = transfer.files; selectedFile();
    });
    $('upload-form').addEventListener('submit', upload);
    $('cancel-upload').addEventListener('click', () => {
      if (uploadOperation && !uploadOperation.committing) { uploadOperation.cancelled = true; uploadOperation.controller.abort(); }
    });
    $('recent-jobs').addEventListener('click', jobAction); $('all-jobs').addEventListener('click', jobAction);
    $('rule-search').addEventListener('input', () => renderRules(state ? state.rules : [], true));
    $('rule-form').addEventListener('submit', (event) => {
      event.preventDefault();
      const button = $('rule-form').querySelector('button[type="submit"]');
      act(button, async () => {
        const value = $('rule-text').value.trim();
        if (!value) throw new Error('اكتب نص التعليمة أولًا.');
        const tags = $('rule-tags').value.split(/[,،]/).map((tag) => tag.trim()).filter(Boolean);
        await request('/api/rules', {method: 'POST', body: {text: value, category: $('rule-category').value, tags}});
        $('rule-text').value = ''; $('rule-tags').value = '';
        toast('حُفظت التعليمة في الذاكرة المحلية.'); await refresh();
      });
    });
    $('rules-list').addEventListener('click', (event) => {
      const button = event.target.closest('[data-rule-id]'); if (!button) return;
      act(button, async () => {
        await request('/api/rules/' + encodeURIComponent(button.dataset.ruleId), {method: 'PUT', body: {enabled: button.dataset.enabled === 'true'}});
        await refresh(); toast('تم تحديث حالة التعليمة مع الاحتفاظ بسجلها.');
      });
    });
    document.querySelectorAll('[data-prompt]').forEach((button) => button.addEventListener('click', () => { $('chat-input').value = button.dataset.prompt; $('chat-input').focus(); }));
    $('chat-form').addEventListener('submit', (event) => {
      event.preventDefault();
      act($('chat-submit'), async () => {
        const message = $('chat-input').value.trim(); if (!message) return;
        addMessage('user', message); $('chat-input').value = '';
        const body = {message}; if ($('chat-job').value) body.job_id = $('chat-job').value;
        try {
          const result = await request('/api/chat', {method: 'POST', body, timeout: 180000});
          addMessage('assistant', result.reply || 'لم يصل رد نصي من المحرك.'); await refresh();
        } catch (error) { addMessage('assistant', 'تعذر تنفيذ الرسالة: ' + error.message); throw error; }
      });
    });
    $('chat-input').addEventListener('keydown', (event) => { if (event.key === 'Enter' && (event.ctrlKey || event.metaKey)) { event.preventDefault(); $('chat-form').requestSubmit(); } });
    $('run-diagnostics').addEventListener('click', () => act($('run-diagnostics'), async () => {
      const result = await request('/api/diagnostics', {method: 'POST', body: {}, timeout: 120000});
      explicitDiagnostics = true; renderChecks(result.checks || []); toast('اكتمل التشخيص؛ راجع النتائج وما لم يُختبر.');
    }));
    $('backup-button').addEventListener('click', () => act($('backup-button'), async () => {
      const result = await request('/api/backup', {method: 'POST', body: {}, timeout: 180000});
      const blob = await request('/api/backup', {response: 'blob', timeout: 180000});
      downloadBlob(blob, result.filename || 'HERZ_Workspace_Backup.zip'); toast('بدأ تنزيل النسخة الاحتياطية.');
    }));
    $('settings-form').addEventListener('change', () => { settingsDirty = true; });
    $('settings-form').addEventListener('submit', (event) => {
      event.preventDefault();
      act($('settings-form').querySelector('button[type="submit"]'), async () => {
        const chosen = document.querySelector('input[name="theme"]:checked');
        const body = {theme: chosen ? chosen.value : 'violet'};
        const result = await request('/api/settings', {method: 'POST', body});
        settingsDirty = false; applyTheme(result.settings ? result.settings.theme : body.theme); toast('حُفظت الإعدادات.'); await refresh();
      });
    });
    $('shutdown-button').addEventListener('click', () => $('confirm-dialog').showModal());
    $('dismiss-shutdown').addEventListener('click', () => $('confirm-dialog').close());
    $('confirm-shutdown').addEventListener('click', () => act($('confirm-shutdown'), async () => {
      await request('/api/shutdown', {method: 'POST', body: {}});
      shuttingDown = true; clearInterval(polling); $('confirm-dialog').close();
      $('connection-state').className = 'connection-state';
      $('connection-state').replaceChildren(el('span'), document.createTextNode('متوقف'));
      $('connection-banner').hidden = false; text('connection-banner', 'توقف البرنامج بأمان. أعد فتح ملف START لاستئناف العمل.');
      document.querySelectorAll('button').forEach((button) => { if (!button.closest('dialog') && button.id !== 'menu-button') button.disabled = true; });
    }));
    $('close-preview').addEventListener('click', closePreview);
    $('preview-dialog').addEventListener('close', closePreview);
    $('preview-device').addEventListener('click', () => {
      const phone = $('preview-surface').classList.toggle('phone'); text('preview-device', phone ? 'عرض الحاسوب' : 'عرض الهاتف');
    });
    $('close-report').addEventListener('click', () => $('report-dialog').close());
    window.addEventListener('beforeunload', (event) => { if (uploadOperation) { event.preventDefault(); event.returnValue = ''; } });
  }

  readToken(); attachEvents();
  empty($('recent-jobs'), 'جارٍ قراءة مساحة العمل', 'ستظهر المهمات بعد الاتصال بالخادم المحلي.', 'folder');
  empty($('all-jobs'), 'جارٍ قراءة مساحة العمل', 'ستظهر المهمات بعد الاتصال بالخادم المحلي.', 'folder');
  renderChecks([]); renderCapabilities({});
  refresh();
  polling = window.setInterval(() => { if (!document.hidden) refresh(); }, 2200);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });
})();
