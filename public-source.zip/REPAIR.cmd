@echo off
setlocal DisableDelayedExpansion
set "HERZ_ROOT=%~dp0"
cd /d "%HERZ_ROOT%"
if errorlevel 1 goto folder_error
if not exist "%HERZ_ROOT%runtime\python.exe" goto runtime_error
echo Restoring damaged program files from the offline repair seed...
"%HERZ_ROOT%runtime\python.exe" -I "%HERZ_ROOT%repair\repair_bootstrap.py"
set "HERZ_EXIT=%ERRORLEVEL%"
if "%HERZ_EXIT%"=="0" goto done
echo.
echo The operation reported a problem. Read the message above.
echo Open FIRST_RUN_AR.html for the short Arabic guide.
goto done
:runtime_error
echo The portable runtime is missing. Run RESTORE_RUNTIME.cmd.
set "HERZ_EXIT=1"
goto done
:folder_error
echo Extract the entire ZIP into a writable local folder first.
set "HERZ_EXIT=1"
:done
echo.
if not "%HERZ_NONINTERACTIVE%"=="1" pause
exit /b %HERZ_EXIT%
