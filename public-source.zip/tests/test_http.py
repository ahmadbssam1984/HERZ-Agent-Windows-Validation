"""Real loopback HTTP and upload-state tests, never public network traffic."""
import concurrent.futures
import http.client
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'vendor'))
from agent.http_server import Server
from agent.service import Service,MAX_UPLOAD,private_path


class HTTPTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.service=Service(Path(self.temp.name)/'data')
        self.token='test-token-'+('a'*40)
        self.server=Server(self.service,self.token)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.origin=self.server.origin

    def tearDown(self):
        self.service.close();self.server.shutdown();self.server.server_close();self.thread.join(2);self.temp.cleanup()

    def request(self,method,path,body=None,headers=None,authorized=True,raw=False):
        h={'Authorization':'Bearer '+self.token} if authorized else {}
        if body is not None:
            h['Content-Type']='application/octet-stream' if raw else 'application/json'
            payload=body if raw else json.dumps(body).encode('utf-8')
        else:payload=None
        h.update(headers or {})
        client=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=5)
        try:
            client.request(method,path,body=payload,headers=h)
            response=client.getresponse();data=response.read();status=response.status
            headers=dict(response.getheaders())
            try:data=json.loads(data)
            except (ValueError,UnicodeError):pass
            return status,data,headers
        finally:client.close()

    def begin(self,size=8,name='sample.pdf'):
        code,body,_=self.request('POST','/api/uploads',{'filename':name,'size':size,'title':'تجربة','rights_confirmed':True})
        self.assertEqual(code,201,body);return body['id']

    def test_health_is_minimal_and_state_needs_bearer(self):
        code,body,_=self.request('GET','/api/health',authorized=False)
        self.assertEqual(code,200);self.assertEqual(set(body),{'app','version'})
        self.assertEqual(self.request('GET','/api/state',authorized=False)[0],403)
        code,body,headers=self.request('GET','/api/state')
        self.assertEqual(code,200);self.assertNotIn(self.token,json.dumps(body))
        self.assertIn("sha256-",headers['Content-Security-Policy'])
        self.assertNotIn("'unsafe-inline'",headers['Content-Security-Policy'].split('script-src ')[1].split(';')[0])

    def test_host_is_exact_numeric_loopback(self):
        for host in ('localhost:123','evil.test','127.1:'+str(self.server.server_port),'127.0.0.1','[::1]:'+str(self.server.server_port)):
            with self.subTest(host=host):self.assertEqual(self.request('GET','/api/health',headers={'Host':host},authorized=False)[0],403)

    def test_cross_site_and_mismatched_origins_rejected(self):
        for headers in ({'Origin':'https://evil.test'},{'Origin':'null'},{'Origin':self.origin+'/'},{'Sec-Fetch-Site':'cross-site'}):
            with self.subTest(headers=headers):self.assertEqual(self.request('POST','/api/jobs/demo',{},headers=headers)[0],403)
        self.assertEqual(self.request('GET','/api/state',headers={'Origin':self.origin})[0],200)

    def test_duplicate_security_headers_rejected(self):
        for field,value in (('Host',f'127.0.0.1:{self.server.server_port}'),('Origin',self.origin),('Authorization','Bearer '+self.token)):
            with self.subTest(field=field):
                client=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=5)
                try:
                    client.putrequest('GET','/api/state',skip_host=True)
                    client.putheader('Host',f'127.0.0.1:{self.server.server_port}')
                    client.putheader('Authorization','Bearer '+self.token)
                    if field=='Origin':client.putheader(field,value)
                    client.putheader(field,value);client.endheaders()
                    result=client.getresponse();result.read();self.assertIn(result.status,(400,403))
                finally:client.close()

    def test_non_ascii_bearer_is_denied_without_server_error(self):
        self.assertEqual(self.request('GET','/api/state',headers={'Authorization':'Bearer é'})[0],403)

    def test_api_json_rejects_duplicate_keys_nonfinite_and_deep_objects(self):
        for raw in (b'{"theme":"ocean","theme":"violet"}',b'{"theme":NaN}',b'{"n":'+b'['*1100+b'0'+b']'*1100+b'}'):
            with self.subTest(raw=raw[:30]):
                self.assertEqual(self.request('POST','/api/settings',raw,headers={'Content-Type':'application/json'},raw=True)[0],400)
        self.assertEqual(self.request('GET','/api/state',b'{}',headers={'Content-Type':'application/json'},raw=True)[0],400)

    def test_static_mime_types_do_not_depend_on_windows_registry(self):
        for path,mime in (('/app.js','text/javascript'),('/app.css','text/css'),('/','text/html')):
            status,body,headers=self.request('GET',path,authorized=False)
            self.assertEqual(status,200)
            self.assertTrue(headers['Content-Type'].startswith(mime))

    def test_static_path_traversal_and_privates_are_not_served(self):
        for path in ('/../run.py','/%2e%2e/run.py','/data/server.json','/vendor/pypdf/__init__.py','/api/jobs/../preview'):
            with self.subTest(path=path):self.assertEqual(self.request('GET',path)[0],404)

    def test_upload_rights_types_sizes_and_path_names(self):
        base={'filename':'sample.pdf','size':10,'rights_confirmed':True}
        for change in ({'rights_confirmed':False},{'size':True},{'size':MAX_UPLOAD+1},{'size':0},{'filename':'../x.pdf'},{'filename':'C:\\x.pdf'},{'filename':'x.exe'}):
            with self.subTest(change=change):self.assertEqual(self.request('POST','/api/uploads',dict(base,**change))[0],400)

    def test_upload_offsets_and_exact_commit(self):
        uid=self.begin(8)
        path=f'/api/uploads/{uid}'
        self.assertEqual(self.request('POST',path+'/complete',{})[0],400)
        self.assertEqual(self.request('PUT',path+'?offset=1',b'%PDF-',raw=True)[0],400)
        self.assertEqual(self.request('PUT',path+'?offset=0',b'%PDF-',raw=True)[0],200)
        self.assertEqual(self.request('PUT',path+'?offset=0',b'bad',raw=True)[0],400)
        self.assertEqual(self.request('PUT',path+'?offset=5',b'1.7',raw=True)[0],200)
        code,body,_=self.request('POST',path+'/complete',{})
        self.assertEqual(code,201,body);self.assertEqual(body['job']['status'],'queued')
        self.assertEqual((self.service.root/'jobs'/uid/'source.pdf').read_bytes(),b'%PDF-1.7')
        self.assertEqual(self.request('POST',path+'/complete',{})[0],404)

    def test_competing_chunks_cannot_append_twice(self):
        uid=self.begin(8);url=f'/api/uploads/{uid}?offset=0'
        with concurrent.futures.ThreadPoolExecutor(2) as pool:
            outcomes=list(pool.map(lambda _:self.request('PUT',url,b'%PDF-',raw=True)[0],range(2)))
        self.assertEqual(sorted(outcomes),[200,400])
        self.assertEqual((self.service.root/'uploads'/f'{uid}.part').read_bytes(),b'%PDF-')

    def test_upload_signature_failure_and_abort_preserve_safety(self):
        uid=self.begin(3)
        self.request('PUT',f'/api/uploads/{uid}?offset=0',b'BAD',raw=True)
        self.assertEqual(self.request('POST',f'/api/uploads/{uid}/complete',{})[0],400)
        self.assertEqual(self.request('DELETE',f'/api/uploads/{uid}',{})[0],200)
        self.assertFalse((self.service.root/'uploads'/f'{uid}.part').exists())

    def test_pending_upload_quota(self):
        for _ in range(4):self.begin(8)
        self.assertEqual(self.request('POST','/api/uploads',{'filename':'x.pdf','size':8,'rights_confirmed':True})[0],400)

    def test_worker_cannot_start_without_successful_preflight(self):
        with self.assertRaises(PermissionError):self.service.start()
        self.assertFalse(self.service.thread.is_alive())

    def test_job_actions_preserve_cancelled_and_pause_states(self):
        job=self.service.demo()['job'];jid=job['id']
        self.assertEqual(self.service.action(jid,'pause')['job']['status'],'paused')
        self.assertEqual(self.service.action(jid,'resume')['job']['status'],'queued')
        self.assertEqual(self.service.action(jid,'cancel')['job']['status'],'cancelled')
        with self.assertRaises(ValueError):self.service.action(jid,'resume')
        self.assertEqual(self.service.action(jid,'retry')['job']['status'],'queued')

    def test_private_paths_do_not_follow_symlinks(self):
        base=self.service.root
        outside=Path(self.temp.name)/'outside';outside.mkdir();(outside/'secret').write_text('secret')
        try:(base/'jobs'/'link').symlink_to(outside,target_is_directory=True)
        except OSError:self.skipTest('link creation unavailable for this Windows account')
        with self.assertRaises(ValueError):private_path(base,'jobs','link','secret')
        with self.assertRaises(ValueError):private_path(base,'..','outside','secret')

if __name__=='__main__':unittest.main()
