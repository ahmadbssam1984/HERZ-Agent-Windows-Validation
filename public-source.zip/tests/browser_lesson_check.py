"""Optional lesson browser checks on the selected app runtime and local browser.

The ordinary RUN_TESTS.cmd does not require Playwright. These developer checks do
not install software or modify shipped examples. Windows defaults to the bundled
runtime/python.exe and an existing Edge/Chrome; --app-python/HERZ_APP_PYTHON and
--browser/--browser-channel override these choices explicitly.
"""
from __future__ import annotations

import argparse
import subprocess
import tempfile
import time
from pathlib import Path

from browser_support import (ROOT, add_browser_arguments, resolve_runtime, launch_options, app_command, runtime_evidence, write_report)


def save_screenshot(page, output, name, full_page=True):
    if output:
        page.screenshot(path=str(output / name), full_page=full_page, animations="disabled")


def build_demo(runtime, directory):
    code = """import sys
from pathlib import Path
root=Path(sys.argv[1])
sys.path.insert(0,str(root/'vendor'));sys.path.insert(0,str(root))
from agent.lesson import build_package,demo_document
build_package(demo_document(),Path(sys.argv[2]),'رحلة الأعداد: نجمع ونطرح ونفهم')
"""
    subprocess.run(app_command(runtime, "-c", code, ROOT, directory), cwd=ROOT, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30, check=True)


def run_lesson(runtime, output, demo, evidence, sync_playwright):
    results = []
    browser, browser_version = None, None
    def passed(name, detail=""):
        results.append({"name": name, "status": "pass", "detail": detail})

    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(**launch_options(runtime))
            browser_version = browser.version
            context = browser.new_context(viewport={"width": 1440, "height": 1000}, reduced_motion="reduce")
            context.add_init_script("""window.__audioEvents=[];const originalPlay=HTMLMediaElement.prototype.play;
            HTMLMediaElement.prototype.play=function(){window.__playedAudio=this;const promise=originalPlay.call(this);promise.then(()=>window.__audioEvents.push('played'),()=>window.__audioEvents.push('rejected'));return promise;}""")
            page = context.new_page()
            errors, requests = [], []
            page.on("pageerror", lambda error: errors.append(str(error)))
            page.on("console", lambda message: errors.append(message.text) if message.type == "error" else None)
            page.on("request", lambda request: requests.append(request.url))
            url = (demo / "index.html").as_uri()
            page.goto(url)
            assert page.locator(".example-card").count() == 1
            assert page.locator(".step").count() == 0
            save_screenshot(page, output, "lesson_desktop.png")
            page.get_by_role("button", name="ابدأ الحل ←", exact=True).click()
            for _ in range(3):
                page.get_by_role("button", name="الخطوة التالية ←", exact=True).click()
            assert page.locator(".step").count() == 4
            assert page.locator('[data-question-card="f1"]').count() == 1
            assert page.locator('[data-question-card="f2"]').count() == 0
            passed("one_example_and_linked_formative", "Only e1 and its f1 appear after four steps.")
            field = page.locator('input[data-question="f1"]')
            field.fill("3")
            assert page.locator(".feedback").count() == 0
            field.fill("37")
            assert page.locator(".feedback").count() == 0
            field.fill("٣٧٨")
            page.locator(".feedback.success").wait_for()
            passed("partial_input_arabic_digits", "3 and 37 do not cost attempts; ٣٧٨ completes correctly.")
            deadline = time.monotonic() + 3
            while not page.evaluate("window.__audioEvents.includes('played')") and time.monotonic() < deadline:
                page.wait_for_timeout(50)
            assert page.evaluate("window.__audioEvents.includes('played')"), "The browser did not play the bundled WAV"
            page.get_by_role("button", name="انتقل للمثال التالي ←", exact=True).click()
            assert page.evaluate("window.__playedAudio.paused && window.__playedAudio.currentTime===0")
            assert page.locator(".example-card").count() == 1
            assert page.locator('[data-question-card="f1"]').count() == 0
            page.get_by_role("button", name="ابدأ الحل ←", exact=True).click()
            for _ in range(3):
                page.get_by_role("button", name="الخطوة التالية ←", exact=True).click()
            assert page.locator('[data-question-card="f2"]').count() == 1
            passed("second_example_and_audio", "Second example has its own formative question; browser decoded/played WAV and navigation paused/reset it. No human listening assessment.")
            page.get_by_role("button", name="نتدرب", exact=False).click()
            q2 = page.locator('[data-question-card="f2"]')
            for attempt in range(3):
                q2.locator("input").fill("111")
                q2.get_by_role("button", name="تحقّق من إجابتي", exact=True).click()
                if attempt < 2:
                    assert "الإجابة:" not in q2.locator(".feedback").inner_text()
            assert "الإجابة: 315" in q2.inner_text()
            q2.locator("input").fill("315")
            assert "إنجاز مستقل: 1 من 5" in page.locator(".score-strip").inner_text()
            passed("third_error_reveal_without_credit", "Third submitted wrong answer reveals explanation; entering revealed answer gives no independent point.")
            mcq = page.locator('[data-question-card="p1"]')
            assert mcq.locator(".option").count() == 4
            mcq.get_by_role("button", name="B 356", exact=True).click()
            assert mcq.locator(".feedback.success").count() == 1
            passed("four_choice_mcq")
            matching = page.locator('[data-question-card="p2"]')
            for pair in ("h", "t", "o"):
                if pair == "h":
                    matching.locator(f'[data-drag-id="{pair}"]').focus()
                    matching.locator(f'[data-drag-id="{pair}"]').press("Enter")
                    matching.locator(f'[data-slot="{pair}"]').focus()
                    matching.locator(f'[data-slot="{pair}"]').press("Enter")
                else:
                    matching.locator(f'[data-drag-id="{pair}"]').click()
                    matching.locator(f'[data-slot="{pair}"]').click()
            matching.get_by_role("button", name="تحقّق من إجابتي", exact=True).click()
            assert matching.locator(".feedback.success").count() == 1
            passed("matching_click_keyboard_alternative")
            ordering = page.locator('[data-question-card="p3"]')
            for label in ("حرّك للأعلى: أجمع الآحاد", "حرّك للأعلى: أجمع الآحاد", "حرّك للأعلى: أجمع العشرات"):
                ordering.get_by_role("button", name=label, exact=True).click()
            ordering.get_by_role("button", name="تحقّق من إجابتي", exact=True).click()
            assert ordering.locator(".feedback.success").count() == 1
            passed("ordering_and_scoring")
            save_screenshot(page, output, "lesson_practice_desktop.png")
            page.get_by_role("button", name="اختبار الدرس", exact=False).first.click()
            assert page.locator(".feedback,.is-correct,.is-wrong").count() == 0
            page.locator('input[data-question="x1"]').fill("100")
            page.locator('input[data-question="x2"]').fill("444")
            page.locator('[data-question-card="x3"]').get_by_role("button", name="B 50", exact=True).click()
            assert page.locator(".feedback,.is-correct,.is-wrong").count() == 0
            page.reload()
            assert page.locator('input[data-question="x1"]').input_value() == "100"
            assert page.locator(".feedback,.is-correct,.is-wrong").count() == 0
            passed("exam_no_feedback_and_persist_before_submit")
            page.get_by_role("button", name="تسليم الاختبار وعرض النتيجة", exact=True).click()
            assert "2 / 3" in page.locator(".exam-summary").inner_text()
            assert page.locator('input[data-question="x1"]').is_disabled()
            page.reload()
            assert "2 / 3" in page.locator(".exam-summary").inner_text()
            passed("exam_scoring_lock_and_persistence", "2 correct of 3; answers locked after submission and retained on reload.")
            page.get_by_role("button", name="إعادة التدرب على الأخطاء", exact=True).click()
            assert page.locator("[data-question-card]").count() == 1
            assert page.locator('[data-question-card="x1"]').count() == 1
            assert page.locator(".feedback").count() == 0
            page.locator('input[data-question="x1"]').fill("468")
            assert "إنجاز مستقل: 0 من 1" in page.locator(".score-strip").inner_text()
            passed("retry_only_mistakes", "Previously revealed exam answers cannot inflate independent practice points.")
            page.get_by_role("button", name="اختبار الدرس", exact=False).first.click()
            page.get_by_role("button", name="محاولة اختبار جديدة", exact=True).click()
            assert page.locator('input[data-question="x1"]').input_value() == ""
            assert page.locator(".exam-summary,.feedback,.is-correct,.is-wrong").count() == 0
            passed("new_exam_clears_prior_attempt")
            page.get_by_role("button", name="المختبر", exact=False).click()
            page.get_by_label("عدد المختبر", exact=True).fill("999")
            page.get_by_label("عدد المختبر", exact=True).press("Tab")
            assert "999 = 900 + 90 + 9" in page.locator(".lab-equation").inner_text()
            for selector in (".hundred-block", ".ten-block", ".one-block"):
                assert page.locator(selector).count() == 9
            page.get_by_label("عدد المختبر", exact=True).fill("0")
            page.get_by_label("عدد المختبر", exact=True).press("Tab")
            assert page.locator(".hundred-block,.ten-block,.one-block").count() == 0
            passed("lab_place_values_and_zero")
            assert not errors, errors
            assert not [url for url in requests if url.startswith("http")]
            passed("offline_and_console", "No HTTP requests and no JavaScript/console errors.")
            context.close()

            mobile = browser.new_context(viewport={"width": 360, "height": 800}, has_touch=True, is_mobile=True, device_scale_factor=1)
            page = mobile.new_page()
            page.on("pageerror", lambda error: errors.append(str(error)))
            page.on("console", lambda message: errors.append(message.text) if message.type == "error" else None)
            page.on("request", lambda request: requests.append(request.url))
            page.goto(url)
            assert page.evaluate("document.documentElement.scrollWidth <= innerWidth")
            save_screenshot(page, output, "lesson_mobile_home.png")
            page.get_by_role("button", name="نتدرب", exact=False).click()
            matching = page.locator('[data-question-card="p2"]')
            matching.scroll_into_view_if_needed()
            cdp = mobile.new_cdp_session(page)
            for pair in ("h", "t", "o"):
                source = matching.locator(f'[data-drag-id="{pair}"]')
                target = matching.locator(f'[data-slot="{pair}"]')
                source.scroll_into_view_if_needed()
                a, b = source.bounding_box(), target.bounding_box()
                x1, y1 = a["x"] + a["width"] / 2, a["y"] + a["height"] / 2
                x2, y2 = b["x"] + b["width"] / 2, b["y"] + b["height"] / 2
                cdp.send("Input.dispatchTouchEvent", {"type": "touchStart", "touchPoints": [{"x": x1, "y": y1}]})
                for fraction in (.25, .5, .75, 1):
                    cdp.send("Input.dispatchTouchEvent", {"type": "touchMove", "touchPoints": [{"x": x1 + (x2 - x1) * fraction, "y": y1 + (y2 - y1) * fraction}]})
                cdp.send("Input.dispatchTouchEvent", {"type": "touchEnd", "touchPoints": []})
                assert target.inner_text() != "ضع البطاقة هنا"
            matching.get_by_role("button", name="تحقّق من إجابتي", exact=True).tap()
            matching.locator(".feedback.success").wait_for(timeout=3000)
            assert page.evaluate("document.documentElement.scrollWidth <= innerWidth")
            matching.scroll_into_view_if_needed()
            save_screenshot(page, output, "lesson_mobile_matching.png", full_page=False)
            passed("mobile_360_touch_drag", "Three simulated-touch card drags and check tap succeed at 360px without horizontal overflow; not a physical Android/WebView test.")
            first = page.locator('[data-question-card="f1"]')
            first.locator("input").fill("111")
            first.get_by_role("button", name="تحقّق من إجابتي", exact=True).tap()
            first.locator(".feedback.error").wait_for()
            assert "المحاولة 1 من 3" in first.locator(".feedback").inner_text()
            passed("touch_tap_counts_once", "One touch tap counts one wrong attempt; no compatibility-click duplication.")
            assert not errors, errors
            assert not [request for request in requests if request.startswith("http")], "Offline lesson made HTTP requests"
            mobile.close()
            browser.close()
    except Exception as error:
        results.append({"name": "browser_run", "status": "fail", "detail": repr(error)})
    finally:
        if browser and browser.is_connected():
            try:
                browser.close()
            except Exception:
                pass  # Playwright context may already have closed its event loop.
        report = {"success": bool(results) and all(item["status"] == "pass" for item in results), "passed": sum(item["status"] == "pass" for item in results), "runtime": evidence, "browser_version": browser_version, "checks": results, "not_run": ["physical Android/WebView", "human audio listening", "official HERZ importer", "user's physical computer"], "scope": "Actual reported OS and browser; generated with selected app Python. Touch/mobile sizes are simulated."}
        write_report(report, output, "LESSON_BROWSER_RESULTS.json")
    return 0 if report["success"] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    add_browser_arguments(parser)
    parser.add_argument("--output", type=Path, help="Optional local JSON/screenshot directory")
    args = parser.parse_args()
    runtime = resolve_runtime(args, parser)
    output = args.output.resolve() if args.output else None
    if output:
        output.mkdir(parents=True, exist_ok=True)
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        parser.exit(2, "Optional browser QA requires Playwright in a separate developer Python environment; nothing was installed.\n")
    try:
        evidence = runtime_evidence(runtime)
        with tempfile.TemporaryDirectory(prefix="herz-lesson-browser-") as folder:
            demo = Path(folder) / "offline_math"
            build_demo(runtime, demo)
            return run_lesson(runtime, output, demo, evidence, sync_playwright)
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        write_report({"success": False, "passed": 0, "failure": "Unable to run selected app Python/build: " + str(error)}, output, "LESSON_BROWSER_RESULTS.json")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
