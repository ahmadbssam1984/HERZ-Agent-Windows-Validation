"""Opt-in large-file API check; NOT collected by unittest discovery.

Run: python tests/large_pipeline_check.py --size-mib 500 --report PATH
Windows: add --app-python runtime/python.exe (also selected by default on Windows).
HERZ_APP_PYTHON can select the app runtime; psutil is optional in the host Python.
Uses temporary data and a synthetic PDF, and deletes both after the check.
This is a size/streaming test, not a scanned textbook or a home-PC benchmark.
"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import io
import json
import os
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import urllib.request
import zipfile
from pathlib import Path

from browser_support import resolve_runtime, app_command, runtime_evidence, close_server

APP = Path(__file__).resolve().parents[1]


def fixture(path: Path, size: int) -> str:
    """Write actual bytes, not a sparse file; preserve valid PDF xref offsets."""
    offsets = []
    with path.open("wb") as stream:
        stream.write(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
        objects = [
            b"<< /Type /Catalog /Pages 2 0 R >>",
            b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 600 800] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
            b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        ]
        content = b"BT /F1 12 Tf 50 700 Td (12 + 3 = ?) Tj ET"
        objects.append(b"<< /Length " + str(len(content)).encode() + b" >>\nstream\n" + content + b"\nendstream")
        for number, obj in enumerate(objects, 1):
            offsets.append(stream.tell())
            stream.write(f"{number} 0 obj\n".encode() + obj + b"\nendobj\n")
        offsets.append(stream.tell())
        padding = size - 2000
        stream.write(b"6 0 obj\n<< /Length " + str(padding).encode() + b" >>\nstream\n")
        block = b"A" * (1024 * 1024)
        while padding:
            count = min(padding, len(block))
            stream.write(block[:count])
            padding -= count
        stream.write(b"\nendstream\nendobj\n")
        xref = stream.tell()
        stream.write(b"xref\n0 7\n0000000000 65535 f \n")
        for offset in offsets:
            stream.write(f"{offset:010d} 00000 n \n".encode())
        stream.write(b"trailer\n<< /Size 7 /Root 1 0 R >>\nstartxref\n" + str(xref).encode() + b"\n%%EOF\n")
        stream.write(b" " * (size - stream.tell()))
    return sha256(path)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--size-mib", type=int, default=500)
    parser.add_argument("--app-python", type=Path, help="Application Python; defaults to HERZ_APP_PYTHON, bundled runtime/python.exe on Windows, or current Python elsewhere")
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    if not 1 <= args.size_mib <= 500:
        parser.error("size-mib must be 1..500")
    runtime = resolve_runtime(argparse.Namespace(app_python=args.app_python, browser=None, browser_channel=None), parser)
    result = {
        "status": "failed",
        "source_bytes": args.size_mib * 1024 * 1024,
        "fixture": "Valid synthetic PDF: one text arithmetic page plus a large unreferenced uncompressed stream, written as real bytes (not sparse).",
        "limitations": [
            "This proves the tested synthetic source shape and size only, not a large scanned textbook, OCR, or full textbook conversion.",
            "Measured on the OS/runtime recorded in this report; not a benchmark of the user's physical computer.",
            "RSS samples are process resident memory, not all OS file-cache memory; short-lived peaks may be missed.",
            "This is a pipeline check on the reported OS, not full Windows UI, Android, or driver compatibility validation.",
        ],
    }
    started = time.perf_counter()
    process = None
    credentials = None
    temporary_root = None
    sample_count = 0
    stop_monitor = threading.Event()
    samples = {"driver_peak_sampled_rss_mib": 0.0, "server_peak_sampled_rss_mib": 0.0,
               "worker_peak_sampled_rss_mib": 0.0, "server_tree_peak_sampled_rss_mib": 0.0}
    try:
        import psutil
    except ImportError:
        psutil = None
        result["limitations"].append("psutil unavailable; process RSS samples not measured.")
    try:
        result["runtime"] = runtime_evidence(runtime)
        for key in ("browser_executable", "browser_channel"):
            result["runtime"].pop(key, None)
        version_check = subprocess.run(app_command(runtime, "-c", "import sys;sys.path.insert(0,sys.argv[1]);import pypdf;print(pypdf.__version__)", APP / "vendor"), cwd=APP, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=20, check=True)
        result["pypdf_version"] = version_check.stdout.strip()
        with contextlib.ExitStack() as cleanup:
            temporary = cleanup.enter_context(tempfile.TemporaryDirectory(prefix="herz-large-api-"))
            root = temporary_root = Path(temporary)
            source = root / "size-check.pdf"
            source_digest = fixture(source, result["source_bytes"])
            data = root / "data"
            env = {**os.environ, "HERZ_DATA_DIR": str(data), "PYTHONDONTWRITEBYTECODE": "1"}
            with (root / "server.log").open("wb") as server_log:
                process = subprocess.Popen(app_command(runtime, APP / "run.py"), cwd=APP, env=env,
                                           stdout=server_log, stderr=subprocess.STDOUT)
                cleanup.callback(lambda: close_server(process, credentials))

                def monitor():
                    nonlocal sample_count
                    if psutil is None:
                        return
                    while not stop_monitor.is_set():
                        try:
                            driver = psutil.Process(os.getpid()).memory_info().rss / 1024 ** 2
                            parent = psutil.Process(process.pid)
                            server = parent.memory_info().rss / 1024 ** 2
                            children = [child.memory_info().rss / 1024 ** 2 for child in parent.children(recursive=True) if child.is_running()]
                            sample_count += 1
                            samples["driver_peak_sampled_rss_mib"] = max(samples["driver_peak_sampled_rss_mib"], driver)
                            samples["server_peak_sampled_rss_mib"] = max(samples["server_peak_sampled_rss_mib"], server)
                            samples["worker_peak_sampled_rss_mib"] = max([samples["worker_peak_sampled_rss_mib"], *children])
                            samples["server_tree_peak_sampled_rss_mib"] = max(samples["server_tree_peak_sampled_rss_mib"], server + sum(children))
                        except (psutil.Error, ProcessLookupError):
                            pass
                        stop_monitor.wait(.02)

                observer = threading.Thread(target=monitor, daemon=True)
                observer.start()
                cleanup.callback(lambda: (stop_monitor.set(), observer.join(timeout=2)))
                deadline = time.monotonic() + 30
                while not (data / "server.json").is_file():
                    if process.poll() is not None:
                        raise AssertionError("Server exited before readiness: " + (root / "server.log").read_text(errors="replace")[-2000:])
                    if time.monotonic() > deadline:
                        raise TimeoutError("Server readiness timed out")
                    time.sleep(.05)
                credentials = json.loads((data / "server.json").read_text("utf-8"))
                opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

                def api(path, method="GET", body=None, raw=False, binary=False):
                    payload = body if raw else json.dumps(body).encode() if body is not None else None
                    headers = {"Authorization": "Bearer " + credentials["token"], "Origin": credentials["url"]}
                    if payload is not None:
                        headers["Content-Type"] = "application/octet-stream" if raw else "application/json"
                    request = urllib.request.Request(credentials["url"] + path, data=payload, method=method, headers=headers)
                    with opener.open(request, timeout=30) as response:
                        data_bytes = response.read()
                    return data_bytes if binary else json.loads(data_bytes)

                upload_start = time.perf_counter()
                upload = api("/api/uploads", "POST", {"filename": "size-check.pdf", "title": "Synthetic size check", "size": result["source_bytes"], "rights_confirmed": True})
                chunk_size = upload["chunk_bytes"]
                assert chunk_size == 4 * 1024 * 1024
                offset = 0
                chunks = 0
                with source.open("rb") as stream:
                    while True:
                        block = stream.read(chunk_size)
                        if not block:
                            break
                        receipt = api(f"/api/uploads/{upload['id']}?offset={offset}", "PUT", block, raw=True)
                        offset += len(block)
                        assert receipt["offset"] == offset, "Acknowledged upload offset differs"
                        chunks += 1
                result["upload_seconds"] = round(time.perf_counter() - upload_start, 3)
                result["chunks"] = chunks
                result["chunk_bytes"] = chunk_size
                result["final_acknowledged_offset"] = offset
                assert offset == result["source_bytes"]
                job = api(f"/api/uploads/{upload['id']}/complete", "POST", {})["job"]
                processing_start = time.perf_counter()
                deadline = time.monotonic() + 120
                while True:
                    state = api("/api/state")
                    job = next(item for item in state["jobs"] if item["id"] == job["id"])
                    if job["status"] in {"failed", "cancelled"}:
                        raise AssertionError("Worker failed: " + str(job.get("error")))
                    if job["status"] in {"completed", "needs_review"}:
                        break
                    if time.monotonic() > deadline:
                        raise TimeoutError("Pipeline processing timed out: " + str(job))
                    time.sleep(.1)
                result["processing_seconds"] = round(time.perf_counter() - processing_start, 3)
                assert job["status"] == "needs_review" and job["output_ready"] is True
                report = api(f"/api/jobs/{job['id']}/report")
                assert report["recognized_source_questions"] == 1
                assert report["source_pages_or_parts"] == 1
                assert report["content_coverage_complete"] is False
                package = api(f"/api/jobs/{job['id']}/download", binary=True)
                with zipfile.ZipFile(io.BytesIO(package)) as archive:
                    assert archive.testzip() is None
                    bundle = json.loads(archive.read("bundle.json"))
                    questions = [question for lesson in bundle["lessons"] for question in lesson["questions"]]
                    # The package deliberately uses the source exercise once for
                    # formative practice and once for its separate exam mode.
                    assert len(questions) == 2 and all(str(question["answer"]) == "15" for question in questions)
                    assert {question["role"] for question in questions} == {"formative", "exam"}
                    assert "12 + 3 = ?" in bundle["pages"][0]["text"]
                    assert archive.read("index.html").startswith(b"<!doctype html>")
                    result["package_members"] = archive.namelist()
                job_path = data / "jobs" / job["id"]
                uploaded_source = job_path / "source.pdf"
                assert uploaded_source.stat().st_size == result["source_bytes"]
                assert sha256(uploaded_source) == source_digest
                extraction_paths = list(job_path.rglob("coverage-extraction.json"))
                assert len(extraction_paths) == 1
                extraction = json.loads(extraction_paths[0].read_text("utf-8"))
                assert extraction["source_sha256"] == source_digest
                assert extraction["source_size"] == result["source_bytes"]
                result.update({"status": "passed", "job_status": job["status"], "pages": 1, "recognized_questions": 1,
                               "verified_answer": "15", "authored_activities": len(questions), "source_sha256": source_digest,
                               "uploaded_sha256_matches_source": True, "extraction_source_sha256_matches": True,
                               "zip_crc_valid": True, "zip_bytes": len(package), "output_ready": job["output_ready"],
                               "platform_import": report["platform_import"], "content_coverage_complete": False})
                api("/api/shutdown", "POST", {})
                process.wait(timeout=15)
                assert process.returncode == 0
                result["server_exit_code"] = process.returncode
                stop_monitor.set()
                observer.join(timeout=2)
    except Exception as exc:
        result["status"] = "failed"
        result["error"] = repr(exc)
        result["traceback"] = traceback.format_exc()
    finally:
        stop_monitor.set()
        if process is not None and process.poll() is None:
            close_server(process, credentials)
        result["elapsed_seconds_including_fixture"] = round(time.perf_counter() - started, 3)
        result["rss_measurement"] = "sampled every 20 ms using host psutil" if psutil and sample_count else "not measured"
        result["rss_sample_count"] = sample_count
        result.update({key: round(value, 2) if sample_count else None for key, value in samples.items()})
        result["temporary_source_and_job_data_deleted"] = temporary_root is not None and not temporary_root.exists()
        if credentials:
            for key in ("error", "traceback"):
                if key in result:
                    result[key] = result[key].replace(credentials["token"], "[REDACTED]")
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(result, ensure_ascii=True))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
