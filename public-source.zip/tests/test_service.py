"""Exercise real HTTP server, worker, persistence, upload and exported artifact."""
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import threading
import unittest
import urllib.error
import urllib.request
import zipfile
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'vendor'))
from agent.service import Service
from agent import service as service_module


def windows_pipe_error(code=109):
    error=OSError(f'[WinError {code}] The pipe has been ended')
    error.winerror=code
    return error


class _WindowsClosingReceive:
    """Simulate Windows closing-pipe poll around a real child connection."""
    def __init__(self,connection):
        self.connection=connection;self.terminal_seen=False;self.polls_after_terminal=0
    def poll(self,timeout=0):
        if self.terminal_seen:
            self.polls_after_terminal+=1
            raise windows_pipe_error()
        return self.connection.poll(timeout)
    def recv(self):
        message=self.connection.recv()
        if message.get('type') in ('result','error','paused'):self.terminal_seen=True
        return message
    def close(self):self.connection.close()


class _ClosingPipeContext:
    def __init__(self,context):self.context=context;self.receivers=[]
    def Pipe(self,duplex=False):
        receive,send=self.context.Pipe(duplex)
        wrapped=_WindowsClosingReceive(receive);self.receivers.append(wrapped)
        return wrapped,send
    def Event(self):return self.context.Event()
    def Process(self,*args,**kwargs):return self.context.Process(*args,**kwargs)


class WorkerPipeTests(unittest.TestCase):
    def test_peer_closure_from_poll_or_recv_is_distinct_from_timeout(self):
        from unittest.mock import Mock
        for phase in ('poll','recv'):
            for error in (EOFError(),BrokenPipeError(),ConnectionResetError(),windows_pipe_error(109),windows_pipe_error(232),windows_pipe_error(233)):
                with self.subTest(phase=phase,error=repr(error)):
                    connection=Mock();connection.poll.return_value=True
                    getattr(connection,phase).side_effect=error
                    self.assertIs(service_module._read_worker_message(connection,.1),service_module._PIPE_CLOSED)
        connection=Mock();connection.poll.return_value=False
        self.assertIs(service_module._read_worker_message(connection,.1),service_module._NO_PIPE_MESSAGE)
        connection.recv.assert_not_called()

    def test_unrelated_pipe_errors_are_not_silenced(self):
        from unittest.mock import Mock
        for phase in ('poll','recv'):
            connection=Mock();connection.poll.return_value=True
            getattr(connection,phase).side_effect=windows_pipe_error(6)
            with self.subTest(phase=phase),self.assertRaises(OSError):
                service_module._read_worker_message(connection,.1)

    def test_real_worker_terminal_result_and_error_survive_windows_pipe_close(self):
        with tempfile.TemporaryDirectory(prefix='herz-windows-pipe-') as tmp:
            s=Service(tmp);self.assertTrue(s.preflight(),s.checks)
            context=_ClosingPipeContext(s.context);s.context=context;s.start()
            try:
                for kind in ('demo','corrupt_pdf'):
                    with self.subTest(kind=kind):
                        if kind=='demo':job=s.demo()['job']
                        else:
                            source=b'%PDF-1.7\ncorrupt'
                            upload=s.begin_upload({'filename':'broken.pdf','size':len(source),'rights_confirmed':True})
                            s.upload_chunk(upload['id'],0,source);job=s.complete_upload(upload['id'])['job']
                        deadline=time.monotonic()+15
                        while time.monotonic()<deadline:
                            job=s.db.job(job['id'])
                            if job['status'] not in ('queued','running'):break
                            time.sleep(.02)
                        if kind=='demo':
                            self.assertEqual(job['status'],'completed',job)
                            self.assertTrue(s.validate(job['id'])['valid'])
                        else:
                            self.assertEqual(job['status'],'failed',job)
                            self.assertFalse(job['output_ready'])
                            self.assertIn('PDF',job['error'])
                            self.assertNotIn('109',job['error'])
                        self.assertTrue(context.receivers[-1].terminal_seen)
                        self.assertEqual(context.receivers[-1].polls_after_terminal,0)
            finally:s.close()

    def test_closed_pipe_without_result_and_nonzero_exit_never_publish_ready(self):
        from unittest.mock import Mock
        cases=[('no_result',None,0),('late_crash',{'type':'result','result':{'coverage_complete':True}},7)]
        for name,message,exitcode in cases:
            with self.subTest(name=name),tempfile.TemporaryDirectory(prefix='herz-missing-result-') as tmp:
                s=Service(tmp);context=Mock();receive=Mock();send=Mock();process=Mock()
                if message is None:receive.poll.side_effect=windows_pipe_error()
                else:receive.poll.return_value=True;receive.recv.return_value=message
                process.is_alive.return_value=False;process.exitcode=exitcode
                context.Pipe.return_value=(receive,send);context.Event.return_value=threading.Event();context.Process.return_value=process
                s.context=context;s._preflight_ok=True
                try:
                    job=s.demo()['job'];s.start();deadline=time.monotonic()+5
                    while time.monotonic()<deadline:
                        job=s.db.job(job['id'])
                        if job['status'] not in ('queued','running'):break
                        time.sleep(.02)
                    self.assertEqual(job['status'],'failed',job)
                    self.assertFalse(job['output_ready'])
                    self.assertTrue(job['error'])
                finally:s.close()

class ServiceStateTests(unittest.TestCase):
    def test_ready_publication_allows_immediate_export_and_validation(self):
        """No polling delay is required after a real worker publishes readiness.

        Observe the exact durable-state boundary, before the worker-loop's
        finally cleanup can run, so the old race fails deterministically.
        """
        with tempfile.TemporaryDirectory(prefix='herz-ready-boundary-') as tmp:
            s=Service(tmp);published=threading.Event();observed={}
            self.assertTrue(s.preflight(),s.checks)
            save_job=s.db.save_job
            def observe_publication(job):
                saved=save_job(job)
                if saved['output_ready']:
                    try:
                        self.assertEqual(s.db.job(saved['id'])['status'],'completed')
                        with zipfile.ZipFile(s.package(saved['id'])) as archive:
                            self.assertIsNone(archive.testzip())
                            observed['bundle']=json.loads(archive.read('bundle.json'))
                        observed['validation']=s.validate(saved['id'])
                    except Exception as error:
                        observed['error']=error
                    finally:published.set()
                return saved
            try:
                with patch.object(s.db,'save_job',side_effect=observe_publication):
                    job=s.demo()['job'];s.start()
                    self.assertTrue(published.wait(15),'Real worker did not publish output readiness')
                    if 'error' in observed:raise observed['error']
                    self.assertTrue(observed['validation']['valid'])
                    self.assertEqual(len(observed['bundle']['lessons'][0]['questions']),8)
                    self.assertTrue(s.db.job(job['id'])['output_ready'])
            finally:s.close()

    def test_immediate_resume_queues_behind_stopping_worker(self):
        with tempfile.TemporaryDirectory() as tmp:
            s=Service(tmp);j=s.demo()['job'];event=threading.Event()
            s.active={'id':j['id'],'cancel':event,'stop_requested':None}
            self.assertEqual(s.action(j['id'],'pause')['job']['status'],'paused')
            deadline=s.active['stop_requested']
            self.assertEqual(s.action(j['id'],'resume')['job']['status'],'queued')
            self.assertTrue(event.is_set())
            self.assertEqual(s.active['stop_requested'],deadline)
            self.assertEqual(s.action(j['id'],'cancel')['job']['status'],'cancelled')
            self.assertEqual(s.action(j['id'],'retry')['job']['status'],'queued')
            s.active=None

    def test_restart_pauses_pending_and_preserves_memory(self):
        with tempfile.TemporaryDirectory() as tmp:
            s=Service(tmp);j=s.demo()['job'];s.db.add_rule('قاعدة اختبار دائمة','feedback',['testing'])
            t=Service(tmp)
            self.assertEqual(t.db.job(j['id'])['status'],'paused')
            self.assertTrue(any(x['text']=='قاعدة اختبار دائمة' for x in t.db.rules()))
            self.assertEqual(t.action(j['id'],'resume')['job']['status'],'queued')
            self.assertEqual(t.action(j['id'],'cancel')['job']['status'],'cancelled')

    def test_upload_rejects_out_of_order_and_keeps_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            s=Service(tmp)
            with self.assertRaises(ValueError):s.begin_upload({'filename':'x.pdf','size':10})
            u=s.begin_upload({'filename':'درس.pdf','size':10,'rights_confirmed':True})
            with self.assertRaises(ValueError):s.upload_chunk(u['id'],1,b'123')
            self.assertEqual(s.upload_chunk(u['id'],0,b'%PDF-1.7\n\n')['offset'],10)
            j=s.complete_upload(u['id'])['job']
            self.assertEqual((Path(tmp)/'jobs'/j['id']/'source.pdf').read_bytes(),b'%PDF-1.7\n\n')

class RealServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory(prefix='herz-integration-');cls.data=Path(cls.temp.name)/'data'
        cls.log=(Path(cls.temp.name)/'server.log').open('w+')
        env=dict(os.environ,HERZ_DATA_DIR=str(cls.data),PYTHONDONTWRITEBYTECODE='1')
        cls.proc=subprocess.Popen([sys.executable,str(ROOT/'run.py')],env=env,cwd=ROOT,stdout=cls.log,stderr=cls.log)
        info=cls.data/'server.json'
        for _ in range(120):
            if info.is_file():break
            if cls.proc.poll() is not None:
                cls.log.seek(0);raise RuntimeError(cls.log.read())
            time.sleep(.1)
        cls.info=json.loads(info.read_text());cls.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    @classmethod
    def tearDownClass(cls):
        try:cls.request('/api/shutdown',{})
        except Exception:pass
        try:cls.proc.wait(8)
        except subprocess.TimeoutExpired:cls.proc.terminate();cls.proc.wait(3)
        cls.log.close();cls.temp.cleanup()
    @classmethod
    def request(cls,path,body=None,method=None,raw=None):
        data=raw if raw is not None else json.dumps(body,ensure_ascii=False).encode() if body is not None else None
        headers={'Authorization':'Bearer '+cls.info['token'],'Content-Type':'application/octet-stream' if raw is not None else 'application/json'}
        req=urllib.request.Request(cls.info['url']+path,data=data,headers=headers,method=method)
        with cls.opener.open(req,timeout=30) as r:
            b=r.read()
            return json.loads(b) if 'json' in r.headers.get('content-type','') else b
    def wait_job(self,jid):
        for _ in range(150):
            j=next(x for x in self.request('/api/state')['jobs'] if x['id']==jid)
            if j['status'] not in ('running','queued'):return j
            time.sleep(.1)
        self.fail('Worker did not finish')
    def test_demo_real_worker_export_and_backup(self):
        j=self.wait_job(self.request('/api/jobs/demo',{})['job']['id'])
        self.assertEqual(j['status'],'completed',j)
        self.assertTrue(j['output_ready']);self.assertEqual(j['counts']['questions'],8)
        raw=self.request('/api/jobs/'+j['id']+'/download')
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            self.assertIn('index.html',z.namelist());bundle=json.loads(z.read('bundle.json'))
            self.assertEqual(bundle['platform_compatibility'],'not_verified')
            self.assertEqual(len(bundle['lessons'][0]['examples']),2)
        self.assertTrue(self.request('/api/jobs/'+j['id']+'/validate',{})['valid'])
        self.request('/api/backup',{})
        backup_bytes=self.request('/api/backup')
        with zipfile.ZipFile(io.BytesIO(backup_bytes)) as z:
            self.assertIn('data/state.sqlite3',z.namelist());self.assertIn('BACKUP_INFO.json',z.namelist())
            self.assertNotIn('data/server.json',z.namelist())
        from agent.maintenance import restore_backup
        backup_path=Path(self.temp.name)/'downloaded-backup.zip';backup_path.write_bytes(backup_bytes)
        restore_data=Path(self.temp.name)/'restore-data'
        with patch.dict(os.environ,{'HERZ_DATA_DIR':str(restore_data)}):
            restored=restore_backup(backup_path)
        self.assertTrue(restored['ok'])
        self.assertEqual((Path(restored['path'])/'jobs'/j['id']/'output'/'index.html').read_bytes(),self.request('/api/jobs/'+j['id']+'/preview'))
        self.assertFalse((Path(restored['path'])/'server.json').exists())
    def test_real_docx_upload_to_interactive_draft(self):
        data=io.BytesIO()
        with zipfile.ZipFile(data,'w') as z:
            z.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>')
            z.writestr('word/document.xml','<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>12 + 3 = ?</w:t></w:r></w:p></w:body></w:document>')
        raw=data.getvalue()
        u=self.request('/api/uploads',{'filename':'lesson.docx','size':len(raw),'title':'اختبار حقيقي','rights_confirmed':True})
        middle=len(raw)//2
        self.request('/api/uploads/'+u['id']+'?offset=0',method='PUT',raw=raw[:middle])
        self.request('/api/uploads/'+u['id']+'?offset='+str(middle),method='PUT',raw=raw[middle:])
        j=self.wait_job(self.request('/api/uploads/'+u['id']+'/complete',{})['job']['id'])
        self.assertEqual(j['status'],'needs_review',j)
        self.assertEqual(j['counts']['questions'],2) # one source exercise, practice and exam variants
        report=self.request('/api/jobs/'+j['id']+'/report')
        self.assertFalse(report['content_coverage_complete'])
        self.assertEqual(report['recognized_source_questions'],1)
    def test_memory_chat_theme_and_diagnostics(self):
        r=self.request('/api/rules',{'text':'احفظ ترتيب الخانات','category':'feedback','tags':['math']})['rule']
        self.assertFalse(self.request('/api/rules/'+r['id'],{'enabled':False},method='PUT')['rule']['enabled'])
        self.assertEqual(self.request('/api/chat',{'message':'غيّر لون الواجهة إلى أزرق'})['action'],'theme_changed')
        self.assertEqual(self.request('/api/state')['settings']['theme'],'ocean')
        checks=self.request('/api/diagnostics',{})['checks']
        self.assertTrue(all(x['status']=='pass' for x in checks if x['name'].startswith('worker_')))
    def test_corrupt_pdf_fails_without_success_claim(self):
        raw=b'%PDF-1.7\ncorrupt'
        u=self.request('/api/uploads',{'filename':'broken.pdf','size':len(raw),'rights_confirmed':True})
        self.request('/api/uploads/'+u['id']+'?offset=0',method='PUT',raw=raw)
        j=self.wait_job(self.request('/api/uploads/'+u['id']+'/complete',{})['job']['id'])
        self.assertEqual(j['status'],'failed');self.assertFalse(j['output_ready']);self.assertTrue(j['error'])

if __name__=='__main__':unittest.main()
