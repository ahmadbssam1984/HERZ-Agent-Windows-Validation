"""Negative tests for application guards. These do NOT prove an OS sandbox."""
import importlib.util
import ctypes
import json
import multiprocessing
import os
from pathlib import Path
import socket
import sys
import tempfile
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'vendor'))
from agent.security import contained,guard_probe,install_worker_guard,GuardError
from agent import security
from agent.central_adapter import status,contract,make_cli_result


def guard_negative_child(send,root_string):
    """Everything attempted here is local; socket calls stop at the audit hook."""
    root=Path(root_string);allowed=root/'allowed';outside=root/'outside'
    allowed.mkdir();outside.mkdir();(outside/'private.txt').write_text('private')
    outfd=os.open(outside,os.O_RDONLY) if os.open in os.supports_dir_fd else None
    os.chdir(allowed)
    install_worker_guard([allowed],[allowed])
    outcomes={}
    attempts={
        'read_outside':lambda:(outside/'private.txt').read_text(),
        'traversal_read':lambda:(allowed/'..'/'outside'/'private.txt').read_text(),
        'write_outside':lambda:(outside/'new.txt').write_text('bad'),
        'list_outside':lambda:os.listdir(outside),
        'scan_outside':lambda:os.scandir(outside),
        'dirfd_open':lambda:os.open('private.txt',os.O_RDONLY,dir_fd=outfd),
        'dirfd_remove':lambda:os.remove('private.txt',dir_fd=outfd),
        'symlink':lambda:os.symlink('anything',allowed/'link'),
        'hardlink':lambda:os.link(allowed/'new',allowed/'newer'),
        'ipv4':lambda:socket.socket(socket.AF_INET,socket.SOCK_STREAM),
        'ipv6':lambda:socket.socket(socket.AF_INET6,socket.SOCK_STREAM),
        'dns':lambda:socket.getaddrinfo('example.com',80),
    }
    if outfd is None:
        attempts.pop('dirfd_open');attempts.pop('dirfd_remove')
    for name,attempt in attempts.items():
        try:attempt();outcomes[name]=False
        except GuardError:outcomes[name]=True
        except BaseException as error:outcomes[name]='unexpected '+type(error).__name__
    (allowed/'good.txt').write_text('good')
    outcomes['allowed_read_write']=(allowed/'good.txt').read_text()=='good'
    send.send(outcomes);send.close()


class SecurityTests(unittest.TestCase):
    def test_containment_path_boundaries(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)/'allowed';root.mkdir()
            self.assertTrue(contained(root/'x',[root]))
            self.assertFalse(contained(root.parent/'allowed_evil',[root]))
            self.assertFalse(contained(root/'..'/'x',[root]))
            try:(root/'link').symlink_to(root.parent/'outside')
            except OSError:return # Windows user may lack link creation rights.
            self.assertFalse(contained(root/'link',[root]))

    def test_guard_stops_network_and_filesystem_at_python_layer(self):
        context=multiprocessing.get_context('spawn')
        with tempfile.TemporaryDirectory() as t:
            receive,send=context.Pipe(False)
            process=context.Process(target=guard_negative_child,args=(send,t));process.start();send.close()
            try:
                self.assertTrue(receive.poll(15),'guard child did not reply')
                outcomes=receive.recv()
                self.assertTrue(all(v is True for v in outcomes.values()),outcomes)
            finally:
                process.join(3)
                if process.is_alive():process.terminate();process.join(3)
                receive.close()
            self.assertEqual(process.exitcode,0)

    def test_startup_probe_is_explicit_application_guard(self):
        context=multiprocessing.get_context('spawn')
        with tempfile.TemporaryDirectory() as t:
            receive,send=context.Pipe(False)
            process=context.Process(target=guard_probe,args=(send,str(Path(t)/'allowed')));process.start();send.close()
            try:
                self.assertTrue(receive.poll(15))
                result=receive.recv()
                self.assertTrue(result['ok'],result)
                self.assertTrue(all(x['status']=='pass' for x in result['checks']))
            finally:
                process.join(3)
                if process.is_alive():process.terminate();process.join(3)
                receive.close()
            self.assertEqual(process.exitcode,0)

    def test_central_contract_cannot_claim_connection(self):
        self.assertFalse(status()['connected']);self.assertFalse(status()['ready'])
        c=contract();c['controls'].append('pause');self.assertNotIn('pause',contract()['controls'])

    def test_central_artifact_paths_reject_escape_and_windows_aliases(self):
        self.assertEqual(make_cli_result({'ok':True},['report.json'])['artifacts'],['report.json'])
        for name in ('../x','a/../x','/x','C:/x','a\\x','a//x','a/./x','NUL.txt','CON','x.','x ','a/<x>'):
            with self.subTest(name=name),self.assertRaises(ValueError):make_cli_result({},[name])
        with self.assertRaises(ValueError):make_cli_result({},['A.txt','a.txt'])
        with self.assertRaises(ValueError):make_cli_result({'n':float('nan')},[])

    def test_real_guarded_worker_builds_and_validates_demo(self):
        from agent.service import Service
        with tempfile.TemporaryDirectory() as t:
            service=Service(Path(t)/'data')
            self.assertTrue(service.preflight(),service.checks)
            service.start()
            try:
                jid=service.demo()['job']['id']
                deadline=time.monotonic()+20
                while time.monotonic()<deadline:
                    job=service.db.job(jid)
                    if job['status'] not in ('queued','running'):break
                    time.sleep(.05)
                self.assertEqual(job['status'],'completed',job)
                self.assertTrue(service.package(jid).is_file())
                self.assertTrue(service.validate(jid)['valid'])
            finally:service.close()

    def test_previous_server_does_not_follow_redirect_with_token(self):
        spec=importlib.util.spec_from_file_location('herz_test_run',ROOT/'run.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        seen=[]
        class Redirect(BaseHTTPRequestHandler):
            def do_GET(self):
                seen.append(self.path)
                self.send_response(302);self.send_header('Location',f'http://127.0.0.1:{self.server.server_port}/stolen');self.end_headers()
            def log_message(self,*args):pass
        server=HTTPServer(('127.0.0.1',0),Redirect)
        worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
        try:
            with tempfile.TemporaryDirectory() as t:
                p=Path(t)/'server.json';p.write_text(json.dumps({'url':f'http://127.0.0.1:{server.server_port}','token':'private-test-token'}))
                self.assertIsNone(module.previous_server(p))
                self.assertEqual(seen,['/api/state'])
        finally:server.shutdown();server.server_close();worker.join(2)



class _FakeWinFunction:
    def __init__(self, function):
        self.function = function
    def __call__(self, *args):
        return self.function(*args)


class _FakeJobKernel:
    """API marshalling simulation; never represents a Windows run."""
    def __init__(self, failure=None):
        self.failure = failure
        self.closed = []
        self.requested = None
        self.CreateJobObjectW = _FakeWinFunction(lambda *args: 0 if failure == 'create' else 123)
        self.SetInformationJobObject = _FakeWinFunction(self.set_info)
        self.AssignProcessToJobObject = _FakeWinFunction(lambda *args: failure != 'assign')
        self.GetCurrentProcess = _FakeWinFunction(lambda: -1)
        self.QueryInformationJobObject = _FakeWinFunction(self.query_info)
        self.IsProcessInJob = _FakeWinFunction(self.membership)
        self.CloseHandle = _FakeWinFunction(lambda value: self.closed.append(value) or True)
    def set_info(self, handle, kind, pointer, length):
        assert kind == 9
        assert length == ctypes.sizeof(security._ExtendedJobLimits)
        self.requested = security._ExtendedJobLimits.from_buffer_copy(ctypes.string_at(pointer, length))
        return self.failure != 'set'
    def query_info(self, handle, kind, pointer, length, returned):
        if self.failure == 'query':return False
        value = security._ExtendedJobLimits.from_buffer_copy(self.requested)
        if self.failure == 'flags':value.BasicLimitInformation.LimitFlags = 0x104
        if self.failure == 'cpu':value.BasicLimitInformation.PerProcessUserTimeLimit = 0
        if self.failure == 'memory':value.ProcessMemoryLimit = 0
        if self.failure == 'processes':value.BasicLimitInformation.ActiveProcessLimit = 2
        ctypes.memmove(pointer, ctypes.byref(value), length)
        return True
    def membership(self, process, job, pointer):
        if self.failure == 'membership_api':return False
        ctypes.cast(pointer, ctypes.POINTER(ctypes.c_int32)).contents.value = self.failure != 'membership_false'
        return True


def windows_limit_child(send, operation):
    """Actual Win32 probe, always in its own disposable process."""
    try:
        limits = security.set_worker_limits(256, cpu_seconds=1 if operation == 'cpu' else 30)
        send.send({'ready': True, 'limits': limits})
        if operation == 'cpu':
            while True:pass  # Only this job-limited child burns CPU.
        if operation == 'memory':
            blocks = []
            denied = False
            try:
                for _ in range(64):blocks.append(bytearray(8 * 1024**2))
            except MemoryError:
                denied = True
            finally:
                blocks.clear()
            send.send({'memory_denied': denied})
    except BaseException as error:
        send.send({'error': type(error).__name__ + ': ' + str(error)})
    finally:
        send.close()


class WindowsLimitsContractTests(unittest.TestCase):
    def call_fake(self, kernel):
        previous = getattr(security, '_job_handle', None)
        try:
            with patch.object(security.ctypes, 'WinDLL', return_value=kernel, create=True), \
                 patch.object(security.ctypes, 'get_last_error', return_value=5, create=True):
                return security._windows_worker_limits(768, 180)
        finally:
            if previous is None:security.__dict__.pop('_job_handle', None)
            else:security._job_handle = previous

    def test_windows_resource_flags_match_documented_process_time_field(self):
        kernel = _FakeJobKernel()
        result = self.call_fake(kernel)
        basic = kernel.requested.BasicLimitInformation
        self.assertEqual(basic.LimitFlags, 0x0000010A)
        self.assertEqual(basic.LimitFlags & 0x00000004, 0)
        self.assertEqual(basic.PerProcessUserTimeLimit, 1_800_000_000)
        self.assertEqual(basic.PerJobUserTimeLimit, 0)
        self.assertEqual(basic.ActiveProcessLimit, 1)
        self.assertEqual(kernel.requested.ProcessMemoryLimit, 768 * 1024**2)
        self.assertTrue(result['limits_verified'])
        self.assertEqual(kernel.closed, [])

    def test_windows_api_failures_and_mismatched_readback_fail_closed(self):
        for mode in ('create','set','assign','query','membership_api','membership_false','flags','cpu','memory','processes'):
            with self.subTest(mode=mode):
                kernel = _FakeJobKernel(mode)
                with self.assertRaises(OSError):self.call_fake(kernel)
                self.assertEqual(kernel.closed, [] if mode == 'create' else [123])

    def test_win64_structures_use_dword_width_and_correct_alignment(self):
        if ctypes.sizeof(ctypes.c_void_p) != 8:self.skipTest('64-bit ABI check')
        self.assertEqual(ctypes.sizeof(security._BasicJobLimits), 64)
        self.assertEqual(ctypes.sizeof(security._ExtendedJobLimits), 144)
        self.assertEqual(security._BasicJobLimits.ActiveProcessLimit.offset, 40)
        self.assertEqual(security._ExtendedJobLimits.ProcessMemoryLimit.offset, 112)

    def test_invalid_resource_limits_rejected_before_any_os_change(self):
        for memory,cpu in ((True,180),(0,180),(2049,180),(768,0),(768,181),(768,False)):
            with self.subTest(memory=memory,cpu=cpu),self.assertRaises(ValueError):
                security.set_worker_limits(memory,cpu)

    @unittest.skipUnless(os.name == 'nt', 'Requires actual Windows Job Object enforcement')
    def test_native_windows_process_memory_limit_denies_allocation(self):
        context = multiprocessing.get_context('spawn')
        receive,send = context.Pipe(False)
        process = context.Process(target=windows_limit_child,args=(send,'memory'))
        process.start();send.close()
        try:
            self.assertTrue(receive.poll(20), 'Windows limit setup gave no reply')
            ready = receive.recv()
            self.assertTrue(ready.get('ready'), ready)
            self.assertEqual(ready['limits']['job_limit_flags'] & 0x10A, 0x10A)
            self.assertTrue(receive.poll(20), 'Memory enforcement probe gave no reply')
            self.assertEqual(receive.recv(), {'memory_denied': True})
            process.join(5)
            self.assertEqual(process.exitcode, 0)
        finally:
            if process.is_alive():process.terminate();process.join(5)
            receive.close()

    @unittest.skipUnless(os.name == 'nt', 'Requires actual Windows Job Object enforcement')
    def test_native_windows_cpu_limit_terminates_only_its_child(self):
        context = multiprocessing.get_context('spawn')
        receive,send = context.Pipe(False)
        process = context.Process(target=windows_limit_child,args=(send,'cpu'))
        process.start();send.close()
        try:
            self.assertTrue(receive.poll(20), 'Windows limit setup gave no reply')
            ready = receive.recv()
            self.assertTrue(ready.get('ready'), ready)
            process.join(12)
            self.assertFalse(process.is_alive(), 'CPU cap was not enforced within 12 seconds')
            self.assertIsNotNone(process.exitcode)
            self.assertNotEqual(process.exitcode, 0)
        finally:
            if process.is_alive():process.terminate();process.join(5)
            receive.close()

if __name__=='__main__':unittest.main()
