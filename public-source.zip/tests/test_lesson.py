import base64
import json
import re
import tempfile
import unittest
import wave
import io
from pathlib import Path

from agent.lesson import _calculated, build_package, demo_document, validate_package


class LessonPackageTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)

    def tearDown(self):
        self.temporary.cleanup()

    def build(self, document=None):
        return build_package(document or demo_document(), self.root, "رحلة الأعداد")

    def test_demo_compiles_and_validates_actual_arithmetic(self):
        result = self.build()
        self.assertEqual(result["counts"]["questions"], 8)
        self.assertTrue(result["coverage_complete"])
        self.assertTrue(validate_package(self.root)["valid"])
        bundle = json.loads((self.root / "bundle.json").read_text(encoding="utf-8"))
        self.assertEqual(bundle["platform_compatibility"], "not_verified")
        self.assertEqual(bundle["audio_kind"], "encouragement_tone")

    def test_wrong_author_answer_blocks_generation(self):
        doc = demo_document()
        doc["questions"][0]["answer"] = "999"
        with self.assertRaisesRegex(ValueError, "Incorrect arithmetic"):
            self.build(doc)

    def test_arithmetic_uses_exact_fractions_and_no_evaluation(self):
        self.assertEqual(str(_calculated("٨٠٠−٣٥٦")), "444")
        self.assertEqual(str(_calculated("0.1+0.2")), "0.3")
        self.assertEqual(str(_calculated("1/8")), "0.125")
        for invalid in ("1/3", "1/0", "__import__('os')", "2**4", "1+2+3"):
            with self.assertRaises(ValueError, msg=invalid):
                _calculated(invalid)

    def test_four_choices_required(self):
        doc = demo_document()
        doc["questions"][2]["options"].pop()
        with self.assertRaisesRegex(ValueError, "four distinct"):
            self.build(doc)

    def test_equivalent_mcq_choices_and_missing_answer_blocked(self):
        doc = demo_document()
        doc["questions"][2]["options"] = ["356", "0356", "536", "653"]
        with self.assertRaisesRegex(ValueError, "semantically distinct"):
            self.build(doc)
        doc = demo_document()
        doc["questions"][2]["answer"] = ""
        with self.assertRaisesRegex(ValueError, "answer is missing"):
            self.build(doc)

    def test_source_content_does_not_escape_json_or_html(self):
        payload = '</script><script>window.PWNED=1</script><img src=x onerror="alert(1)">'
        doc = {"format": "docx", "coverage_complete": True, "pages": [{"number": 1, "text": payload, "issues": ["images_unconverted"]}], "questions": [], "warnings": []}
        result = build_package(doc, self.root, payload)
        output = (self.root / "index.html").read_text(encoding="utf-8")
        self.assertNotIn('<script>window.PWNED', output)
        self.assertIn('\\u003c/script>', output)
        self.assertFalse(result["coverage_complete"])
        self.assertEqual(len(re.findall(r'<script(?:\s[^>]*)?>', output)), 2)
        self.assertTrue(validate_package(self.root)["valid"])

    def test_text_extraction_is_not_claimed_as_complete_book(self):
        doc = {"format": "pdf", "coverage_complete": True, "pages": [{"number": 1, "text": "452-137=?", "issues": []}], "questions": [{"id": "p1-q1", "type": "input", "prompt": "أوجد الناتج", "expression": "452-137", "answer": "315", "source_page": 1}], "warnings": []}
        result = self.build(doc)
        self.assertFalse(result["coverage_complete"])
        self.assertEqual(result["counts"]["questions"], 2)
        bundle = json.loads((self.root / "bundle.json").read_text(encoding="utf-8"))
        self.assertEqual([q["role"] for q in bundle["lessons"][0]["questions"]], ["formative", "exam"])
        report = json.loads((self.root / "coverage.json").read_text(encoding="utf-8"))
        self.assertEqual(report["recognized_source_questions"], 1)
        self.assertFalse(report["original_page_images_embedded"])

    def test_duplicate_ids_rejected(self):
        doc = demo_document()
        doc["questions"][1]["id"] = doc["questions"][0]["id"]
        with self.assertRaisesRegex(ValueError, "structural"):
            self.build(doc)

    def test_broken_example_link_rejected(self):
        doc = demo_document()
        doc["questions"][0]["example_id"] = "missing"
        with self.assertRaisesRegex(ValueError, "structural"):
            self.build(doc)

    def test_tampered_script_fails_hash_validation(self):
        self.build()
        page = self.root / "index.html"
        content = page.read_text(encoding="utf-8").replace("'use strict';", "'use strict';window.PWNED=1;")
        page.write_text(content, encoding="utf-8")
        self.assertFalse(validate_package(self.root)["valid"])

    def test_embedded_tone_is_decodable_wav(self):
        self.build()
        page = (self.root / "index.html").read_text(encoding="utf-8")
        payload = json.loads(re.search(r'<script id="lesson-data" type="application/json">(.*?)</script>', page, re.S).group(1))
        raw = base64.b64decode(payload["tone"].split(",", 1)[1])
        with wave.open(io.BytesIO(raw)) as sound:
            self.assertEqual(sound.getframerate(), 16000)
            self.assertEqual(sound.getnchannels(), 1)
            self.assertGreater(sound.getnframes(), 4000)


if __name__ == "__main__":
    unittest.main()
