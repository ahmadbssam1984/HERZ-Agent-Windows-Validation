import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from agent.converter import SourceValidationError, extract_document, extract_questions

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
M = "http://schemas.openxmlformats.org/officeDocument/2006/math"


def docx(path, body, extra=None):
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"/>')
        z.writestr("word/document.xml", f'<w:document xmlns:w="{W}" xmlns:m="{M}"><w:body>{body}</w:body></w:document>')
        for name, value in (extra or {}).items():
            z.writestr(name, value)


def pdf(path, texts, encrypted=False):
    from pypdf import PdfWriter
    from pypdf.generic import DictionaryObject, NameObject, DecodedStreamObject
    writer = PdfWriter()
    for text in texts:
        page = writer.add_blank_page(600, 800)
        font = DictionaryObject({NameObject("/Type"): NameObject("/Font"), NameObject("/Subtype"): NameObject("/Type1"),
                                 NameObject("/BaseFont"): NameObject("/Helvetica")})
        page[NameObject("/Resources")] = DictionaryObject({NameObject("/Font"): DictionaryObject({NameObject("/F1"): writer._add_object(font)})})
        stream = DecodedStreamObject()
        stream.set_data(f"BT /F1 12 Tf 50 700 Td ({text}) Tj ET".encode("ascii"))
        page[NameObject("/Contents")] = writer._add_object(stream)
    if encrypted:
        writer.encrypt("secret")
    with open(path, "wb") as stream:
        writer.write(stream)


class ConverterTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.updates = []

    def tearDown(self):
        self.tmp.cleanup()

    def run_source(self, path, name="work", cancelled=lambda: False, start_page=0):
        return extract_document(path, self.root / name, lambda *args: self.updates.append(args), cancelled, start_page)

    def test_docx_arabic_and_source_order(self):
        source = self.root / "اختبار.docx"
        docx(source, '<w:p><w:r><w:t>أوجد الناتج</w:t></w:r></w:p><w:p><w:r><w:t>١٢ + ٣ = ؟</w:t></w:r></w:p>')
        result = self.run_source(source)
        self.assertEqual(result["pages"][0]["text"], "أوجد الناتج\n١٢ + ٣ = ؟")
        self.assertEqual(result["questions"][0]["answer"], "15")
        self.assertEqual(result["questions"][0]["source_page"], 1)
        self.assertEqual(result["pagination_kind"], "docx_logical_sections")
        self.assertFalse(result["source_coverage_verified"])

    def test_docx_page_break_and_resume_without_duplicate(self):
        source = self.root / "book.docx"
        docx(source, '<w:p><w:r><w:t>First</w:t><w:br w:type="page"/><w:t>Second</w:t></w:r></w:p>')
        result = self.run_source(source, start_page=9)
        resumed = self.run_source(source, start_page=1)
        self.assertEqual([p["text"] for p in result["pages"]], ["First", "Second"])
        self.assertEqual(result, resumed)
        self.assertEqual(len((self.root / "work/pages.jsonl").read_text().splitlines()), 2)

    def test_docx_marks_math_images_table_and_secondary_parts(self):
        source = self.root / "rich.docx"
        body = ('<w:tbl><w:tr><w:tc><w:p><w:r><w:t>Cell</w:t></w:r></w:p></w:tc></w:tr></w:tbl>'
                '<w:p><m:oMath><m:r><m:t>12 + 3 = ?</m:t></m:r></m:oMath><w:r><w:drawing/></w:r></w:p>')
        docx(source, body, {"word/media/a.png": b"placeholder", "word/header1.xml": "<header/>"})
        result = self.run_source(source)
        self.assertFalse(result["coverage_complete"])
        self.assertIn("images_not_reconstructed", result["coverage_issues"])
        self.assertIn("math_layout_needs_review", result["coverage_issues"])
        self.assertIn("secondary_document_parts_not_extracted", result["coverage_issues"])
        self.assertEqual(result["questions"], [])
        self.assertFalse((self.root / "work/a.png").exists())

    def test_docx_external_links_not_fetched(self):
        source = self.root / "links.docx"
        rels = '<Relationships><Relationship Type="http://example/image" TargetMode="External" Target="http://127.0.0.1:9/leak"/></Relationships>'
        docx(source, '<w:p><w:r><w:t>Safe</w:t></w:r></w:p>', {"word/_rels/document.xml.rels": rels})
        result = self.run_source(source)
        self.assertIn("external_media_not_fetched", result["coverage_issues"])

    def test_docx_rejects_zip_traversal(self):
        source = self.root / "bad.docx"
        docx(source, "", {"../escaped.txt": "evil"})
        with self.assertRaises(SourceValidationError):
            self.run_source(source)
        self.assertFalse((self.root / "escaped.txt").exists())

    def test_docx_rejects_entities(self):
        source = self.root / "bad.docx"
        with zipfile.ZipFile(source, "w") as z:
            z.writestr("[Content_Types].xml", "<Types/>")
            z.writestr("word/document.xml", '<!DOCTYPE doc [<!ENTITY x "secret">]><doc>&x;</doc>')
        with self.assertRaises(SourceValidationError):
            self.run_source(source)

    def test_docx_rejects_bomb(self):
        source = self.root / "bomb.docx"
        docx(source, "", {"word/bomb.xml": " " * 2_000_000})
        with self.assertRaises(SourceValidationError):
            self.run_source(source)

    def test_docx_rejects_macros(self):
        source = self.root / "macro.docx"
        docx(source, "", {"word/vbaProject.bin": b"not executed"})
        with self.assertRaises(SourceValidationError):
            self.run_source(source)

    def test_pdf_text_and_arithmetic(self):
        source = self.root / "exercise.pdf"
        pdf(source, ["12 + 3 = ?", "800 - 356 = ?"])
        result = self.run_source(source)
        self.assertEqual([q["answer"] for q in result["questions"]], ["15", "444"])
        self.assertEqual(result["pages_total"], 2)
        self.assertFalse(result["coverage_complete"])
        self.assertFalse(result["source_coverage_verified"])

    def test_pdf_empty_page_is_not_silently_complete(self):
        source = self.root / "empty.pdf"
        pdf(source, [""])
        result = self.run_source(source)
        self.assertIn("empty_or_vector_page_needs_review", result["pages"][0]["issues"])
        self.assertFalse(result["coverage_complete"])

    def test_pdf_encryption_rejected(self):
        source = self.root / "encrypted.pdf"
        pdf(source, ["12 + 3 = ?"], encrypted=True)
        with self.assertRaises(SourceValidationError):
            self.run_source(source)

    def test_cancel_and_resume_pdf(self):
        source = self.root / "many.pdf"
        pdf(source, ["1 + 2 = ?", "2 + 3 = ?", "3 + 4 = ?"])
        cancelled = [False]

        def progress(done, total, stage):
            if done == 1:
                cancelled[0] = True

        with self.assertRaises(InterruptedError):
            extract_document(source, self.root / "work", progress, lambda: cancelled[0])
        self.assertEqual(len((self.root / "work/pages.jsonl").read_text().splitlines()), 1)
        result = self.run_source(source, start_page=1)
        self.assertEqual(len(result["pages"]), 3)
        self.assertEqual(len((self.root / "work/pages.jsonl").read_text().splitlines()), 3)

    def test_partial_checkpoint_tail_recovers(self):
        source = self.root / "simple.pdf"
        pdf(source, ["1 + 2 = ?"])
        self.run_source(source)
        with (self.root / "work/pages.jsonl").open("ab") as f:
            f.write(b'{"number":2')
        result = self.run_source(source)
        self.assertEqual(len(result["pages"]), 1)
        self.assertEqual(len((self.root / "work/pages.jsonl").read_text().splitlines()), 1)

    def test_changed_source_cannot_reuse_checkpoint(self):
        source = self.root / "changed.docx"
        docx(source, '<w:p><w:r><w:t>A</w:t></w:r></w:p>')
        self.run_source(source)
        docx(source, '<w:p><w:r><w:t>B</w:t></w:r></w:p>')
        with self.assertRaises(SourceValidationError):
            self.run_source(source)

    def test_invalid_extension_empty_corrupt_files(self):
        for name, content in [("empty.pdf", b""), ("bad.pdf", b"not a pdf"), ("bad.docx", b"not a zip"), ("bad.exe", b"MZ")]:
            source = self.root / name
            source.write_bytes(content)
            with self.subTest(name=name), self.assertRaises(SourceValidationError):
                self.run_source(source, name="work-" + name)

    def test_arithmetic_conservative_exact_answers(self):
        lines = ["١٢ + ٣ = ؟", "800 − 356 = ?", "1. 3 × 4 = ___", "Calculate: 1 / 4 = ?", "1 / 3 = ?",
                 "1 / 0 = ?", "2026 report 12 + 3", "12 + 3 = 15", "3 + 4 * 2 = ?", "0.1 + 0.2 = ?", "9 - -2 = ?"]
        questions = extract_questions([{"number": 1, "text": "\n".join(lines), "issues": []}])
        self.assertEqual([q["answer"] for q in questions], ["15", "444", "12", "0.25", "0.3", "11"])
        self.assertTrue(all(q["verified"] for q in questions))


if __name__ == "__main__":
    unittest.main()
