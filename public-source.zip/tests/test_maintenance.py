import hashlib
from contextlib import closing
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

from agent import maintenance as m


class MaintenanceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="herz maintenance عربي & ")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.environment = patch.dict(os.environ)
        self.environment.start()
        self.addCleanup(self.environment.stop)
        os.environ["HERZ_DATA_DIR"] = str(self.root / "data")
        (self.root / "repair").mkdir()

    def seed(self, files):
        path = self.root / "repair/payload.zip"
        with zipfile.ZipFile(path, "w") as archive:
            for rel, value in files.items():
                archive.writestr(rel, value)
        manifest = {"version": "test", "archive_sha256": m.sha256(path), "files": {rel: hashlib.sha256(value).hexdigest() for rel, value in files.items()}}
        (self.root / "repair/payload-manifest.json").write_text(json.dumps(manifest))

    def test_repair_preserves_old_program_and_user_data(self):
        self.seed({"web/a.js": b"good", "run.py": b"pass\n"})
        (self.root / "web").mkdir()
        (self.root / "web/a.js").write_bytes(b"damaged")
        (self.root / "data").mkdir()
        (self.root / "data/user.txt").write_bytes(b"keep me")
        result = m.repair(self.root)
        self.assertTrue(result["ok"])
        self.assertEqual((self.root / "web/a.js").read_bytes(), b"good")
        self.assertEqual((self.root / "data/user.txt").read_bytes(), b"keep me")
        with zipfile.ZipFile(result["backup"]) as backup:
            self.assertEqual(backup.read("web/a.js"), b"damaged")
        self.assertTrue(m.verify_installation(self.root)["valid"])

    def test_tampered_seed_fails_without_replacing_program(self):
        self.seed({"run.py": b"new"})
        (self.root / "run.py").write_bytes(b"old")
        with (self.root / "repair/payload.zip").open("ab") as stream:
            stream.write(b"tampered")
        with self.assertRaisesRegex(ValueError, "checksum"):
            m.repair(self.root)
        self.assertEqual((self.root / "run.py").read_bytes(), b"old")

    def test_repair_rejects_data_and_traversal_members(self):
        for rel in ("../escape.py", "data/user.db", "web/../run.py", "C:/evil.py", "web\\evil.py", "runtime/python.exe", "web/NUL.txt", "web/foo. ", "web/a?.js"):
            with self.subTest(rel=rel), self.assertRaises(ValueError):
                m._safe_relative(rel)

    def test_repair_refuses_symlink_destination(self):
        if not hasattr(os, "symlink"):
            self.skipTest("symlinks unavailable")
        self.seed({"run.py": b"new"})
        target = self.root / "outside.txt"
        target.write_bytes(b"preserve")
        try:
            (self.root / "run.py").symlink_to(target)
        except OSError:
            self.skipTest("symlink creation unavailable to this account")
        with self.assertRaises(ValueError):
            m.repair(self.root)
        self.assertEqual(target.read_bytes(), b"preserve")

    def test_backup_sqlite_snapshot_and_excludes_credentials(self):
        data = self.root / "data"
        data.mkdir()
        (data / "server.json").write_text('{"token":"secret"}')
        (data / "source.txt").write_text("original")
        db = sqlite3.connect(data / "state.db")
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("CREATE TABLE info (v TEXT)")
        db.execute("INSERT INTO info VALUES ('kept')")
        db.commit()
        self.addCleanup(db.close)
        result = m.create_backup(self.root)
        with zipfile.ZipFile(result["path"]) as archive:
            self.assertNotIn("data/server.json", archive.namelist())
            self.assertNotIn("data/state.db-wal", archive.namelist())
            self.assertEqual(archive.read("data/source.txt"), b"original")
            snapshot = self.root / "snapshot.db"
            snapshot.write_bytes(archive.read("data/state.db"))
        restored = sqlite3.connect(snapshot)
        self.addCleanup(restored.close)
        self.assertEqual(restored.execute("SELECT v FROM info").fetchone(), ("kept",))

    def test_backup_uses_explicit_data_directory_and_excludes_pending_uploads(self):
        custom = self.root / "custom"
        custom.mkdir()
        (custom / "uploads").mkdir()
        (custom / "uploads/pending.json").write_text('{"offset":100}')
        (custom / "uploads/pending.part").write_bytes(b"partial")
        with closing(sqlite3.connect(custom / "state.sqlite3")) as database:
            with database:
                database.execute("CREATE TABLE test(v INTEGER)")
                database.execute("INSERT INTO test VALUES(1)")
        result = m.create_backup(data_directory=custom)
        with zipfile.ZipFile(result["path"]) as archive:
            self.assertIn("data/state.sqlite3", archive.namelist())
            self.assertIn("BACKUP_INFO.json", archive.namelist())
            self.assertFalse(any(name.startswith("data/uploads/") for name in archive.namelist()))
        self.assertTrue(Path(result["path"]).resolve().is_relative_to((custom / "backups").resolve()))

    def test_backup_hashes_written_bytes_without_reading_unclosed_zip(self):
        data = self.root / "data"
        (data / "nested").mkdir(parents=True)
        payload = b"original contents\n" * 100000
        (data / "nested/source.txt").write_bytes(payload)
        original_open = zipfile.ZipFile.open
        def no_read_during_creation(archive, name, mode="r", *args, **kwargs):
            if archive.mode == "x" and mode == "r":
                self.fail("Backup reread a member before the ZIP directory was finalized")
            return original_open(archive, name, mode, *args, **kwargs)
        with patch.object(zipfile.ZipFile, "open", new=no_read_during_creation):
            result = m.create_backup(data_directory=data)
        with zipfile.ZipFile(result["path"]) as archive:
            metadata = json.loads(archive.read("BACKUP_INFO.json"))
            self.assertEqual(archive.read("data/nested/source.txt"), payload)
            self.assertEqual(metadata["sha256"]["data/nested/source.txt"], hashlib.sha256(payload).hexdigest())
            self.assertTrue(all("\\" not in name for name in archive.namelist()))

    def test_backup_rejects_linked_directory_escape_before_creating_zip(self):
        data = self.root / "data"
        data.mkdir()
        outside = self.root / "outside"
        outside.mkdir()
        (outside / "private.txt").write_bytes(b"not authorized for backup")
        try:
            (data / "leak").symlink_to(outside, target_is_directory=True)
        except (OSError, NotImplementedError):
            self.skipTest("Directory links unavailable")
        with self.assertRaises(ValueError):
            m.create_backup(data_directory=data)
        self.assertEqual(list((data / "backups").glob("*.zip")), [])

    def test_backup_skips_disappeared_sqlite_sidecars_before_path_checks(self):
        data = self.root / "data"
        data.mkdir()
        source = data / "source.txt"
        source.write_text("retained")
        vanished = [data / name for name in ("state.sqlite3-wal", "state.sqlite3-shm", "server.json", "server.lock", "upload.part")]
        # Reproduce an enumeration snapshot after SQLite has removed sidecars.
        original_guard = m._backup_source
        def checked_guard(directory, path):
            self.assertNotIn(path, vanished, "Excluded transient file reached filesystem checks")
            return original_guard(directory, path)
        original_rglob = Path.rglob
        def enumerated_snapshot(path, *args, **kwargs):
            return iter([source, *vanished]) if path == data else original_rglob(path, *args, **kwargs)
        with patch.object(Path, "rglob", new=enumerated_snapshot), patch.object(m, "_backup_source", side_effect=checked_guard):
            result = m.create_backup(data_directory=data)
        with zipfile.ZipFile(result["path"]) as archive:
            self.assertEqual(set(archive.namelist()), {"data/source.txt", "BACKUP_INFO.json"})

    def test_server_info_rejects_external_and_ambiguous_urls(self):
        (self.root / "data").mkdir()
        for url in ("http://example.com:1234", "http://localhost:1234", "http://127.0.0.1.evil:1234", "http://127.0.0.1:1234/?secret=1", "http://user@127.0.0.1:1234"):
            (self.root / "data/server.json").write_text(json.dumps({"url": url, "token": "a" * 32}))
            with self.subTest(url=url), self.assertRaises(ValueError):
                m._server_info(self.root)

    def test_repair_refuses_running_application(self):
        self.seed({"run.py": b"new"})
        with patch.object(m, "is_running", return_value=True), self.assertRaises(RuntimeError):
            m.repair(self.root)
        self.assertFalse((self.root / "run.py").exists())

    def test_bootstrap_recovers_corrupted_maintenance_module(self):
        bootstrap = m.ROOT / "repair/repair_bootstrap.py"
        (self.root / "repair/repair_bootstrap.py").write_bytes(bootstrap.read_bytes())
        good = (m.ROOT / "agent/maintenance.py").read_bytes()
        self.seed({"agent/maintenance.py": good})
        (self.root / "agent").mkdir()
        (self.root / "agent/maintenance.py").write_bytes(b"syntax error")
        result = subprocess.run([sys.executable, "-I", str(self.root / "repair/repair_bootstrap.py")], capture_output=True, timeout=20)
        self.assertEqual(result.returncode, 0, result.stdout.decode() + result.stderr.decode())
        self.assertEqual((self.root / "agent/maintenance.py").read_bytes(), good)

    def make_backup(self):
        data = self.root / "data"
        data.mkdir(exist_ok=True)
        (data / "source.txt").write_bytes(b"source version one")
        with closing(sqlite3.connect(data / "state.db")) as database:
            with database:
                database.execute("CREATE TABLE info(v INTEGER)")
                database.execute("INSERT INTO info VALUES(42)")
        return Path(m.create_backup(self.root)["path"])

    def test_restore_validates_database_and_preserves_active_work(self):
        backup = self.make_backup()
        active = self.root / "data/source.txt"
        active.write_bytes(b"new active work")
        result = m.restore_backup(backup, self.root)
        self.assertTrue(result["ok"])
        recovered = Path(result["path"])
        self.assertEqual((recovered / "source.txt").read_bytes(), b"source version one")
        self.assertEqual(active.read_bytes(), b"new active work")
        with closing(sqlite3.connect(recovered / "state.db")) as database:
            self.assertEqual(database.execute("SELECT v FROM info").fetchone(), (42,))
        self.assertFalse((recovered / "server.json").exists())

    def modify_archive(self, path, change):
        with zipfile.ZipFile(path) as original:
            values = {name: original.read(name) for name in original.namelist()}
        change(values)
        altered = self.root / "altered.zip"
        with zipfile.ZipFile(altered, "w") as archive:
            for name, value in values.items():
                archive.writestr(name, value)
        return altered

    def test_restore_rejects_tampered_payload_without_changing_active(self):
        backup = self.make_backup()
        altered = self.modify_archive(backup, lambda values: values.update({"data/source.txt": b"tampered"}))
        with self.assertRaisesRegex(ValueError, "checksum"):
            m.restore_backup(altered, self.root)
        self.assertEqual((self.root / "data/source.txt").read_bytes(), b"source version one")
        self.assertEqual(list((self.root / "data/backups").glob("recovered-*")), [])

    def test_restore_rejects_traversal_even_with_matching_hash(self):
        backup = self.make_backup()
        def inject(values):
            evil = b"injected"
            values["data/../outside.txt"] = evil
            metadata = json.loads(values["BACKUP_INFO.json"])
            metadata["sha256"]["data/../outside.txt"] = hashlib.sha256(evil).hexdigest()
            values["BACKUP_INFO.json"] = json.dumps(metadata).encode()
        altered = self.modify_archive(backup, inject)
        with self.assertRaisesRegex(ValueError, "Unsafe"):
            m.restore_backup(altered, self.root)
        self.assertFalse((self.root / "outside.txt").exists())

    def test_restore_rejects_corrupt_sqlite_even_with_matching_hash(self):
        backup = self.make_backup()
        def corrupt(values):
            values["data/state.db"] = b"not a database"
            metadata = json.loads(values["BACKUP_INFO.json"])
            metadata["sha256"]["data/state.db"] = hashlib.sha256(values["data/state.db"]).hexdigest()
            values["BACKUP_INFO.json"] = json.dumps(metadata).encode()
        altered = self.modify_archive(backup, corrupt)
        with self.assertRaises(sqlite3.DatabaseError):
            m.restore_backup(altered, self.root)
        self.assertEqual(list((self.root / "data/backups").glob("recovered-*")), [])

    def test_cmd_scripts_are_ascii_without_bom_and_use_crlf(self):
        scripts = list(m.ROOT.glob("*.cmd"))
        self.assertGreaterEqual(len(scripts), 7)
        for path in scripts:
            content = path.read_bytes()
            with self.subTest(path=path.name):
                content.decode("ascii")
                self.assertTrue(content.startswith(b"@echo off\r\n"))
                self.assertNotIn(b"\n", content.replace(b"\r\n", b""))
                self.assertIn(b"DisableDelayedExpansion", content)
                self.assertNotIn(b"ExecutionPolicy", content)


if __name__ == "__main__":
    unittest.main()
