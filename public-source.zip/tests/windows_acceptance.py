"""Real Windows acceptance. Linux/macOS execution is BLOCKED, never a pass.

Run with the bundled interpreter. All inputs are generated test fixtures;
credentials stay in the temporary data directory and never enter the report.
"""
from __future__ import annotations
import argparse
from contextlib import closing
import ctypes
import hashlib
import http.client
import io
import json
import multiprocessing
import os
from pathlib import Path
import platform
import shutil
import sqlite3
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def _write_report(path, report):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _docx(sections=1):
    buffer = io.BytesIO()
    paragraphs = []
    for index in range(sections):
        text = "12 + 3 = ?" if index == 0 else f"Original acceptance section {index + 1}."
        paragraphs.append('<w:p><w:r><w:t>' + text + '</w:t><w:br w:type="page"/></w:r></w:p>')
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>')
        archive.writestr("word/document.xml", '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>' + "".join(paragraphs) + '</w:body></w:document>')
    return buffer.getvalue()


class Acceptance:
    def __init__(self, work, report):
        self.work = work
        self.data = work / "private-data"
        self.report = report
        self.environment = dict(os.environ, HERZ_DATA_DIR=str(self.data), HERZ_NONINTERACTIVE="1", HERZ_NO_BROWSER="1", PYTHONDONTWRITEBYTECODE="1")
        self.environment["TEMP"] = str(work)
        self.environment["TMP"] = str(work)
        self.proc = None
        self.info = None
        self.log = None
        self.command_count = 0
        self.last_command_output = ""

    def check(self, name, function):
        started = time.monotonic()
        try:
            detail = function()
            self.report["checks"].append({"name": name, "status": "pass", "seconds": round(time.monotonic() - started, 3), "detail": detail})
            print("PASS " + name, flush=True)
            return detail
        except BaseException as error:
            self.report["checks"].append({"name": name, "status": "fail", "seconds": round(time.monotonic() - started, 3), "detail": str(error)[:1800], "error_type": type(error).__name__})
            print("FAIL " + name + ": " + str(error)[:500], flush=True)
            raise

    def command(self, filename, *, timeout=60, background=False, package=ROOT, environment=None, arguments=(), expected_code=0, log_path=None):
        script = package / filename
        if not script.is_file() or '"' in str(script):
            raise ValueError("Invalid test launcher path")
        if any(any(c in str(arg) for c in ('"', '\r', '\n', '%', '!')) for arg in arguments):
            raise ValueError("Unsafe test launcher argument")
        environment = self.environment if environment is None else environment
        cmd = Path(os.environ["SystemRoot"]) / "System32/cmd.exe"
        # Exact quoted command line required by cmd /s /c. Both paths come from
        # the trusted package, never document contents or an HTTP argument.
        quoted_arguments = "".join(f' "{argument}"' for argument in arguments)
        command_line = f'"{cmd}" /d /s /c ""{script}"{quoted_arguments}"'
        if background:
            self.log = (self.work / "server-console.log").open("ab")
            self.proc = subprocess.Popen(command_line, executable=str(cmd), cwd=package, env=environment, stdin=subprocess.DEVNULL, stdout=self.log, stderr=self.log)
            return self.proc
        self.command_count += 1
        log_path = log_path or self.work / f"launcher-{self.command_count:02d}-{filename}.log"
        # A recovered app starts a new console. A real log file avoids waiting
        # for EOF on a pipe inherited by that independently running process.
        with log_path.open("wb") as log:
            result = subprocess.run(command_line, executable=str(cmd), cwd=package, env=environment, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
        self.last_command_output = log_path.read_text("utf-8", errors="replace")
        if result.returncode != expected_code:
            raise AssertionError(f"{filename} exited {result.returncode}, expected {expected_code}: {self.last_command_output[-1800:]}")
        return {"launcher": filename, "exit_code": result.returncode, "expected_exit_code": expected_code}

    def command_json(self):
        start = self.last_command_output.find("{")
        if start < 0:
            raise AssertionError("Launcher did not return its maintenance result")
        return json.JSONDecoder().raw_decode(self.last_command_output[start:])[0]

    def request(self, path, body=None, *, method=None, raw=None, authorized=True):
        from urllib.parse import urlsplit
        address = urlsplit(self.info["url"])
        if address.hostname != "127.0.0.1" or address.scheme != "http":
            raise AssertionError("Server did not bind to numeric loopback")
        headers = {"Origin": self.info["url"]}
        if authorized:
            headers["Authorization"] = "Bearer " + self.info["token"]
        payload = raw if raw is not None else json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
        if payload is not None:
            headers["Content-Type"] = "application/octet-stream" if raw is not None else "application/json"
        connection = http.client.HTTPConnection("127.0.0.1", address.port, timeout=45)
        try:
            connection.request(method or ("POST" if body is not None else "GET"), path, body=payload, headers=headers)
            response = connection.getresponse()
            result = response.read()
            if "json" in response.getheader("Content-Type", ""):
                result = json.loads(result)
            return response.status, result
        finally:
            connection.close()

    def api(self, path, body=None, **kwargs):
        code, result = self.request(path, body, **kwargs)
        if code not in (200, 201):
            # Responses never contain the bearer token; do not dump requests.
            raise AssertionError(f"{path} returned {code}: {str(result)[:1000]}")
        return result

    def start(self):
        self.command("START.cmd", background=True)
        info_path = self.data / "server.json"
        deadline = time.monotonic() + 45
        while time.monotonic() < deadline:
            if self.proc.poll() is not None:
                self.log.flush()
                output = (self.work / "server-console.log").read_text("utf-8", errors="replace")
                raise AssertionError(f"START.cmd exited {self.proc.returncode}: {output[-1800:]}")
            if info_path.exists():
                try:
                    self.info = json.loads(info_path.read_text("utf-8"))
                    state = self.api("/api/state")
                    assert state["app"] == "HERZ Educational Agent"
                    guards = [c for c in state["checks"] if c["name"].startswith("worker_")]
                    assert len(guards) >= 7, guards
                    assert all(c["status"] == "pass" for c in guards), guards
                    assert self.request("/api/state", authorized=False)[0] == 403
                    return {"actual_cmd": True, "spawn_preflight": guards, "unauthorized_request": "rejected", "loopback": "127.0.0.1"}
                except (OSError, ValueError):
                    pass
            time.sleep(0.1)
        raise AssertionError("Windows startup did not complete within 45 seconds")

    def stop(self):
        result = self.command("STOP.cmd", timeout=30)
        self.proc.wait(timeout=15)
        assert self.proc.returncode == 0, self.proc.returncode
        assert not (self.data / "server.json").exists()
        self.log.close()
        self.log = None
        self.proc = None
        self.info = None
        return result

    def job(self, identity):
        return next(j for j in self.api("/api/state")["jobs"] if j["id"] == identity)

    def wait_job(self, identity, states=("completed", "needs_review", "failed", "cancelled", "paused"), timeout=150):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            job = self.job(identity)
            if job["status"] in states:
                return job
            time.sleep(0.03)
        raise AssertionError("Timed out waiting for document worker")

    def upload(self, raw, filename):
        upload = self.api("/api/uploads", {"filename": filename, "size": len(raw), "title": "Original Windows acceptance fixture", "rights_confirmed": True})
        identity = upload["id"]
        middle = max(1, len(raw) // 2)
        offset = 0
        for chunk in (raw[:middle], raw[middle:]):
            if chunk:
                result = self.api(f"/api/uploads/{identity}?offset={offset}", method="PUT", raw=chunk)
                offset += len(chunk)
                assert result["offset"] == offset
        return self.api(f"/api/uploads/{identity}/complete", {})["job"]["id"]

    def demo(self):
        identity = self.api("/api/jobs/demo", {})["job"]["id"]
        job = self.wait_job(identity)
        assert job["status"] == "completed", job
        assert job["output_ready"] and job["counts"]["questions"] == 8, job
        data = self.api(f"/api/jobs/{identity}/download")
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            assert archive.testzip() is None
            assert "index.html" in archive.namelist()
            assert json.loads(archive.read("bundle.json"))["platform_compatibility"] == "not_verified"
        assert self.api(f"/api/jobs/{identity}/validate", {})["valid"]
        return {"questions": job["counts"]["questions"], "download_bytes": len(data), "zip_valid": True, "official_platform_import": "not_verified"}

    def docx_pause_resume(self):
        identity = self.upload(_docx(2000), "acceptance.docx")
        observed = self.wait_job(identity, ("running", "completed", "needs_review", "failed"), 30)
        assert observed["status"] == "running", {"expected": "running before pause", "observed": observed}
        paused = self.api(f"/api/jobs/{identity}/pause", {})["job"]
        assert paused["status"] == "paused"
        resumed = self.api(f"/api/jobs/{identity}/resume", {})["job"]
        assert resumed["status"] == "queued"
        finished = self.wait_job(identity, ("completed", "needs_review", "failed"))
        assert finished["status"] == "needs_review", finished
        assert finished["output_ready"] and finished["counts"]["pages"] == 2000, finished
        # Wait for the parent to drain the worker before checking the artifact.
        deadline = time.monotonic() + 5
        while True:
            code, result = self.request(f"/api/jobs/{identity}/validate", {})
            if code == 200:
                assert result["valid"], result
                break
            if code != 400 or time.monotonic() > deadline:
                raise AssertionError(f"Post-resume validation failed: {code} {result}")
            time.sleep(0.1)
        return {"observed_running": True, "pause": "paused", "resume": "queued", "final": finished["status"], "sections": finished["counts"]["pages"], "partial_coverage_honestly_reported": True}

    def corrupt_document(self):
        identity = self.upload(b"%PDF-1.7\ninvalid original acceptance fixture", "corrupt.pdf")
        job = self.wait_job(identity)
        assert job["status"] == "failed" and not job["output_ready"] and job["error"], job
        return {"invalid_pdf_rejected": True, "false_success": False}

    def backup_restore(self):
        deadline = time.monotonic() + 10
        while True:
            code, result = self.request("/api/backup", {})
            if code == 200:
                break
            if code != 400 or time.monotonic() >= deadline:
                raise AssertionError(f"Backup failed: {code} {result}")
            time.sleep(0.1)
        content = self.api("/api/backup")
        saved = self.work / "acceptance-backup.zip"
        saved.write_bytes(content)
        with zipfile.ZipFile(io.BytesIO(content)) as archive:
            assert "data/state.sqlite3" in archive.namelist()
            assert "data/server.json" not in archive.namelist()
            assert json.loads(archive.read("BACKUP_INFO.json"))["format_version"] == 1
        from agent.maintenance import restore_backup
        previous = os.environ.get("HERZ_DATA_DIR")
        os.environ["HERZ_DATA_DIR"] = str(self.data)
        try:
            recovered = restore_backup(saved, ROOT)
        finally:
            if previous is None:
                os.environ.pop("HERZ_DATA_DIR", None)
            else:
                os.environ["HERZ_DATA_DIR"] = previous
        assert recovered["ok"]
        with closing(sqlite3.connect(Path(recovered["path"]) / "state.sqlite3")) as database:
            assert database.execute("PRAGMA integrity_check").fetchone() == ("ok",)
        assert (self.data / "state.sqlite3").exists()
        return {"bytes": len(content), "sqlite_integrity": "ok", "original_data_preserved": True, "restored_to_separate_folder": True}

    def persistence_restart(self):
        text = "Windows acceptance retained rule"
        self.api("/api/rules", {"text": text, "category": "feedback", "tags": ["acceptance"]})
        self.stop()
        self.start()
        assert any(rule["text"] == text for rule in self.api("/api/state")["rules"])
        return {"real_cmd_restart": True, "saved_rule_retained": True}

    def repair_launchers(self):
        """Exercise destructive-corruption fixtures only in a second test copy."""
        assert self.proc is None, "Stop the original acceptance app first"
        assert not self.work.resolve().is_relative_to(ROOT), "Recovery work directory must be outside the package"
        package = self.work / "إصلاح repair & spaces"
        data = self.work / "repair-user-data"
        shutil.copytree(ROOT, package, ignore=shutil.ignore_patterns(".git", "__pycache__", "data", "artifacts", "ci-results", "ci"))
        shutil.copytree(self.data, data, ignore=shutil.ignore_patterns("backups", "diagnostics", "server.json", "*.lock", "*-wal", "*-shm"))
        marker = data / "original-user-file.txt"
        marker.write_bytes(b"Keep this original user file through every repair.\n")
        originals = {name: hashlib.sha256((data / name).read_bytes()).hexdigest() for name in ("state.sqlite3", marker.name)}
        environment = dict(self.environment, HERZ_DATA_DIR=str(data))
        outcomes = []
        self.report["repair_launcher_results"] = outcomes

        def run(name, **kwargs):
            outcome = self.command(name, package=package, environment=environment, **kwargs)
            outcomes.append(outcome)
            return outcome

        def diagnosis():
            run("DIAGNOSE.cmd")
            result = self.command_json()
            return {check["name"]: check["status"] for check in result["checks"]}

        checks = diagnosis()
        for name in ("program_files", "windows_execution", "offline_repair_seed", "offline_runtime_seed"):
            assert checks[name] == "pass", checks
        run("BACKUP.cmd")
        backup = self.command_json()
        assert backup["ok"]
        backup_path = Path(backup["path"])
        assert backup_path.resolve().is_relative_to((data / "backups").resolve())
        with zipfile.ZipFile(backup_path) as archive:
            assert archive.testzip() is None
            assert archive.read("data/" + marker.name) == marker.read_bytes()
            assert "data/server.json" not in archive.namelist()
        # This is the actual dropped-file argument path, including Arabic and &.
        selected = self.work / "نسخة backup & spaces.zip"
        shutil.copyfile(backup_path, selected)
        run("RESTORE_BACKUP.cmd", arguments=(selected,))
        restored = self.command_json()
        assert restored["ok"]
        recovered = Path(restored["path"])
        assert recovered.resolve().parent == (data / "backups").resolve()
        with closing(sqlite3.connect(recovered / "state.sqlite3")) as database:
            assert database.execute("PRAGMA integrity_check").fetchone() == ("ok",)
        assert (recovered / marker.name).read_bytes() == marker.read_bytes()

        # START_RESTORED is an asynchronous launcher. Retain a Windows handle to
        # its exact child so cleanup cannot accidentally select an unrelated PID.
        process_handle = None
        restored_pid = None
        saved_info = self.info
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.OpenProcess.argtypes = [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
        kernel.OpenProcess.restype = ctypes.c_void_p
        kernel.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
        kernel.WaitForSingleObject.restype = ctypes.c_ulong
        kernel.CloseHandle.argtypes = [ctypes.c_void_p]
        kernel.CloseHandle.restype = ctypes.c_int
        recovered_environment = dict(environment, HERZ_DATA_DIR=str(recovered))
        try:
            run("START_RESTORED.cmd")
            opened = self.command_json()
            assert opened["ok"] and Path(opened["path"]).resolve() == recovered.resolve()
            restored_pid = int(opened["pid"])
            process_handle = kernel.OpenProcess(0x00100000, False, restored_pid)
            assert process_handle, "Could not track the exact recovered app process"
            deadline = time.monotonic() + 45
            while time.monotonic() < deadline:
                assert kernel.WaitForSingleObject(process_handle, 0) == 258, "Recovered app exited before startup"
                try:
                    self.info = json.loads((recovered / "server.json").read_text("utf-8"))
                    assert self.info["pid"] == restored_pid
                    state = self.api("/api/state")
                    assert any(rule["text"] == "Windows acceptance retained rule" for rule in state["rules"])
                    break
                except (OSError, ValueError):
                    time.sleep(0.1)
            else:
                raise AssertionError("START_RESTORED.cmd did not start the recovered app")
            outcomes.append(self.command("STOP.cmd", package=package, environment=recovered_environment, timeout=30))
            assert kernel.WaitForSingleObject(process_handle, 15000) == 0, "Recovered app did not stop"
            assert not (recovered / "server.json").exists()
        finally:
            self.info = saved_info
            if process_handle:
                if kernel.WaitForSingleObject(process_handle, 0) == 258:
                    subprocess.run([str(Path(os.environ["SystemRoot"]) / "System32/taskkill.exe"), "/PID", str(restored_pid), "/T", "/F"], capture_output=True, timeout=15)
                kernel.CloseHandle(process_handle)

        manifest = json.loads((package / "repair/payload-manifest.json").read_text("utf-8"))
        corrupt = {"web/app.js": b"original damaged JavaScript fixture\n", "agent/maintenance.py": b"original damaged Python fixture !!!\n"}
        (package / "web/app.js").write_bytes(corrupt["web/app.js"])
        assert diagnosis()["program_files"] == "fail", "Diagnostics did not detect the damaged program"
        (package / "agent/maintenance.py").write_bytes(corrupt["agent/maintenance.py"])
        run("REPAIR.cmd")
        repaired = self.command_json()
        assert repaired["ok"] and set(corrupt).issubset(repaired["repaired"])
        with zipfile.ZipFile(repaired["backup"]) as archive:
            for name, original in corrupt.items():
                assert archive.read(name) == original, "Repair did not retain the damaged original"
                assert hashlib.sha256((package / name).read_bytes()).hexdigest() == manifest["files"][name]
        assert diagnosis()["program_files"] == "pass"

        runtime = package / "runtime"
        expected_executable = hashlib.sha256((ROOT / "runtime/python.exe").read_bytes()).hexdigest()
        (runtime / "python.exe").rename(runtime / "python.exe.damaged")
        seed = package / "repair/runtime-original.zip"
        with seed.open("ab") as stream:
            stream.write(b"original corruption fixture")
        run("RESTORE_RUNTIME.cmd", expected_code=1)
        assert not (runtime / "python.exe").exists(), "Invalid runtime seed was accepted"
        assert (runtime / "python.exe.damaged").exists()
        shutil.copyfile(ROOT / "repair/runtime-original.zip", seed)
        run("RESTORE_RUNTIME.cmd", timeout=120)
        assert hashlib.sha256((runtime / "python.exe").read_bytes()).hexdigest() == expected_executable
        saved_runtimes = list(package.glob("runtime-backup-*"))
        assert len(saved_runtimes) == 1
        assert hashlib.sha256((saved_runtimes[0] / "python.exe.damaged").read_bytes()).hexdigest() == expected_executable
        checks = diagnosis()  # Uses the newly restored executable itself.
        assert checks["program_files"] == checks["offline_runtime_seed"] == "pass", checks
        for name, digest in originals.items():
            assert hashlib.sha256((data / name).read_bytes()).hexdigest() == digest, "Recovery modified original user data"
        return {"actual_cmds": outcomes, "damaged_python_bootstrap_repaired": True, "damaged_originals_retained": True, "tampered_runtime_seed_rejected": True, "missing_runtime_restored": True, "old_runtime_retained": True, "backup_sqlite_integrity": "ok", "restored_app_started_and_stopped": True, "original_user_data_unchanged": True}

    def full_suite(self):
        log_path = self.work / "unit-tests.log"
        result = self.command("RUN_TESTS.cmd", timeout=420, log_path=log_path)
        output = log_path.read_text("utf-8", errors="replace")
        import re
        count = re.search(r"Ran (\d+) tests? in", output)
        assert count and int(count[1]) > 0, "RUN_TESTS.cmd did not prove that any tests ran"
        assert re.search(r"\nOK(?: \(skipped=\d+\))?\s*\Z", output), "RUN_TESTS.cmd did not finish with the unittest OK summary"
        return {"launcher": "RUN_TESTS.cmd", "exit_code": result["exit_code"], "tests": int(count[1]), "summary": output[-500:]}

    def cleanup(self):
        if self.proc and self.proc.poll() is None:
            try:
                self.stop()
            except BaseException:
                # Only the process tree started by this test is eligible.
                subprocess.run([str(Path(os.environ["SystemRoot"]) / "System32/taskkill.exe"), "/PID", str(self.proc.pid), "/T", "/F"], capture_output=True, timeout=15)
        if self.log:
            self.log.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--work-dir", type=Path, required=True)
    parser.add_argument("--expect-non-admin", action="store_true")
    parser.add_argument("--full-suite", action="store_true")
    arguments = parser.parse_args()
    report = {"app": "HERZ Educational Agent", "suite": "real-windows-acceptance-v1", "status": "running", "checks": [], "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "home_target": {}, "limitations": ["CI hardware is not the home computer; performance and GPU equivalence are not claimed.", "No official HERZ importer, central integration, OCR/model or human audio certification is implied."]}
    if os.name != "nt":
        report.update(status="blocked", reason="Actual Windows kernel required; this host is " + platform.system())
        _write_report(arguments.report, report)
        print("BLOCKED: this acceptance suite requires actual Windows.")
        return 2
    arguments.work_dir.mkdir(parents=True, exist_ok=True)
    os.environ["TEMP"] = str(arguments.work_dir)
    os.environ["TMP"] = str(arguments.work_dir)
    # Do not repair sys.path here: acceptance must detect a broken embedded
    # ._pth configuration rather than hiding it with test-only imports.
    report["machine"] = {"platform": platform.platform(), "architecture": platform.machine()}
    report["machine"]["administrator"] = bool(ctypes.windll.shell32.IsUserAnAdmin())
    report["machine"]["python"] = sys.version
    report["machine"]["data_directory_overridden_for_isolated_tests"] = True
    report["machine"]["package_path_has_arabic"] = any("\u0600" <= c <= "\u06ff" for c in str(ROOT))
    report["machine"]["package_path_has_space_and_ampersand"] = " " in str(ROOT) and "&" in str(ROOT)
    report["tested_files_sha256"] = {}
    for relative in ("run.py", "agent/security.py", "agent/service.py", "agent/worker.py", "agent/maintenance.py", "repair/repair_bootstrap.py", "tests/windows_acceptance.py", "START.cmd", "STOP.cmd", "DIAGNOSE.cmd", "BACKUP.cmd", "REPAIR.cmd", "RESTORE_BACKUP.cmd", "START_RESTORED.cmd", "RESTORE_RUNTIME.cmd", "RUN_TESTS.cmd", "runtime/python.exe", "runtime/python314._pth"):
        with (ROOT / relative).open("rb") as stream:
            report["tested_files_sha256"][relative] = hashlib.file_digest(stream, "sha256").hexdigest()
    acceptance = Acceptance(arguments.work_dir, report)
    try:
        def runtime():
            assert Path(sys.executable).resolve() == (ROOT / "runtime/python.exe").resolve(), "Must use the delivered embedded runtime"
            assert sys.flags.isolated and sys.flags.no_site, "Embedded runtime isolation was not active"
            assert sys.maxsize > 2**32 and platform.machine().lower() in ("amd64", "x86_64"), "Native x64 validation expected"
            assert sys.version_info[:2] == (3, 14)
            if arguments.expect_non_admin:
                assert not report["machine"]["administrator"], "Non-administrator acceptance accidentally ran elevated"
            import pypdf
            from agent.maintenance import system_resources
            report["machine"].update(system_resources(ROOT))
            assert Path(pypdf.__file__).resolve().is_relative_to(ROOT / "vendor")
            with closing(sqlite3.connect(":memory:")) as connection:
                connection.execute("CREATE TABLE probe(value INTEGER)")
                connection.execute("INSERT INTO probe VALUES(42)")
                assert connection.execute("SELECT value FROM probe").fetchone() == (42,)
            return {"python": platform.python_version(), "pypdf": pypdf.__version__, "sqlite": sqlite3.sqlite_version, "embedded_isolated": True, "native_x64": True, "administrator": report["machine"]["administrator"]}
        acceptance.check("embedded_runtime_sqlite_vendor_and_identity", runtime)
        acceptance.check("actual_start_cmd_and_spawn_security_preflight", acceptance.start)
        acceptance.check("original_demo_export_and_validation", acceptance.demo)
        acceptance.check("active_docx_pause_resume_and_checkpoint", acceptance.docx_pause_resume)
        acceptance.check("corrupt_pdf_fails_closed", acceptance.corrupt_document)
        acceptance.check("backup_and_isolated_restore", acceptance.backup_restore)
        acceptance.check("actual_cmd_restart_and_memory_persistence", acceptance.persistence_restart)
        acceptance.check("actual_stop_cmd", acceptance.stop)
        acceptance.check("actual_repair_backup_restore_and_runtime_cmds", acceptance.repair_launchers)
        if arguments.full_suite:
            acceptance.check("full_unit_suite_on_windows", acceptance.full_suite)
        report["status"] = "pass"
        return_code = 0
    except BaseException as error:
        report.update(status="fail", failure_type=type(error).__name__, failure=str(error)[:2000])
        return_code = 1
    finally:
        try:
            acceptance.cleanup()
        except BaseException as cleanup_error:
            report["checks"].append({"name": "test_process_cleanup", "status": "fail", "detail": str(cleanup_error)[:500]})
            report["status"] = "fail"
            return_code = 1
        report["finished_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        _write_report(arguments.report, report)
        print(json.dumps(report, ensure_ascii=True, separators=(",", ":")), flush=True)
    return return_code


if __name__ == "__main__":
    multiprocessing.freeze_support()
    raise SystemExit(main())
