"""Optional reproducible dashboard browser QA; not part of RUN_TESTS.cmd.

Requires Playwright in the developer Python environment and an installed Chromium.
Does not install anything, use existing HERZ data, or contact external services.

Examples:
  python tests/browser_app_check.py --browser /path/to/chromium --output /tmp/herz-ui-qa
  python tests/browser_app_check.py --browser /path/to/chromium --smoke
  python tests/browser_app_check.py --app-python runtime/python.exe --browser-channel msedge --output ci-results/browser-app

With --output, writes a redacted JSON report and optional synthetic-test screenshots
to that local directory. No upload or Library operation is performed.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import tempfile
import time
import traceback
import zipfile
from pathlib import Path

from browser_support import (add_browser_arguments, resolve_runtime, launch_options, app_command, runtime_evidence, close_server, write_report)

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = None
OUTPUT = None


def screenshot(page, name: str) -> None:
    if OUTPUT:
        page.screenshot(path=str(OUTPUT / name), full_page=True, animations="disabled")


def clear_toasts(page) -> None:
    while page.locator(".toast>button").count():
        page.locator(".toast>button").first.click()


def no_overflow(page) -> None:
    assert page.evaluate("document.documentElement.scrollWidth <= window.innerWidth"), "Horizontal overflow"


def upload_fixture(page, path: Path) -> None:
    page.locator("[data-open-upload]").first.click()
    page.locator("#source-file").set_input_files(str(path))
    page.locator("#rights-confirmed").check()
    page.locator("#upload-submit").click()


def write_docx(path: Path, paragraphs: str) -> None:
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_STORED) as archive:
        archive.writestr("[Content_Types].xml", '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/></Types>')
        archive.writestr("word/document.xml", '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>' + paragraphs + "</w:body></w:document>")


def create_demo(page) -> None:
    page.locator("[data-tab=overview]").click()
    page.get_by_role("button", name="جرّب نموذجًا تفاعليًا", exact=True).click()
    page.locator("#all-jobs [data-job-action=preview]").first.wait_for(timeout=45000)


def open_preview(page) -> int:
    page.locator("#all-jobs [data-job-action=preview]").first.click()
    page.locator("#preview-dialog[open]").wait_for(timeout=10000)
    frame = page.frame_locator("#lesson-preview")
    frame.locator("#lesson-app h1").wait_for(timeout=10000)
    content = frame.locator("body").inner_text()
    assert len(content) > 100, "The sandbox preview must render, not only load an empty iframe"
    return len(content)


def backup_download(page, temporary: Path) -> None:
    page.locator("[data-tab=diagnostics]").click()
    with page.expect_download(timeout=20000) as download:
        page.locator("#backup-button").click()
    path = temporary / "backup.zip"
    download.value.save_as(str(path))
    with zipfile.ZipFile(path) as archive:
        assert "data/state.sqlite3" in archive.namelist()
        assert "BACKUP_INFO.json" in archive.namelist()


def shutdown(page, server) -> None:
    if page.locator("#menu-button").is_visible():
        page.locator("#menu-button").click()
    page.locator("[data-tab=settings]").click()
    page.locator("#shutdown-button").click()
    page.locator("#confirm-shutdown").click()
    page.locator("#connection-banner").filter(has_text="توقف البرنامج بأمان").wait_for(timeout=10000)
    server.wait(timeout=15)
    assert server.returncode == 0, "Graceful shutdown must exit successfully"


def dashboard_suite(page, temporary: Path, server, checks: list[str]) -> None:
    assert page.locator("#stat-jobs").inner_text() == "0"
    checks.append("bootstrap, fragment token removed, actual empty state")
    screenshot(page, "dashboard_desktop.png")
    page.locator("[data-tab=memory]").click()
    page.locator("#rule-text").fill("اختبار أمان: <img src=x onerror=alert(1)> لا تكشف الحل")
    page.locator("#rule-tags").fill("اختبار، أمان")
    page.get_by_role("button", name="حفظ في الذاكرة").click()
    page.get_by_text("اختبار أمان:", exact=False).first.wait_for(timeout=10000)
    assert page.locator("#rules-list img").count() == 0
    rule = page.locator(".rule-item").filter(has_text="اختبار أمان:")
    rule.get_by_role("button", name="تعطيل", exact=True).click()
    rule.get_by_role("button", name="تفعيل", exact=True).wait_for(timeout=10000)
    page.locator("#rule-search").fill("اختبار أمان:")
    assert page.locator(".rule-item").count() == 1
    checks.append("memory save, tags, toggle, search and XSS text handling")
    page.locator("[data-tab=chat]").click()
    page.locator("#chat-input").fill("غيّر لون الواجهة إلى أزرق")
    page.locator("#chat-submit").click()
    page.locator("body[data-theme=ocean]").wait_for(timeout=10000)
    assert page.locator(".chat-message.assistant").count() == 2
    checks.append("chat command changes persistent theme")
    page.locator("[data-tab=settings]").click()
    assert page.locator("input[name=theme][value=ocean]").is_checked()
    page.locator("input[name=theme][value=emerald]").check()
    page.get_by_role("button", name="حفظ الإعدادات", exact=True).click()
    page.locator("body[data-theme=emerald]").wait_for(timeout=10000)
    assert page.locator(".capability").count() == 8
    checks.append("supported settings payload and eight capability statuses")
    create_demo(page)
    checks.append("real demo processing produces preview action")
    count = open_preview(page)
    checks.append("sandbox preview renders through current CSP: " + str(count) + " characters")
    screenshot(page, "preview_desktop.png")
    page.locator("#preview-device").click()
    assert "phone" in page.locator("#preview-surface").get_attribute("class")
    page.locator("#close-preview").click()
    assert not page.locator("#preview-dialog").is_visible()
    page.locator("#all-jobs [data-job-action=validate]").first.click()
    page.locator("#report-dialog[open]").wait_for(timeout=10000)
    assert "checks" in page.locator("#report-content").inner_text()
    page.locator("#close-report").click()
    page.locator("#all-jobs [data-job-action=report]").first.click()
    page.locator("#report-dialog[open]").wait_for(timeout=10000)
    assert "source" in page.locator("#report-content").inner_text()
    page.locator("#close-report").click()
    with page.expect_download(timeout=15000) as download:
        page.locator("#all-jobs [data-job-action=download]").first.click()
    download.value.save_as(str(temporary / "lesson.zip"))
    with zipfile.ZipFile(temporary / "lesson.zip") as archive:
        assert "index.html" in archive.namelist()
    checks.append("preview phone/close, package validation/report and ZIP download")
    page.locator("[data-tab=diagnostics]").click()
    page.locator("#run-diagnostics").click()
    page.get_by_text("official_platform_import", exact=True).wait_for(timeout=20000)
    page.wait_for_timeout(2600)  # Exercise the actual 2200ms dashboard poll.
    assert page.get_by_text("official_platform_import", exact=True).count() == 1
    checks.append("diagnostic results survive state polling")
    backup_download(page, temporary)
    checks.append("backup download contains database and format metadata")
    sample = temporary / "sample.docx"
    write_docx(sample, "".join("<w:p><w:r><w:t>" + value + "</w:t></w:r></w:p>" for value in ["تمارين جمع وطرح", "12 + 8 = ?", "30 - 7 = ?"]))
    upload_fixture(page, sample)
    job = page.locator("#all-jobs .job").filter(has_text="sample.docx")
    job.locator("[data-job-action=preview]").wait_for(timeout=30000)
    checks.append("DOCX selection, rights confirmation, upload and completed draft")
    page.locator("[data-tab=overview]").click()
    clear_toasts(page)
    screenshot(page, "dashboard_populated.png")
    page.set_viewport_size({"width": 390, "height": 844})
    no_overflow(page)
    page.locator("#menu-button").click()
    assert page.locator("#sidebar").evaluate("e => e.classList.contains('open')")
    page.locator("[data-tab=memory]").click()
    assert not page.locator("#sidebar").evaluate("e => e.classList.contains('open')")
    no_overflow(page)
    page.get_by_role("button", name="مهمة جديدة", exact=True).click()
    assert page.locator("#panel-workspace").is_visible()
    no_overflow(page)
    checks.append("390px dashboard/memory/workspace, mobile menu and new task")
    page.set_viewport_size({"width": 360, "height": 800})
    no_overflow(page)
    checks.append("360px workspace has no horizontal overflow")


def controls_suite(page, temporary: Path, server, checks: list[str]) -> None:
    large = temporary / "large-control.docx"
    text = "This is a local processing control test. " * 140
    write_docx(large, "".join("<w:p><w:r><w:t>" + str(i) + " " + text + '</w:t><w:br w:type="page"/></w:r></w:p>' for i in range(3000)))
    assert large.stat().st_size > 4 * 1024 * 1024
    upload_fixture(page, large)
    job = page.locator("#all-jobs .job").filter(has_text="large-control.docx")
    job.locator("[data-job-action=pause]").wait_for(timeout=20000)
    job.locator("[data-job-action=pause]").click()
    job.locator("[data-job-action=resume]").wait_for(timeout=15000)
    checks.append("16MB multi-chunk upload and pause through UI")
    job.locator("[data-job-action=resume]").click()
    # Cancel is also present while paused; require the actual resumed state first.
    job.locator("[data-job-action=pause]").wait_for(timeout=10000)
    job.locator("[data-job-action=cancel]").wait_for(timeout=10000)
    job.locator("[data-job-action=cancel]").click()
    job.locator("[data-job-action=retry]").wait_for(timeout=15000)
    checks.append("resume and cancel through UI")
    job.locator("[data-job-action=retry]").click()
    job.locator("[data-job-action=pause]").wait_for(timeout=10000)
    job.locator("[data-job-action=pause]").click()
    job.locator("[data-job-action=resume]").wait_for(timeout=15000)
    checks.append("retry and pause with checkpoint state")
    create_demo(page)
    page.locator("[data-tab=overview]").click()
    clear_toasts(page)
    page.set_viewport_size({"width": 390, "height": 844})
    assert page.locator("#sidebar").bounding_box()["x"] >= 390
    screenshot(page, "dashboard_mobile.png")
    checks.append("settled mobile layout keeps closed sidebar outside viewport")
    for tab in ("chat", "diagnostics", "settings"):
        page.locator("#menu-button").click()
        page.locator("[data-tab=" + tab + "]").click()
        no_overflow(page)
    checks.append("390px chat/diagnostics/settings have no overflow")
    page.locator("input[name=theme][value=ocean]").check()
    page.wait_for_timeout(2600)
    assert page.locator("input[name=theme][value=ocean]").is_checked()
    page.get_by_role("button", name="حفظ الإعدادات", exact=True).click()
    page.locator("body[data-theme=ocean]").wait_for(timeout=10000)
    checks.append("unsaved theme selection survives polling and saves")
    page.locator("#shutdown-button").click()
    page.locator("#dismiss-shutdown").click()
    assert page.locator("#connection-state.connected").is_visible()
    checks.append("shutdown confirmation can be dismissed")
    shutdown(page, server)
    checks.append("safe shutdown through UI exits server with code zero")


def smoke_suite(page, temporary: Path, server, checks: list[str]) -> None:
    assert page.locator("#stat-jobs").inner_text() == "0"
    checks.append("fresh authenticated bootstrap")
    create_demo(page)
    checks.append("demo completes")
    count = open_preview(page)
    checks.append("current CSP permits isolated lesson script: " + str(count) + " rendered characters")
    page.locator("#close-preview").click()
    backup_download(page, temporary)
    checks.append("current backup format downloads correctly")
    shutdown(page, server)
    checks.append("safe shutdown exits successfully")


def run_suite(name, suite, sync_playwright) -> dict:
    checks, errors = [], []
    failure, token = None, ""
    browser_version, info = None, None
    with tempfile.TemporaryDirectory(prefix="herz-browser-qa-") as folder:
        temporary = Path(folder)
        data = temporary / "data"
        log_path = temporary / "server.log"
        with log_path.open("w", encoding="utf-8") as log:
            server = subprocess.Popen(app_command(RUNTIME, ROOT / "run.py"), cwd=ROOT, env=dict(os.environ, HERZ_DATA_DIR=str(data)), stdout=log, stderr=log)
            try:
                deadline = time.monotonic() + 25
                while not (data / "server.json").is_file():
                    if server.poll() is not None:
                        raise RuntimeError("Test server stopped: " + log_path.read_text("utf-8", errors="replace"))
                    if time.monotonic() > deadline:
                        raise TimeoutError("Test server did not become ready in 25 seconds")
                    time.sleep(0.1)
                info = json.loads((data / "server.json").read_text("utf-8"))
                token = info["token"]
                with sync_playwright() as playwright:
                    browser = playwright.chromium.launch(**launch_options(RUNTIME))
                    browser_version = browser.version
                    try:
                        page = browser.new_page(viewport={"width": 1440, "height": 1080}, reduced_motion="reduce")
                        page.on("pageerror", lambda error: errors.append(str(error)))
                        def capture_http_error(response):
                            if response.status >= 400:
                                try:
                                    errors.append("HTTP " + str(response.status) + " " + response.url + " " + response.text()[:500])
                                except Exception:
                                    errors.append("HTTP " + str(response.status) + " " + response.url)
                        page.on("response", capture_http_error)
                        page.on("console", lambda message: errors.append(message.text) if message.type == "error" else None)
                        page.goto(info["url"] + "/#token=" + token)
                        page.locator("#connection-state.connected").wait_for(timeout=15000)
                        assert "#token=" not in page.url, "Bootstrap token must be removed from address bar"
                        suite(page, temporary, server, checks)
                    finally:
                        browser.close()
            except Exception:
                failure = traceback.format_exc()
            finally:
                close_server(server, info)
    redact = lambda value: value.replace(token, "[REDACTED]") if token else value
    return {"suite": name, "browser_version": browser_version, "checks": checks, "errors": [redact(error) for error in errors], "failure": redact(failure) if failure else None, "passed": failure is None and not errors}


def main() -> int:
    global RUNTIME, OUTPUT
    parser = argparse.ArgumentParser(description=__doc__)
    add_browser_arguments(parser)
    parser.add_argument("--output", type=Path, help="Optional local report/screenshot directory")
    parser.add_argument("--smoke", action="store_true", help="Only fresh bootstrap/demo/preview/backup/shutdown checks")
    args = parser.parse_args()
    RUNTIME = resolve_runtime(args, parser)
    OUTPUT = args.output.resolve() if args.output else None
    if OUTPUT:
        OUTPUT.mkdir(parents=True, exist_ok=True)
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("Optional browser QA requires Playwright in a separate developer Python environment. No dependency was installed.", file=sys.stderr)
        return 2
    try:
        evidence = runtime_evidence(RUNTIME)
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        write_report({"passed": False, "group_count": 0, "failure": "Cannot execute selected application Python: " + str(error)}, OUTPUT, "browser_app_check.json")
        return 2
    suites = [("smoke", smoke_suite)] if args.smoke else [("dashboard", dashboard_suite), ("controls", controls_suite)]
    results = [run_suite(name, suite, sync_playwright) for name, suite in suites]
    report = {"passed": all(result["passed"] for result in results), "group_count": sum(len(result["checks"]) for result in results), "runtime": evidence, "suites": results, "scope": "Actual reported OS/browser and selected app Python; mobile viewports are simulated. This does not verify the user's physical computer or Android WebView."}
    write_report(report, OUTPUT, "browser_app_check.json")
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
