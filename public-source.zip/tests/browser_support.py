"""Shared optional browser-QA helpers; never imported by the application.

The Playwright host Python and the application Python are deliberately separate.
No helper installs software, changes browser policy, or downloads a browser.
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import subprocess
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def add_browser_arguments(parser) -> None:
    browser = parser.add_mutually_exclusive_group()
    browser.add_argument("--browser", type=Path, help="Existing Chromium, Chrome, Edge or headless-shell executable")
    browser.add_argument("--browser-channel", choices=("chrome", "msedge", "chromium"), help="Use the named installed browser channel; nothing is installed")
    parser.add_argument("--app-python", type=Path, help="Python used for the app/build; HERZ_APP_PYTHON also works. Windows default: bundled runtime/python.exe; elsewhere: current Python")


def _installed_windows_browser() -> Path | None:
    if os.name != "nt":
        return None
    # Standard machine-wide and per-user locations only, with no registry writes.
    bases = [Path(value) for key in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA") if (value := os.environ.get(key))]
    for relative in (Path("Microsoft/Edge/Application/msedge.exe"), Path("Google/Chrome/Application/chrome.exe")):
        for base in bases:
            candidate = base / relative
            if candidate.is_file():
                return candidate.resolve()
    return None


def resolve_runtime(args, parser) -> dict:
    explicit = args.app_python or os.environ.get("HERZ_APP_PYTHON")
    bundled = ROOT / "runtime" / "python.exe"
    if explicit:
        app_python = Path(explicit).expanduser().resolve()
    elif os.name == "nt":
        # Do not silently substitute a host interpreter when validating the bundle.
        app_python = bundled.resolve()
    else:
        app_python = Path(sys.executable).resolve()
    if not app_python.is_file():
        parser.error("Application Python is missing; supply --app-python PATH (Windows expects bundled runtime/python.exe)")
    browser = args.browser.expanduser().resolve() if args.browser else None
    if browser and not browser.is_file():
        parser.error("--browser must point to an existing browser executable")
    channel = args.browser_channel
    if not browser and not channel:
        browser = _installed_windows_browser()
    return {"app_python": app_python, "browser": browser, "channel": channel, "bundled_python": app_python == bundled.resolve()}


def launch_options(runtime: dict) -> dict:
    options = {"headless": True}
    if runtime["browser"]:
        options["executable_path"] = str(runtime["browser"])
    elif runtime["channel"]:
        options["channel"] = runtime["channel"]
    if os.name != "nt":
        options["args"] = ["--no-sandbox"]
    return options


def app_command(runtime: dict, *arguments) -> list[str]:
    return [str(runtime["app_python"]), "-I", *map(str, arguments)]


def runtime_evidence(runtime: dict) -> dict:
    code = """import ctypes,json,os,platform,sys
admin = bool(ctypes.windll.shell32.IsUserAnAdmin()) if os.name == 'nt' else None
print(json.dumps({'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'system':platform.system(),'machine':platform.machine(),'is_64bit':sys.maxsize>2**32,'is_windows_admin':admin,'isolated':bool(sys.flags.isolated)},ensure_ascii=True))
"""
    result = subprocess.run(app_command(runtime, "-c", code), cwd=ROOT, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=20, check=True)
    app = json.loads(result.stdout)
    digest = hashlib.sha256()
    with runtime["app_python"].open("rb") as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    return {"host_python": sys.version, "host_platform": platform.platform(), "app": app, "app_python_sha256": digest.hexdigest(), "uses_bundled_python": runtime["bundled_python"], "browser_executable": str(runtime["browser"]) if runtime["browser"] else None, "browser_channel": runtime["channel"] or (None if runtime["browser"] else "playwright-default")}


def close_server(server, info: dict | None) -> None:
    """Give the app time to close its worker before any forced termination."""
    if server.poll() is not None:
        return
    if info:
        try:
            request = urllib.request.Request(info["url"] + "/api/shutdown", data=b"{}", method="POST", headers={"Authorization": "Bearer " + info["token"], "Content-Type": "application/json", "Origin": info["url"]})
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with opener.open(request, timeout=3) as response:
                response.read(4096)
            server.wait(timeout=12)
            return
        except (OSError, ValueError, subprocess.TimeoutExpired):
            pass
    # Only terminate this test-owned process tree, never arbitrary matching names.
    if os.name == "nt":
        try:
            subprocess.run(["taskkill", "/PID", str(server.pid), "/T", "/F"], capture_output=True, timeout=10, check=False)
        except (OSError, subprocess.TimeoutExpired):
            server.terminate()
    else:
        server.terminate()
    try:
        server.wait(timeout=10)
    except subprocess.TimeoutExpired:
        server.kill()
        server.wait(timeout=5)


def write_report(report: dict, output: Path | None, filename: str) -> None:
    if output:
        output.mkdir(parents=True, exist_ok=True)
        (output / filename).write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    # ASCII JSON also works when PowerShell redirects a legacy Windows code page.
    print(json.dumps(report, ensure_ascii=True, indent=2))
