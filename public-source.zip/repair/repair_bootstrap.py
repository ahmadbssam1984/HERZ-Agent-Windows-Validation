"""Load the verified offline repair tool even if the installed copy is damaged."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import tempfile
import zipfile

root = Path(__file__).resolve().parents[1]


def main():
    metadata = root / "repair" / "payload-manifest.json"
    if metadata.stat().st_size > 2 * 1024 * 1024:
        raise ValueError("Repair metadata is too large")
    manifest = json.loads(metadata.read_text(encoding="utf-8"))
    payload = root / "repair" / "payload.zip"
    with payload.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    if digest != manifest.get("archive_sha256"):
        raise ValueError("Repair archive checksum failed; no files changed")
    with zipfile.ZipFile(payload) as archive:
        matches = [i for i in archive.infolist() if i.filename == "agent/maintenance.py"]
        if len(matches) != 1 or matches[0].file_size > 1024 * 1024:
            raise ValueError("Invalid repair tool in archive")
        code = archive.read(matches[0])
    if hashlib.sha256(code).hexdigest() != manifest.get("files", {}).get("agent/maintenance.py"):
        raise ValueError("Repair tool checksum failed; no files changed")
    with tempfile.TemporaryDirectory(prefix="herz-repair-tool-") as folder:
        path = Path(folder) / "maintenance_verified.py"
        path.write_bytes(code)
        spec = importlib.util.spec_from_file_location("herz_verified_repair", path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        result = module.repair(root)
        print(json.dumps(result, ensure_ascii=True, indent=2))
        return 0 if result.get("ok") else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, RuntimeError, zipfile.BadZipFile, KeyError) as exc:
        print(json.dumps({"ok": False, "error": str(exc), "action": "See FIRST_RUN_AR.html. Your source documents have not been deleted."}))
        raise SystemExit(1)
