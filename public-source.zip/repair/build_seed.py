"""Build an offline repair seed after all release edits and validation are done.

Maintainer-only utility; it never reads user data or edits application files.
"""
from pathlib import Path
import hashlib
import json
import os
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
ALLOWED_DIRS = {"agent", "web", "tests", "vendor", "docs", "examples"}
ROOT_EXTENSIONS = {".py", ".cmd", ".html", ".md", ".txt", ".json"}


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    files = {}
    for path in sorted(ROOT.rglob("*")):
        rel = path.relative_to(ROOT)
        if not path.is_file() or path.is_symlink():
            continue
        if any(part in ("__pycache__", ".git", "node_modules") for part in rel.parts) or path.suffix in (".pyc", ".tmp", ".part"):
            continue
        if len(rel.parts) == 1:
            if path.suffix.lower() not in ROOT_EXTENSIONS or path.name == "CONTRACT.md":
                continue
        elif rel.parts[0] not in ALLOWED_DIRS:
            continue
        files[rel.as_posix()] = digest(path)
    if "agent/maintenance.py" not in files or "run.py" not in files:
        raise ValueError("Release is incomplete: missing launcher or maintenance module")
    repair = ROOT / "repair"
    with tempfile.TemporaryDirectory(prefix="seed-build-", dir=repair) as temp:
        seed = Path(temp) / "payload.zip"
        with zipfile.ZipFile(seed, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for rel in files:
                archive.write(ROOT / rel, rel)
        manifest = {"version": "1.0.0-rc1", "archive_sha256": digest(seed), "files": files}
        metadata = Path(temp) / "payload-manifest.json"
        metadata.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(seed, repair / "payload.zip")
        os.replace(metadata, repair / "payload-manifest.json")
    print(json.dumps({"files": len(files), "archive_sha256": manifest["archive_sha256"], "archive_bytes": (repair / "payload.zip").stat().st_size}, indent=2))


if __name__ == "__main__":
    main()
