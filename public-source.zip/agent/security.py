"""Application guards, not an OS sandbox or a claim of AppContainer isolation."""
import ctypes
import os
import socket
import sys
from pathlib import Path

class GuardError(PermissionError): pass

def contained(path, roots):
    try:
        p=Path(path).resolve()
        # Canonicalize both sides. On Windows a TEMP path can contain an 8.3
        # alias (RUNNER~1) while resolve() returns its long directory name.
        # Resolving still follows existing links so escapes remain rejected.
        return any(p == r or r in p.parents for r in (Path(root).resolve() for root in roots))
    except (OSError,ValueError,TypeError,RuntimeError):return False

def install_worker_guard(read_roots,write_roots):
    read_roots=[Path(p).resolve() for p in read_roots]
    write_roots=[Path(p).resolve() for p in write_roots]
    def audit(event,args):
        if event.startswith(('socket.', 'ctypes.')) or event in ('os.system','os.exec','os.posix_spawn','subprocess.Popen','os.fork','os.forkpty','os.spawn'):
            raise GuardError('عملية شبكة أو تنفيذ خارجي محظورة داخل عامل المستندات')
        if event == 'open':
            path,mode,flags=args
            if isinstance(path,int): return # inherited pipes, opened handles only
            write=(flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)) != 0
            if not contained(path,write_roots if write else read_roots+write_roots):
                raise GuardError('الوصول إلى ملف خارج نطاق المهمة محظور')
        if event in ('os.listdir','os.scandir','os.chdir'):
            if isinstance(args[0],int) or not contained(args[0],read_roots+write_roots):
                raise GuardError('قراءة دليل خارج نطاق المهمة محظورة')
        if event in ('os.remove','os.rmdir','os.mkdir','os.chmod','os.utime','os.chown','os.truncate'):
            if not contained(args[0],write_roots):raise GuardError('تعديل ملف خارج نطاق المهمة محظور')
            # Relative operations based on directory handles cannot be checked
            # against the process cwd. Disallow that alternative addressing mode.
            dirfd_index={'os.remove':1,'os.rmdir':1,'os.mkdir':2,'os.chmod':2,'os.utime':3,'os.chown':3}.get(event)
            if dirfd_index is not None and len(args)>dirfd_index and args[dirfd_index] not in (-1,None):
                raise GuardError('عمليات الملفات عبر مقبض دليل غير مسموحة')
        if event in ('os.link','os.symlink'):
            raise GuardError('إنشاء الروابط داخل عامل المستندات محظور')
        if event == 'os.rename':
            if not all(contained(p,write_roots) for p in args[:2]):raise GuardError('مسار تعديل غير مسموح')
            if any(fd not in (-1,None) for fd in args[2:]):raise GuardError('مقابض الأدلة غير مسموحة')
    # CPython's open audit event omits dir_fd; refuse it at the Python API.
    # This is application hardening, not isolation against arbitrary native code.
    original_os_open = os.open
    def guarded_os_open(path, flags, mode=0o777, *, dir_fd=None):
        if dir_fd is not None:
            raise GuardError('فتح ملف عبر مقبض دليل غير مسموح')
        return original_os_open(path,flags,mode)
    os.open = guarded_os_open
    sys.addaudithook(audit)

# Win32 constants are named deliberately: PROCESS_TIME is 0x2, whereas 0x4
# is JOB_TIME and uses a different structure field. Mixing them can prevent
# the Windows worker from starting even when all Linux tests pass.
JOB_OBJECT_LIMIT_PROCESS_TIME = 0x00000002
JOB_OBJECT_LIMIT_ACTIVE_PROCESS = 0x00000008
JOB_OBJECT_LIMIT_PROCESS_MEMORY = 0x00000100
JOB_OBJECT_EXTENDED_LIMIT_INFORMATION = 9


class _IOCounters(ctypes.Structure):
    _fields_ = [(name, ctypes.c_uint64) for name in (
        'ReadOperationCount', 'WriteOperationCount', 'OtherOperationCount',
        'ReadTransferCount', 'WriteTransferCount', 'OtherTransferCount')]


class _BasicJobLimits(ctypes.Structure):
    # DWORD is always 32-bit on Windows, including the 64-bit ABI. Explicit
    # widths also allow independent marshalling tests on another platform.
    _fields_ = [
        ('PerProcessUserTimeLimit', ctypes.c_int64),
        ('PerJobUserTimeLimit', ctypes.c_int64),
        ('LimitFlags', ctypes.c_uint32),
        ('MinimumWorkingSetSize', ctypes.c_size_t),
        ('MaximumWorkingSetSize', ctypes.c_size_t),
        ('ActiveProcessLimit', ctypes.c_uint32),
        ('Affinity', ctypes.c_size_t),
        ('PriorityClass', ctypes.c_uint32),
        ('SchedulingClass', ctypes.c_uint32),
    ]


class _ExtendedJobLimits(ctypes.Structure):
    _fields_ = [
        ('BasicLimitInformation', _BasicJobLimits),
        ('IoInfo', _IOCounters),
        ('ProcessMemoryLimit', ctypes.c_size_t),
        ('JobMemoryLimit', ctypes.c_size_t),
        ('PeakProcessMemoryUsed', ctypes.c_size_t),
        ('PeakJobMemoryUsed', ctypes.c_size_t),
    ]


def _windows_worker_limits(memory_mb, cpu_seconds):
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    handle, dword, winbool = ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int32
    kernel.CreateJobObjectW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p]
    kernel.CreateJobObjectW.restype = handle
    kernel.SetInformationJobObject.argtypes = [handle, ctypes.c_int, ctypes.c_void_p, dword]
    kernel.SetInformationJobObject.restype = winbool
    kernel.GetCurrentProcess.argtypes = []
    kernel.GetCurrentProcess.restype = handle
    kernel.AssignProcessToJobObject.argtypes = [handle, handle]
    kernel.AssignProcessToJobObject.restype = winbool
    kernel.QueryInformationJobObject.argtypes = [handle, ctypes.c_int, ctypes.c_void_p, dword, ctypes.POINTER(dword)]
    kernel.QueryInformationJobObject.restype = winbool
    kernel.IsProcessInJob.argtypes = [handle, handle, ctypes.POINTER(winbool)]
    kernel.IsProcessInJob.restype = winbool
    kernel.CloseHandle.argtypes = [handle]
    kernel.CloseHandle.restype = winbool

    job = kernel.CreateJobObjectW(None, None)
    if not job:
        raise OSError(ctypes.get_last_error(), 'تعذر إنشاء حدود موارد عامل Windows')
    required_flags = (JOB_OBJECT_LIMIT_PROCESS_MEMORY |
                      JOB_OBJECT_LIMIT_ACTIVE_PROCESS |
                      JOB_OBJECT_LIMIT_PROCESS_TIME)
    info = _ExtendedJobLimits()
    info.BasicLimitInformation.LimitFlags = required_flags
    info.BasicLimitInformation.ActiveProcessLimit = 1
    info.BasicLimitInformation.PerProcessUserTimeLimit = cpu_seconds * 10_000_000
    info.ProcessMemoryLimit = memory_mb * 1024**2
    try:
        if not kernel.SetInformationJobObject(job, JOB_OBJECT_EXTENDED_LIMIT_INFORMATION,
                                             ctypes.byref(info), ctypes.sizeof(info)):
            raise OSError(ctypes.get_last_error(), 'تعذر ضبط حدود موارد عامل Windows')
        process = kernel.GetCurrentProcess()
        if not kernel.AssignProcessToJobObject(job, process):
            raise OSError(ctypes.get_last_error(), 'تعذر ربط العامل بحدود Windows؛ أوقفت المعالجة')
        actual = _ExtendedJobLimits()
        if not kernel.QueryInformationJobObject(job, JOB_OBJECT_EXTENDED_LIMIT_INFORMATION,
                                               ctypes.byref(actual), ctypes.sizeof(actual), None):
            raise OSError(ctypes.get_last_error(), 'تعذر التحقق من حدود موارد Windows')
        assigned = winbool()
        if not kernel.IsProcessInJob(process, job, ctypes.byref(assigned)) or not assigned.value:
            raise OSError(ctypes.get_last_error(), 'لم يثبت ارتباط العامل بحدود موارد Windows')
        basic = actual.BasicLimitInformation
        if (basic.LimitFlags & required_flags != required_flags or
                basic.LimitFlags & 0x00000004 or
                basic.ActiveProcessLimit != 1 or
                basic.PerProcessUserTimeLimit != cpu_seconds * 10_000_000 or
                actual.ProcessMemoryLimit != memory_mb * 1024**2):
            raise OSError('حدود Windows المقروءة لا تطابق المطلوب؛ أوقفت المعالجة')
    except BaseException:
        kernel.CloseHandle(job)
        raise
    # Keep the verified job alive for the entire worker lifetime. This is a
    # resource limit only; no AppContainer or native-code sandbox is implied.
    globals()['_job_handle'] = job
    return {'memory_limit_mb': memory_mb, 'cpu_limit_seconds': cpu_seconds,
            'process_limit': 1, 'job_limit_flags': int(basic.LimitFlags),
            'limits_verified': True, 'method': 'Windows Job Object'}


def set_worker_limits(memory_mb=768, cpu_seconds=180):
    """Set and verify process resource limits before reading document content."""
    if type(memory_mb) is not int or not 64 <= memory_mb <= 2048:
        raise ValueError('حد ذاكرة العامل غير صالح')
    if type(cpu_seconds) is not int or not 1 <= cpu_seconds <= 180:
        raise ValueError('حد وقت العامل غير صالح')
    if os.name == 'nt':
        return _windows_worker_limits(memory_mb, cpu_seconds)
    import resource
    memory = memory_mb * 1024**2
    resource.setrlimit(resource.RLIMIT_AS, (memory, memory))
    resource.setrlimit(resource.RLIMIT_CPU, (cpu_seconds, cpu_seconds + 10))
    if (resource.getrlimit(resource.RLIMIT_AS) != (memory, memory) or
            resource.getrlimit(resource.RLIMIT_CPU) != (cpu_seconds, cpu_seconds + 10)):
        raise OSError('لم يثبت تطبيق حدود موارد العامل')
    return {'memory_limit_mb': memory_mb, 'cpu_limit_seconds': cpu_seconds,
            'limits_verified': True, 'method': 'rlimit'}

def guard_probe(conn,tmp):
    try:
        root=Path(tmp);root.mkdir(parents=True,exist_ok=True)
        limits=set_worker_limits()
        install_worker_guard([root],[root])
        checks=[]
        for name,fn in [
            ('worker_ipv4',lambda:socket.socket(socket.AF_INET,socket.SOCK_STREAM)),
            ('worker_ipv6',lambda:socket.socket(socket.AF_INET6,socket.SOCK_STREAM)),
            ('worker_dns',lambda:socket.getaddrinfo('example.com',443)),
            ('worker_filesystem',lambda:open(root.parent/'outside-probe','w')),
            ('worker_shell',lambda:os.system('echo blocked')),
        ]:
            try:fn();checks.append({'name':name,'status':'fail','detail':'لم تمنع طبقة الحماية العملية'})
            except GuardError:checks.append({'name':name,'status':'pass','detail':'رفض صريح من طبقة حماية العامل'})
        (root/'allowed-probe').write_text('ok')
        file_ok=(root/'allowed-probe').read_text()=='ok'
        checks.append({'name':'worker_allowed_file','status':'pass' if file_ok else 'fail','detail':'كتابة الملف المسموح وقراءته نجحت' if file_ok else 'failed'})
        checks.append({'name':'worker_memory_limit','status':'pass','detail':str(limits)})
        conn.send({'ok':all(x['status']=='pass' for x in checks),'checks':checks})
    except BaseException as e:conn.send({'ok':False,'checks':[{'name':'worker_guard','status':'fail','detail':str(e)}]})
    finally:conn.close()
