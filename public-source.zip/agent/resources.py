import ctypes
import os
import platform
import shutil
from pathlib import Path

def snapshot(data_dir):
    total=available=None
    if os.name=='nt':
        class MEM(ctypes.Structure):
            _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(n,ctypes.c_ulonglong) for n in ('total','available','page_total','page_available','virtual_total','virtual_available','extended')]
        m=MEM();m.length=ctypes.sizeof(m)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):total,available=m.total,m.available
    elif Path('/proc/meminfo').exists():
        vals={line.split(':')[0]:int(line.split()[1])*1024 for line in Path('/proc/meminfo').read_text().splitlines() if len(line.split())>=2}
        total,available=vals.get('MemTotal'),vals.get('MemAvailable')
        # Container limits, when present, describe this development environment only.
        try:
            limit=Path('/sys/fs/cgroup/memory.max').read_text().strip()
            current=int(Path('/sys/fs/cgroup/memory.current').read_text())
            if limit!='max':total=min(total,int(limit));available=min(available,max(0,int(limit)-current))
        except (OSError,ValueError,TypeError):pass
    return {'memory_total_gb':round(total/1024**3,2) if total else None,'memory_available_gb':round(available/1024**3,2) if available else None,'cpu_count':os.cpu_count(),'disk_free_gb':round(shutil.disk_usage(data_dir).free/1024**3,2),'platform':platform.system()+' '+platform.release(),'target_device':'بيئة اختبار Windows محلية'}
