"""HERZ Educational Agent: local, auditable authoring tools."""
VERSION = '1.0.0-rc1'
