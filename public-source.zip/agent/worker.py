"""Single document worker. Imported inputs are always data, never instructions."""
import sys
import traceback
from pathlib import Path

def execute(conn, cancel, source, work, output, title, rules, demo=False):
    try:
        from . import converter, lesson
        import pypdf
        import encodings.utf_8, encodings.utf_16_le, encodings.cp1252
        from .security import set_worker_limits, install_worker_guard
        work,output=Path(work),Path(output)
        work.mkdir(parents=True,exist_ok=True);output.mkdir(parents=True,exist_ok=True)
        limits=set_worker_limits(768)
        app=Path(__file__).resolve().parent.parent
        roots=[app/'agent',app/'web',app/'vendor',Path(sys.base_prefix)]
        if source:roots.append(Path(source))
        install_worker_guard(roots,[work,output])
        def progress(done,total,stage):
            if cancel.is_set():raise InterruptedError('تم إيقاف المهمة عند نقطة الحفظ')
            conn.send({'type':'progress','done':done,'total':total,'stage':str(stage)})
        if demo:
            document=lesson.demo_document()
            progress(1,1,'إنشاء نموذج تعليمي أصلي')
        else:
            document=converter.extract_document(Path(source),work,progress,cancel.is_set)
            if cancel.is_set():raise InterruptedError('تم إيقاف المهمة')
            if not document.get('questions'):document['questions']=converter.extract_questions(document['pages'])
        progress(len(document.get('pages',[])),len(document.get('pages',[])),'بناء الدروس وفحص الحزمة')
        result=lesson.build_package(document,output,title,rules)
        checks=lesson.validate_package(output)
        result['validation']=checks
        result['limits']=limits
        if not checks.get('valid',False):raise ValueError('الحزمة لم تجتز الفحص البنيوي؛ راجع تقرير التحقق')
        if cancel.is_set():raise InterruptedError('تم إيقاف المهمة')
        conn.send({'type':'result','result':result})
    except InterruptedError:
        conn.send({'type':'paused'})
    except BaseException as e:
        try:conn.send({'type':'error','error':str(e) or type(e).__name__,'error_type':type(e).__name__})
        except (OSError,BrokenPipeError):pass
    finally:conn.close()
