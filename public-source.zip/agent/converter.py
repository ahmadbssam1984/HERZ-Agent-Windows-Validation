"""Bounded local document extraction, with explicit content coverage limitations.

No document content is executed and no external relationships are followed.
PDF parsers still require an OS resource boundary supplied by the job runner.
DOCX sections are logical sections, never asserted to be Word page numbers.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import re
import stat
import zipfile
from decimal import Decimal, InvalidOperation, localcontext
from pathlib import Path, PurePosixPath
from typing import Callable
from xml.etree import ElementTree as ET

EXTRACTOR_VERSION = 1
MAX_SOURCE_BYTES = 500 * 1024 * 1024
MAX_PAGES = 10_000
MAX_PAGE_CHARS = 200_000
MAX_TOTAL_CHARS = 20_000_000
MAX_ZIP_ENTRIES = 10_000
MAX_XML_BYTES = 256 * 1024 * 1024
MAX_UNCOMPRESSED_BYTES = 1024 * 1024 * 1024
DOCX_SECTION_CHARS = 12_000
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
M = "{http://schemas.openxmlformats.org/officeDocument/2006/math}"


class SourceValidationError(ValueError):
    """A readable document failure, safe for a user-facing job report."""


def _atomic_json(path: Path, value: object) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, separators=(",", ":"))
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def _fingerprint(path: Path, cancelled: Callable[[], bool]) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while True:
            if cancelled():
                raise InterruptedError("أوقفت معالجة الملف.")
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


class _Checkpoint:
    def __init__(self, work_dir: Path, source: Path, cancelled: Callable[[], bool]):
        work_dir.mkdir(parents=True, exist_ok=True)
        self.meta_path = work_dir / "extraction.json"
        self.path = work_dir / "pages.jsonl"
        self.cancelled = cancelled
        self.identity = {
            "version": EXTRACTOR_VERSION,
            "source_sha256": _fingerprint(source, cancelled),
            "source_size": source.stat().st_size,
            "format": source.suffix.lower().lstrip("."),
        }
        self.pages: list[dict] = []
        self.total_chars = 0
        self.completed = None
        if self.meta_path.exists():
            if self.meta_path.stat().st_size > 65536:
                raise SourceValidationError("سجل الاستئناف غير صالح.")
            try:
                old = json.loads(self.meta_path.read_text(encoding="utf-8"))
            except (ValueError, OSError) as exc:
                raise SourceValidationError("سجل الاستئناف تالف؛ أعد المهمة في مجلد جديد.") from exc
            if any(old.get(key) != value for key, value in self.identity.items()):
                raise SourceValidationError("تغيّر الملف عن سجل الاستئناف؛ أنشئ مهمة جديدة.")
            self.completed = old.get("completed")
        elif self.path.exists() and self.path.stat().st_size:
            raise SourceValidationError("ملف الاستئناف يفتقد بصمة المصدر؛ أنشئ مهمة جديدة.")
        else:
            _atomic_json(self.meta_path, self.identity)
        if self.path.exists():
            self._read_existing()

    def _read_existing(self) -> None:
        valid_end = 0
        damaged_tail = False
        with self.path.open("rb") as stream:
            while True:
                # UTF-8 Arabic and escaped controls may use up to six bytes per char.
                raw = stream.readline(MAX_PAGE_CHARS * 6 + 65_536)
                if not raw:
                    break
                if not raw.endswith(b"\n"):
                    # A write interrupted at EOF can be resumed without duplicating a page.
                    if stream.read(1):
                        raise SourceValidationError("سطر استئناف أكبر من الحد المسموح.")
                    damaged_tail = True
                    break
                try:
                    page = json.loads(raw)
                    if not isinstance(page, dict) or page.get("number") != len(self.pages) + 1:
                        raise ValueError("noncontiguous checkpoint")
                    self._validate_page(page)
                except (ValueError, TypeError) as exc:
                    raise SourceValidationError("سجل الصفحات تالف؛ لا يمكن الاستئناف الآمن.") from exc
                self.pages.append(page)
                self.total_chars += len(page["text"])
                self._validate_total()
                valid_end = stream.tell()
        if damaged_tail:
            with self.path.open("r+b") as stream:
                stream.truncate(valid_end)
            self.completed = None
            _atomic_json(self.meta_path, self.identity)

    @staticmethod
    def _validate_page(page: dict) -> None:
        if not isinstance(page.get("text"), str) or len(page["text"]) > MAX_PAGE_CHARS:
            raise SourceValidationError("نص قسم واحد يتجاوز حد المعالجة الآمن؛ لم يُحذف أي محتوى بصمت.")
        issues = page.get("issues", [])
        if not isinstance(issues, list) or any(not isinstance(item, str) or len(item) > 200 for item in issues):
            raise SourceValidationError("ملاحظات سجل الصفحة غير صالحة.")

    def _validate_total(self) -> None:
        if len(self.pages) > MAX_PAGES:
            raise SourceValidationError("عدد الصفحات يتجاوز حد 10000 صفحة.")
        if self.total_chars > MAX_TOTAL_CHARS:
            raise SourceValidationError("النص المستخرج يتجاوز حد 20 مليون محرف؛ قسّم المصدر إلى أجزاء.")

    def append(self, page: dict) -> None:
        if self.cancelled():
            raise InterruptedError("أوقفت معالجة الملف.")
        self._validate_page(page)
        if page["number"] != len(self.pages) + 1:
            raise SourceValidationError("ترتيب صفحات الاستئناف غير متصل.")
        if len(self.pages) + 1 > MAX_PAGES or self.total_chars + len(page["text"]) > MAX_TOTAL_CHARS:
            raise SourceValidationError("تجاوز الملف حد النص الآمن؛ قسّمه إلى أجزاء دون حذف محتواه.")
        raw = (json.dumps(page, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")
        with self.path.open("ab") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        self.pages.append(page)
        self.total_chars += len(page["text"])

    def finish(self, details: dict) -> None:
        self.completed = details
        _atomic_json(self.meta_path, {**self.identity, "completed": details})


class _SafeXMLReader:
    """Reject declarations/entities across read boundaries before XML sees them."""
    def __init__(self, stream, cancelled: Callable[[], bool]):
        self.stream = stream
        self.cancelled = cancelled
        self.total = 0
        self.tail = b""

    def read(self, size: int = -1) -> bytes:
        if self.cancelled():
            raise InterruptedError("أوقفت معالجة الملف.")
        # ElementTree normally requests 16 KiB; never honor an unbounded read.
        block = self.stream.read(min(size if size >= 0 else 65536, 65536))
        self.total += len(block)
        if self.total > MAX_XML_BYTES:
            raise SourceValidationError("ملف XML داخل المستند أكبر من الحد الآمن.")
        combined = self.tail + block
        # Word XML is UTF-8 or UTF-16; ignoring NUL covers UTF-16 declaration spellings.
        normalized = combined.replace(b"\x00", b"").upper()
        if b"<!DOCTYPE" in normalized or b"<!ENTITY" in normalized:
            raise SourceValidationError("المستند يحتوي تعريفات XML غير مسموح بها.")
        self.tail = combined[-128:]
        return block


def _checked_zip(path: Path) -> zipfile.ZipFile:
    try:
        archive = zipfile.ZipFile(path)
        entries = archive.infolist()
        if len(entries) > MAX_ZIP_ENTRIES:
            raise SourceValidationError("عدد ملفات DOCX الداخلية أكبر من الحد الآمن.")
        total = 0
        names: set[str] = set()
        for item in entries:
            name = item.filename
            parts = PurePosixPath(name).parts
            if (not name or "\\" in name or "\x00" in name or ":" in name or
                    name.startswith("/") or any(part in {"..", "."} for part in parts)):
                raise SourceValidationError("مسار داخلي غير آمن في ملف DOCX.")
            if name in names:
                raise SourceValidationError("ملف DOCX يحتوي أسماء داخلية مكررة.")
            names.add(name)
            if stat.S_ISLNK(item.external_attr >> 16):
                raise SourceValidationError("الروابط الرمزية غير مسموح بها داخل DOCX.")
            if item.flag_bits & 1:
                raise SourceValidationError("ملف DOCX مشفّر وغير مدعوم.")
            total += item.file_size
            if total > MAX_UNCOMPRESSED_BYTES:
                raise SourceValidationError("الحجم بعد فك الضغط يتجاوز الحد الآمن.")
            if name.lower().endswith((".xml", ".rels")) and item.file_size > MAX_XML_BYTES:
                raise SourceValidationError("عنصر XML داخل DOCX أكبر من الحد الآمن.")
            if item.file_size > 1024 * 1024 and item.file_size > max(item.compress_size, 1) * 200:
                raise SourceValidationError("نسبة ضغط DOCX غير آمنة؛ احتمال أرشيف تضخمي.")
        if "word/document.xml" not in names or "[Content_Types].xml" not in names:
            raise SourceValidationError("هذا الأرشيف ليس مستند DOCX صالحًا.")
        if any(name.lower().endswith("vbaproject.bin") for name in names):
            raise SourceValidationError("ملفات Word المحتوية على ماكرو غير مقبولة.")
        return archive
    except SourceValidationError:
        if "archive" in locals():
            archive.close()
        raise
    except (zipfile.BadZipFile, OSError, RuntimeError) as exc:
        raise SourceValidationError("تعذر قراءة بنية ملف DOCX.") from exc


def _extract_docx(source: Path, checkpoint: _Checkpoint, progress: Callable, cancelled: Callable) -> dict:
    warnings = ["ترقيم DOCX يمثل أقسامًا نصية منطقية، ولا يساوي أرقام صفحات Word المطبوعة."]
    global_issues: set[str] = set()
    page_number = 0
    blocks: list[str] = []
    issues: set[str] = set()
    current_chars = 0
    resume_count = len(checkpoint.pages)

    def flush(force: bool = False) -> None:
        nonlocal page_number, blocks, issues, current_chars
        if not blocks and not issues and not force:
            return
        page_number += 1
        if page_number > MAX_PAGES:
            raise SourceValidationError("عدد أقسام DOCX يتجاوز الحد الآمن.")
        page = {"number": page_number, "text": "\n".join(blocks).strip(), "issues": sorted(issues),
                "pagination_kind": "docx_logical_sections"}
        if page_number > resume_count:
            checkpoint.append(page)
        elif page != checkpoint.pages[page_number - 1]:
            raise SourceValidationError("سجل DOCX لا يطابق نتيجة الاستخراج؛ أنشئ مهمة جديدة.")
        progress(page_number, 0, "استخراج أقسام Word" if page_number > resume_count else "استعادة سجل Word")
        blocks, issues, current_chars = [], set(), 0

    with _checked_zip(source) as archive:
        media_count = sum(name.startswith("word/media/") and not name.endswith("/") for name in archive.namelist())
        if media_count:
            global_issues.add("images_not_reconstructed")
            warnings.append(f"يتضمن المستند {media_count} ملف وسائط؛ لم تُنسخ الصور الأصلية إلى الحزمة.")
        secondary_parts = [name for name in archive.namelist()
                           if re.fullmatch(r"word/(?:header\d*|footer\d*|footnotes|endnotes|comments)\.xml", name)]
        if secondary_parts:
            global_issues.add("secondary_document_parts_not_extracted")
            warnings.append("حواشي/رؤوس/تذييلات/تعليقات Word خارج النص الرئيسي لم تُستخرج: " + ", ".join(secondary_parts))
        # Relationships are parsed only to record missing external media; never followed.
        rel_path = "word/_rels/document.xml.rels"
        if rel_path in archive.namelist():
            with archive.open(rel_path) as stream:
                try:
                    for _, elem in ET.iterparse(_SafeXMLReader(stream, cancelled), events=("end",)):
                        if elem.tag.endswith("Relationship") and elem.attrib.get("TargetMode") == "External":
                            rel_type = elem.attrib.get("Type", "")
                            if not rel_type.endswith("/hyperlink"):
                                global_issues.add("external_media_not_fetched")
                            warnings.append("رابط خارجي داخل Word لم يُفتح أو يُحمّل.")
                        elem.clear()
                except ET.ParseError as exc:
                    raise SourceValidationError("علاقات DOCX غير صالحة.") from exc
        with archive.open("word/document.xml") as stream:
            try:
                stack: list = []
                paragraph_depth = 0
                for event, elem in ET.iterparse(_SafeXMLReader(stream, cancelled), events=("start", "end")):
                    if event == "start":
                        stack.append(elem)
                        if elem.tag == W + "p":
                            paragraph_depth += 1
                        if elem.tag == W + "tbl":
                            issues.add("table_structure_not_reconstructed")
                            global_issues.add("table_structure_not_reconstructed")
                        continue
                    if elem.tag == W + "p":
                        # Textbox paragraphs can nest inside a drawing; only consume outer once.
                        paragraph_depth -= 1
                        if paragraph_depth == 0:
                            fragments: list[str] = []
                            paragraph_issues: set[str] = set()
                            for node in elem.iter():
                                if node.tag in {W + "t", M + "t"}:
                                    fragments.append(node.text or "")
                                elif node.tag == W + "tab":
                                    fragments.append("\t")
                                elif node.tag == W + "br":
                                    fragments.append("\f" if node.attrib.get(W + "type") == "page" else "\n")
                                elif node.tag == W + "lastRenderedPageBreak":
                                    fragments.append("\f")
                                if node.tag in {M + "oMath", M + "oMathPara"}:
                                    paragraph_issues.add("math_layout_needs_review")
                                    global_issues.add("math_layout_needs_review")
                                if node.tag in {W + "drawing", W + "pict", W + "object"}:
                                    paragraph_issues.add("images_not_reconstructed")
                                    global_issues.add("images_not_reconstructed")
                                if node.tag in {W + "fldChar", W + "instrText"}:
                                    paragraph_issues.add("dynamic_field_needs_review")
                                    global_issues.add("dynamic_field_needs_review")
                                if node.tag in {W + "ins", W + "del"}:
                                    paragraph_issues.add("tracked_changes_need_review")
                                    global_issues.add("tracked_changes_need_review")
                            paragraph = "".join(fragments)
                            if len(paragraph) > MAX_PAGE_CHARS:
                                raise SourceValidationError("فقرة Word تتجاوز حد النص الآمن؛ قسّم المستند.")
                            for part_index, part in enumerate(paragraph.split("\f")):
                                if part_index:
                                    flush(force=True)
                                if part:
                                    if current_chars and current_chars + len(part) > DOCX_SECTION_CHARS:
                                        flush()
                                    issues.update(paragraph_issues)
                                    blocks.append(part)
                                    current_chars += len(part) + 1
                                elif paragraph_issues:
                                    issues.update(paragraph_issues)
                            elem.clear()
                            if len(stack) > 1:
                                stack[-2].remove(elem)
                    elif paragraph_depth == 0 and elem.tag not in {W + "document", W + "body"}:
                        elem.clear()
                        if len(stack) > 1:
                            stack[-2].remove(elem)
                    stack.pop()
            except ET.ParseError as exc:
                raise SourceValidationError("نص XML داخل Word تالف أو غير مدعوم.") from exc
            except (zipfile.BadZipFile, EOFError, RuntimeError) as exc:
                raise SourceValidationError("تعذر فك محتوى Word بصورة سليمة.") from exc
        flush(force=page_number == 0)
    if page_number < resume_count:
        raise SourceValidationError("سجل الاستئناف أطول من مصدر Word الحالي.")
    if not any(page["text"].strip() for page in checkpoint.pages):
        global_issues.add("no_extractable_text")
        warnings.append("لا يوجد نص قابل للاستخراج؛ الصور تحتاج OCR محليًا غير مرفق بهذه النسخة.")
    for issue, message in {
        "math_layout_needs_review": "معادلات Word حفظت كنص فقط؛ الكسور والأسس والبنية الرياضية تحتاج إعادة بناء وتحقق.",
        "table_structure_not_reconstructed": "حُفظ نص الجداول بترتيب المصدر؛ بنية الصفوف والأعمدة لم تُعد بناؤها.",
        "dynamic_field_needs_review": "حقول Word الديناميكية محفوظة بنصها الظاهر وتحتاج تحققًا.",
        "external_media_not_fetched": "وسائط Word الخارجية لم تُحمّل ولم تُضمن.",
        "tracked_changes_need_review": "يتضمن Word تعقب تغييرات؛ لم تُعتمد النسخة العلمية النهائية للنص.",
    }.items():
        if issue in global_issues:
            warnings.append(message)
    progress(page_number, page_number, "اكتمل استخراج نص Word")
    return {"warnings": list(dict.fromkeys(warnings)), "format": "docx", "pages_total": page_number,
            "pagination_kind": "docx_logical_sections", "coverage_complete": not global_issues,
            "coverage_issues": sorted(global_issues), "source_coverage_verified": False,
            "images_count": media_count}


def _pdf_image_count(page) -> int:
    seen: set[tuple] = set()

    def walk(resources, depth: int) -> int:
        if not resources or depth > 4:
            return 0
        resources = resources.get_object() if hasattr(resources, "get_object") else resources
        objects = resources.get("/XObject", {})
        objects = objects.get_object() if hasattr(objects, "get_object") else objects
        if len(objects) > 10_000:
            raise SourceValidationError("موارد PDF في صفحة واحدة تتجاوز الحد الآمن.")
        count = 0
        for ref in objects.values():
            key = (getattr(ref, "idnum", id(ref)), getattr(ref, "generation", 0))
            if key in seen:
                continue
            seen.add(key)
            obj = ref.get_object() if hasattr(ref, "get_object") else ref
            if obj.get("/Subtype") == "/Image":
                count += 1
            elif obj.get("/Subtype") == "/Form":
                count += walk(obj.get("/Resources", {}), depth + 1)
        return count

    return walk(page.get("/Resources", {}), 0)


def _extract_pdf(source: Path, checkpoint: _Checkpoint, progress: Callable, cancelled: Callable) -> dict:
    try:
        from pypdf import PdfReader
        from pypdf.errors import PdfReadError
    except ImportError as exc:
        raise SourceValidationError("مكوّن قراءة PDF غير موجود؛ شغّل فحص ملفات الإصلاح.") from exc
    warnings = ["استخراج نص PDF لا يثبت ترتيب العربية أو صحة المعادلات والرسومات؛ يلزم تدقيق التغطية قبل الاعتماد."]
    # The caller runs this parser in a worker with a memory/time limit.
    try:
        with source.open("rb") as stream:
            reader = PdfReader(stream, strict=True)
            if reader.is_encrypted:
                raise SourceValidationError("ملف PDF مشفر؛ أرسل نسخة غير مشفرة مسموحًا بمعالجتها.")
            total = len(reader.pages)
            if total < 1 or total > MAX_PAGES:
                raise SourceValidationError("عدد صفحات PDF يجب أن يكون بين 1 و10000.")
            if len(checkpoint.pages) > total:
                raise SourceValidationError("سجل استئناف PDF يتجاوز عدد صفحات المصدر.")
            progress(len(checkpoint.pages), total, "قراءة صفحات PDF")
            for index in range(len(checkpoint.pages), total):
                if cancelled():
                    raise InterruptedError("أوقفت معالجة الملف.")
                page = reader.pages[index]
                text = page.extract_text() or ""
                if len(text) > MAX_PAGE_CHARS:
                    raise SourceValidationError(f"نص الصفحة {index + 1} يتجاوز حد المعالجة الآمن.")
                image_count = _pdf_image_count(page)
                issues = []
                if image_count:
                    issues.append("images_not_reconstructed")
                if not text.strip():
                    issues.append("needs_ocr" if image_count else "empty_or_vector_page_needs_review")
                checkpoint.append({"number": index + 1, "text": text, "issues": issues,
                                   "images_count": image_count, "needs_ocr": not text.strip() and image_count > 0,
                                   "pagination_kind": "pdf_pages"})
                progress(index + 1, total, "استخراج نص PDF")
    except (SourceValidationError, InterruptedError):
        raise
    except (PdfReadError, ValueError, TypeError, KeyError, IndexError, RecursionError, OSError) as exc:
        raise SourceValidationError("تعذر قراءة PDF بصورة سليمة؛ قد يكون تالفًا أو يستخدم ترميزًا غير مدعوم.") from exc
    all_issues = sorted({issue for page in checkpoint.pages for issue in page["issues"]})
    if "needs_ocr" in all_issues:
        warnings.append("توجد صفحات مصورة تحتاج OCR؛ محرك OCR غير مرفق، ولم يُدّع استخراج محتواها.")
    if "images_not_reconstructed" in all_issues:
        warnings.append("الصور والرسومات لم تُعد بناؤها؛ لم تُدرج صفحات الكتاب الأصلية داخل الحزمة.")
    if "empty_or_vector_page_needs_review" in all_issues:
        warnings.append("توجد صفحات بلا نص مستخرج؛ قد تكون فارغة أو تحتوي رسومات/نصًا مرسومًا.")
    return {"warnings": warnings, "format": "pdf", "pages_total": total,
            "pagination_kind": "pdf_pages", "coverage_complete": False,
            "coverage_issues": sorted(set(all_issues + ["pdf_layout_and_math_not_verified"])),
            "source_coverage_verified": False,
            "images_count": sum(page.get("images_count", 0) for page in checkpoint.pages)}


_DIGIT_MAP = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹٫−–", "01234567890123456789.--")
_NUMBER = r"[+-]?\d{1,10}(?:\.\d{1,6})?"
_EXERCISE = re.compile(
    rf"^\s*(?:(?:احسب|أحسب|اوجد|أوجد|Calculate|Compute)\s*[:：]?\s*)?"
    rf"(?:(?:\(?[A-Da-d]\)?|\d{{1,3}})\s*[).:：]\s+)?"
    rf"(?P<a>{_NUMBER})\s*(?P<op>[+\-×xX*÷/])\s*(?P<b>{_NUMBER})"
    rf"\s*=\s*(?:[?؟]|[_…]+|\.{2,}|□|\[\s*\])\s*$"
)


def _decimal_text(value: Decimal) -> str:
    if value == 0:
        return "0"
    return format(value.normalize(), "f")


def extract_questions(pages: list[dict]) -> list[dict]:
    """Recognize only explicit, standalone, unsolved binary arithmetic exercises.

    Textbook semantic questions, solved examples and arbitrary number pairs are
    deliberately not inferred. Answers use Decimal and exact finite division.
    """
    questions: list[dict] = []
    for page in pages:
        page_count = 0
        # Math-layout pages may have lost fraction/exponent structure.
        if "math_layout_needs_review" in page.get("issues", []):
            continue
        for original_line in page.get("text", "").splitlines():
            if len(original_line) > 250:
                continue
            line = original_line.translate(_DIGIT_MAP).replace("\u200f", "").replace("\u200e", "")
            match = _EXERCISE.fullmatch(line)
            if not match:
                continue
            a, b = Decimal(match["a"]), Decimal(match["b"])
            operation = match["op"]
            try:
                with localcontext() as context:
                    context.prec = 50
                    if operation == "+":
                        answer = a + b
                    elif operation == "-":
                        answer = a - b
                    elif operation in {"×", "x", "X", "*"}:
                        answer = a * b
                    else:
                        if not b:
                            continue
                        answer = a / b
                        if answer * b != a or answer.as_tuple().exponent < -8:
                            continue
            except (InvalidOperation, ArithmeticError):
                continue
            page_count += 1
            op = "×" if operation in {"x", "X", "*"} else "÷" if operation == "/" else operation
            expression = f"{_decimal_text(a)} {op} {_decimal_text(b)}"
            answer_text = _decimal_text(answer)
            questions.append({
                "id": f"p{page['number']}-q{page_count}", "type": "input",
                "prompt": f"احسب: {expression} = ؟", "answer": answer_text,
                "expression": expression, "explanation": f"{expression} = {answer_text}",
                "hint": "حدّد العملية أولًا، ثم احسب بعناية.", "source_page": page["number"],
                "source_text": original_line.strip(), "verified": True,
                "verification": "decimal_arithmetic_v1",
            })
    return questions


def extract_document(source: Path, work_dir: Path, progress: Callable[[int, int, str], None],
                     cancelled: Callable[[], bool], start_page: int = 0) -> dict:
    """Extract a PDF/DOCX incrementally, resuming verified page checkpoints.

    ``start_page`` is a hint only: never skip pages absent from the checkpoint.
    Completed source sections remain in ``pages.jsonl`` on cancellation.
    The final list is bounded by MAX_TOTAL_CHARS, independently of source size.
    """
    source, work_dir = Path(source), Path(work_dir)
    if source.is_symlink() or not source.is_file():
        raise SourceValidationError("ملف المصدر غير موجود أو ليس ملفًا عاديًا.")
    size = source.stat().st_size
    if size <= 0 or size > MAX_SOURCE_BYTES:
        raise SourceValidationError("حجم المصدر يجب أن يكون أكبر من صفر وألا يتجاوز 500 MiB.")
    suffix = source.suffix.lower()
    if suffix not in {".pdf", ".docx"}:
        raise SourceValidationError("الصيغ المقبولة هي PDF وDOCX فقط.")
    if not isinstance(start_page, int) or start_page < 0:
        raise SourceValidationError("موضع الاستئناف غير صالح.")
    if cancelled():
        raise InterruptedError("أوقفت معالجة الملف.")
    checkpoint = _Checkpoint(work_dir, source, cancelled)
    if checkpoint.completed is not None:
        details = checkpoint.completed
        if details.get("pages_total") != len(checkpoint.pages):
            raise SourceValidationError("سجل اكتمال الصفحات غير متطابق.")
        progress(len(checkpoint.pages), len(checkpoint.pages), "استعادة الاستخراج المكتمل")
    elif suffix == ".docx":
        details = _extract_docx(source, checkpoint, progress, cancelled)
        checkpoint.finish(details)
    else:
        details = _extract_pdf(source, checkpoint, progress, cancelled)
        checkpoint.finish(details)
    questions = extract_questions(checkpoint.pages)
    result = {**details, "pages": checkpoint.pages, "questions": questions,
              "source_sha256": checkpoint.identity["source_sha256"],
              "source_size": size, "characters": checkpoint.total_chars,
              "extraction_version": EXTRACTOR_VERSION}
    _atomic_json(work_dir / "coverage-extraction.json", {key: value for key, value in result.items() if key not in {"pages", "questions"}})
    return result
