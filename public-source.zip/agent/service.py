import hashlib
import importlib.util
import json
import multiprocessing
import os
import queue
import re
import shutil
import tempfile
import threading
import time
import uuid
import zipfile
from pathlib import Path

from . import VERSION
from .resources import snapshot
from .store import Store,now
from . import central_adapter

MAX_UPLOAD=500*1024**2
CHUNK=4*1024**2
_NO_PIPE_MESSAGE=object()
_PIPE_CLOSED=object()

def _read_worker_message(connection,timeout=0):
    """Distinguish no message from a peer closing its IPC connection.

    Windows named-pipe poll can raise ERROR_BROKEN_PIPE after the child
    closes its end; Unix normally exposes that closure as EOF during recv.
    Only peer-closure errors are normalized. Invalid handles and other I/O
    errors remain failures instead of being mistaken for successful work.
    """
    try:
        if not connection.poll(timeout):return _NO_PIPE_MESSAGE
        return connection.recv()
    except EOFError:return _PIPE_CLOSED
    except OSError as error:
        if isinstance(error,(BrokenPipeError,ConnectionResetError)) or getattr(error,'winerror',None) in (109,232,233):
            return _PIPE_CLOSED
        raise

def private_path(root,*parts):
    # Resolve internal paths without following links/junctions out of data.
    base=Path(root).resolve()
    candidate=base.joinpath(*parts)
    try:relative=candidate.relative_to(base)
    except ValueError:raise ValueError('مسار خارج مجلد بيانات البرنامج') from None
    if any(p in ('..','.') for p in relative.parts):raise ValueError('مسار بيانات غير صالح')
    current=base
    for part in relative.parts:
        current=current/part
        if current.is_symlink() or (hasattr(current,'is_junction') and current.is_junction()):
            raise ValueError('روابط الملفات والأدلة غير مسموحة داخل بيانات البرنامج')
    resolved=candidate.resolve()
    if resolved!=base and base not in resolved.parents:raise ValueError('مسار خارج مجلد بيانات البرنامج')
    return candidate

def data_root():
    if os.environ.get('HERZ_DATA_DIR'):return Path(os.environ['HERZ_DATA_DIR']).resolve()
    if os.name=='nt':return Path(os.environ.get('LOCALAPPDATA',str(Path.home())))/'HERZ'/'EducationalAgent'
    return Path(__file__).resolve().parent.parent/'data'

class Service:
    def __init__(self,root=None):
        self.root=Path(root or data_root()).resolve();self.root.mkdir(parents=True,exist_ok=True,mode=0o700)
        for n in ('uploads','jobs','backups','reports'): private_path(self.root,n).mkdir(exist_ok=True)
        self.db=Store(private_path(self.root,'state.sqlite3'));self.lock=threading.RLock();self.stopping=threading.Event()
        self.active=None;self.checks=[];self._preflight_ok=False;self.context=multiprocessing.get_context('spawn')
        self._backup_path=None
        for job in self.db.jobs():
            if job['status'] in ('running','queued'):
                job.update(status='paused',stage='توقفت الجلسة السابقة؛ يمكن الاستئناف من آخر نقطة حفظ')
                self.db.save_job(job)
        self.thread=threading.Thread(target=self._loop,daemon=True)

    def preflight(self):
        from .security import guard_probe
        recv,send=self.context.Pipe(duplex=False)
        with tempfile.TemporaryDirectory(prefix='herz-guard-') as tmp:
            process=self.context.Process(target=guard_probe,args=(send,str(Path(tmp)/'allowed')))
            process.start();send.close()
            result={'ok':False,'checks':[{'name':'startup_guard','status':'fail','detail':'لم يكتمل فحص الحماية خلال المهلة'}]}
            try:
                message=_read_worker_message(recv,15)
                if message is not _NO_PIPE_MESSAGE and message is not _PIPE_CLOSED:result=message
            finally:
                process.join(2)
                if process.is_alive():process.terminate();process.join(3)
                recv.close()
        self.checks=result['checks']
        self._preflight_ok=result.get('ok') is True and all(c.get('status')=='pass' for c in self.checks)
        return self._preflight_ok

    def start(self):
        if not self._preflight_ok:raise PermissionError('لا تبدأ المعالجة قبل نجاح فحص حماية العامل')
        self.thread.start()

    def capabilities(self):
        return {
            'pdf':{'available':importlib.util.find_spec('pypdf') is not None,'detail':'استخراج النص؛ لا يثبت فهم كل تمارين الكتاب'},
            'docx':{'available':True,'detail':'نصوص مرتبة وأقسام منطقية مع كشف العناصر غير المحولة'},
            'ocr':{'available':False,'detail':'محرك OCR عربي معتمد غير مرفق؛ الصفحات المصورة تُسجّل معلقة'},
            'local_ai':{'available':False,'detail':'لا نموذج لغوي معتمد مرفق. المحادثة الحالية أوامر محددة مع استرجاع الذاكرة'},
            'central':{'available':False,'detail':'نسخة المدير الحالية تمنع تشغيل الوكلاء الخارجيين؛ أُرفق تقرير الربط'},
            'platform_import':{'available':False,'detail':'تصدير HTML مستقل؛ لم يُختبر في المستورد الرسمي للمنصة'},
            'speech':{'available':False,'detail':'أصوات تشجيع محلية؛ القراءة العربية والإنجليزية غير معتمدة'},
            'free_services':{'available':False,'detail':'لا تسجيل حسابات أو خدمات خارجية في هذه النسخة؛ لا تكاليف'},
        }

    def state(self):
        return {'app':'HERZ Educational Agent','version':VERSION,'jobs':self.db.jobs(),'rules':self.db.rules(),'events':self.db.events(),'resources':snapshot(self.root),'capabilities':self.capabilities(),'settings':self.db.settings(),'checks':self.checks}

    def begin_upload(self,body):
        name=body.get('filename','');size=body.get('size')
        if not isinstance(name,str) or not name or len(name)>180 or any(c in name for c in '\\/:\x00\r\n') or name.strip()!=name:
            raise ValueError('اسم الملف غير صالح؛ استخدم اسمًا قصيرًا دون مسارات')
        if Path(name).suffix.lower() not in ('.pdf','.docx'):raise ValueError('الصيغ المدعومة PDF وDOCX فقط')
        if type(size) is not int or not 1<=size<=MAX_UPLOAD:raise ValueError('حجم الملف يجب أن يكون بين بايت واحد و500MB')
        if body.get('rights_confirmed') is not True:raise ValueError('أكّد امتلاك حق استخدام المحتوى قبل المعالجة')
        title=body.get('title') or Path(name).stem
        if not isinstance(title,str) or len(title)>180:raise ValueError('عنوان غير صالح')
        with self.lock:
            pending=[]
            for p in private_path(self.root,'uploads').glob('*.json'):
                try:
                    p=private_path(self.root,'uploads',p.name)
                    if p.stat().st_size<=16384:pending.append(json.loads(p.read_text('utf-8')))
                except (OSError,ValueError):continue
            if len(pending)>=4:raise ValueError('أكمل أو ألغِ الرفوع المعلقة أولًا (الحد 4)')
            reserved=sum(x['size'] for x in pending)
            if shutil.disk_usage(self.root).free < reserved+size*3+512*1024**2:raise ValueError('المساحة الحرة لا تكفي للملف ونسخ العمل الآمنة')
            uid=uuid.uuid4().hex
            meta={'id':uid,'filename':name,'size':size,'title':title,'offset':0,'created_at':now()}
            private_path(self.root,'uploads',f'{uid}.part').touch(exist_ok=False)
            self._save_upload(meta)
        return {'id':uid,'offset':0,'chunk_bytes':CHUNK}

    def _id(self,value):
        if not isinstance(value,str) or not re.fullmatch('[0-9a-f]{32}',value):raise ValueError('معرّف غير صالح')
        return value

    def _upload(self,uid):
        p=private_path(self.root,'uploads',f'{self._id(uid)}.json')
        if not p.exists():raise KeyError('عملية الرفع غير موجودة')
        if p.stat().st_size>16384:raise ValueError('بيانات الرفع المحفوظة غير صالحة')
        return json.loads(p.read_text('utf-8'))

    def _save_upload(self,meta):
        p=private_path(self.root,'uploads',f'{self._id(meta["id"])}.json')
        tmp=private_path(self.root,'uploads',f'{meta["id"]}.json.tmp');tmp.write_text(json.dumps(meta,ensure_ascii=False),encoding='utf-8');os.replace(tmp,p)

    def upload_chunk(self,uid,offset,content):
        if not content or len(content)>CHUNK:raise ValueError('حجم جزء الرفع غير صالح')
        with self.lock:
            meta=self._upload(uid);p=private_path(self.root,'uploads',f'{self._id(uid)}.part')
            if offset != meta['offset'] or p.stat().st_size != offset:raise ValueError('ترتيب أجزاء الملف غير صحيح؛ أعد رفع الملف')
            if offset+len(content)>meta['size']:raise ValueError('البيانات تتجاوز حجم الملف المعلن')
            with p.open('ab') as f:f.write(content);f.flush();os.fsync(f.fileno())
            meta['offset']+=len(content);self._save_upload(meta)
        return {'offset':meta['offset']}

    def abort_upload(self,uid):
        with self.lock:
            self._upload(uid)
            for suffix in ('.part','.json','.json.tmp'):private_path(self.root,'uploads',f'{uid}{suffix}').unlink(missing_ok=True)
        return {'ok':True}

    def complete_upload(self,uid):
        with self.lock:
            meta=self._upload(uid);part=private_path(self.root,'uploads',f'{self._id(uid)}.part')
            if meta['offset']!=meta['size'] or part.stat().st_size!=meta['size']:raise ValueError('الرفع غير مكتمل')
            with part.open('rb') as f:magic=f.read(8)
            suffix=Path(meta['filename']).suffix.lower()
            if (suffix=='.pdf' and not magic.startswith(b'%PDF-')) or (suffix=='.docx' and not magic.startswith(b'PK\x03\x04')):raise ValueError('محتوى الملف لا يطابق امتداده')
            jobdir=private_path(self.root,'jobs',uid);jobdir.mkdir(exist_ok=True)
            os.replace(part,private_path(jobdir,'source'+suffix))
            job=self._new_job(uid,meta['title'],meta['filename'],suffix)
            private_path(self.root,'uploads',f'{uid}.json').unlink()
            self.db.event('info','استلام مستند جديد ووضعه في قائمة المعالجة')
            return {'job':job}

    def _new_job(self,uid,title,filename,suffix=None,demo=False):
        job={'id':uid,'title':title,'filename':filename,'status':'queued','progress':0,'stage':'بانتظار العامل','pages_done':0,'pages_total':0,'created_at':now(),'updated_at':now(),'error':None,'counts':{'pages':0,'questions':0,'lessons':0,'warnings':0},'warnings':[],'output_ready':False,'source_suffix':suffix,'demo':demo}
        return self.db.save_job(job)

    def demo(self):
        with self.lock:
            uid=uuid.uuid4().hex;private_path(self.root,'jobs',uid).mkdir()
            return {'job':self._new_job(uid,'مختبر الجمع والطرح','نموذج أصلي مرفق',demo=True)}

    def action(self,jid,action):
        self._id(jid)
        with self.lock:
            job=self.db.job(jid);status=job['status']
            allowed={'pause':('running','queued'),'resume':('paused',),'cancel':('queued','running','paused'),'retry':('failed','cancelled','needs_review','completed')}
            if action not in allowed or status not in allowed[action]:raise ValueError('هذا الإجراء لا يناسب حالة المهمة الحالية')
            if self.active and self.active['id']==jid:
                # A fast resume is queued behind the worker that is still
                # draining. Never start a replacement before active is cleared.
                self.active['cancel'].set()
                if self.active.get('stop_requested') is None:self.active['stop_requested']=time.monotonic()
            if action=='pause':job.update(status='paused',stage='إيقاف مؤقت؛ حفظ النتائج المكتملة')
            elif action=='cancel':job.update(status='cancelled',stage='أُلغيت المهمة؛ احتُفظ بالملفات')
            else:job.update(status='queued',stage='استئناف من آخر نقطة حفظ',error=None,output_ready=False)
            label={'pause':'إيقاف مؤقت','resume':'استئناف','cancel':'إلغاء','retry':'إعادة المعالجة'}[action]
            self.db.save_job(job);self.db.event('info',f'{label}: {job["title"]}')
            return {'job':job}

    def _loop(self):
        while not self.stopping.wait(.15):
            with self.lock:
                if self.active:continue
                jobs=[j for j in self.db.jobs() if j['status']=='queued']
                if not jobs:continue
                job=jobs[-1];res=snapshot(self.root)
                if res['memory_available_gb'] is not None and res['memory_available_gb']<1.25:
                    job.update(status='paused',stage='الذاكرة المتاحة أقل من 1.25GB؛ أغلق البرامج الثقيلة ثم استأنف')
                    self.db.save_job(job);continue
                if res['disk_free_gb']<.5:
                    job.update(status='paused',stage='المساحة الحرة أقل من 512MB؛ حرر مساحة ثم استأنف')
                    self.db.save_job(job);continue
                try:
                    root=private_path(self.root,'jobs',self._id(job['id']))
                    work=private_path(root,'work');output=private_path(root,'output')
                    work.mkdir(exist_ok=True);output.mkdir(exist_ok=True)
                    if not job['demo']:private_path(root,'source'+job['source_suffix'])
                except (OSError,ValueError,KeyError,TypeError) as error:
                    job.update(status='failed',error=str(error),stage='تعذر تجهيز مجلد المهمة بأمان')
                    self.db.save_job(job);continue
                from .worker import execute
                recv,send=self.context.Pipe(duplex=False);cancel=self.context.Event()
                source=None if job['demo'] else str(root/('source'+job['source_suffix']))
                proc=self.context.Process(target=execute,args=(send,cancel,source,str(work),str(output),job['title'],[r for r in self.db.rules() if r['enabled']],job['demo']))
                job.update(status='running',stage='قراءة المستند والتحقق من بنيته');self.db.save_job(job)
                try:proc.start();send.close()
                except Exception as e:
                    job.update(status='failed',error=str(e),stage='تعذر بدء العامل');self.db.save_job(job);recv.close();send.close();continue
                self.active={'id':job['id'],'process':proc,'cancel':cancel,'stop_requested':None}
            result=None;start=time.monotonic();deadline=300
            try:
                while True:
                    if self.stopping.is_set():cancel.set()
                    if time.monotonic()-start>deadline:
                        cancel.set();proc.terminate();result={'type':'error','error':'تجاوزت المهمة مهلة 5 دقائق؛ استأنف من آخر نقطة محفوظة'};break
                    with self.lock:
                        requested=self.active.get('stop_requested')
                    if requested and time.monotonic()-requested>3:
                        proc.terminate();break
                    if self.stopping.is_set() and time.monotonic()-start>3:
                        proc.terminate();break
                    message=_read_worker_message(recv,.1)
                    if message is _PIPE_CLOSED:break
                    if message is _NO_PIPE_MESSAGE:
                        if proc.is_alive():continue
                        # Drain a message sent between the timeout and the
                        # process-exit check before concluding that it is absent.
                        message=_read_worker_message(recv,0)
                        if message is _PIPE_CLOSED or message is _NO_PIPE_MESSAGE:break
                    if message['type']=='progress':
                        with self.lock:
                            current=self.db.job(job['id'])
                            if current['status']=='running':
                                done,total=message['done'],message['total']
                                current.update(pages_done=done,pages_total=total,progress=min(95,round(done/max(1,total)*90)),stage=message['stage'])
                                self.db.save_job(current)
                    elif message['type'] in ('result','error','paused'):
                        # The worker protocol has exactly one final message.
                        # Polling again after it closes its Windows pipe can
                        # overwrite this actual result with WinError 109.
                        result=message;break
                    else:raise ValueError('رسالة غير معروفة من عامل المستندات')
                proc.join(3)
                if proc.is_alive():proc.terminate();proc.join(3)
                if proc.is_alive():
                    raise RuntimeError('لم يتوقف العامل؛ لا يمكن إتاحة مخرجاته قبل توقفه بأمان')
                if result and result['type']=='result' and proc.exitcode!=0:
                    result={'type':'error','error':f'أرسل العامل نتيجة ثم انتهى بخطأ (رمز {proc.exitcode})؛ لم تُعتمد المخرجات'}
                with self.lock:
                    # Readiness is a promise that callers can immediately use
                    # the files. Release the stopped worker before publishing
                    # the terminal state, under the same lock used by exports.
                    # Leaving this until finally created a window where state
                    # said output_ready but download/validate still rejected it.
                    self.active=None
                    current=self.db.job(job['id'])
                    if current['status']=='running':
                        if result and result['type']=='result':
                            r=result['result'];warn=r.get('warnings',[])
                            current.update(status='completed' if r.get('coverage_complete',False) else 'needs_review',progress=100,stage='اكتمل النموذج' if current['demo'] else 'اكتملت المسودة؛ راجع تقرير التغطية',counts=r.get('counts',{}),warnings=warn,output_ready=True,error=None)
                            self.db.event('info',f'انتهت المعالجة: {current["title"]}')
                        elif result and result['type']=='paused':current.update(status='paused',stage='توقفت المهمة مع حفظ التقدم')
                        else:
                            error=result.get('error') if result else f'توقف العامل قبل اكتمال المهمة (رمز {proc.exitcode})؛ قد يكون حد الذاكرة أو الوقت'
                            current.update(status='failed',error=error,stage='تعذرت المعالجة؛ يمكن إعادة المحاولة')
                            self.db.event('error',error)
                        self.db.save_job(current)
            except Exception as e:
                with self.lock:
                    current=self.db.job(job['id'])
                    if current['status']=='running':
                        current.update(status='failed',error=str(e));self.db.save_job(current)
            finally:
                recv.close()
                if proc.is_alive():proc.terminate();proc.join(3)
                with self.lock:self.active=None

    def output(self,jid,name):
        job=self.db.job(self._id(jid))
        if not job['output_ready']:raise ValueError('لا توجد مخرجات مكتملة لهذه المهمة')
        if name not in ('index.html','coverage.json','bundle.json'):raise ValueError('اسم مخرج غير مسموح')
        p=private_path(self.root,'jobs',jid,'output',name)
        if not p.is_file():raise KeyError('ملف المخرجات غير موجود')
        return p

    def package(self,jid):
        with self.lock:
            self.output(jid,'index.html');folder=private_path(self.root,'jobs',jid,'output')
            if self.active and self.active['id']==jid:raise ValueError('انتظر توقف العامل قبل تصدير الحزمة')
            dest=private_path(self.root,'jobs',jid,'educational-bundle.zip')
            temp=private_path(self.root,'jobs',jid,'educational-bundle.tmp')
            with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED) as z:
                for p in sorted(folder.rglob('*')):
                    if p.is_file() and not p.is_symlink():z.write(private_path(folder,p.relative_to(folder)),p.relative_to(folder).as_posix())
            os.replace(temp,dest)
        return dest

    def validate(self,jid):
        from .lesson import validate_package
        with self.lock:
            self.output(jid,'index.html')
            if self.active and self.active['id']==jid:raise ValueError('انتظر توقف العامل قبل فحص الحزمة')
            return validate_package(private_path(self.root,'jobs',jid,'output'))

    def diagnostics(self):
        checks=list(self.checks)
        with self.db.connect() as db:integrity=db.execute('PRAGMA quick_check').fetchone()[0]
        checks += [{'name':'database','status':'pass' if integrity=='ok' else 'fail','detail':integrity},
            {'name':'central_integration','status':'blocked','detail':'المشغّل المركزي يمنع الوكلاء الخارجيين حاليًا'},
            {'name':'official_platform_import','status':'not_run','detail':'لم يتوفر عقد الاستيراد الرسمي المطابق'},
            {'name':'windows_runtime','status':'not_run','detail':'وجود البرنامج على Windows لا يثبت اختبار جميع سيناريوهات التشغيل'},
            {'name':'os_sandbox','status':'not_run','detail':'طبقة حماية Python وحدود موارد؛ لا ادعاء بعزل AppContainer'}]
        report={'generated_at':now(),'resources':snapshot(self.root),'checks':checks,'target':'Windows acceptance host'}
        p=private_path(self.root,'reports','diagnostics.json');p.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        return {'checks':checks,'report':report}

    def backup(self):
        from .maintenance import create_backup
        with self.lock:
            if self.active:raise ValueError('أوقف المهمة الحالية مؤقتًا قبل النسخ الاحتياطي لضمان اتساق الملفات')
            dest=private_path(self.root,'backups','HERZ_Backup_'+time.strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6]+'.zip')
            create_backup(destination=dest,data_directory=self.root)
            self._backup_path=dest
            return {'filename':dest.name}

    def chat(self,body):
        message=body.get('message','')
        if not isinstance(message,str) or not 1<=len(message.strip())<=4000:raise ValueError('اكتب رسالة بين حرف و4000 حرف')
        message=message.strip()
        for trigger in ('احفظ قاعدة:','احفظ تعليمات:'):
            if message.startswith(trigger):
                text=message[len(trigger):].strip()
                if not text:raise ValueError('اكتب نص القاعدة بعد النقطتين')
                self.db.add_rule(text,'feedback',[])
                return {'reply':'حُفظت القاعدة مع سجل دائم. قواعد النص تُسترجع للتأليف؛ لا تغيّر المحرك البرمجي تلقائيًا.','action':'rule_saved'}
        for word,theme in [('بنفسجي','violet'),('أزرق','ocean'),('ازرق','ocean'),('أخضر','emerald'),('اخضر','emerald')]:
            if word in message and any(w in message for w in ['لون','واجهة','غيّر','غير']):
                self.db.set_settings({'theme':theme});return {'reply':'تم تغيير ألوان لوحة التحكم وحفظ اختيارك.','action':'theme_changed'}
        if any(w in message for w in ('حالة','تقدم','مهام')):
            jobs=self.db.jobs();return {'reply':'لا توجد مهام بعد.' if not jobs else '\n'.join(f'{j["title"]}: {j["stage"]} ({j["progress"]}٪)' for j in jobs[:5])}
        rules=[r for r in self.db.rules(message) if r['enabled']][:3]
        return {'reply':'المحادثة تعمل حاليًا بأوامر محددة، ولم يُرفق نموذج لغوي معتمد. أستطيع عرض حالة المهام، تغيير لون الواجهة، أو حفظ قاعدة بصيغة «احفظ قاعدة: ...».\n\nقواعد ذات صلة:\n'+'\n'.join('• '+r['text'] for r in rules)}

    def close(self):
        self.stopping.set()
        with self.lock:
            if self.active:
                self.active['cancel'].set();self.active['stop_requested']=time.monotonic()
                current=self.db.job(self.active['id']);current.update(status='paused',stage='حُفظ التقدم عند إغلاق البرنامج');self.db.save_job(current)
        if self.thread.is_alive():self.thread.join(6)
