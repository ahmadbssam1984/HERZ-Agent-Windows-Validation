"""Read-only contract adapter for the inspected HERZ Command Center.

The inspected Windows runner accepts only two bundled workers.  This module
NEVER registers an agent, starts a child process, opens a socket, writes to
central data, or marks central execution ready.  A local report is not a
successful central registration or a proof of OS-level isolation.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import PurePosixPath
from typing import Any

SOURCE_ARCHIVE = 'not bundled in public acceptance'
SOURCE_REVIEW_DATE = "2026-11-25"
_REJECTION = (
    'الربط المركزي غير متاح في الاختبار العام.'
)
_CONTRACT = {'transport': 'disabled', 'connector': 'cli_json', 'controls': ['start', 'stop', 'restart', 'cancel'], 'network': 'deny', 'cloud': False, 'cost': 'free', 'supports_central_pause': False}


def status() -> dict[str, Any]:
    return {'connected': False, 'ready': False, 'execution_enabled': False, 'installed_center_verified': False, 'status': 'not_configured', 'label': 'غير متصل بالمركز', 'reason': 'الربط المركزي غير متاح في الاختبار العام.'}


def contract() -> dict[str, Any]:
    """Return an independent copy of the inspected source contract."""
    return copy.deepcopy(_CONTRACT)


def get_status() -> dict[str, Any]:
    """Alias for the dashboard API."""
    return status()


def _artifact_name(value: str) -> str:
    if not isinstance(value, str) or not value or len(value) > 240:
        raise ValueError("Invalid central artifact name")
    # Match the central Windows contract even when packaging on Linux.
    if "\\" in value or ":" in value or "\x00" in value:
        raise ValueError("Central artifact name must be a POSIX relative path")
    path = PurePosixPath(value)
    parts = value.split("/")
    if path.is_absolute() or any(p in ("", ".", "..") for p in parts):
        raise ValueError("Central artifact path escapes the workspace")
    reserved = {"CON", "PRN", "AUX", "NUL", "CONIN$", "CONOUT$"}
    reserved.update(f"{prefix}{n}" for prefix in ("COM", "LPT") for n in range(10))
    if any(p[-1:] in (" ", ".") or p.split(".")[0].upper() in reserved for p in parts):
        raise ValueError("Reserved Windows artifact name")
    if any(ord(c) < 32 or c in '<>"|?*' for c in value):
        raise ValueError("Invalid Windows artifact name")
    return value


def make_cli_result(result: dict[str, Any], artifacts: list[str]) -> dict[str, Any]:
    """Build the exact generic CLI output shape without claiming acceptance.

    The central manager must still verify every artifact's actual path, size,
    hash, and output schema in its assigned workspace. This helper does not
    read artifacts or prove compatibility with a future educational manifest.
    """
    if not isinstance(result, dict) or not isinstance(artifacts, list) or len(artifacts) > 256:
        raise ValueError("Invalid central result envelope")
    names = [_artifact_name(name) for name in artifacts]
    if len({name.casefold() for name in names}) != len(names):
        raise ValueError("Duplicate central artifact path")
    try:
        encoded = json.dumps(result, ensure_ascii=False, allow_nan=False)
    except (TypeError, ValueError, RecursionError) as error:
        raise ValueError("Result must be finite JSON data") from error
    if len(encoded.encode("utf-8")) > 1024 * 1024:
        raise ValueError("Result exceeds the adapter's 1 MiB limit")
    return {"result": json.loads(encoded), "artifacts": names}


def contract_report() -> dict[str, Any]:
    """Inert information that can be exported for an integration review."""
    description = contract()
    canonical = json.dumps(description, sort_keys=True, separators=(",", ":")).encode()
    return {
        "kind": "central_contract_review",
        "status": status(),
        "contract": description,
        "contract_sha256": hashlib.sha256(canonical).hexdigest(),
        "note": "هذا تقرير محلي، وليس إثبات تسجيل أو تشغيل داخل المركز.",
    }
