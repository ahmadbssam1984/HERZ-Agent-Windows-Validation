"""Offline repair, backup and diagnostic tools. Never removes user data."""
from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import shutil
import sqlite3
import stat
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
APP = "HERZ Educational Agent"
MAX_PAYLOAD = 160 * 1024 * 1024


def data_root(root: Path = ROOT) -> Path:
    configured = os.environ.get("HERZ_DATA_DIR")
    if configured:
        return Path(configured).expanduser().resolve()
    if os.name == "nt":
        local = os.environ.get("LOCALAPPDATA")
        if not local:
            raise RuntimeError("LOCALAPPDATA is unavailable; set HERZ_DATA_DIR to a writable local directory")
        return (Path(local) / "HERZ" / "EducationalAgent").resolve()
    return (Path(root) / "data").resolve()


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def _json(path: Path):
    if path.stat().st_size > 2 * 1024 * 1024:
        raise ValueError("Metadata is too large")
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("Duplicate metadata key")
            result[key] = value
        return result
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=unique)


def _safe_relative(value: str) -> PurePosixPath:
    if not isinstance(value, str) or not value or len(value) > 500:
        raise ValueError("Invalid relative filename")
    item = PurePosixPath(value)
    if item.is_absolute() or any(p in ("", ".", "..") for p in value.split("/")):
        raise ValueError("Unsafe archive path")
    if "\\" in value or ":" in value or "\x00" in value:
        raise ValueError("Unsafe archive path")
    reserved = {"CON", "PRN", "AUX", "NUL", *("COM" + str(i) for i in range(1, 10)), *("LPT" + str(i) for i in range(1, 10))}
    for part in item.parts:
        if part.endswith((".", " ")) or part.split(".", 1)[0].upper() in reserved or any(ord(c) < 32 or c in '<>"|?*' for c in part):
            raise ValueError("Unsafe Windows archive filename")
    if item.parts[0].lower() in ("data", "repair", "runtime", "runtime_recovered"):
        raise ValueError("Repair cannot replace data, repair or runtime directories")
    return item


def _not_link(path: Path) -> None:
    if path.is_symlink():
        raise ValueError("Symbolic links are not allowed in repair targets")
    try:
        attributes = path.lstat().st_file_attributes
    except (AttributeError, FileNotFoundError):
        return
    if attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
        raise ValueError("Reparse points are not allowed in repair targets")


def _target(root: Path, rel: str) -> Path:
    item = _safe_relative(rel)
    current = root
    _not_link(current)
    for part in item.parts:
        current = current / part
        _not_link(current)
    if not current.resolve().is_relative_to(root.resolve()):
        raise ValueError("Repair target escapes package")
    return current


def _manifest(root: Path) -> dict:
    manifest = _json(root / "repair" / "payload-manifest.json")
    files = manifest.get("files")
    if not isinstance(files, dict) or not files or len(files) > 10000:
        raise ValueError("Invalid repair manifest")
    for rel, digest in files.items():
        _target(root, rel)
        if not isinstance(digest, str) or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
            raise ValueError("Invalid file checksum")
    return manifest


def verify_installation(root: Path = ROOT) -> dict:
    root = Path(root).resolve()
    try:
        manifest = _manifest(root)
    except (OSError, ValueError) as exc:
        return {"valid": False, "status": "unavailable", "error": str(exc), "checked": 0, "changed": [], "missing": []}
    changed, missing = [], []
    for rel, expected in manifest["files"].items():
        path = _target(root, rel)
        if not path.is_file():
            missing.append(rel)
        elif sha256(path) != expected:
            changed.append(rel)
    return {"valid": not changed and not missing, "status": "pass" if not changed and not missing else "fail", "checked": len(manifest["files"]), "changed": changed, "missing": missing}


def system_resources(root: Path = ROOT) -> dict:
    result = {"platform": platform.platform(), "cpu_count": os.cpu_count(), "processor": platform.processor(), "memory_total_gb": None, "memory_available_gb": None, "memory_installed_gb": None, "disk_free_gb": round(shutil.disk_usage(root).free / 2**30, 2), "architecture": platform.machine(), "is_windows": os.name == "nt"}
    if os.name == "nt":
        from ctypes import wintypes
        class MemoryStatus(ctypes.Structure):
            _fields_ = [("length", wintypes.DWORD), ("load", wintypes.DWORD), ("total", ctypes.c_ulonglong), ("available", ctypes.c_ulonglong), ("total_page", ctypes.c_ulonglong), ("available_page", ctypes.c_ulonglong), ("total_virtual", ctypes.c_ulonglong), ("available_virtual", ctypes.c_ulonglong), ("extended", ctypes.c_ulonglong)]
        info = MemoryStatus()
        info.length = ctypes.sizeof(info)
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.GlobalMemoryStatusEx.argtypes = [ctypes.POINTER(MemoryStatus)]
        kernel.GlobalMemoryStatusEx.restype = wintypes.BOOL
        if kernel.GlobalMemoryStatusEx(ctypes.byref(info)):
            result.update(memory_total_gb=round(info.total / 2**30, 2), memory_available_gb=round(info.available / 2**30, 2))
        installed = ctypes.c_ulonglong()
        kernel.GetPhysicallyInstalledSystemMemory.argtypes = [ctypes.POINTER(ctypes.c_ulonglong)]
        kernel.GetPhysicallyInstalledSystemMemory.restype = wintypes.BOOL
        if kernel.GetPhysicallyInstalledSystemMemory(ctypes.byref(installed)):
            result["memory_installed_gb"] = round(installed.value / 2**20, 2)
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\CentralProcessor\0") as key:
                result["processor"] = winreg.QueryValueEx(key, "ProcessorNameString")[0].strip()
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion") as key:
                for name in ("ProductName", "DisplayVersion", "CurrentBuildNumber", "EditionID"):
                    try:
                        result[name] = winreg.QueryValueEx(key, name)[0]
                    except OSError:
                        pass
        except OSError:
            pass
    elif Path("/proc/meminfo").exists():
        values = {}
        for line in Path("/proc/meminfo").read_text().splitlines():
            name, rest = line.split(":", 1)
            values[name] = int(rest.split()[0])
        result["memory_total_gb"] = round(values.get("MemTotal", 0) / 2**20, 2)
        result["memory_available_gb"] = round(values.get("MemAvailable", 0) / 2**20, 2)
    return result


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError("Local control redirects are refused")


def _server_info(root: Path = ROOT) -> dict | None:
    path = data_root(root) / "server.json"
    if not path.exists():
        return None
    value = _json(path)
    parsed = urllib.parse.urlsplit(value.get("url", ""))
    if parsed.scheme != "http" or parsed.hostname != "127.0.0.1" or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in ("", "/"):
        raise ValueError("Invalid local server address")
    if not parsed.port or not isinstance(value.get("token"), str) or not 20 <= len(value["token"]) <= 512:
        raise ValueError("Invalid local server credentials")
    value["url"] = f"http://127.0.0.1:{parsed.port}"
    return value


def _request(info: dict, endpoint: str, method="GET") -> bytes:
    headers = {"Authorization": "Bearer " + info["token"], "Origin": info["url"]}
    body = None
    if method == "POST":
        body = b"{}"
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(info["url"] + endpoint, data=body, headers=headers, method=method)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
    with opener.open(request, timeout=5) as response:
        return response.read(2 * 1024 * 1024)


def is_running(root: Path = ROOT) -> bool:
    info = _server_info(root)
    if info is None:
        return False
    try:
        health = json.loads(_request(info, "/api/health"))
        return health.get("app") == APP
    except (urllib.error.URLError, TimeoutError, ConnectionError, OSError):
        return False


def stop(root: Path = ROOT) -> dict:
    info = _server_info(root)
    if info is None:
        return {"ok": True, "message": "No running instance recorded."}
    try:
        health = json.loads(_request(info, "/api/health"))
        if health.get("app") != APP:
            raise ValueError("The recorded port is not the educational agent")
        result = json.loads(_request(info, "/api/shutdown", "POST"))
        if not result.get("ok"):
            raise ValueError("Agent did not accept shutdown")
        for _ in range(50):
            if not is_running(root):
                return {"ok": True, "message": "Agent stopped. User files were preserved."}
            time.sleep(0.1)
        return {"ok": False, "message": "Shutdown accepted but process has not stopped yet. Wait before repair."}
    except (urllib.error.URLError, TimeoutError, ConnectionError) as exc:
        return {"ok": False, "message": "Could not contact the recorded agent; no process was killed.", "detail": type(exc).__name__}


def _timestamp() -> str:
    return time.strftime("%Y%m%d-%H%M%S") + f"-{time.time_ns() % 1000000:06d}"


def _backup_source(data: Path, path: Path) -> None:
    """Refuse links/junctions at every component of an archived source."""
    current = data
    _not_link(current)
    for part in path.relative_to(data).parts:
        current = current / part
        _not_link(current)
    if not path.resolve().is_relative_to(data):
        raise ValueError("Backup source escapes the configured data directory")


def create_backup(root: Path = ROOT, *, destination: Path | None = None, data_directory: Path | None = None) -> dict:
    """Snapshot SQLite online; immutable document files are copied separately."""
    root = Path(root).resolve()
    data = Path(data_directory).expanduser().resolve() if data_directory is not None else data_root(root)
    data.mkdir(parents=True, exist_ok=True)
    backup_dir = data / "backups"
    _not_link(backup_dir)
    backup_dir.mkdir(exist_ok=True)
    destination = Path(destination) if destination else backup_dir / ("HERZ-backup-" + _timestamp() + ".zip")
    if destination.exists():
        raise FileExistsError("Refusing to overwrite an existing backup")
    included, skipped, file_hashes = [], [], {}
    sources = []
    # Preflight before creating the ZIP, so unsafe trees do not leave a
    # misleading backup artifact. Pending uploads are not recoverable jobs.
    for path in sorted(data.rglob("*")):
        rel = path.relative_to(data)
        if "backups" in rel.parts or rel.parts[0] == "uploads":
            continue
        # SQLite closes/recreates these between directory enumeration and
        # reading. Exclude them lexically before any path stat or resolution.
        if path.name in ("server.json", "server.lock") or path.name.endswith(("-wal", "-shm", ".part", ".lock")):
            skipped.append(rel.as_posix())
            continue
        _backup_source(data, path)
        if not path.is_file():
            continue
        _safe_relative(rel.as_posix())
        sources.append(path)
    with tempfile.TemporaryDirectory(prefix="herz-backup-") as temp, zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=3) as archive:
        for path in sources:
            rel = path.relative_to(data)
            _backup_source(data, path)
            if path.suffix.lower() in (".sqlite", ".sqlite3", ".db"):
                snapshot = Path(temp) / (hashlib.sha256(rel.as_posix().encode()).hexdigest() + ".db")
                source_connection = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, timeout=10)
                target_connection = sqlite3.connect(snapshot)
                try:
                    source_connection.backup(target_connection, pages=128, sleep=0.01)
                finally:
                    source_connection.close()
                    target_connection.close()
                archive.write(snapshot, "data/" + rel.as_posix())
                file_hashes["data/" + rel.as_posix()] = sha256(snapshot)
            else:
                # Hash the same stream that is written. Reading a ZipFile.write
                # member before closing the archive can compare its original
                # Windows backslash name with the normalized ZIP header name.
                # Streaming also keeps metadata tied to the archived bytes if
                # the input is edited concurrently, without reopening the ZIP.
                digest = hashlib.sha256()
                with path.open("rb") as source, archive.open("data/" + rel.as_posix(), "w") as stored:
                    while chunk := source.read(1024 * 1024):
                        stored.write(chunk)
                        digest.update(chunk)
                file_hashes["data/" + rel.as_posix()] = digest.hexdigest()
            included.append(rel.as_posix())
        archive.writestr("BACKUP_INFO.json", json.dumps({"app": APP, "format_version": 1, "sha256": file_hashes, "created_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "included": included, "skipped": skipped, "note": "SQLite has a consistent online snapshot. Other files are copied at their individual copy times. Pause processing for a whole-project checkpoint. Authentication tokens excluded."}, ensure_ascii=False, indent=2))
    return {"ok": True, "filename": destination.name, "path": str(destination), "files": len(included), "size": destination.stat().st_size}


def restore_backup(backup_file: Path, root: Path = ROOT) -> dict:
    """Restore to a fresh folder only, validating every byte before publication."""
    root = Path(root).resolve()
    source = Path(backup_file).expanduser().resolve()
    if not source.is_file() or source.suffix.lower() != ".zip":
        raise ValueError("Choose an existing HERZ backup ZIP file")
    parent = data_root(root) / "backups"
    _not_link(parent)
    parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(source) as archive:
        infos = archive.infolist()
        names = [i.filename for i in infos]
        if len(infos) > 100000 or len(names) != len(set(names)) or "BACKUP_INFO.json" not in names:
            raise ValueError("Invalid backup archive inventory")
        info = archive.getinfo("BACKUP_INFO.json")
        if info.file_size > 16 * 1024 * 1024:
            raise ValueError("Backup metadata exceeds limit")
        metadata = json.loads(archive.read(info))
        hashes = metadata.get("sha256")
        if metadata.get("app") != APP or metadata.get("format_version") != 1 or not isinstance(hashes, dict):
            raise ValueError("Backup lacks supported integrity metadata")
        data_names = set(names) - {"BACKUP_INFO.json"}
        if set(hashes) != data_names:
            raise ValueError("Backup files differ from integrity metadata")
        total_size = sum(i.file_size for i in infos)
        if total_size > 20 * 1024**3 or total_size + 256 * 1024**2 > shutil.disk_usage(parent).free:
            raise ValueError("Insufficient free space or backup exceeds 20 GiB restore limit")
        for item in infos:
            if item.filename == "BACKUP_INFO.json":
                continue
            if not item.filename.startswith("data/") or stat.S_ISLNK(item.external_attr >> 16):
                raise ValueError("Unsafe backup archive member")
            rel = item.filename[5:]
            relative = _safe_relative(rel)
            if "backups" in relative.parts or relative.name in ("server.json", "server.lock") or relative.name.endswith((".lock", ".part", "-wal", "-shm")):
                raise ValueError("Backup contains live credentials, nested backups or temporary files")
            if item.file_size > 500 * 1024**2 or (item.file_size > 10 * 1024**2 and item.file_size > max(1, item.compress_size) * 1000):
                raise ValueError("Unsafe backup member size or compression ratio")
            digest = hashes[item.filename]
            if not isinstance(digest, str) or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
                raise ValueError("Invalid backup file checksum")
        # This temporary staging directory is never the active user directory.
        with tempfile.TemporaryDirectory(prefix="restore-check-", dir=parent) as temporary:
            staging = Path(temporary) / "data"
            staging.mkdir()
            for item in infos:
                if item.filename == "BACKUP_INFO.json":
                    continue
                relative = item.filename[5:]
                target = _target(staging, relative)
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(item) as input_stream, target.open("xb") as output:
                    shutil.copyfileobj(input_stream, output, 1024 * 1024)
                if sha256(target) != hashes[item.filename]:
                    raise ValueError("Backup checksum failed; active user data were not changed")
                if target.suffix.lower() in (".db", ".sqlite", ".sqlite3"):
                    connection = sqlite3.connect(target.as_uri() + "?mode=ro", uri=True)
                    try:
                        result = connection.execute("PRAGMA integrity_check").fetchone()
                    finally:
                        connection.close()
                    if result != ("ok",):
                        raise ValueError("Restored SQLite integrity check failed")
            final = parent / ("recovered-" + _timestamp())
            if final.exists():
                raise FileExistsError("Refusing to overwrite an earlier recovery")
            os.replace(staging, final)
    record = {"app": APP, "path": str(final), "source": source.name, "files": len(data_names), "source_sha256": sha256(source), "created_at": time.strftime("%Y-%m-%dT%H:%M:%S%z")}
    (final / "RESTORE_INFO.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    (data_root(root) / "LAST_RESTORE.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"ok": True, **record, "message": "Restored into a separate folder. Original work is unchanged. Stop the current agent, then run START_RESTORED.cmd."}


def start_restored(root: Path = ROOT) -> dict:
    root = Path(root).resolve()
    if is_running(root):
        raise RuntimeError("Stop the current agent with STOP.cmd before opening restored work")
    record = _json(data_root(root) / "LAST_RESTORE.json")
    recovered = Path(record.get("path", "")).resolve()
    parent = (data_root(root) / "backups").resolve()
    if not recovered.is_relative_to(parent) or recovered.parent != parent or not recovered.name.startswith("recovered-"):
        raise ValueError("Invalid recovery folder")
    _not_link(recovered)
    saved = _json(recovered / "RESTORE_INFO.json")
    if saved.get("app") != APP or saved.get("path") != str(recovered):
        raise ValueError("Recovery folder is missing its validated restore record")
    environment = dict(os.environ)
    environment["HERZ_DATA_DIR"] = str(recovered)
    flags = subprocess.CREATE_NEW_CONSOLE if os.name == "nt" else 0
    process = subprocess.Popen([sys.executable, "-I", str(root / "run.py"), "--open"], cwd=root, env=environment, creationflags=flags)
    return {"ok": True, "pid": process.pid, "path": str(recovered), "message": "Opening recovered work separately; original work remains unchanged. Close the recovered app from its interface."}


def repair(root: Path = ROOT) -> dict:
    root = Path(root).resolve()
    if is_running(root):
        raise RuntimeError("Stop the agent with STOP.cmd before repairing program files.")
    manifest = _manifest(root)
    payload = root / "repair" / "payload.zip"
    if sha256(payload) != manifest.get("archive_sha256"):
        raise ValueError("Repair archive checksum failed. No files were changed.")
    verification = verify_installation(root)
    targets = sorted(set(verification["changed"] + verification["missing"]))
    if not targets:
        return {"ok": True, "message": "All program files match the bundled release. No changes needed.", "repaired": []}
    with zipfile.ZipFile(payload) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or set(names) != set(manifest["files"]):
            raise ValueError("Repair archive contents do not match its manifest")
        if sum(i.file_size for i in archive.infolist()) > MAX_PAYLOAD:
            raise ValueError("Repair archive exceeds size limit")
        # Verify every seed member before replacing any installed file.
        for info in archive.infolist():
            _safe_relative(info.filename)
            if stat.S_ISLNK(info.external_attr >> 16):
                raise ValueError("Repair archive contains a link")
            digest = hashlib.sha256()
            with archive.open(info) as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b""):
                    digest.update(block)
            if digest.hexdigest() != manifest["files"][info.filename]:
                raise ValueError("Repair seed file checksum failed")
        backup_dir = data_root(root) / "backups"
        _not_link(backup_dir)
        backup_dir.mkdir(parents=True, exist_ok=True)
        backup_path = backup_dir / ("before-repair-" + _timestamp() + ".zip")
        with zipfile.ZipFile(backup_path, "x", compression=zipfile.ZIP_DEFLATED) as backup:
            for rel in targets:
                target = _target(root, rel)
                if target.exists():
                    if not target.is_file():
                        raise ValueError("Repair target is not a file")
                    backup.write(target, rel)
            backup.writestr("REPAIR_LOG.json", json.dumps({"targets": targets, "missing": verification["missing"]}, indent=2))
        repaired = []
        for rel in targets:
            target = _target(root, rel)
            target.parent.mkdir(parents=True, exist_ok=True)
            # Unique temporary file; atomic replacement cannot touch user data.
            fd, temp_name = tempfile.mkstemp(prefix=".herz-repair-", dir=target.parent)
            try:
                with os.fdopen(fd, "wb") as output, archive.open(rel) as source:
                    shutil.copyfileobj(source, output, 1024 * 1024)
                    output.flush()
                    os.fsync(output.fileno())
                if sha256(Path(temp_name)) != manifest["files"][rel]:
                    raise ValueError("Repair write verification failed")
                os.replace(temp_name, target)
                repaired.append(rel)
            finally:
                if Path(temp_name).exists():
                    Path(temp_name).unlink()
    final = verify_installation(root)
    return {"ok": final["valid"], "repaired": repaired, "backup": str(backup_path), "verification": final, "note": "Data, documents and settings were not replaced. Checksums detect accidental corruption; they are not a digital publisher signature."}


def diagnose(root: Path = ROOT, *, save: bool = True) -> dict:
    root = Path(root).resolve()
    resources = system_resources(root)
    integrity = verify_installation(root)
    checks = [
        {"name": "program_files", "status": integrity["status"], "detail": integrity},
        {"name": "python_runtime", "status": "pass" if sys.version_info >= (3, 11) else "fail", "detail": sys.version.split()[0]},
        {"name": "windows_execution", "status": "pass" if os.name == "nt" else "not_run", "detail": "Running on this Windows host" if os.name == "nt" else "This diagnosis was not run on Windows"},
        {"name": "disk_space", "status": "pass" if resources["disk_free_gb"] >= 2 else "warning", "detail": f"{resources['disk_free_gb']} GiB available"},
        {"name": "memory_available", "status": "pass" if (resources.get("memory_available_gb") or 0) >= 2 else "warning", "detail": resources.get("memory_available_gb")},
    ]
    try:
        seed_manifest = _manifest(root)
        seed_valid = sha256(root / "repair/payload.zip") == seed_manifest.get("archive_sha256")
        checks.append({"name": "offline_repair_seed", "status": "pass" if seed_valid else "fail", "detail": "SHA256 checked against bundled metadata"})
    except (OSError, ValueError) as exc:
        checks.append({"name": "offline_repair_seed", "status": "unavailable", "detail": str(exc)})
    try:
        dependency_lock = _json(root / "docs/DEPENDENCY_LOCK.json")
        original = next(item for item in dependency_lock["dependencies"] if item["name"].startswith("python-"))
        runtime_valid = sha256(root / "repair/runtime-original.zip") == original["sha256"]
        checks.append({"name": "offline_runtime_seed", "status": "pass" if runtime_valid else "fail", "detail": original["name"]})
    except (OSError, ValueError, KeyError, StopIteration) as exc:
        checks.append({"name": "offline_runtime_seed", "status": "unavailable", "detail": str(exc)})
    report = {"app": APP, "time": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "resources": resources, "checks": checks, "home_target": {}, "limitations": ["Local diagnostics do not certify zero defects.", "Windows application compatibility requires tests on the actual home computer.", "No administrator privileges or network access are requested by offline diagnostics."]}
    if save:
        folder = data_root(root) / "diagnostics"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / ("HERZ_DIAGNOSTIC_" + _timestamp() + ".json")
        path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        report["path"] = str(path)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="HERZ offline diagnostics, backup and repair")
    parser.add_argument("command", choices=("stop", "diagnose", "repair", "backup", "verify", "restore-backup", "start-restored"))
    parser.add_argument("--file", help="HERZ backup ZIP for restore-backup")
    args = parser.parse_args()
    try:
        if args.command == "restore-backup":
            selected = args.file or input("Drop a HERZ backup ZIP onto RESTORE_BACKUP.cmd, or paste its full path here: ")
            selected = selected.strip().strip('"')
            if not selected:
                raise ValueError("No backup file selected")
            result = restore_backup(Path(selected))
        else:
            result = {"stop": stop, "diagnose": diagnose, "repair": repair, "backup": create_backup, "verify": verify_installation, "start-restored": start_restored}[args.command]()
        print(json.dumps(result, ensure_ascii=True, indent=2))
        return 1 if result.get("ok") is False or result.get("valid") is False else 0
    except (OSError, ValueError, RuntimeError, sqlite3.Error, zipfile.BadZipFile) as exc:
        print(json.dumps({"ok": False, "error": str(exc), "action": "No user data were deleted. See FIRST_RUN_AR.html."}, ensure_ascii=True, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
