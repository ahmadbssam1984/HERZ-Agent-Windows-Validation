"""SQLite persistence; every operation uses a short independent transaction."""
import json
import sqlite3
import time
import uuid
from contextlib import contextmanager,closing
from pathlib import Path

DEFAULT_RULES = [
 ('permanent','اعرض مثالًا واحدًا في كل تبويب، ثم تقييمًا بنائيًا مرتبطًا به.',['lesson','examples']),
 ('permanent','في التدريب: تلميح بعد الخطأ، والحل والشرح بعد ثلاث محاولات خاطئة؛ لا تُحتسب الإجابة المكشوفة إنجازًا مستقلًا.',['practice']),
 ('permanent','في الاختبار: لا تلميحات ولا حلول ولا ألوان تكشف الصحة قبل التسليم.',['exam']),
 ('permanent','لا تُدرج صور صفحات المصدر في الحزمة النهائية؛ أعد بناء التفاعل.',['media']),
 ('permanent','الاختيار من متعدد يحتوي أربعة خيارات A وB وC وD.',['mcq']),
 ('permanent','لا تفترض توافق HERZ Academy قبل نجاح المستورد الرسمي للإصدار المستهدف.',['export']),
 ('permanent','استخدم حسابًا عاديًا وحدود الموارد المحلية المحددة في البرنامج.',['hardware']),
 ('permanent','استخدم متتالية بدل متتابعة والنسبة الثابتة بدل النسبة المشتركة.',['math','terms']),
]

def now():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())

class Store:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript('''
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY, status TEXT NOT NULL, updated TEXT NOT NULL, body TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS jobs_status ON jobs(status,updated);
            CREATE TABLE IF NOT EXISTS rules(id TEXT PRIMARY KEY, category TEXT NOT NULL, body TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS rules_category ON rules(category);
            CREATE TABLE IF NOT EXISTS revisions(id INTEGER PRIMARY KEY, rule_id TEXT, at TEXT, body TEXT);
            CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, at TEXT, level TEXT, message TEXT);
            CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
            ''')
            count = db.execute('SELECT count(*) FROM rules').fetchone()[0]
        if not count:
            for category,text,tags in DEFAULT_RULES:
                self.add_rule(text,category,tags)

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.execute('PRAGMA busy_timeout=15000')
        try:
            with db:
                yield db
        finally:
            db.close()

    def save_job(self, job):
        job['updated_at'] = now()
        with self.connect() as db:
            db.execute('INSERT OR REPLACE INTO jobs VALUES(?,?,?,?)',(job['id'],job['status'],job['updated_at'],json.dumps(job,ensure_ascii=False)))
        return job

    def job(self,jid):
        with self.connect() as db:
            row = db.execute('SELECT body FROM jobs WHERE id=?',(jid,)).fetchone()
        if not row: raise KeyError('المهمة غير موجودة')
        return json.loads(row[0])

    def jobs(self):
        with self.connect() as db:
            return [json.loads(r[0]) for r in db.execute('SELECT body FROM jobs ORDER BY updated DESC LIMIT 500')]

    def add_rule(self,text,category,tags):
        rule={'id':uuid.uuid4().hex,'text':text,'category':category,'tags':tags,'created_at':now(),'enabled':True}
        with self.connect() as db:
            db.execute('INSERT INTO rules VALUES(?,?,?)',(rule['id'],category,json.dumps(rule,ensure_ascii=False)))
        self.event('info','حفظ قاعدة معرفية جديدة')
        return rule

    def rules(self, query=None):
        with self.connect() as db:
            result=[json.loads(r[0]) for r in db.execute('SELECT body FROM rules ORDER BY rowid')]
        if query:
            terms=set(query.casefold().split())
            result.sort(key=lambda r:sum(t in (r['text']+' '+' '.join(r['tags'])).casefold() for t in terms),reverse=True)
        return result

    def toggle_rule(self,rid,enabled):
        with self.connect() as db:
            row=db.execute('SELECT body FROM rules WHERE id=?',(rid,)).fetchone()
            if not row: raise KeyError('القاعدة غير موجودة')
            rule=json.loads(row[0]); db.execute('INSERT INTO revisions(rule_id,at,body) VALUES(?,?,?)',(rid,now(),row[0]))
            rule['enabled']=enabled
            db.execute('UPDATE rules SET body=? WHERE id=?',(json.dumps(rule,ensure_ascii=False),rid))
        self.event('info','تحديث تفعيل قاعدة مع الاحتفاظ بالإصدار السابق')
        return rule

    def settings(self):
        result={'theme':'violet','max_upload_mb':500,'workers':1,'local_ai_enabled':False,'local_ai_model':''}
        with self.connect() as db:
            for k,v in db.execute('SELECT key,value FROM settings'):result[k]=json.loads(v)
        return result

    def set_settings(self,values):
        with self.connect() as db:
            for k,v in values.items(): db.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',(k,json.dumps(v)))
        return self.settings()

    def event(self,level,message):
        with self.connect() as db:
            db.execute('INSERT INTO events(at,level,message) VALUES(?,?,?)',(now(),level,str(message)[:2000]))
            db.execute('DELETE FROM events WHERE id < (SELECT max(id)-5000 FROM events)')

    def events(self):
        with self.connect() as db:
            return [{'time':a,'level':b,'message':c} for a,b,c in db.execute('SELECT at,level,message FROM events ORDER BY id DESC LIMIT 100')]

    def backup(self,dest):
        with self.connect() as src,closing(sqlite3.connect(dest)) as dst:src.backup(dst)
