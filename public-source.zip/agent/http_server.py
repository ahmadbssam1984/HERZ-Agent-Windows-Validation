import hmac
import hashlib
import base64
import json
import mimetypes
import re
import socket
import threading
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit,parse_qs

from . import VERSION
from . import central_adapter
from .service import CHUNK

class Server(ThreadingHTTPServer):
    daemon_threads=True
    allow_reuse_address=False
    request_queue_size=32
    def __init__(self,service,token,port=0):
        self.service=service;self.token=token;self.web=Path(__file__).resolve().parent.parent/'web'
        lesson_script=(self.web/'lesson.js').read_text(encoding='utf-8')
        self.lesson_script_hash=base64.b64encode(hashlib.sha256(lesson_script.encode('utf-8')).digest()).decode('ascii')
        self.slots=threading.BoundedSemaphore(16)
        super().__init__(('127.0.0.1',port),Handler)
        self.origin=f'http://127.0.0.1:{self.server_port}'
    def process_request(self,request,client_address):
        if not self.slots.acquire(blocking=False):
            request.close();return
        try:super().process_request(request,client_address)
        except BaseException:self.slots.release();raise
    def process_request_thread(self,request,client_address):
        try:super().process_request_thread(request,client_address)
        finally:self.slots.release()

class Handler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    server_version='HERZLocal'
    sys_version=''
    def setup(self):
        super().setup();self.connection.settimeout(25)
    def log_message(self,*args):pass # no token or document names in console request logs
    def _headers(self,status,mime,length,filename=None):
        self.send_response(status)
        self.send_header('Content-Type',mime)
        self.send_header('Content-Length',str(length))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Cross-Origin-Resource-Policy','same-origin')
        self.send_header('Permissions-Policy','camera=(),microphone=(),geolocation=(),payment=()')
        self.send_header('Content-Security-Policy',f"default-src 'self'; script-src 'self' 'sha256-{self.server.lesson_script_hash}'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; frame-src blob:; media-src 'self' data: blob:; object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
        if filename:self.send_header('Content-Disposition',f'attachment; filename="{filename}"')
        self.end_headers()
    def send_json(self,body,status=200):
        content=json.dumps(body,ensure_ascii=False,allow_nan=False).encode('utf-8')
        self._headers(status,'application/json; charset=utf-8',len(content));self.wfile.write(content)
    def send_file(self,path,mime=None,download=None):
        self._headers(200,mime or mimetypes.guess_type(path)[0] or 'application/octet-stream',path.stat().st_size,download)
        with path.open('rb') as f:
            while True:
                part=f.read(128*1024)
                if not part:break
                self.wfile.write(part)
    def _security(self):
        if self.headers.get_all('Host') != [f'127.0.0.1:{self.server.server_port}']:
            raise PermissionError('عنوان الاتصال المحلي غير مسموح')
        for singleton in ('Origin','Authorization','Content-Type','Sec-Fetch-Site'):
            if len(self.headers.get_all(singleton,[]))>1:raise ValueError('ترويسة طلب مكررة')
        origin=self.headers.get('Origin')
        if origin and origin!=self.server.origin:raise PermissionError('مصدر الطلب غير مسموح')
        if self.headers.get('Sec-Fetch-Site')=='cross-site':raise PermissionError('طلب من موقع خارجي مرفوض')
        if self.headers.get('Transfer-Encoding'):raise ValueError('ترميز نقل غير مدعوم')
        if self.headers.get_all('Content-Length') and len(self.headers.get_all('Content-Length'))!=1:raise ValueError('حجم طلب مكرر')
        split=urlsplit(self.path)
        if split.scheme or split.netloc:raise ValueError('مسار الطلب غير صالح')
        if split.path.startswith('/api/') and split.path!='/api/health':
            header=self.headers.get('Authorization','')
            if not header.isascii() or not hmac.compare_digest(header,'Bearer '+self.server.token):raise PermissionError('افتح البرنامج من START.cmd للحصول على جلسة مصرح بها')
        return split
    def _body(self,limit=65536,raw=False):
        content_type=self.headers.get('Content-Type','').split(';')[0].strip().lower()
        if content_type!=('application/octet-stream' if raw else 'application/json'):raise ValueError('نوع محتوى الطلب غير صالح')
        length=self.headers.get('Content-Length')
        if not length or not re.fullmatch(r'\d+',length):raise ValueError('حجم الطلب مفقود')
        n=int(length)
        if not 0<n<=limit:raise ValueError('حجم الطلب خارج الحدود المسموحة')
        data=self.rfile.read(n)
        if len(data)!=n:raise ValueError('بيانات الطلب ناقصة')
        if raw:return data
        def unique_object(pairs):
            obj={}
            for key,value in pairs:
                if key in obj:raise ValueError('مفتاح JSON مكرر')
                obj[key]=value
            return obj
        def reject_constant(value):raise ValueError('قيمة JSON رقمية غير صالحة')
        try:body=json.loads(data.decode('utf-8'),object_pairs_hook=unique_object,parse_constant=reject_constant)
        except RecursionError as error:raise ValueError('تداخل JSON زائد') from error
        if not isinstance(body,dict):raise ValueError('يجب إرسال كائن JSON')
        return body
    def _dispatch(self):
        split=self._security();path=split.path;method=self.command;s=self.server.service
        if method=='GET':
            if self.headers.get('Content-Length') not in (None,'0'):raise ValueError('طلب القراءة لا يقبل جسمًا')
            if path=='/api/health':return self.send_json({'app':'HERZ Educational Agent','version':VERSION})
            if path=='/api/state':return self.send_json(s.state())
            if path=='/api/central':return self.send_json(central_adapter.status())
            if path=='/api/backup':
                if not s._backup_path or not s._backup_path.is_file():raise ValueError('أنشئ نسخة احتياطية أولًا')
                return self.send_file(s._backup_path,'application/zip',s._backup_path.name)
            match=re.fullmatch(r'/api/jobs/([0-9a-f]{32})/(preview|download|report)',path)
            if match:
                jid,action=match.groups()
                if action=='preview':return self.send_file(s.output(jid,'index.html'),'text/html; charset=utf-8')
                if action=='download':return self.send_file(s.package(jid),'application/zip','HERZ_Standalone_Lessons.zip')
                return self.send_file(s.output(jid,'coverage.json'),'application/json; charset=utf-8')
            known={'/':'index.html','/index.html':'index.html','/app.js':'app.js','/app.css':'app.css','/favicon.ico':None}
            if path not in known:raise KeyError('الصفحة غير موجودة')
            if known[path] is None:self._headers(204,'image/x-icon',0);return
            mime={'index.html':'text/html; charset=utf-8','app.js':'text/javascript; charset=utf-8','app.css':'text/css; charset=utf-8'}[known[path]]
            return self.send_file(self.server.web/known[path],mime)
        if method=='PUT' and re.fullmatch(r'/api/uploads/[0-9a-f]{32}',path):
            q=parse_qs(split.query,strict_parsing=True)
            if set(q)!={'offset'} or len(q['offset'])!=1 or not re.fullmatch(r'\d+',q['offset'][0]):raise ValueError('إزاحة الرفع غير صالحة')
            body=self._body(CHUNK,True)
            return self.send_json(s.upload_chunk(path.rsplit('/',1)[1],int(q['offset'][0]),body))
        body=self._body()
        if method=='POST':
            if path=='/api/uploads':return self.send_json(s.begin_upload(body),201)
            if path=='/api/jobs/demo':return self.send_json(s.demo(),201)
            match=re.fullmatch(r'/api/uploads/([0-9a-f]{32})/complete',path)
            if match:return self.send_json(s.complete_upload(match[1]),201)
            match=re.fullmatch(r'/api/jobs/([0-9a-f]{32})/(pause|resume|cancel|retry|validate)',path)
            if match:return self.send_json(s.validate(match[1]) if match[2]=='validate' else s.action(match[1],match[2]))
            if path=='/api/rules':
                text=body.get('text');cat=body.get('category','feedback');tags=body.get('tags',[])
                if not isinstance(text,str) or not 1<=len(text.strip())<=4000:raise ValueError('نص القاعدة مطلوب وحده الأقصى 4000 حرف')
                if cat not in ('permanent','feedback','reference'):raise ValueError('تصنيف قاعدة غير صالح')
                if not isinstance(tags,list) or len(tags)>20 or any(not isinstance(t,str) or len(t)>50 for t in tags):raise ValueError('وسوم غير صالحة')
                return self.send_json({'rule':s.db.add_rule(text.strip(),cat,tags)},201)
            if path=='/api/chat':return self.send_json(s.chat(body))
            if path=='/api/settings':
                if set(body)!={'theme'} or body['theme'] not in ('violet','ocean','emerald'):raise ValueError('المتاح حاليًا تغيير مظهر الواجهة فقط')
                return self.send_json({'settings':s.db.set_settings(body)})
            if path=='/api/diagnostics':return self.send_json(s.diagnostics())
            if path=='/api/backup':return self.send_json(s.backup())
            if path=='/api/shutdown':
                self.send_json({'ok':True})
                threading.Thread(target=self.server.shutdown,daemon=True).start();return
        if method=='DELETE' and re.fullmatch(r'/api/uploads/[0-9a-f]{32}',path):return self.send_json(s.abort_upload(path.rsplit('/',1)[1]))
        if method=='PUT' and re.fullmatch(r'/api/rules/[0-9a-f]{32}',path):
            if type(body.get('enabled')) is not bool:raise ValueError('قيمة التفعيل غير صالحة')
            return self.send_json({'rule':s.db.toggle_rule(path.rsplit('/',1)[1],body['enabled'])})
        raise KeyError('المسار غير موجود')
    def _handle(self):
        try:self._dispatch()
        except (BrokenPipeError,ConnectionResetError,socket.timeout):self.close_connection=True
        except PermissionError as e:self.close_connection=True;self.send_json({'error':str(e)},403)
        except KeyError as e:self.close_connection=True;self.send_json({'error':str(e).strip("'")},404)
        except (ValueError,UnicodeError) as e:self.close_connection=True;self.send_json({'error':str(e)},400)
        except Exception as e:
            self.close_connection=True
            self.server.service.db.event('error',f'{type(e).__name__}: {e}')
            self.send_json({'error':'حدث خطأ داخلي محفوظ في السجل؛ افتح التشخيص'},500)
    do_GET=do_POST=do_PUT=do_DELETE=_handle
    def do_OPTIONS(self):self.close_connection=True;self.send_json({'error':'الطلبات عبر مواقع أخرى غير مسموحة'},403)
