"""Offline interactive lesson compiler. This is an internal authoring format.

It does not claim official HERZ importer compatibility or complete semantic
conversion of an arbitrary textbook. Original page images are never embedded.
"""
from __future__ import annotations

import base64
import hashlib
import html
import io
import json
import math
import re
import struct
import wave
from decimal import Decimal, InvalidOperation, localcontext
from fractions import Fraction
from pathlib import Path

SCHEMA = "herz-local-lesson/1"
ROOT = Path(__file__).resolve().parents[1]
DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹٫−×÷", "01234567890123456789.-*/")
ARITHMETIC = re.compile(r"^\s*([+-]?\d+(?:\.\d+)?)\s*([+*/-])\s*([+-]?\d+(?:\.\d+)?)\s*$")


def _number(value):
    text = str(value).translate(DIGITS).strip()
    if len(text) > 80 or not re.fullmatch(r"[+-]?\d+(?:\.\d+)?", text):
        raise ValueError("Invalid numeric answer")
    number = Decimal(text)
    if not number.is_finite() or abs(number) > Decimal("1e20"):
        raise ValueError("Answer outside supported numeric bounds")
    return number


def _calculated(expression):
    match = ARITHMETIC.fullmatch(str(expression).translate(DIGITS))
    if not match:
        raise ValueError("Unsupported arithmetic expression")
    a, operation, b = match.groups()
    a, b = Fraction(_number(a)), Fraction(_number(b))
    with localcontext() as context:
        context.prec = 70
        if operation == "+":
            answer = a + b
        if operation == "-":
            answer = a - b
        if operation == "*":
            answer = a * b
        if operation == "/":
            if not b:
                raise ValueError("Division by zero")
            answer = a / b
        denominator = answer.denominator
        for factor in (2, 5):
            while denominator % factor == 0:
                denominator //= factor
        if denominator != 1:
            raise ValueError("Non-terminating arithmetic answer")
        context.prec = max(70, len(str(abs(answer.numerator))) + len(str(answer.denominator)) + 10)
        return Decimal(answer.numerator) / Decimal(answer.denominator)


def _question(item, index):
    """Normalize converter arithmetic records and authored demo records."""
    result = dict(item)
    result["id"] = str(item.get("id", f"q-{index}"))
    result["type"] = item.get("type", "input")
    result["prompt"] = str(item.get("prompt", ""))
    result["role"] = item.get("role", "practice")
    if result["type"] in ("input", "mcq"):
        result["answer"] = str(item.get("answer", ""))
        if not result["answer"].strip():
            raise ValueError("Question answer is missing")
        if item.get("expression"):
            if _calculated(item["expression"]) != _number(result["answer"]):
                raise ValueError(f"Incorrect arithmetic answer: {result['id']}")
            result["verified"] = True
    if not result["prompt"] or len(result["prompt"]) > 10000:
        raise ValueError("Question prompt is missing or too long")
    if result["type"] not in ("input", "mcq", "matching", "ordering"):
        raise ValueError("Unsupported question type")
    if result["type"] == "mcq":
        options = result.get("options", [])
        if len(options) != 4 or len(set(map(str, options))) != 4 or result["answer"] not in list(map(str, options)):
            raise ValueError("MCQ needs four distinct choices including its answer")
        result["options"] = list(map(str, options))
        comparable = []
        for option in result["options"]:
            try:
                comparable.append(("number", _number(option)))
            except (ValueError, InvalidOperation):
                comparable.append(("text", re.sub(r"\s", "", option.translate(DIGITS))))
        if len(set(comparable)) != 4:
            raise ValueError("MCQ choices must be semantically distinct")
    if result["type"] == "matching":
        pairs = result.get("pairs", [])
        if not 2 <= len(pairs) <= 12 or len({p.get("id") for p in pairs}) != len(pairs):
            raise ValueError("Matching pairs are invalid")
        if any(not all(isinstance(p.get(k), str) and p[k] for k in ("id", "label", "target")) for p in pairs):
            raise ValueError("Matching labels are invalid")
    if result["type"] == "ordering":
        items = result.get("items", [])
        if not 2 <= len(items) <= 12 or len(set(items)) != len(items):
            raise ValueError("Ordering items are invalid")
    return result


def _tone():
    stream = io.BytesIO()
    rate = 16000
    with wave.open(stream, "wb") as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(rate)
        samples = []
        for frequency in (659.25, 783.99, 1046.50):
            for index in range(int(rate * 0.10)):
                envelope = min(index / (rate * 0.01), 1) * max(0, 1 - index / (rate * 0.10))
                samples.append(struct.pack("<h", int(6000 * envelope * math.sin(2 * math.pi * frequency * index / rate))))
        output.writeframes(b"".join(samples))
    return "data:audio/wav;base64," + base64.b64encode(stream.getvalue()).decode("ascii")


def demo_document():
    """Original authored content, independent of the user's textbooks."""
    q = [
        {"id": "f1", "type": "input", "role": "formative", "example_id": "e1", "prompt": "أوجد ناتج: 246 + 132", "expression": "246+132", "answer": "378", "hint": "ابدأ بالآحاد، ثم العشرات، ثم المئات.", "explanation": "6 + 2 = 8، و4 + 3 = 7 عشرات، و2 + 1 = 3 مئات؛ الناتج 378."},
        {"id": "f2", "type": "input", "role": "formative", "example_id": "e2", "prompt": "أوجد ناتج: 452 − 137", "expression": "452-137", "answer": "315", "hint": "لا تكفي آحاد العدد 452 لطرح 7؛ أعد تجميع عشرة واحدة.", "explanation": "452 = 400 + 40 + 12. الآحاد 12 − 7 = 5، العشرات 4 − 3 = 1، المئات 4 − 1 = 3؛ الناتج 315."},
        {"id": "p1", "type": "mcq", "role": "practice", "prompt": "أي عدد يساوي 3 مئات و5 عشرات و6 آحاد؟", "options": ["365", "356", "536", "653"], "answer": "356", "hint": "اكتب المئات أولًا، ثم العشرات، ثم الآحاد.", "explanation": "300 + 50 + 6 = 356."},
        {"id": "p2", "type": "matching", "role": "practice", "prompt": "صل كل جزء بالقيمة المناسبة في العدد 356.", "pairs": [{"id": "h", "label": "3 مئات", "target": "300"}, {"id": "t", "label": "5 عشرات", "target": "50"}, {"id": "o", "label": "6 آحاد", "target": "6"}], "hint": "كل مئة تساوي 100، وكل عشرة تساوي 10.", "explanation": "3 مئات = 300، و5 عشرات = 50، و6 آحاد = 6."},
        {"id": "p3", "type": "ordering", "role": "practice", "prompt": "رتب خطوات إجراء الجمع العمودي من البداية إلى النهاية.", "items": ["أجمع الآحاد", "أجمع العشرات", "أجمع المئات"], "hint": "ابدأ بالمنزلة الأصغر.", "explanation": "نبدأ بالآحاد، ثم العشرات، ثم المئات."},
        {"id": "x1", "type": "input", "role": "exam", "prompt": "أوجد ناتج: 325 + 143", "expression": "325+143", "answer": "468", "explanation": "5 + 3 = 8؛ 2 + 4 = 6؛ 3 + 1 = 4. الناتج 468."},
        {"id": "x2", "type": "input", "role": "exam", "prompt": "أوجد ناتج: 800 − 356", "expression": "800-356", "answer": "444", "explanation": "800 = 700 + 90 + 10. نطرح الآحاد: 10 − 6 = 4، والعشرات: 9 − 5 = 4، والمئات: 7 − 3 = 4. الناتج 444."},
        {"id": "x3", "type": "mcq", "role": "exam", "prompt": "ما قيمة الرقم 5 في العدد 452؟", "options": ["5", "50", "500", "45"], "answer": "50", "explanation": "الرقم 5 في منزلة العشرات؛ قيمته 50."},
    ]
    return {
        "format": "original_demo", "coverage_complete": True, "pages": [], "warnings": [], "questions": q,
        "lesson_title": "رحلة الأعداد: نجمع ونطرح ونفهم",
        "examples": [
            {"id": "e1", "title": "مثال 1 · الجمع", "description": "نجمع كل منزلة مع المنزلة المشابهة لها.", "math": "234 + 125", "steps": [{"text": "نبدأ بجمع الآحاد.", "math": "4 + 5 = 9"}, {"text": "ثم نجمع العشرات.", "math": "3 + 2 = 5"}, {"text": "ثم نجمع المئات.", "math": "2 + 1 = 3"}, {"text": "نكتب الناتج بالترتيب: مئات، عشرات، آحاد.", "math": "234 + 125 = 359"}]},
            {"id": "e2", "title": "مثال 2 · إعادة التجميع", "description": "عند الطرح، يمكن تبديل مئة بعشر عشرات، ثم تبديل عشرة بعشر آحاد، دون تغيير قيمة العدد.", "math": "600 − 247", "steps": [{"text": "نفك مئة واحدة إلى عشر عشرات، ثم نفك عشرة واحدة إلى عشر آحاد.", "math": "600 = 500 + 90 + 10"}, {"text": "نطرح الآحاد.", "math": "10 − 7 = 3"}, {"text": "نطرح العشرات.", "math": "9 − 4 = 5"}, {"text": "نطرح المئات ثم نكتب الناتج.", "math": "5 − 2 = 3; 600 − 247 = 353"}]},
        ],
    }


def _lessons(document, questions):
    if document.get("examples"):
        return [{"id": "lesson-1", "title": document.get("lesson_title", "درس تفاعلي"), "explanation": "تعلّم خطوة بخطوة، ثم جرّب بنفسك. في التدريب تظهر المساعدة، وفي الاختبار تظهر النتيجة بعد التسليم.", "examples": document["examples"], "questions": questions, "lab": document.get("format") == "original_demo"}]
    by_page = {}
    for question in questions:
        by_page.setdefault(question.get("source_page", 1), []).append(question)
    lessons = []
    for page, entries in by_page.items():
        example = {"id": f"e-{page}", "title": "طريقة الحل", "description": "اقرأ العملية وحدد أعدادها وإشارتها، ثم احسب وتحقق من الناتج.", "steps": [{"text": "حدد العملية: جمع أو طرح أو ضرب أو قسمة."}, {"text": "رتب المنازل عند الجمع والطرح، ونفّذ العملية بدقة."}, {"text": "راجع الناتج باستخدام العملية العكسية عندما تكون مناسبة."}]}
        copied = []
        for item in entries:
            entry = dict(item, role="formative", example_id=example["id"])
            copied.append(entry)
            copied.append(dict(item, id=item["id"] + "-exam", role="exam", example_id=None))
        lessons.append({"id": f"lesson-p{page}", "title": f"تدريبات الصفحة / الجزء {page}", "explanation": "هذه تدريبات حسابية التُقطت آليًا من المصدر. راجع النص المستخرج وسجل التغطية؛ لم يُثبت تحويل بقية أنواع الأسئلة.", "examples": [example], "questions": copied, "lab": False})
    if not lessons:
        lessons.append({"id": "draft", "title": "مسودة النص المستخرج", "explanation": "لم يتعرف المحول على تمارين حسابية واضحة يمكن تصحيحها بثقة. النص متاح للمراجعة في تبويب المصدر؛ هذه ليست حزمة تعليمية مكتملة.", "examples": [], "questions": [], "lab": False})
    return lessons


def build_package(document: dict, out_dir: Path, title: str, rules: list | None = None) -> dict:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    warnings = [str(item) for item in document.get("warnings", [])]
    questions = []
    for index, item in enumerate(document.get("questions", [])):
        try:
            questions.append(_question(item, index))
        except (ValueError, TypeError, InvalidOperation, KeyError) as error:
            raise ValueError(f"Invalid authored question {item.get('id', index)}: {error}") from error
    original = document.get("format") == "original_demo"
    if not original:
        warnings.append("تحويل النص والتدريبات الحسابية المدعومة فقط؛ لم تُثبت تغطية كل أمثلة وأسئلة الكتاب أو إعادة بناء رسومه.")
    warnings.append("التوافق مع مستورد HERZ Academy غير متحقق؛ هذه معاينة HTML مستقلة.")
    warnings.append("الأصوات المضمّنة نغمات تشجيع فقط؛ القراءة الصوتية العربية والإنجليزية غير مضمّنة.")
    lessons = _lessons(document, questions)
    pages = [{"number": page.get("number", index + 1), "text": str(page.get("text", "")), "issues": page.get("issues", [])} for index, page in enumerate(document.get("pages", []))]
    bundle = {"schema": SCHEMA, "version": "1.0.0", "title": str(title)[:300], "language": "ar", "platform_compatibility": "not_verified", "source_format": document.get("format", "unknown"), "coverage_complete": original and bool(document.get("coverage_complete")), "warnings": warnings, "lessons": lessons, "pages": pages, "context_rule_ids": [str(rule.get("id", "")) for rule in (rules or []) if isinstance(rule, dict) and rule.get("enabled", True)], "audio_kind": "encouragement_tone"}
    digest = hashlib.sha256(json.dumps(bundle, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
    bundle["bundle_id"] = digest[:24]
    coverage = {"schema": "herz-local-coverage/1", "source_format": bundle["source_format"], "source_pages_or_parts": len(pages), "recognized_source_questions": len(questions), "authored_lessons": len(lessons), "source_question_ids": [q["id"] for q in questions], "pages": [{"number": p["number"], "text_characters": len(p["text"]), "issues": p["issues"]} for p in pages], "content_coverage_complete": bundle["coverage_complete"], "platform_import": "not_verified", "original_page_images_embedded": False, "warnings": warnings, "checks": [{"name": "source_coverage", "status": "pass" if original else "not_verified", "detail": "Original authored demo" if original else "Only recognized arithmetic lines become exercises; source extraction is not semantic coverage."}, {"name": "platform_import", "status": "not_run", "detail": "Official target importer unavailable to this compiler."}]}
    (out_dir / "bundle.json").write_text(json.dumps(bundle, ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "coverage.json").write_text(json.dumps(coverage, ensure_ascii=False, indent=2), encoding="utf-8")
    css = (ROOT / "web" / "lesson.css").read_text(encoding="utf-8")
    js = (ROOT / "web" / "lesson.js").read_text(encoding="utf-8")
    payload = json.dumps(dict(bundle, tone=_tone()), ensure_ascii=False).replace("<", "\\u003c").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    script = js
    script_hash = base64.b64encode(hashlib.sha256(script.encode()).digest()).decode()
    style_hash = base64.b64encode(hashlib.sha256(css.encode()).digest()).decode()
    csp = f"default-src 'none'; script-src 'sha256-{script_hash}'; style-src 'sha256-{style_hash}'; img-src data:; media-src data:; connect-src 'none'; base-uri 'none'; form-action 'none'"
    contents = f'''<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="{html.escape(csp, quote=True)}"><title>{html.escape(bundle['title'])}</title><style>{css}</style></head><body><div id="lesson-app"></div><noscript>فعّل JavaScript لتشغيل التمارين التفاعلية. لا يحتاج هذا الملف إلى الإنترنت.</noscript><script id="lesson-data" type="application/json">{payload}</script><script>{script}</script></body></html>'''
    (out_dir / "index.html").write_text(contents, encoding="utf-8")
    (out_dir / "README_AR.txt").write_text("افتح index.html من هذا المجلد. جميع الأصول مضمّنة ولا يوجد اتصال خارجي.\nهذه صيغة تأليف داخلية وليست حزمة ثبت قبولها في مستورد HERZ Academy.\nدرجات المتصفح تدريبية محلية وليست درجات امتحان رسمية محمية من التلاعب.\nالحفظ المحلي قد يكون غير متاح داخل المعاينة المعزولة؛ تُعرض رسالة بذلك.\nراجع coverage.json لمعرفة الأجزاء غير المحولة والتحذيرات.\n", encoding="utf-8")
    result = validate_package(out_dir)
    if not result["valid"]:
        raise ValueError("Package failed structural validation")
    return {"counts": {"pages": len(pages), "questions": sum(len(item["questions"]) for item in lessons), "lessons": len(lessons), "warnings": len(warnings)}, "warnings": warnings, "output_ready": True, "coverage_complete": bundle["coverage_complete"]}


def validate_package(out_dir: Path):
    out_dir = Path(out_dir)
    checks = []
    try:
        bundle = json.loads((out_dir / "bundle.json").read_text(encoding="utf-8"))
        page = (out_dir / "index.html").read_text(encoding="utf-8")
        coverage = json.loads((out_dir / "coverage.json").read_text(encoding="utf-8"))
        if bundle.get("schema") != SCHEMA:
            raise ValueError("Unrecognized internal schema")
        ids = set()
        lesson_ids = set()
        for lesson in bundle["lessons"]:
            if lesson["id"] in lesson_ids:
                raise ValueError("Duplicate lesson identifier")
            lesson_ids.add(lesson["id"])
            example_ids = {example["id"] for example in lesson["examples"]}
            if len(example_ids) != len(lesson["examples"]):
                raise ValueError("Duplicate example identifier")
            for question in lesson["questions"]:
                if question["id"] in ids:
                    raise ValueError("Duplicate question identifier")
                ids.add(question["id"])
                _question(question, 0)
                if question.get("role") == "formative" and question.get("example_id") not in example_ids:
                    raise ValueError("Formative question has no matching example")
        checks.append({"name": "questions_and_links", "status": "pass", "detail": f"{len(ids)} unique exercise records; types, arithmetic and example links validated."})
        if re.search(r"(?:src|href)\s*=\s*[\"']https?://", page, re.I):
            raise ValueError("External asset found")
        scripts = re.findall(r"<script>(.*?)</script>", page, re.S)
        styles = re.findall(r"<style>(.*?)</style>", page, re.S)
        if len(scripts) != 1 or len(styles) != 1:
            raise ValueError("Unexpected active HTML content")
        for block in scripts + styles:
            expected = base64.b64encode(hashlib.sha256(block.encode()).digest()).decode()
            if "sha256-" + expected not in page:
                raise ValueError("Content security hash mismatch")
        checks.append({"name": "offline_assets_and_csp", "status": "pass", "detail": "Self-contained styles, script and WAV tone; no external asset references; CSP hashes verified."})
        if coverage.get("original_page_images_embedded") is not False:
            raise ValueError("Original image policy mismatch")
        checks.append({"name": "source_image_policy", "status": "pass", "detail": "No original page images embedded."})
        checks.append({"name": "platform_import", "status": "not_run", "detail": "Official HERZ importer compatibility has not been tested."})
        return {"valid": True, "scope": "local_structure_only", "checks": checks}
    except (OSError, ValueError, TypeError, KeyError, InvalidOperation) as error:
        checks.append({"name": "structure", "status": "fail", "detail": str(error)})
        return {"valid": False, "scope": "local_structure_only", "checks": checks}
