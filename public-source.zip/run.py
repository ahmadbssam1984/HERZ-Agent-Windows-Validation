"""Portable local entry point. No installation, admin elevation, or remote calls."""
import argparse
import json
import multiprocessing
import os
import secrets
import sys
import urllib.request
import webbrowser
from pathlib import Path

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'vendor'))
from agent.service import Service,data_root,private_path
from agent.http_server import Server

def previous_server(path):
    if not path.is_file():return None
    try:
        data=json.loads(path.read_text('utf-8'))
        from urllib.parse import urlsplit
        url=urlsplit(data['url'])
        if url.scheme!='http' or url.hostname!='127.0.0.1' or not url.port or url.path or url.query or url.fragment or url.username:return None
        req=urllib.request.Request(data['url']+'/api/state',headers={'Authorization':'Bearer '+data['token']})
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self,*args,**kwargs):return None
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
        with opener.open(req,timeout=2) as r:
            if json.load(r).get('app')=='HERZ Educational Agent':return data
    except (OSError,ValueError,KeyError,TypeError):pass
    return None

def main():
    p=argparse.ArgumentParser(description='HERZ Educational Agent local authoring workspace')
    p.add_argument('--open',action='store_true');p.add_argument('--port',type=int,default=0)
    args=p.parse_args();root=data_root();root.mkdir(parents=True,exist_ok=True)
    info=private_path(root,'server.json');old=previous_server(info)
    if old:
        if args.open:webbrowser.open(old['url']+'/#token='+old['token'])
        print('HERZ is already running.');return 0
    # Lock held for the lifetime of the server. Stale OS locks release on exit.
    lock=private_path(root,'instance.lock').open('a+b')
    try:
        if os.name=='nt':
            import msvcrt
            lock.seek(0);lock.write(b'0');lock.flush();lock.seek(0)
            msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except OSError:
        print('HERZ is starting in another window. Please wait.');return 1
    service=Service(root)
    if not service.preflight():
        service.diagnostics()
        print('Startup safety checks failed. Open DIAGNOSE.cmd. No document worker was started.')
        return 2
    server=Server(service,secrets.token_urlsafe(32),args.port)
    data={'pid':os.getpid(),'url':server.origin,'token':server.token}
    fd=os.open(info,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
    if os.name!='nt':os.fchmod(fd,0o600)
    with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump(data,f)
    service.start();service.db.event('info','بدأ البرنامج محليًا بعد نجاح فحوص طبقة حماية العامل')
    if args.open:webbrowser.open(server.origin+'/#token='+server.token)
    print('HERZ running locally at '+server.origin,flush=True)
    print('Use START.cmd to open the authorized browser session. Close with STOP.cmd.',flush=True)
    try:server.serve_forever(poll_interval=.2)
    except KeyboardInterrupt:pass
    finally:
        service.close();server.server_close();info.unlink(missing_ok=True);lock.close()
    return 0

if __name__=='__main__':
    multiprocessing.freeze_support()
    raise SystemExit(main())
