# Run only in an ephemeral hosted Windows CI VM, never on the home computer.
# This script does not provision cloud resources, start billing, or log passwords.
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$PackageRoot,
    [Parameter(Mandatory = $true)][string]$OutputDirectory,
    [ValidateRange(3, 30)][int]$TimeoutMinutes = 15
)

$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT') { throw 'Actual Windows is required.' }
if ($env:GITHUB_ACTIONS -ne 'true' -and $env:APPVEYOR -ne 'True') {
    throw 'This account-creation harness is restricted to ephemeral GitHub/AppVeyor CI runners.'
}
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if (!$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'The CI setup process needs administrator rights to create its temporary standard test user.'
}
$PackageRoot = (Resolve-Path -LiteralPath $PackageRoot).Path
$OutputDirectory = [IO.Path]::GetFullPath($OutputDirectory)
if ($PackageRoot.Contains('"') -or $OutputDirectory.Contains('"')) { throw 'Invalid path.' }
if (!(Test-Path -LiteralPath (Join-Path $PackageRoot 'runtime\python.exe'))) { throw 'The delivered portable runtime is missing.' }
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null

$suffix = [Guid]::NewGuid().ToString('N').Substring(0, 10)
$userName = 'herzqa' + $suffix
$caseRoot = Join-Path $env:PUBLIC ('HERZ-Acceptance-' + $suffix)
# Construct the Arabic word from codepoints so Windows PowerShell 5.1 also
# reads this ASCII script without an encoding-dependent source filename.
$arabic = -join @([char]0x062D, [char]0x0632, [char]0x0645, [char]0x0629)
$casePackage = Join-Path $caseRoot ($arabic + ' package & spaces')
$caseWork = Join-Path $caseRoot 'work'
$reportPath = Join-Path $caseRoot 'windows-acceptance.json'
$stdoutPath = Join-Path $caseRoot 'acceptance.stdout.log'
$stderrPath = Join-Path $caseRoot 'acceptance.stderr.log'
$userCreated = $false
$process = $null
$resultCode = 1

# Copy only release components into the standard user's disposable directory.
# Never follow junctions/symlinks or include checkout credentials, source data,
# generated CI output, or other files merely because they exist in the checkout.
function Copy-ReleaseItem {
    param([string]$Source, [string]$Destination)
    $entry = Get-Item -LiteralPath $Source -Force
    if ($entry.Name -in @('.git', 'data', 'artifacts', 'ci-results', '__pycache__')) { return }
    $sourceFull = [IO.Path]::GetFullPath($entry.FullName).TrimEnd('\')
    $outputFull = $OutputDirectory.TrimEnd('\')
    if ($sourceFull.Equals($outputFull, [StringComparison]::OrdinalIgnoreCase) -or
        $sourceFull.StartsWith($outputFull + '\', [StringComparison]::OrdinalIgnoreCase)) { return }
    if (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw ('Reparse points are not permitted in the test package: ' + $entry.Name)
    }
    if ($entry.PSIsContainer) {
        [IO.Directory]::CreateDirectory($Destination) | Out-Null
        foreach ($child in (Get-ChildItem -LiteralPath $Source -Force)) {
            Copy-ReleaseItem -Source $child.FullName -Destination (Join-Path $Destination $child.Name)
        }
    }
    else {
        [IO.File]::Copy($entry.FullName, $Destination, $false)
    }
}

try {
    $randomBytes = New-Object byte[] 40
    $generator = [Security.Cryptography.RandomNumberGenerator]::Create()
    $generator.GetBytes($randomBytes)
    $generator.Dispose()
    $plainPassword = 'Aa1!' + [Convert]::ToBase64String($randomBytes)
    $securePassword = ConvertTo-SecureString -String $plainPassword -AsPlainText -Force
    $plainPassword = $null
    [Array]::Clear($randomBytes, 0, $randomBytes.Length)
    New-LocalUser -Name $userName -Password $securePassword -AccountNeverExpires -PasswordNeverExpires -UserMayNotChangePassword -Description 'Temporary HERZ non-admin acceptance account' | Out-Null
    $userCreated = $true
    $localUser = Get-LocalUser -Name $userName
    $usersGroup = Get-LocalGroup -SID 'S-1-5-32-545'
    if (!(Get-LocalGroupMember -Group $usersGroup | Where-Object { $_.SID -eq $localUser.SID })) {
        Add-LocalGroupMember -Group $usersGroup -Member $localUser
    }
    $administrators = Get-LocalGroup -SID 'S-1-5-32-544'
    if (Get-LocalGroupMember -Group $administrators | Where-Object { $_.SID -eq $localUser.SID }) {
        throw 'Test account unexpectedly belongs to Administrators.'
    }
    New-Item -ItemType Directory -Path $caseRoot | Out-Null
    # Isolated disposable copies only. Existing package and user data stay intact.
    $acl = New-Object Security.AccessControl.DirectorySecurity
    $acl.SetAccessRuleProtection($true, $false)
    foreach ($sidText in @($localUser.SID.Value, 'S-1-5-32-544', 'S-1-5-18')) {
        $sid = [Security.Principal.SecurityIdentifier]::new($sidText)
        $rule = [Security.AccessControl.FileSystemAccessRule]::new($sid, 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow')
        $acl.AddAccessRule($rule)
    }
    Set-Acl -LiteralPath $caseRoot -AclObject $acl
    if (((Get-Item -LiteralPath $PackageRoot -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw 'The package root must not be a reparse point.'
    }
    [IO.Directory]::CreateDirectory($casePackage) | Out-Null
    $releaseItems = @(
        'agent', 'web', 'tests', 'docs', 'examples', 'vendor', 'runtime', 'repair',
        'run.py', 'START.cmd', 'STOP.cmd', 'DIAGNOSE.cmd', 'REPAIR.cmd',
        'BACKUP.cmd', 'RUN_TESTS.cmd', 'RESTORE_RUNTIME.cmd',
        'RESTORE_BACKUP.cmd', 'START_RESTORED.cmd', 'README_AR.md', 'FIRST_RUN_AR.html'
    )
    foreach ($name in $releaseItems) {
        Copy-ReleaseItem -Source (Join-Path $PackageRoot $name) -Destination (Join-Path $casePackage $name)
    }
    # The public source bundle may add these documented root files before its
    # repair manifest is generated. Preserve them when present, never glob.
    foreach ($name in @('README_PUBLIC.md', 'PUBLIC_SOURCE_MANIFEST.json', 'README.md')) {
        $source = Join-Path $PackageRoot $name
        if (Test-Path -LiteralPath $source) {
            Copy-ReleaseItem -Source $source -Destination (Join-Path $casePackage $name)
        }
    }
    New-Item -ItemType Directory -Path $caseWork | Out-Null
    $credential = [PSCredential]::new(('.\' + $userName), $securePassword)
    $python = Join-Path $casePackage 'runtime\python.exe'
    $script = Join-Path $casePackage 'tests\windows_acceptance.py'
    $arguments = '-I "' + $script + '" --report "' + $reportPath + '" --work-dir "' + $caseWork + '" --expect-non-admin --full-suite'
    # Do not inherit process-scoped CI credentials or runner environment. The
    # acceptance test sets its own writable TEMP and HERZ_DATA_DIR explicitly;
    # profile loading is not treated as proof of a fresh user environment.
    $process = Start-Process -FilePath $python -ArgumentList $arguments -Credential $credential -LoadUserProfile -UseNewEnvironment -WorkingDirectory $casePackage -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath -PassThru
    if (!$process.WaitForExit($TimeoutMinutes * 60000)) {
        & (Join-Path $env:SystemRoot 'System32\taskkill.exe') /PID $process.Id /T /F | Out-Null
        throw 'Actual Windows standard-user acceptance exceeded the timeout.'
    }
    $process.WaitForExit()
    $process.Refresh()
    $resultCode = $process.ExitCode
    if (!(Test-Path -LiteralPath $reportPath)) { throw 'Acceptance exited without a result report.' }
    $report = Get-Content -LiteralPath $reportPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($report.machine.administrator -ne $false) { throw 'Report did not prove a non-administrator process.' }
    if ($report.machine.package_path_has_arabic -ne $true -or $report.machine.package_path_has_space_and_ampersand -ne $true) {
        throw 'Required Windows path compatibility fixture was not exercised.'
    }
    Copy-Item -LiteralPath $reportPath -Destination (Join-Path $OutputDirectory 'windows-standard-user.json')
    if ($report.status -ne 'pass' -or $resultCode -ne 0) { throw 'Windows standard-user acceptance failed; inspect sanitized results.' }
    Write-Output 'PASS: actual Windows tests ran as a standard user with the bundled interpreter.'
}
catch {
    $resultCode = 1
    Write-Output ('FAIL: ' + $_.Exception.Message)
    if (!(Test-Path -LiteralPath (Join-Path $OutputDirectory 'windows-standard-user.json'))) {
        $failure = @{ status = 'fail'; suite = 'windows-standard-user-harness'; reason = $_.Exception.Message; actual_windows = $true }
        $failure | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $OutputDirectory 'windows-standard-user.json') -Encoding UTF8
    }
}
finally {
    # Test logs contain generated fixtures and public machine characteristics,
    # never server.json, auth tokens, credentials or private document contents.
    foreach ($file in @($stdoutPath, $stderrPath, (Join-Path $caseWork 'unit-tests.log'))) {
        if (Test-Path -LiteralPath $file) { Copy-Item -LiteralPath $file -Destination $OutputDirectory -Force }
    }
    if ($process -and !$process.HasExited) {
        & (Join-Path $env:SystemRoot 'System32\taskkill.exe') /PID $process.Id /T /F 2>$null | Out-Null
    }
    # Clean only processes whose executable lives in this unique test copy.
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
        $_.ExecutablePath -and $_.ExecutablePath.StartsWith($casePackage + '\', [StringComparison]::OrdinalIgnoreCase)
    } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    if ($userCreated) { Remove-LocalUser -Name $userName -ErrorAction SilentlyContinue }
    # The CI VM owns this generated test directory; preserve reports first.
    if (Test-Path -LiteralPath $caseRoot) { Remove-Item -LiteralPath $caseRoot -Recurse -Force -ErrorAction SilentlyContinue }
    $credential = $null
    $securePassword = $null
}
exit $resultCode
