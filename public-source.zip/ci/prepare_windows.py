"""Prepare pinned portable dependencies for public Windows acceptance only.

Only Python.org and files.pythonhosted.org are contacted. No pip, accounts,
paid APIs, registry edits, machine-wide install or private artifacts are used.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import runpy
import shutil
import stat
import tempfile
import urllib.parse
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
ALLOWED_HOSTS = {'www.python.org', 'files.pythonhosted.org'}
MAX_ARCHIVE_BYTES = 32 * 1024**2
MAX_UNPACKED_BYTES = 256 * 1024**2


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def checked_url(value):
    parsed = urllib.parse.urlsplit(value)
    if (parsed.scheme != 'https' or parsed.hostname not in ALLOWED_HOSTS or
            parsed.username is not None or parsed.password is not None or
            parsed.port not in (None,443) or parsed.fragment):
        raise ValueError('Dependency URL is outside the reviewed official hosts')
    return value


class OfficialRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        checked_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def verify(path, record):
    if Path(path).stat().st_size != record['size'] or digest(path) != record['sha256']:
        raise ValueError('Pinned dependency size or SHA256 mismatch: ' + record['name'])


def download(record, destination, cache=None):
    name = record['name']
    if not re.fullmatch(r'[A-Za-z0-9._-]+', name):raise ValueError('Unsafe dependency filename')
    if type(record['size']) is not int or not 0 < record['size'] <= MAX_ARCHIVE_BYTES:
        raise ValueError('Invalid dependency size')
    if not re.fullmatch(r'[a-f0-9]{64}', record['sha256']):raise ValueError('Invalid pinned SHA256')
    checked_url(record['url'])
    cached = Path(cache) / name if cache else None
    if cached and cached.is_file():
        verify(cached,record);shutil.copyfile(cached,destination);return
    request = urllib.request.Request(record['url'], headers={'User-Agent':'HERZ-public-Windows-acceptance/1'})
    opener = urllib.request.build_opener(OfficialRedirects())
    count = 0
    with opener.open(request,timeout=30) as response, Path(destination).open('xb') as stream:
        checked_url(response.geturl())
        while True:
            block = response.read(1024*1024)
            if not block:break
            count += len(block)
            if count > record['size']:raise ValueError('Dependency download exceeded its pinned size')
            stream.write(block)
    verify(destination,record)


def safe_members(archive):
    infos = archive.infolist()
    if not 0 < len(infos) <= 10000:raise ValueError('Archive member count out of bounds')
    total = 0
    seen = set()
    reserved = {'CON','PRN','AUX','NUL',*(f'{a}{n}' for a in ('COM','LPT') for n in range(10))}
    for info in infos:
        name = info.filename.rstrip('/') if info.is_dir() else info.filename
        path = PurePosixPath(name)
        parts = name.split('/')
        if (not name or path.is_absolute() or '\\' in name or ':' in name or
                any(part in ('','.','..') for part in parts) or
                any(part.endswith((' ','.')) or part.split('.')[0].upper() in reserved for part in parts) or
                any(ord(c)<32 or c in '<>"|?*' for c in name)):
            raise ValueError('Unsafe dependency archive member')
        if name.casefold() in seen:raise ValueError('Duplicate dependency archive member')
        seen.add(name.casefold())
        if stat.S_ISLNK(info.external_attr >> 16) or info.flag_bits & 1:
            raise ValueError('Links and encrypted entries are not permitted')
        total += info.file_size
        if info.file_size > 64*1024**2 or total > MAX_UNPACKED_BYTES:
            raise ValueError('Dependency archive expansion limit exceeded')
        yield info,path


def unpack(archive_path, destination):
    destination=Path(destination)
    destination.mkdir(parents=True,exist_ok=False)
    with zipfile.ZipFile(archive_path) as archive:
        members=list(safe_members(archive))
        for info,relative in members:
            target=destination.joinpath(*relative.parts)
            if info.is_dir():target.mkdir(parents=True,exist_ok=True);continue
            target.parent.mkdir(parents=True,exist_ok=True)
            with archive.open(info) as source,target.open('xb') as output:
                shutil.copyfileobj(source,output,1024*1024)



def pe_machine(path):
    with Path(path).open('rb') as stream:
        header=stream.read(64)
        if len(header)!=64 or header[:2]!=b'MZ':raise ValueError('Invalid Windows PE header')
        offset=int.from_bytes(header[60:64],'little')
        if offset>1024*1024:raise ValueError('Invalid Windows PE offset')
        stream.seek(offset);signature=stream.read(6)
        if signature[:4]!=b'PE\x00\x00':raise ValueError('Invalid Windows PE signature')
        return int.from_bytes(signature[4:6],'little')


def prepare(root=ROOT,cache=None):
    root=Path(root).resolve()
    lock=json.loads((root/'docs/DEPENDENCY_LOCK.json').read_text(encoding='utf-8'))
    dependencies=lock['dependencies']
    python=[item for item in dependencies if item['name'].startswith('python-') and item['name'].endswith('-embed-amd64.zip')]
    pdf=[item for item in dependencies if item['name'].startswith('pypdf-') and item['name'].endswith('.whl')]
    if len(python)!=1 or len(pdf)!=1:raise ValueError('Exactly one pinned Python runtime and pypdf wheel are required')
    if (root/'runtime').exists() or (root/'vendor').exists():
        raise FileExistsError('Prepare requires a fresh source checkout; existing runtime/vendor are not overwritten')
    with tempfile.TemporaryDirectory(prefix='herz-dependencies-',dir=root) as temporary:
        temp=Path(temporary)
        runtime_archive=temp/python[0]['name'];pdf_archive=temp/pdf[0]['name']
        download(python[0],runtime_archive,cache);download(pdf[0],pdf_archive,cache)
        unpack(runtime_archive,temp/'runtime');unpack(pdf_archive,temp/'vendor')
        stdlibs=list((temp/'runtime').glob('python[0-9]*.zip'))
        if len(stdlibs)!=1 or not (temp/'runtime/python.exe').is_file():
            raise ValueError('Portable runtime is missing the executable or standard library')
        for binary in ('python.exe',stdlibs[0].stem+'.dll','_sqlite3.pyd'):
            if pe_machine(temp/'runtime'/binary)!=0x8664:raise ValueError('Expected native AMD64 runtime components')
        if not (temp/'runtime/LICENSE.txt').is_file():raise ValueError('Python runtime license is missing')
        if not list((temp/'vendor').glob('pypdf-*.dist-info/licenses/LICENSE')):raise ValueError('pypdf license is missing')
        pth=stdlibs[0].stem+'._pth'
        (temp/'runtime'/pth).write_bytes((stdlibs[0].name+'\r\n.\r\n..\r\n../vendor\r\n').encode('ascii'))
        if not (temp/'vendor/pypdf/__init__.py').is_file():raise ValueError('pypdf wheel layout is incomplete')
        repair=root/'repair';repair.mkdir(exist_ok=True)
        shutil.copyfile(runtime_archive,repair/'runtime-original.zip')
        os.replace(temp/'runtime',root/'runtime');os.replace(temp/'vendor',root/'vendor')
    # Build the original authored example from reviewed source, never from an
    # existing user file. The release-copy harness requires this directory.
    lesson=runpy.run_path(str(root/'agent/lesson.py'))
    demo_directory=root/'examples/offline_math'
    lesson['build_package'](lesson['demo_document'](),demo_directory,'رحلة الأعداد')
    lesson['validate_package'](demo_directory)
    # This builds a new seed from the public source checkout and verified deps;
    # no private repair payload or pre-existing data is brought into CI.
    runpy.run_path(str(root/'repair/build_seed.py'),run_name='__main__')
    return {'prepared':True,'dependencies':[{'name':x['name'],'sha256':x['sha256'],'size':x['size']} for x in (python[0],pdf[0])],
            'runtime_configuration':'isolated ._pth; no site; no pip', 'runtime_executed':False}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--cache-dir',type=Path)
    args=parser.parse_args()
    print(json.dumps(prepare(cache=args.cache_dir),indent=2))

if __name__=='__main__':main()
